package org.gjt.mm.mysql;

import com.mysql.jdbc.Driver;

public class Driver extends Driver {}


/* Location:              C:\Users\neons\Desktop\JacobAloSchedulingApp\build\classes\!\lib\mysql-connector-java-5.1.47.jar!\org\gjt\mm\mysql\Driver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */
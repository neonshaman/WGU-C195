/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.log.Log;
/*      */ import com.mysql.jdbc.log.LogFactory;
/*      */ import com.mysql.jdbc.log.LogUtils;
/*      */ import com.mysql.jdbc.log.NullLogger;
/*      */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*      */ import com.mysql.jdbc.profiler.ProfilerEventHandler;
/*      */ import com.mysql.jdbc.util.LRUCache;
/*      */ import java.io.IOException;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.lang.reflect.Array;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.InvocationHandler;
/*      */ import java.lang.reflect.Method;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.CharBuffer;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.charset.CharsetEncoder;
/*      */ import java.nio.charset.UnsupportedCharsetException;
/*      */ import java.sql.Blob;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLPermission;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Savepoint;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Collections;
/*      */ import java.util.Enumeration;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.Random;
/*      */ import java.util.Stack;
/*      */ import java.util.TimeZone;
/*      */ import java.util.Timer;
/*      */ import java.util.concurrent.CopyOnWriteArrayList;
/*      */ import java.util.concurrent.Executor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ConnectionImpl
/*      */   extends ConnectionPropertiesImpl
/*      */   implements MySQLConnection
/*      */ {
/*      */   private static final long serialVersionUID = 2877471301981509474L;
/*   84 */   private static final SQLPermission SET_NETWORK_TIMEOUT_PERM = new SQLPermission("setNetworkTimeout");
/*      */   
/*   86 */   private static final SQLPermission ABORT_PERM = new SQLPermission("abort");
/*      */   
/*      */   public static final String JDBC_LOCAL_CHARACTER_SET_RESULTS = "jdbc.local.character_set_results";
/*      */   
/*      */   public String getHost() {
/*   91 */     return this.host;
/*      */   }
/*      */   
/*      */   public String getHostPortPair() {
/*   95 */     return (this.hostPortPair != null) ? this.hostPortPair : (this.host + ":" + this.port);
/*      */   }
/*      */   
/*   98 */   private MySQLConnection proxy = null;
/*   99 */   private InvocationHandler realProxy = null;
/*      */   
/*      */   public boolean isProxySet() {
/*  102 */     return (this.proxy != null);
/*      */   }
/*      */   
/*      */   public void setProxy(MySQLConnection proxy) {
/*  106 */     this.proxy = proxy;
/*  107 */     this.realProxy = (this.proxy instanceof MultiHostMySQLConnection) ? ((MultiHostMySQLConnection)proxy).getThisAsProxy() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private MySQLConnection getProxy() {
/*  113 */     return (this.proxy != null) ? this.proxy : this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public MySQLConnection getLoadBalanceSafeProxy() {
/*  121 */     return getMultiHostSafeProxy();
/*      */   }
/*      */   
/*      */   public MySQLConnection getMultiHostSafeProxy() {
/*  125 */     return getProxy();
/*      */   }
/*      */   
/*      */   public MySQLConnection getActiveMySQLConnection() {
/*  129 */     return this;
/*      */   }
/*      */   
/*      */   public Object getConnectionMutex() {
/*  133 */     return (this.realProxy != null) ? this.realProxy : getProxy();
/*      */   }
/*      */   
/*      */   public class ExceptionInterceptorChain implements ExceptionInterceptor {
/*      */     private List<Extension> interceptors;
/*      */     
/*      */     ExceptionInterceptorChain(String interceptorClasses) throws SQLException {
/*  140 */       this.interceptors = Util.loadExtensions(ConnectionImpl.this, ConnectionImpl.this.props, interceptorClasses, "Connection.BadExceptionInterceptor", this);
/*      */     }
/*      */ 
/*      */     
/*      */     void addRingZero(ExceptionInterceptor interceptor) throws SQLException {
/*  145 */       this.interceptors.add(0, interceptor);
/*      */     }
/*      */     
/*      */     public SQLException interceptException(SQLException sqlEx, Connection conn) {
/*  149 */       if (this.interceptors != null) {
/*  150 */         Iterator<Extension> iter = this.interceptors.iterator();
/*      */         
/*  152 */         while (iter.hasNext()) {
/*  153 */           sqlEx = ((ExceptionInterceptor)iter.next()).interceptException(sqlEx, ConnectionImpl.this);
/*      */         }
/*      */       } 
/*      */       
/*  157 */       return sqlEx;
/*      */     }
/*      */     
/*      */     public void destroy() {
/*  161 */       if (this.interceptors != null) {
/*  162 */         Iterator<Extension> iter = this.interceptors.iterator();
/*      */         
/*  164 */         while (iter.hasNext()) {
/*  165 */           ((ExceptionInterceptor)iter.next()).destroy();
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void init(Connection conn, Properties properties) throws SQLException {
/*  172 */       if (this.interceptors != null) {
/*  173 */         Iterator<Extension> iter = this.interceptors.iterator();
/*      */         
/*  175 */         while (iter.hasNext()) {
/*  176 */           ((ExceptionInterceptor)iter.next()).init(conn, properties);
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*      */     public List<Extension> getInterceptors() {
/*  182 */       return this.interceptors;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static class CompoundCacheKey
/*      */   {
/*      */     final String componentOne;
/*      */ 
/*      */     
/*      */     final String componentTwo;
/*      */ 
/*      */     
/*      */     final int hashCode;
/*      */ 
/*      */     
/*      */     CompoundCacheKey(String partOne, String partTwo) {
/*  200 */       this.componentOne = partOne;
/*  201 */       this.componentTwo = partTwo;
/*      */       
/*  203 */       int hc = 17;
/*  204 */       hc = 31 * hc + ((this.componentOne != null) ? this.componentOne.hashCode() : 0);
/*  205 */       hc = 31 * hc + ((this.componentTwo != null) ? this.componentTwo.hashCode() : 0);
/*  206 */       this.hashCode = hc;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(Object obj) {
/*  216 */       if (this == obj) {
/*  217 */         return true;
/*      */       }
/*  219 */       if (obj != null && CompoundCacheKey.class.isAssignableFrom(obj.getClass())) {
/*  220 */         CompoundCacheKey another = (CompoundCacheKey)obj;
/*  221 */         if ((this.componentOne == null) ? (another.componentOne == null) : this.componentOne.equals(another.componentOne)) {
/*  222 */           return (this.componentTwo == null) ? ((another.componentTwo == null)) : this.componentTwo.equals(another.componentTwo);
/*      */         }
/*      */       } 
/*  225 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*  235 */       return this.hashCode;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  243 */   private static final Object CHARSET_CONVERTER_NOT_AVAILABLE_MARKER = new Object();
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map<?, ?> charsetMap;
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final String DEFAULT_LOGGER_CLASS = "com.mysql.jdbc.log.StandardLogger";
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int HISTOGRAM_BUCKETS = 20;
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String LOGGER_INSTANCE_NAME = "MySQL";
/*      */ 
/*      */ 
/*      */   
/*  263 */   private static Map<String, Integer> mapTransIsolationNameToValue = null;
/*      */ 
/*      */   
/*  266 */   private static final Log NULL_LOGGER = (Log)new NullLogger("MySQL");
/*      */ 
/*      */ 
/*      */   
/*      */   protected static Map<?, ?> roundRobinStatsMap;
/*      */ 
/*      */   
/*  273 */   private static final Map<String, Map<Integer, String>> customIndexToCharsetMapByUrl = new HashMap<String, Map<Integer, String>>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  278 */   private static final Map<String, Map<String, Integer>> customCharsetToMblenMapByUrl = new HashMap<String, Map<String, Integer>>();
/*      */   
/*      */   private CacheAdapter<String, Map<String, String>> serverConfigCache;
/*      */   
/*      */   private long queryTimeCount;
/*      */   
/*      */   private double queryTimeSum;
/*      */   
/*      */   private double queryTimeSumSquares;
/*      */   
/*      */   private double queryTimeMean;
/*      */   
/*      */   private transient Timer cancelTimer;
/*      */   private List<Extension> connectionLifecycleInterceptors;
/*      */   private static final Constructor<?> JDBC_4_CONNECTION_CTOR;
/*      */   private static final int DEFAULT_RESULT_SET_TYPE = 1003;
/*      */   private static final int DEFAULT_RESULT_SET_CONCURRENCY = 1007;
/*      */   private static final Random random;
/*      */   
/*      */   static {
/*  298 */     mapTransIsolationNameToValue = new HashMap<String, Integer>(8);
/*  299 */     mapTransIsolationNameToValue.put("READ-UNCOMMITED", Integer.valueOf(1));
/*  300 */     mapTransIsolationNameToValue.put("READ-UNCOMMITTED", Integer.valueOf(1));
/*  301 */     mapTransIsolationNameToValue.put("READ-COMMITTED", Integer.valueOf(2));
/*  302 */     mapTransIsolationNameToValue.put("REPEATABLE-READ", Integer.valueOf(4));
/*  303 */     mapTransIsolationNameToValue.put("SERIALIZABLE", Integer.valueOf(8));
/*      */     
/*  305 */     if (Util.isJdbc4()) {
/*      */       try {
/*  307 */         JDBC_4_CONNECTION_CTOR = Class.forName("com.mysql.jdbc.JDBC4Connection").getConstructor(new Class[] { String.class, int.class, Properties.class, String.class, String.class });
/*      */       }
/*  309 */       catch (SecurityException e) {
/*  310 */         throw new RuntimeException(e);
/*  311 */       } catch (NoSuchMethodException e) {
/*  312 */         throw new RuntimeException(e);
/*  313 */       } catch (ClassNotFoundException e) {
/*  314 */         throw new RuntimeException(e);
/*      */       } 
/*      */     } else {
/*  317 */       JDBC_4_CONNECTION_CTOR = null;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  390 */     random = new Random();
/*      */   }
/*      */   protected static SQLException appendMessageToException(SQLException sqlEx, String messageToAppend, ExceptionInterceptor interceptor) { String origMessage = sqlEx.getMessage(); String sqlState = sqlEx.getSQLState(); int vendorErrorCode = sqlEx.getErrorCode(); StringBuilder messageBuf = new StringBuilder(origMessage.length() + messageToAppend.length()); messageBuf.append(origMessage); messageBuf.append(messageToAppend); SQLException sqlExceptionWithNewMessage = SQLError.createSQLException(messageBuf.toString(), sqlState, vendorErrorCode, interceptor); try { Method getStackTraceMethod = null; Method setStackTraceMethod = null; Object theStackTraceAsObject = null; Class<?> stackTraceElementClass = Class.forName("java.lang.StackTraceElement"); Class<?> stackTraceElementArrayClass = Array.newInstance(stackTraceElementClass, new int[] { 0 }).getClass(); getStackTraceMethod = Throwable.class.getMethod("getStackTrace", new Class[0]); setStackTraceMethod = Throwable.class.getMethod("setStackTrace", new Class[] { stackTraceElementArrayClass }); if (getStackTraceMethod != null && setStackTraceMethod != null) { theStackTraceAsObject = getStackTraceMethod.invoke(sqlEx, new Object[0]); setStackTraceMethod.invoke(sqlExceptionWithNewMessage, new Object[] { theStackTraceAsObject }); }  }
/*      */     catch (NoClassDefFoundError noClassDefFound) {  }
/*      */     catch (NoSuchMethodException noSuchMethodEx) {  }
/*      */     catch (Throwable catchAll) {} return sqlExceptionWithNewMessage; }
/*      */   public Timer getCancelTimer() { synchronized (getConnectionMutex()) { if (this.cancelTimer == null)
/*      */         this.cancelTimer = new Timer("MySQL Statement Cancellation Timer", true);  return this.cancelTimer; }
/*      */      } protected static Connection getInstance(String hostToConnectTo, int portToConnectTo, Properties info, String databaseToConnectTo, String url) throws SQLException { if (!Util.isJdbc4())
/*  399 */       return new ConnectionImpl(hostToConnectTo, portToConnectTo, info, databaseToConnectTo, url);  return (Connection)Util.handleNewInstance(JDBC_4_CONNECTION_CTOR, new Object[] { hostToConnectTo, Integer.valueOf(portToConnectTo), info, databaseToConnectTo, url }, null); } protected static synchronized int getNextRoundRobinHostIndex(String url, List<?> hostList) { int indexRange = hostList.size();
/*      */     
/*  401 */     int index = random.nextInt(indexRange);
/*      */     
/*  403 */     return index; }
/*      */ 
/*      */   
/*      */   private static boolean nullSafeCompare(String s1, String s2) {
/*  407 */     if (s1 == null && s2 == null) {
/*  408 */       return true;
/*      */     }
/*      */     
/*  411 */     if (s1 == null && s2 != null) {
/*  412 */       return false;
/*      */     }
/*      */     
/*  415 */     return (s1 != null && s1.equals(s2));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean autoCommit = true;
/*      */ 
/*      */   
/*      */   private CacheAdapter<String, PreparedStatement.ParseInfo> cachedPreparedStatementParams;
/*      */ 
/*      */   
/*  427 */   private String characterSetMetadata = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  433 */   private String characterSetResultsOnServer = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  440 */   private final Map<String, Object> charsetConverterMap = new HashMap<String, Object>(CharsetMapping.getNumberOfCharsetsConfigured());
/*      */ 
/*      */   
/*  443 */   private long connectionCreationTimeMillis = 0L;
/*      */ 
/*      */   
/*      */   private long connectionId;
/*      */ 
/*      */   
/*  449 */   private String database = null;
/*      */ 
/*      */   
/*  452 */   private DatabaseMetaData dbmd = null;
/*      */ 
/*      */   
/*      */   private TimeZone defaultTimeZone;
/*      */ 
/*      */   
/*      */   private ProfilerEventHandler eventSink;
/*      */ 
/*      */   
/*      */   private Throwable forceClosedReason;
/*      */ 
/*      */   
/*      */   private boolean hasIsolationLevels = false;
/*      */ 
/*      */   
/*      */   private boolean hasQuotedIdentifiers = false;
/*      */   
/*  469 */   private String host = null;
/*      */   
/*  471 */   public Map<Integer, String> indexToCustomMysqlCharset = null;
/*      */   
/*  473 */   private Map<String, Integer> mysqlCharsetToCustomMblen = null;
/*      */ 
/*      */   
/*  476 */   private transient MysqlIO io = null;
/*      */ 
/*      */   
/*      */   private boolean isClientTzUTC = false;
/*      */ 
/*      */   
/*      */   private boolean isClosed = true;
/*      */ 
/*      */   
/*      */   private boolean isInGlobalTx = false;
/*      */ 
/*      */   
/*      */   private boolean isRunningOnJDK13 = false;
/*      */   
/*  490 */   private int isolationLevel = 2;
/*      */ 
/*      */   
/*      */   private boolean isServerTzUTC = false;
/*      */   
/*  495 */   private long lastQueryFinishedTime = 0L;
/*      */ 
/*      */   
/*  498 */   private transient Log log = NULL_LOGGER;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  504 */   private long longestQueryTimeMs = 0L;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean lowerCaseTableNames = false;
/*      */ 
/*      */ 
/*      */   
/*  512 */   private long maximumNumberTablesAccessed = 0L;
/*      */ 
/*      */   
/*  515 */   private int sessionMaxRows = -1;
/*      */ 
/*      */   
/*      */   private long metricsLastReportedMs;
/*      */   
/*  520 */   private long minimumNumberTablesAccessed = Long.MAX_VALUE;
/*      */ 
/*      */   
/*  523 */   private String myURL = null;
/*      */ 
/*      */   
/*      */   private boolean needsPing = false;
/*      */   
/*  528 */   private int netBufferLength = 16384;
/*      */   
/*      */   private boolean noBackslashEscapes = false;
/*      */   
/*      */   private boolean serverTruncatesFracSecs = false;
/*      */   
/*  534 */   private long numberOfPreparedExecutes = 0L;
/*      */   
/*  536 */   private long numberOfPrepares = 0L;
/*      */   
/*  538 */   private long numberOfQueriesIssued = 0L;
/*      */   
/*  540 */   private long numberOfResultSetsCreated = 0L;
/*      */   
/*      */   private long[] numTablesMetricsHistBreakpoints;
/*      */   
/*      */   private int[] numTablesMetricsHistCounts;
/*      */   
/*  546 */   private long[] oldHistBreakpoints = null;
/*      */   
/*  548 */   private int[] oldHistCounts = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  554 */   private final CopyOnWriteArrayList<Statement> openStatements = new CopyOnWriteArrayList<Statement>();
/*      */ 
/*      */   
/*      */   private LRUCache<CompoundCacheKey, CallableStatement.CallableStatementParamInfo> parsedCallableStatementCache;
/*      */   
/*      */   private boolean parserKnowsUnicode = false;
/*      */   
/*  561 */   private String password = null;
/*      */ 
/*      */   
/*      */   private long[] perfMetricsHistBreakpoints;
/*      */ 
/*      */   
/*      */   private int[] perfMetricsHistCounts;
/*      */   
/*      */   private String pointOfOrigin;
/*      */   
/*  571 */   private int port = 3306;
/*      */ 
/*      */   
/*  574 */   protected Properties props = null;
/*      */ 
/*      */   
/*      */   private boolean readInfoMsg = false;
/*      */ 
/*      */   
/*      */   private boolean readOnly = false;
/*      */ 
/*      */   
/*      */   protected LRUCache<String, CachedResultSetMetaData> resultSetMetadataCache;
/*      */ 
/*      */   
/*  586 */   private TimeZone serverTimezoneTZ = null;
/*      */ 
/*      */   
/*  589 */   private Map<String, String> serverVariables = null;
/*      */   
/*  591 */   private long shortestQueryTimeMs = Long.MAX_VALUE;
/*      */   
/*  593 */   private double totalQueryTimeMs = 0.0D;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean transactionsSupported = false;
/*      */ 
/*      */ 
/*      */   
/*      */   private Map<String, Class<?>> typeMap;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean useAnsiQuotes = false;
/*      */ 
/*      */   
/*  608 */   private String user = null;
/*      */ 
/*      */   
/*      */   private boolean useServerPreparedStmts = false;
/*      */ 
/*      */   
/*      */   private LRUCache<String, Boolean> serverSideStatementCheckCache;
/*      */ 
/*      */   
/*      */   private LRUCache<CompoundCacheKey, ServerPreparedStatement> serverSideStatementCache;
/*      */ 
/*      */   
/*      */   private Calendar sessionCalendar;
/*      */   
/*      */   private Calendar utcCalendar;
/*      */   
/*      */   private String origHostToConnectTo;
/*      */   
/*      */   private int origPortToConnectTo;
/*      */   
/*      */   private String origDatabaseToConnectTo;
/*      */   
/*  630 */   private String errorMessageEncoding = "Cp1252";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean usePlatformCharsetConverters;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean hasTriedMasterFlag = false;
/*      */ 
/*      */ 
/*      */   
/*  643 */   private String statementComment = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean storesLowerCaseTableName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<StatementInterceptorV2> statementInterceptors;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean requiresEscapingEncoder;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String hostPortPair;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String SERVER_VERSION_STRING_VAR_NAME = "server_version_string";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int autoIncrementIncrement;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ExceptionInterceptor exceptionInterceptor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unSafeStatementInterceptors() throws SQLException {
/*  818 */     ArrayList<StatementInterceptorV2> unSafedStatementInterceptors = new ArrayList<StatementInterceptorV2>(this.statementInterceptors.size());
/*      */     
/*  820 */     for (int i = 0; i < this.statementInterceptors.size(); i++) {
/*  821 */       NoSubInterceptorWrapper wrappedInterceptor = (NoSubInterceptorWrapper)this.statementInterceptors.get(i);
/*      */       
/*  823 */       unSafedStatementInterceptors.add(wrappedInterceptor.getUnderlyingInterceptor());
/*      */     } 
/*      */     
/*  826 */     this.statementInterceptors = unSafedStatementInterceptors;
/*      */     
/*  828 */     if (this.io != null) {
/*  829 */       this.io.setStatementInterceptors(this.statementInterceptors);
/*      */     }
/*      */   }
/*      */   
/*      */   public void initializeSafeStatementInterceptors() throws SQLException {
/*  834 */     this.isClosed = false;
/*      */     
/*  836 */     List<Extension> unwrappedInterceptors = Util.loadExtensions(this, this.props, getStatementInterceptors(), "MysqlIo.BadStatementInterceptor", getExceptionInterceptor());
/*      */ 
/*      */     
/*  839 */     this.statementInterceptors = new ArrayList<StatementInterceptorV2>(unwrappedInterceptors.size());
/*      */     
/*  841 */     for (int i = 0; i < unwrappedInterceptors.size(); i++) {
/*  842 */       Extension interceptor = unwrappedInterceptors.get(i);
/*      */ 
/*      */       
/*  845 */       if (interceptor instanceof StatementInterceptor) {
/*  846 */         if (ReflectiveStatementInterceptorAdapter.getV2PostProcessMethod(interceptor.getClass()) != null) {
/*  847 */           this.statementInterceptors.add(new NoSubInterceptorWrapper(new ReflectiveStatementInterceptorAdapter((StatementInterceptor)interceptor)));
/*      */         } else {
/*  849 */           this.statementInterceptors.add(new NoSubInterceptorWrapper(new V1toV2StatementInterceptorAdapter((StatementInterceptor)interceptor)));
/*      */         } 
/*      */       } else {
/*  852 */         this.statementInterceptors.add(new NoSubInterceptorWrapper((StatementInterceptorV2)interceptor));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public List<StatementInterceptorV2> getStatementInterceptorsInstances() {
/*  859 */     return this.statementInterceptors;
/*      */   }
/*      */ 
/*      */   
/*      */   private void addToHistogram(int[] histogramCounts, long[] histogramBreakpoints, long value, int numberOfTimes, long currentLowerBound, long currentUpperBound) {
/*  864 */     if (histogramCounts == null) {
/*  865 */       createInitialHistogram(histogramBreakpoints, currentLowerBound, currentUpperBound);
/*      */     } else {
/*  867 */       for (int i = 0; i < 20; i++) {
/*  868 */         if (histogramBreakpoints[i] >= value) {
/*  869 */           histogramCounts[i] = histogramCounts[i] + numberOfTimes;
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void addToPerformanceHistogram(long value, int numberOfTimes) {
/*  878 */     checkAndCreatePerformanceHistogram();
/*      */     
/*  880 */     addToHistogram(this.perfMetricsHistCounts, this.perfMetricsHistBreakpoints, value, numberOfTimes, (this.shortestQueryTimeMs == Long.MAX_VALUE) ? 0L : this.shortestQueryTimeMs, this.longestQueryTimeMs);
/*      */   }
/*      */ 
/*      */   
/*      */   private void addToTablesAccessedHistogram(long value, int numberOfTimes) {
/*  885 */     checkAndCreateTablesAccessedHistogram();
/*      */     
/*  887 */     addToHistogram(this.numTablesMetricsHistCounts, this.numTablesMetricsHistBreakpoints, value, numberOfTimes, (this.minimumNumberTablesAccessed == Long.MAX_VALUE) ? 0L : this.minimumNumberTablesAccessed, this.maximumNumberTablesAccessed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void buildCollationMapping() throws SQLException {
/*  899 */     Map<Integer, String> customCharset = null;
/*  900 */     Map<String, Integer> customMblen = null;
/*      */     
/*  902 */     if (getCacheServerConfiguration()) {
/*  903 */       synchronized (customIndexToCharsetMapByUrl) {
/*  904 */         customCharset = customIndexToCharsetMapByUrl.get(getURL());
/*  905 */         customMblen = customCharsetToMblenMapByUrl.get(getURL());
/*      */       } 
/*      */     }
/*      */     
/*  909 */     if (customCharset == null && getDetectCustomCollations() && versionMeetsMinimum(4, 1, 0)) {
/*      */       
/*  911 */       Statement stmt = null;
/*  912 */       ResultSet results = null;
/*      */       
/*      */       try {
/*  915 */         customCharset = new HashMap<Integer, String>();
/*  916 */         customMblen = new HashMap<String, Integer>();
/*      */         
/*  918 */         stmt = getMetadataSafeStatement();
/*      */         
/*      */         try {
/*  921 */           results = stmt.executeQuery("SHOW COLLATION");
/*  922 */           while (results.next()) {
/*  923 */             int collationIndex = ((Number)results.getObject(3)).intValue();
/*  924 */             String charsetName = results.getString(2);
/*      */ 
/*      */             
/*  927 */             if (collationIndex >= 2048 || !charsetName.equals(CharsetMapping.getMysqlCharsetNameForCollationIndex(Integer.valueOf(collationIndex))))
/*      */             {
/*  929 */               customCharset.put(Integer.valueOf(collationIndex), charsetName);
/*      */             }
/*      */ 
/*      */             
/*  933 */             if (!CharsetMapping.CHARSET_NAME_TO_CHARSET.containsKey(charsetName)) {
/*  934 */               customMblen.put(charsetName, null);
/*      */             }
/*      */           } 
/*  937 */         } catch (SQLException ex) {
/*  938 */           if (ex.getErrorCode() != 1820 || getDisconnectOnExpiredPasswords()) {
/*  939 */             throw ex;
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/*  944 */         if (customMblen.size() > 0) {
/*      */           try {
/*  946 */             results = stmt.executeQuery("SHOW CHARACTER SET");
/*  947 */             while (results.next()) {
/*  948 */               String charsetName = results.getString("Charset");
/*  949 */               if (customMblen.containsKey(charsetName)) {
/*  950 */                 customMblen.put(charsetName, Integer.valueOf(results.getInt("Maxlen")));
/*      */               }
/*      */             } 
/*  953 */           } catch (SQLException ex) {
/*  954 */             if (ex.getErrorCode() != 1820 || getDisconnectOnExpiredPasswords()) {
/*  955 */               throw ex;
/*      */             }
/*      */           } 
/*      */         }
/*      */         
/*  960 */         if (getCacheServerConfiguration()) {
/*  961 */           synchronized (customIndexToCharsetMapByUrl) {
/*  962 */             customIndexToCharsetMapByUrl.put(getURL(), customCharset);
/*  963 */             customCharsetToMblenMapByUrl.put(getURL(), customMblen);
/*      */           }
/*      */         
/*      */         }
/*  967 */       } catch (SQLException ex) {
/*  968 */         throw ex;
/*  969 */       } catch (RuntimeException ex) {
/*  970 */         SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", (ExceptionInterceptor)null);
/*  971 */         sqlEx.initCause(ex);
/*  972 */         throw sqlEx;
/*      */       } finally {
/*  974 */         if (results != null) {
/*      */           try {
/*  976 */             results.close();
/*  977 */           } catch (SQLException sqlE) {}
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  982 */         if (stmt != null) {
/*      */           try {
/*  984 */             stmt.close();
/*  985 */           } catch (SQLException sqlE) {}
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  992 */     if (customCharset != null) {
/*  993 */       this.indexToCustomMysqlCharset = Collections.unmodifiableMap(customCharset);
/*      */     }
/*  995 */     if (customMblen != null) {
/*  996 */       this.mysqlCharsetToCustomMblen = Collections.unmodifiableMap(customMblen);
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean canHandleAsServerPreparedStatement(String sql) throws SQLException {
/* 1001 */     if (sql == null || sql.length() == 0) {
/* 1002 */       return true;
/*      */     }
/*      */     
/* 1005 */     if (!this.useServerPreparedStmts) {
/* 1006 */       return false;
/*      */     }
/*      */     
/* 1009 */     if (getCachePreparedStatements()) {
/* 1010 */       synchronized (this.serverSideStatementCheckCache) {
/* 1011 */         Boolean flag = (Boolean)this.serverSideStatementCheckCache.get(sql);
/*      */         
/* 1013 */         if (flag != null) {
/* 1014 */           return flag.booleanValue();
/*      */         }
/*      */         
/* 1017 */         boolean canHandle = canHandleAsServerPreparedStatementNoCache(sql);
/*      */         
/* 1019 */         if (sql.length() < getPreparedStatementCacheSqlLimit()) {
/* 1020 */           this.serverSideStatementCheckCache.put(sql, canHandle ? Boolean.TRUE : Boolean.FALSE);
/*      */         }
/*      */         
/* 1023 */         return canHandle;
/*      */       } 
/*      */     }
/*      */     
/* 1027 */     return canHandleAsServerPreparedStatementNoCache(sql);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean canHandleAsServerPreparedStatementNoCache(String sql) throws SQLException {
/* 1033 */     if (StringUtils.startsWithIgnoreCaseAndNonAlphaNumeric(sql, "CALL")) {
/* 1034 */       return false;
/*      */     }
/*      */     
/* 1037 */     boolean canHandleAsStatement = true;
/*      */     
/* 1039 */     boolean allowBackslashEscapes = !this.noBackslashEscapes;
/* 1040 */     String quoteChar = this.useAnsiQuotes ? "\"" : "'";
/*      */     
/* 1042 */     if (getAllowMultiQueries()) {
/* 1043 */       if (StringUtils.indexOfIgnoreCase(0, sql, ";", quoteChar, quoteChar, allowBackslashEscapes ? StringUtils.SEARCH_MODE__ALL : StringUtils.SEARCH_MODE__MRK_COM_WS) != -1)
/*      */       {
/* 1045 */         canHandleAsStatement = false;
/*      */       }
/* 1047 */     } else if (!versionMeetsMinimum(5, 0, 7) && (StringUtils.startsWithIgnoreCaseAndNonAlphaNumeric(sql, "SELECT") || StringUtils.startsWithIgnoreCaseAndNonAlphaNumeric(sql, "DELETE") || StringUtils.startsWithIgnoreCaseAndNonAlphaNumeric(sql, "INSERT") || StringUtils.startsWithIgnoreCaseAndNonAlphaNumeric(sql, "UPDATE") || StringUtils.startsWithIgnoreCaseAndNonAlphaNumeric(sql, "REPLACE"))) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1057 */       int currentPos = 0;
/* 1058 */       int statementLength = sql.length();
/* 1059 */       int lastPosToLook = statementLength - 7;
/* 1060 */       boolean foundLimitWithPlaceholder = false;
/*      */       
/* 1062 */       while (currentPos < lastPosToLook) {
/* 1063 */         int limitStart = StringUtils.indexOfIgnoreCase(currentPos, sql, "LIMIT ", quoteChar, quoteChar, allowBackslashEscapes ? StringUtils.SEARCH_MODE__ALL : StringUtils.SEARCH_MODE__MRK_COM_WS);
/*      */ 
/*      */         
/* 1066 */         if (limitStart == -1) {
/*      */           break;
/*      */         }
/*      */         
/* 1070 */         currentPos = limitStart + 7;
/*      */         
/* 1072 */         while (currentPos < statementLength) {
/* 1073 */           char c = sql.charAt(currentPos);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1079 */           if (!Character.isDigit(c) && !Character.isWhitespace(c) && c != ',' && c != '?') {
/*      */             break;
/*      */           }
/*      */           
/* 1083 */           if (c == '?') {
/* 1084 */             foundLimitWithPlaceholder = true;
/*      */             
/*      */             break;
/*      */           } 
/* 1088 */           currentPos++;
/*      */         } 
/*      */       } 
/*      */       
/* 1092 */       canHandleAsStatement = !foundLimitWithPlaceholder;
/* 1093 */     } else if (StringUtils.startsWithIgnoreCaseAndWs(sql, "XA ")) {
/* 1094 */       canHandleAsStatement = false;
/* 1095 */     } else if (StringUtils.startsWithIgnoreCaseAndWs(sql, "CREATE TABLE")) {
/* 1096 */       canHandleAsStatement = false;
/* 1097 */     } else if (StringUtils.startsWithIgnoreCaseAndWs(sql, "DO")) {
/* 1098 */       canHandleAsStatement = false;
/* 1099 */     } else if (StringUtils.startsWithIgnoreCaseAndWs(sql, "SET")) {
/* 1100 */       canHandleAsStatement = false;
/* 1101 */     } else if (StringUtils.startsWithIgnoreCaseAndWs(sql, "SHOW WARNINGS") && versionMeetsMinimum(5, 7, 2)) {
/* 1102 */       canHandleAsStatement = false;
/* 1103 */     } else if (sql.startsWith("/* ping */")) {
/* 1104 */       canHandleAsStatement = false;
/*      */     } 
/*      */     
/* 1107 */     return canHandleAsStatement;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void changeUser(String userName, String newPassword) throws SQLException {
/* 1124 */     synchronized (getConnectionMutex()) {
/* 1125 */       checkClosed();
/*      */       
/* 1127 */       if (userName == null || userName.equals("")) {
/* 1128 */         userName = "";
/*      */       }
/*      */       
/* 1131 */       if (newPassword == null) {
/* 1132 */         newPassword = "";
/*      */       }
/*      */ 
/*      */       
/* 1136 */       this.sessionMaxRows = -1;
/*      */       
/*      */       try {
/* 1139 */         this.io.changeUser(userName, newPassword, this.database);
/* 1140 */       } catch (SQLException ex) {
/* 1141 */         if (versionMeetsMinimum(5, 6, 13) && "28000".equals(ex.getSQLState())) {
/* 1142 */           cleanup(ex);
/*      */         }
/* 1144 */         throw ex;
/*      */       } 
/* 1146 */       this.user = userName;
/* 1147 */       this.password = newPassword;
/*      */       
/* 1149 */       if (versionMeetsMinimum(4, 1, 0)) {
/* 1150 */         configureClientCharacterSet(true);
/*      */       }
/*      */       
/* 1153 */       setSessionVariables();
/*      */       
/* 1155 */       setupServerForTruncationChecks();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean characterSetNamesMatches(String mysqlEncodingName) {
/* 1161 */     return (mysqlEncodingName != null && mysqlEncodingName.equalsIgnoreCase(this.serverVariables.get("character_set_client")) && mysqlEncodingName.equalsIgnoreCase(this.serverVariables.get("character_set_connection")));
/*      */   }
/*      */ 
/*      */   
/*      */   private void checkAndCreatePerformanceHistogram() {
/* 1166 */     if (this.perfMetricsHistCounts == null) {
/* 1167 */       this.perfMetricsHistCounts = new int[20];
/*      */     }
/*      */     
/* 1170 */     if (this.perfMetricsHistBreakpoints == null) {
/* 1171 */       this.perfMetricsHistBreakpoints = new long[20];
/*      */     }
/*      */   }
/*      */   
/*      */   private void checkAndCreateTablesAccessedHistogram() {
/* 1176 */     if (this.numTablesMetricsHistCounts == null) {
/* 1177 */       this.numTablesMetricsHistCounts = new int[20];
/*      */     }
/*      */     
/* 1180 */     if (this.numTablesMetricsHistBreakpoints == null) {
/* 1181 */       this.numTablesMetricsHistBreakpoints = new long[20];
/*      */     }
/*      */   }
/*      */   
/*      */   public void checkClosed() throws SQLException {
/* 1186 */     if (this.isClosed) {
/* 1187 */       throwConnectionClosedException();
/*      */     }
/*      */   }
/*      */   
/*      */   public void throwConnectionClosedException() throws SQLException {
/* 1192 */     SQLException ex = SQLError.createSQLException("No operations allowed after connection closed.", "08003", getExceptionInterceptor());
/*      */ 
/*      */     
/* 1195 */     if (this.forceClosedReason != null) {
/* 1196 */       ex.initCause(this.forceClosedReason);
/*      */     }
/*      */     
/* 1199 */     throw ex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkServerEncoding() throws SQLException {
/* 1209 */     if (getUseUnicode() && getEncoding() != null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1214 */     String serverCharset = this.serverVariables.get("character_set");
/*      */     
/* 1216 */     if (serverCharset == null)
/*      */     {
/* 1218 */       serverCharset = this.serverVariables.get("character_set_server");
/*      */     }
/*      */     
/* 1221 */     String mappedServerEncoding = null;
/*      */     
/* 1223 */     if (serverCharset != null) {
/*      */       try {
/* 1225 */         mappedServerEncoding = CharsetMapping.getJavaEncodingForMysqlCharset(serverCharset);
/* 1226 */       } catch (RuntimeException ex) {
/* 1227 */         SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", (ExceptionInterceptor)null);
/* 1228 */         sqlEx.initCause(ex);
/* 1229 */         throw sqlEx;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1236 */     if (!getUseUnicode() && mappedServerEncoding != null) {
/* 1237 */       SingleByteCharsetConverter converter = getCharsetConverter(mappedServerEncoding);
/*      */       
/* 1239 */       if (converter != null) {
/* 1240 */         setUseUnicode(true);
/* 1241 */         setEncoding(mappedServerEncoding);
/*      */ 
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1250 */     if (serverCharset != null) {
/* 1251 */       if (mappedServerEncoding == null)
/*      */       {
/* 1253 */         if (Character.isLowerCase(serverCharset.charAt(0))) {
/* 1254 */           char[] ach = serverCharset.toCharArray();
/* 1255 */           ach[0] = Character.toUpperCase(serverCharset.charAt(0));
/* 1256 */           setEncoding(new String(ach));
/*      */         } 
/*      */       }
/*      */       
/* 1260 */       if (mappedServerEncoding == null) {
/* 1261 */         throw SQLError.createSQLException("Unknown character encoding on server '" + serverCharset + "', use 'characterEncoding=' property " + " to provide correct mapping", "01S00", getExceptionInterceptor());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 1270 */         StringUtils.getBytes("abc", mappedServerEncoding);
/* 1271 */         setEncoding(mappedServerEncoding);
/* 1272 */         setUseUnicode(true);
/* 1273 */       } catch (UnsupportedEncodingException UE) {
/* 1274 */         throw SQLError.createSQLException("The driver can not map the character encoding '" + getEncoding() + "' that your server is using " + "to a character encoding your JVM understands. You can specify this mapping manually by adding \"useUnicode=true\" " + "as well as \"characterEncoding=[an_encoding_your_jvm_understands]\" to your JDBC URL.", "0S100", getExceptionInterceptor());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkTransactionIsolationLevel() throws SQLException {
/* 1288 */     String s = this.serverVariables.get("transaction_isolation");
/* 1289 */     if (s == null) {
/* 1290 */       s = this.serverVariables.get("tx_isolation");
/*      */     }
/*      */     
/* 1293 */     if (s != null) {
/* 1294 */       Integer intTI = mapTransIsolationNameToValue.get(s);
/*      */       
/* 1296 */       if (intTI != null) {
/* 1297 */         this.isolationLevel = intTI.intValue();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void abortInternal() throws SQLException {
/* 1309 */     if (this.io != null) {
/*      */ 
/*      */       
/*      */       try {
/*      */ 
/*      */         
/* 1315 */         this.io.forceClose();
/* 1316 */         this.io.releaseResources();
/* 1317 */       } catch (Throwable t) {}
/*      */ 
/*      */       
/* 1320 */       this.io = null;
/*      */     } 
/*      */     
/* 1323 */     this.isClosed = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void cleanup(Throwable whyCleanedUp) {
/*      */     try {
/* 1334 */       if (this.io != null) {
/* 1335 */         if (isClosed()) {
/* 1336 */           this.io.forceClose();
/*      */         } else {
/* 1338 */           realClose(false, false, false, whyCleanedUp);
/*      */         } 
/*      */       }
/* 1341 */     } catch (SQLException sqlEx) {}
/*      */ 
/*      */ 
/*      */     
/* 1345 */     this.isClosed = true;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public void clearHasTriedMaster() {
/* 1350 */     this.hasTriedMasterFlag = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearWarnings() throws SQLException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql) throws SQLException {
/* 1369 */     return clientPrepareStatement(sql, 1003, 1007);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, int autoGenKeyIndex) throws SQLException {
/* 1376 */     PreparedStatement pStmt = clientPrepareStatement(sql);
/*      */     
/* 1378 */     ((PreparedStatement)pStmt).setRetrieveGeneratedKeys((autoGenKeyIndex == 1));
/*      */     
/* 1380 */     return pStmt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/* 1390 */     return clientPrepareStatement(sql, resultSetType, resultSetConcurrency, true);
/*      */   }
/*      */ 
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, int resultSetType, int resultSetConcurrency, boolean processEscapeCodesIfNeeded) throws SQLException {
/* 1395 */     checkClosed();
/*      */     
/* 1397 */     String nativeSql = (processEscapeCodesIfNeeded && getProcessEscapeCodesForPrepStmts()) ? nativeSQL(sql) : sql;
/*      */     
/* 1399 */     PreparedStatement pStmt = null;
/*      */     
/* 1401 */     if (getCachePreparedStatements()) {
/* 1402 */       PreparedStatement.ParseInfo pStmtInfo = this.cachedPreparedStatementParams.get(nativeSql);
/*      */       
/* 1404 */       if (pStmtInfo == null) {
/* 1405 */         pStmt = PreparedStatement.getInstance(getMultiHostSafeProxy(), nativeSql, this.database);
/*      */         
/* 1407 */         this.cachedPreparedStatementParams.put(nativeSql, pStmt.getParseInfo());
/*      */       } else {
/* 1409 */         pStmt = PreparedStatement.getInstance(getMultiHostSafeProxy(), nativeSql, this.database, pStmtInfo);
/*      */       } 
/*      */     } else {
/* 1412 */       pStmt = PreparedStatement.getInstance(getMultiHostSafeProxy(), nativeSql, this.database);
/*      */     } 
/*      */     
/* 1415 */     pStmt.setResultSetType(resultSetType);
/* 1416 */     pStmt.setResultSetConcurrency(resultSetConcurrency);
/*      */     
/* 1418 */     return pStmt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, int[] autoGenKeyIndexes) throws SQLException {
/* 1426 */     PreparedStatement pStmt = (PreparedStatement)clientPrepareStatement(sql);
/*      */     
/* 1428 */     pStmt.setRetrieveGeneratedKeys((autoGenKeyIndexes != null && autoGenKeyIndexes.length > 0));
/*      */     
/* 1430 */     return pStmt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, String[] autoGenKeyColNames) throws SQLException {
/* 1437 */     PreparedStatement pStmt = (PreparedStatement)clientPrepareStatement(sql);
/*      */     
/* 1439 */     pStmt.setRetrieveGeneratedKeys((autoGenKeyColNames != null && autoGenKeyColNames.length > 0));
/*      */     
/* 1441 */     return pStmt;
/*      */   }
/*      */ 
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/* 1446 */     return clientPrepareStatement(sql, resultSetType, resultSetConcurrency, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws SQLException {
/* 1462 */     synchronized (getConnectionMutex()) {
/* 1463 */       if (this.connectionLifecycleInterceptors != null) {
/* 1464 */         (new IterateBlock<Extension>(this.connectionLifecycleInterceptors.iterator())
/*      */           {
/*      */             void forEach(Extension each) throws SQLException {
/* 1467 */               ((ConnectionLifecycleInterceptor)each).close();
/*      */             }
/*      */           }).doForAll();
/*      */       }
/*      */       
/* 1472 */       realClose(true, true, false, (Throwable)null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void closeAllOpenStatements() throws SQLException {
/* 1482 */     SQLException postponedException = null;
/*      */     
/* 1484 */     for (Statement stmt : this.openStatements) {
/*      */       try {
/* 1486 */         ((StatementImpl)stmt).realClose(false, true);
/* 1487 */       } catch (SQLException sqlEx) {
/* 1488 */         postponedException = sqlEx;
/*      */       } 
/*      */     } 
/*      */     
/* 1492 */     if (postponedException != null) {
/* 1493 */       throw postponedException;
/*      */     }
/*      */   }
/*      */   
/*      */   private void closeStatement(Statement stmt) {
/* 1498 */     if (stmt != null) {
/*      */       try {
/* 1500 */         stmt.close();
/* 1501 */       } catch (SQLException sqlEx) {}
/*      */ 
/*      */ 
/*      */       
/* 1505 */       stmt = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void commit() throws SQLException {
/* 1523 */     synchronized (getConnectionMutex()) {
/* 1524 */       checkClosed();
/*      */       
/*      */       try {
/* 1527 */         if (this.connectionLifecycleInterceptors != null) {
/* 1528 */           IterateBlock<Extension> iter = new IterateBlock<Extension>(this.connectionLifecycleInterceptors.iterator())
/*      */             {
/*      */               void forEach(Extension each) throws SQLException
/*      */               {
/* 1532 */                 if (!((ConnectionLifecycleInterceptor)each).commit()) {
/* 1533 */                   this.stopIterating = true;
/*      */                 }
/*      */               }
/*      */             };
/*      */           
/* 1538 */           iter.doForAll();
/*      */           
/* 1540 */           if (!iter.fullIteration()) {
/*      */             return;
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/* 1546 */         if (this.autoCommit && !getRelaxAutoCommit())
/* 1547 */           throw SQLError.createSQLException("Can't call commit when autocommit=true", getExceptionInterceptor()); 
/* 1548 */         if (this.transactionsSupported) {
/* 1549 */           if (getUseLocalTransactionState() && versionMeetsMinimum(5, 0, 0) && 
/* 1550 */             !this.io.inTransactionOnServer()) {
/*      */             return;
/*      */           }
/*      */ 
/*      */           
/* 1555 */           execSQL((StatementImpl)null, "commit", -1, (Buffer)null, 1003, 1007, false, this.database, (Field[])null, false);
/*      */         } 
/* 1557 */       } catch (SQLException sqlException) {
/* 1558 */         if ("08S01".equals(sqlException.getSQLState())) {
/* 1559 */           throw SQLError.createSQLException("Communications link failure during commit(). Transaction resolution unknown.", "08007", getExceptionInterceptor());
/*      */         }
/*      */ 
/*      */         
/* 1563 */         throw sqlException;
/*      */       } finally {
/* 1565 */         this.needsPing = getReconnectAtTxEnd();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void configureCharsetProperties() throws SQLException {
/* 1578 */     if (getEncoding() != null) {
/*      */       
/*      */       try {
/* 1581 */         String testString = "abc";
/* 1582 */         StringUtils.getBytes(testString, getEncoding());
/* 1583 */       } catch (UnsupportedEncodingException UE) {
/*      */         
/* 1585 */         String oldEncoding = getEncoding();
/*      */         
/*      */         try {
/* 1588 */           setEncoding(CharsetMapping.getJavaEncodingForMysqlCharset(oldEncoding));
/* 1589 */         } catch (RuntimeException ex) {
/* 1590 */           SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", (ExceptionInterceptor)null);
/* 1591 */           sqlEx.initCause(ex);
/* 1592 */           throw sqlEx;
/*      */         } 
/*      */         
/* 1595 */         if (getEncoding() == null) {
/* 1596 */           throw SQLError.createSQLException("Java does not support the MySQL character encoding '" + oldEncoding + "'.", "01S00", getExceptionInterceptor());
/*      */         }
/*      */ 
/*      */         
/*      */         try {
/* 1601 */           String testString = "abc";
/* 1602 */           StringUtils.getBytes(testString, getEncoding());
/* 1603 */         } catch (UnsupportedEncodingException encodingEx) {
/* 1604 */           throw SQLError.createSQLException("Unsupported character encoding '" + getEncoding() + "'.", "01S00", getExceptionInterceptor());
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean configureClientCharacterSet(boolean dontCheckServerMatch) throws SQLException {
/* 1625 */     String realJavaEncoding = getEncoding();
/* 1626 */     boolean characterSetAlreadyConfigured = false;
/*      */     
/*      */     try {
/* 1629 */       if (versionMeetsMinimum(4, 1, 0)) {
/* 1630 */         characterSetAlreadyConfigured = true;
/*      */         
/* 1632 */         setUseUnicode(true);
/*      */         
/* 1634 */         configureCharsetProperties();
/* 1635 */         realJavaEncoding = getEncoding();
/*      */         
/* 1637 */         String connectionCollationSuffix = "";
/* 1638 */         String connectionCollationCharset = "";
/*      */         
/* 1640 */         if (!getUseOldUTF8Behavior() && !StringUtils.isNullOrEmpty(getConnectionCollation())) {
/* 1641 */           for (int i = 1; i < CharsetMapping.COLLATION_INDEX_TO_COLLATION_NAME.length; i++) {
/* 1642 */             if (CharsetMapping.COLLATION_INDEX_TO_COLLATION_NAME[i].equals(getConnectionCollation())) {
/* 1643 */               connectionCollationSuffix = " COLLATE " + CharsetMapping.COLLATION_INDEX_TO_COLLATION_NAME[i];
/* 1644 */               connectionCollationCharset = (CharsetMapping.COLLATION_INDEX_TO_CHARSET[i]).charsetName;
/* 1645 */               realJavaEncoding = CharsetMapping.getJavaEncodingForCollationIndex(Integer.valueOf(i));
/*      */             } 
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/* 1654 */           if (this.props != null && this.props.getProperty("com.mysql.jdbc.faultInjection.serverCharsetIndex") != null) {
/* 1655 */             this.io.serverCharsetIndex = Integer.parseInt(this.props.getProperty("com.mysql.jdbc.faultInjection.serverCharsetIndex"));
/*      */           }
/*      */           
/* 1658 */           String serverEncodingToSet = CharsetMapping.getJavaEncodingForCollationIndex(Integer.valueOf(this.io.serverCharsetIndex));
/*      */           
/* 1660 */           if (serverEncodingToSet == null || serverEncodingToSet.length() == 0) {
/* 1661 */             if (realJavaEncoding != null) {
/*      */               
/* 1663 */               setEncoding(realJavaEncoding);
/*      */             } else {
/* 1665 */               throw SQLError.createSQLException("Unknown initial character set index '" + this.io.serverCharsetIndex + "' received from server. Initial client character set can be forced via the 'characterEncoding' property.", "S1000", getExceptionInterceptor());
/*      */             } 
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1673 */           if (versionMeetsMinimum(4, 1, 0) && "ISO8859_1".equalsIgnoreCase(serverEncodingToSet)) {
/* 1674 */             serverEncodingToSet = "Cp1252";
/*      */           }
/* 1676 */           if ("UnicodeBig".equalsIgnoreCase(serverEncodingToSet) || "UTF-16".equalsIgnoreCase(serverEncodingToSet) || "UTF-16LE".equalsIgnoreCase(serverEncodingToSet) || "UTF-32".equalsIgnoreCase(serverEncodingToSet))
/*      */           {
/* 1678 */             serverEncodingToSet = "UTF-8";
/*      */           }
/*      */           
/* 1681 */           setEncoding(serverEncodingToSet);
/*      */         }
/* 1683 */         catch (ArrayIndexOutOfBoundsException outOfBoundsEx) {
/* 1684 */           if (realJavaEncoding != null) {
/*      */             
/* 1686 */             setEncoding(realJavaEncoding);
/*      */           } else {
/* 1688 */             throw SQLError.createSQLException("Unknown initial character set index '" + this.io.serverCharsetIndex + "' received from server. Initial client character set can be forced via the 'characterEncoding' property.", "S1000", getExceptionInterceptor());
/*      */           
/*      */           }
/*      */         
/*      */         }
/* 1693 */         catch (SQLException ex) {
/* 1694 */           throw ex;
/* 1695 */         } catch (RuntimeException ex) {
/* 1696 */           SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", (ExceptionInterceptor)null);
/* 1697 */           sqlEx.initCause(ex);
/* 1698 */           throw sqlEx;
/*      */         } 
/*      */         
/* 1701 */         if (getEncoding() == null)
/*      */         {
/* 1703 */           setEncoding("ISO8859_1");
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1709 */         if (getUseUnicode()) {
/* 1710 */           if (realJavaEncoding != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1715 */             if (realJavaEncoding.equalsIgnoreCase("UTF-8") || realJavaEncoding.equalsIgnoreCase("UTF8")) {
/*      */ 
/*      */               
/* 1718 */               boolean utf8mb4Supported = versionMeetsMinimum(5, 5, 2);
/* 1719 */               String utf8CharsetName = (connectionCollationSuffix.length() > 0) ? connectionCollationCharset : (utf8mb4Supported ? "utf8mb4" : "utf8");
/*      */ 
/*      */               
/* 1722 */               if (!getUseOldUTF8Behavior()) {
/* 1723 */                 if (dontCheckServerMatch || !characterSetNamesMatches("utf8") || (utf8mb4Supported && !characterSetNamesMatches("utf8mb4")) || (connectionCollationSuffix.length() > 0 && !getConnectionCollation().equalsIgnoreCase(this.serverVariables.get("collation_server")))) {
/*      */ 
/*      */                   
/* 1726 */                   execSQL((StatementImpl)null, "SET NAMES " + utf8CharsetName + connectionCollationSuffix, -1, (Buffer)null, 1003, 1007, false, this.database, (Field[])null, false);
/*      */                   
/* 1728 */                   this.serverVariables.put("character_set_client", utf8CharsetName);
/* 1729 */                   this.serverVariables.put("character_set_connection", utf8CharsetName);
/*      */                 } 
/*      */               } else {
/* 1732 */                 execSQL((StatementImpl)null, "SET NAMES latin1", -1, (Buffer)null, 1003, 1007, false, this.database, (Field[])null, false);
/*      */                 
/* 1734 */                 this.serverVariables.put("character_set_client", "latin1");
/* 1735 */                 this.serverVariables.put("character_set_connection", "latin1");
/*      */               } 
/*      */               
/* 1738 */               setEncoding(realJavaEncoding);
/*      */             } else {
/* 1740 */               String mysqlCharsetName = (connectionCollationSuffix.length() > 0) ? connectionCollationCharset : CharsetMapping.getMysqlCharsetForJavaEncoding(realJavaEncoding.toUpperCase(Locale.ENGLISH), this);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1752 */               if (mysqlCharsetName != null)
/*      */               {
/* 1754 */                 if (dontCheckServerMatch || !characterSetNamesMatches(mysqlCharsetName)) {
/* 1755 */                   execSQL((StatementImpl)null, "SET NAMES " + mysqlCharsetName + connectionCollationSuffix, -1, (Buffer)null, 1003, 1007, false, this.database, (Field[])null, false);
/*      */                   
/* 1757 */                   this.serverVariables.put("character_set_client", mysqlCharsetName);
/* 1758 */                   this.serverVariables.put("character_set_connection", mysqlCharsetName);
/*      */                 } 
/*      */               }
/*      */ 
/*      */ 
/*      */               
/* 1764 */               setEncoding(realJavaEncoding);
/*      */             } 
/* 1766 */           } else if (getEncoding() != null) {
/*      */             
/* 1768 */             String mysqlCharsetName = (connectionCollationSuffix.length() > 0) ? connectionCollationCharset : (getUseOldUTF8Behavior() ? "latin1" : getServerCharset());
/*      */ 
/*      */             
/* 1771 */             boolean ucs2 = false;
/* 1772 */             if ("ucs2".equalsIgnoreCase(mysqlCharsetName) || "utf16".equalsIgnoreCase(mysqlCharsetName) || "utf16le".equalsIgnoreCase(mysqlCharsetName) || "utf32".equalsIgnoreCase(mysqlCharsetName)) {
/*      */               
/* 1774 */               mysqlCharsetName = "utf8";
/* 1775 */               ucs2 = true;
/* 1776 */               if (getCharacterSetResults() == null) {
/* 1777 */                 setCharacterSetResults("UTF-8");
/*      */               }
/*      */             } 
/*      */             
/* 1781 */             if (dontCheckServerMatch || !characterSetNamesMatches(mysqlCharsetName) || ucs2) {
/*      */               try {
/* 1783 */                 execSQL((StatementImpl)null, "SET NAMES " + mysqlCharsetName + connectionCollationSuffix, -1, (Buffer)null, 1003, 1007, false, this.database, (Field[])null, false);
/*      */                 
/* 1785 */                 this.serverVariables.put("character_set_client", mysqlCharsetName);
/* 1786 */                 this.serverVariables.put("character_set_connection", mysqlCharsetName);
/* 1787 */               } catch (SQLException ex) {
/* 1788 */                 if (ex.getErrorCode() != 1820 || getDisconnectOnExpiredPasswords()) {
/* 1789 */                   throw ex;
/*      */                 }
/*      */               } 
/*      */             }
/*      */             
/* 1794 */             realJavaEncoding = getEncoding();
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1804 */         String onServer = null;
/* 1805 */         boolean isNullOnServer = false;
/*      */         
/* 1807 */         if (this.serverVariables != null) {
/* 1808 */           onServer = this.serverVariables.get("character_set_results");
/*      */           
/* 1810 */           isNullOnServer = (onServer == null || "NULL".equalsIgnoreCase(onServer) || onServer.length() == 0);
/*      */         } 
/*      */         
/* 1813 */         if (getCharacterSetResults() == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1818 */           if (!isNullOnServer) {
/*      */             try {
/* 1820 */               execSQL((StatementImpl)null, "SET character_set_results = NULL", -1, (Buffer)null, 1003, 1007, false, this.database, (Field[])null, false);
/*      */             }
/* 1822 */             catch (SQLException ex) {
/* 1823 */               if (ex.getErrorCode() != 1820 || getDisconnectOnExpiredPasswords()) {
/* 1824 */                 throw ex;
/*      */               }
/*      */             } 
/* 1827 */             this.serverVariables.put("jdbc.local.character_set_results", null);
/*      */           } else {
/* 1829 */             this.serverVariables.put("jdbc.local.character_set_results", onServer);
/*      */           } 
/*      */         } else {
/*      */           
/* 1833 */           if (getUseOldUTF8Behavior()) {
/*      */             try {
/* 1835 */               execSQL((StatementImpl)null, "SET NAMES latin1", -1, (Buffer)null, 1003, 1007, false, this.database, (Field[])null, false);
/*      */               
/* 1837 */               this.serverVariables.put("character_set_client", "latin1");
/* 1838 */               this.serverVariables.put("character_set_connection", "latin1");
/* 1839 */             } catch (SQLException ex) {
/* 1840 */               if (ex.getErrorCode() != 1820 || getDisconnectOnExpiredPasswords()) {
/* 1841 */                 throw ex;
/*      */               }
/*      */             } 
/*      */           }
/* 1845 */           String charsetResults = getCharacterSetResults();
/* 1846 */           String mysqlEncodingName = null;
/*      */           
/* 1848 */           if ("UTF-8".equalsIgnoreCase(charsetResults) || "UTF8".equalsIgnoreCase(charsetResults)) {
/* 1849 */             mysqlEncodingName = "utf8";
/* 1850 */           } else if ("null".equalsIgnoreCase(charsetResults)) {
/* 1851 */             mysqlEncodingName = "NULL";
/*      */           } else {
/* 1853 */             mysqlEncodingName = CharsetMapping.getMysqlCharsetForJavaEncoding(charsetResults.toUpperCase(Locale.ENGLISH), this);
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1860 */           if (mysqlEncodingName == null) {
/* 1861 */             throw SQLError.createSQLException("Can't map " + charsetResults + " given for characterSetResults to a supported MySQL encoding.", "S1009", getExceptionInterceptor());
/*      */           }
/*      */ 
/*      */           
/* 1865 */           if (!mysqlEncodingName.equalsIgnoreCase(this.serverVariables.get("character_set_results"))) {
/* 1866 */             StringBuilder setBuf = new StringBuilder("SET character_set_results = ".length() + mysqlEncodingName.length());
/* 1867 */             setBuf.append("SET character_set_results = ").append(mysqlEncodingName);
/*      */             
/*      */             try {
/* 1870 */               execSQL((StatementImpl)null, setBuf.toString(), -1, (Buffer)null, 1003, 1007, false, this.database, (Field[])null, false);
/*      */             }
/* 1872 */             catch (SQLException ex) {
/* 1873 */               if (ex.getErrorCode() != 1820 || getDisconnectOnExpiredPasswords()) {
/* 1874 */                 throw ex;
/*      */               }
/*      */             } 
/*      */             
/* 1878 */             this.serverVariables.put("jdbc.local.character_set_results", mysqlEncodingName);
/*      */ 
/*      */             
/* 1881 */             if (versionMeetsMinimum(5, 5, 0)) {
/* 1882 */               this.errorMessageEncoding = charsetResults;
/*      */             }
/*      */           } else {
/*      */             
/* 1886 */             this.serverVariables.put("jdbc.local.character_set_results", onServer);
/*      */           } 
/*      */         } 
/*      */       } else {
/*      */         
/* 1891 */         realJavaEncoding = getEncoding();
/*      */       }
/*      */     
/*      */     }
/*      */     finally {
/*      */       
/* 1897 */       setEncoding(realJavaEncoding);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1905 */       CharsetEncoder enc = Charset.forName(getEncoding()).newEncoder();
/* 1906 */       CharBuffer cbuf = CharBuffer.allocate(1);
/* 1907 */       ByteBuffer bbuf = ByteBuffer.allocate(1);
/*      */       
/* 1909 */       cbuf.put("¥");
/* 1910 */       cbuf.position(0);
/* 1911 */       enc.encode(cbuf, bbuf, true);
/* 1912 */       if (bbuf.get(0) == 92) {
/* 1913 */         this.requiresEscapingEncoder = true;
/*      */       } else {
/* 1915 */         cbuf.clear();
/* 1916 */         bbuf.clear();
/*      */         
/* 1918 */         cbuf.put("₩");
/* 1919 */         cbuf.position(0);
/* 1920 */         enc.encode(cbuf, bbuf, true);
/* 1921 */         if (bbuf.get(0) == 92) {
/* 1922 */           this.requiresEscapingEncoder = true;
/*      */         }
/*      */       } 
/* 1925 */     } catch (UnsupportedCharsetException ucex) {
/*      */       
/*      */       try {
/* 1928 */         byte[] bbuf = StringUtils.getBytes("¥", getEncoding());
/* 1929 */         if (bbuf[0] == 92) {
/* 1930 */           this.requiresEscapingEncoder = true;
/*      */         } else {
/* 1932 */           bbuf = StringUtils.getBytes("₩", getEncoding());
/* 1933 */           if (bbuf[0] == 92) {
/* 1934 */             this.requiresEscapingEncoder = true;
/*      */           }
/*      */         } 
/* 1937 */       } catch (UnsupportedEncodingException ueex) {
/* 1938 */         throw SQLError.createSQLException("Unable to use encoding: " + getEncoding(), "S1000", ueex, getExceptionInterceptor());
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1943 */     return characterSetAlreadyConfigured;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void configureTimezone() throws SQLException {
/* 1954 */     String configuredTimeZoneOnServer = this.serverVariables.get("timezone");
/*      */     
/* 1956 */     if (configuredTimeZoneOnServer == null) {
/* 1957 */       configuredTimeZoneOnServer = this.serverVariables.get("time_zone");
/*      */       
/* 1959 */       if ("SYSTEM".equalsIgnoreCase(configuredTimeZoneOnServer)) {
/* 1960 */         configuredTimeZoneOnServer = this.serverVariables.get("system_time_zone");
/*      */       }
/*      */     } 
/*      */     
/* 1964 */     String canonicalTimezone = getServerTimezone();
/*      */     
/* 1966 */     if ((getUseTimezone() || !getUseLegacyDatetimeCode()) && configuredTimeZoneOnServer != null)
/*      */     {
/* 1968 */       if (canonicalTimezone == null || StringUtils.isEmptyOrWhitespaceOnly(canonicalTimezone)) {
/*      */         try {
/* 1970 */           canonicalTimezone = TimeUtil.getCanonicalTimezone(configuredTimeZoneOnServer, getExceptionInterceptor());
/* 1971 */         } catch (IllegalArgumentException iae) {
/* 1972 */           throw SQLError.createSQLException(iae.getMessage(), "S1000", getExceptionInterceptor());
/*      */         } 
/*      */       }
/*      */     }
/*      */     
/* 1977 */     if (canonicalTimezone != null && canonicalTimezone.length() > 0) {
/* 1978 */       this.serverTimezoneTZ = TimeZone.getTimeZone(canonicalTimezone);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1983 */       if (!canonicalTimezone.equalsIgnoreCase("GMT") && this.serverTimezoneTZ.getID().equals("GMT")) {
/* 1984 */         throw SQLError.createSQLException("No timezone mapping entry for '" + canonicalTimezone + "'", "S1009", getExceptionInterceptor());
/*      */       }
/*      */ 
/*      */       
/* 1988 */       this.isServerTzUTC = (!this.serverTimezoneTZ.useDaylightTime() && this.serverTimezoneTZ.getRawOffset() == 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void createInitialHistogram(long[] breakpoints, long lowerBound, long upperBound) {
/* 1994 */     double bucketSize = (upperBound - lowerBound) / 20.0D * 1.25D;
/*      */     
/* 1996 */     if (bucketSize < 1.0D) {
/* 1997 */       bucketSize = 1.0D;
/*      */     }
/*      */     
/* 2000 */     for (int i = 0; i < 20; i++) {
/* 2001 */       breakpoints[i] = lowerBound;
/* 2002 */       lowerBound = (long)(lowerBound + bucketSize);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void createNewIO(boolean isForReconnect) throws SQLException {
/* 2017 */     synchronized (getConnectionMutex()) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2022 */       Properties mergedProps = exposeAsProperties(this.props);
/*      */       
/* 2024 */       if (!getHighAvailability()) {
/* 2025 */         connectOneTryOnly(isForReconnect, mergedProps);
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/* 2030 */       connectWithRetries(isForReconnect, mergedProps);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void connectWithRetries(boolean isForReconnect, Properties mergedProps) throws SQLException {
/* 2035 */     double timeout = getInitialTimeout();
/* 2036 */     boolean connectionGood = false;
/*      */     
/* 2038 */     Exception connectionException = null;
/*      */     
/* 2040 */     for (int attemptCount = 0; attemptCount < getMaxReconnects() && !connectionGood; attemptCount++) {
/*      */       try {
/* 2042 */         boolean oldAutoCommit; int oldIsolationLevel; boolean oldReadOnly; String oldCatalog; if (this.io != null) {
/* 2043 */           this.io.forceClose();
/*      */         }
/*      */         
/* 2046 */         coreConnect(mergedProps);
/* 2047 */         pingInternal(false, 0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2054 */         synchronized (getConnectionMutex()) {
/* 2055 */           this.connectionId = this.io.getThreadId();
/* 2056 */           this.isClosed = false;
/*      */ 
/*      */           
/* 2059 */           oldAutoCommit = getAutoCommit();
/* 2060 */           oldIsolationLevel = this.isolationLevel;
/* 2061 */           oldReadOnly = isReadOnly(false);
/* 2062 */           oldCatalog = getCatalog();
/*      */           
/* 2064 */           this.io.setStatementInterceptors(this.statementInterceptors);
/*      */         } 
/*      */ 
/*      */         
/* 2068 */         initializePropsFromServer();
/*      */         
/* 2070 */         if (isForReconnect) {
/*      */           
/* 2072 */           setAutoCommit(oldAutoCommit);
/*      */           
/* 2074 */           if (this.hasIsolationLevels) {
/* 2075 */             setTransactionIsolation(oldIsolationLevel);
/*      */           }
/*      */           
/* 2078 */           setCatalog(oldCatalog);
/* 2079 */           setReadOnly(oldReadOnly);
/*      */         } 
/*      */         
/* 2082 */         connectionGood = true;
/*      */         
/*      */         break;
/* 2085 */       } catch (Exception EEE) {
/* 2086 */         connectionException = EEE;
/* 2087 */         connectionGood = false;
/*      */ 
/*      */         
/* 2090 */         if (connectionGood) {
/*      */           break;
/*      */         }
/*      */         
/* 2094 */         if (attemptCount > 0) {
/*      */           try {
/* 2096 */             Thread.sleep((long)timeout * 1000L);
/* 2097 */           } catch (InterruptedException IE) {}
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 2103 */     if (!connectionGood) {
/*      */       
/* 2105 */       SQLException chainedEx = SQLError.createSQLException(Messages.getString("Connection.UnableToConnectWithRetries", new Object[] { Integer.valueOf(getMaxReconnects()) }), "08001", getExceptionInterceptor());
/*      */ 
/*      */       
/* 2108 */       chainedEx.initCause(connectionException);
/*      */       
/* 2110 */       throw chainedEx;
/*      */     } 
/*      */     
/* 2113 */     if (getParanoid() && !getHighAvailability()) {
/* 2114 */       this.password = null;
/* 2115 */       this.user = null;
/*      */     } 
/*      */     
/* 2118 */     if (isForReconnect) {
/*      */ 
/*      */ 
/*      */       
/* 2122 */       Iterator<Statement> statementIter = this.openStatements.iterator();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2128 */       Stack<Statement> serverPreparedStatements = null;
/*      */       
/* 2130 */       while (statementIter.hasNext()) {
/* 2131 */         Statement statementObj = statementIter.next();
/*      */         
/* 2133 */         if (statementObj instanceof ServerPreparedStatement) {
/* 2134 */           if (serverPreparedStatements == null) {
/* 2135 */             serverPreparedStatements = new Stack<Statement>();
/*      */           }
/*      */           
/* 2138 */           serverPreparedStatements.add(statementObj);
/*      */         } 
/*      */       } 
/*      */       
/* 2142 */       if (serverPreparedStatements != null) {
/* 2143 */         while (!serverPreparedStatements.isEmpty()) {
/* 2144 */           ((ServerPreparedStatement)serverPreparedStatements.pop()).rePrepare();
/*      */         }
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private void coreConnect(Properties mergedProps) throws SQLException, IOException {
/* 2151 */     int newPort = 3306;
/* 2152 */     String newHost = "localhost";
/*      */     
/* 2154 */     String protocol = mergedProps.getProperty("PROTOCOL");
/*      */     
/* 2156 */     if (protocol != null) {
/*      */ 
/*      */       
/* 2159 */       if ("tcp".equalsIgnoreCase(protocol)) {
/* 2160 */         newHost = normalizeHost(mergedProps.getProperty("HOST"));
/* 2161 */         newPort = parsePortNumber(mergedProps.getProperty("PORT", "3306"));
/* 2162 */       } else if ("pipe".equalsIgnoreCase(protocol)) {
/* 2163 */         setSocketFactoryClassName(NamedPipeSocketFactory.class.getName());
/*      */         
/* 2165 */         String path = mergedProps.getProperty("PATH");
/*      */         
/* 2167 */         if (path != null) {
/* 2168 */           mergedProps.setProperty("namedPipePath", path);
/*      */         }
/*      */       } else {
/*      */         
/* 2172 */         newHost = normalizeHost(mergedProps.getProperty("HOST"));
/* 2173 */         newPort = parsePortNumber(mergedProps.getProperty("PORT", "3306"));
/*      */       } 
/*      */     } else {
/*      */       
/* 2177 */       String[] parsedHostPortPair = NonRegisteringDriver.parseHostPortPair(this.hostPortPair);
/* 2178 */       newHost = parsedHostPortPair[0];
/*      */       
/* 2180 */       newHost = normalizeHost(newHost);
/*      */       
/* 2182 */       if (parsedHostPortPair[1] != null) {
/* 2183 */         newPort = parsePortNumber(parsedHostPortPair[1]);
/*      */       }
/*      */     } 
/*      */     
/* 2187 */     this.port = newPort;
/* 2188 */     this.host = newHost;
/*      */ 
/*      */     
/* 2191 */     this.sessionMaxRows = -1;
/*      */ 
/*      */     
/* 2194 */     this.serverVariables = new HashMap<String, String>();
/* 2195 */     this.serverVariables.put("character_set_server", "utf8");
/*      */     
/* 2197 */     this.io = new MysqlIO(newHost, newPort, mergedProps, getSocketFactoryClassName(), getProxy(), getSocketTimeout(), this.largeRowSizeThreshold.getValueAsInt());
/*      */     
/* 2199 */     this.io.doHandshake(this.user, this.password, this.database);
/* 2200 */     if (versionMeetsMinimum(5, 5, 0))
/*      */     {
/* 2202 */       this.errorMessageEncoding = this.io.getEncodingForHandshake();
/*      */     }
/*      */   }
/*      */   
/*      */   private String normalizeHost(String hostname) {
/* 2207 */     if (hostname == null || StringUtils.isEmptyOrWhitespaceOnly(hostname)) {
/* 2208 */       return "localhost";
/*      */     }
/*      */     
/* 2211 */     return hostname;
/*      */   }
/*      */   
/*      */   private int parsePortNumber(String portAsString) throws SQLException {
/* 2215 */     int portNumber = 3306;
/*      */     try {
/* 2217 */       portNumber = Integer.parseInt(portAsString);
/* 2218 */     } catch (NumberFormatException nfe) {
/* 2219 */       throw SQLError.createSQLException("Illegal connection port value '" + portAsString + "'", "01S00", getExceptionInterceptor());
/*      */     } 
/*      */     
/* 2222 */     return portNumber;
/*      */   }
/*      */   
/*      */   private void connectOneTryOnly(boolean isForReconnect, Properties mergedProps) throws SQLException {
/* 2226 */     Exception connectionNotEstablishedBecause = null;
/*      */ 
/*      */     
/*      */     try {
/* 2230 */       coreConnect(mergedProps);
/* 2231 */       this.connectionId = this.io.getThreadId();
/* 2232 */       this.isClosed = false;
/*      */ 
/*      */       
/* 2235 */       boolean oldAutoCommit = getAutoCommit();
/* 2236 */       int oldIsolationLevel = this.isolationLevel;
/* 2237 */       boolean oldReadOnly = isReadOnly(false);
/* 2238 */       String oldCatalog = getCatalog();
/*      */       
/* 2240 */       this.io.setStatementInterceptors(this.statementInterceptors);
/*      */ 
/*      */       
/* 2243 */       initializePropsFromServer();
/*      */       
/* 2245 */       if (isForReconnect) {
/*      */         
/* 2247 */         setAutoCommit(oldAutoCommit);
/*      */         
/* 2249 */         if (this.hasIsolationLevels) {
/* 2250 */           setTransactionIsolation(oldIsolationLevel);
/*      */         }
/*      */         
/* 2253 */         setCatalog(oldCatalog);
/*      */         
/* 2255 */         setReadOnly(oldReadOnly);
/*      */       } 
/*      */       
/*      */       return;
/* 2259 */     } catch (Exception EEE) {
/*      */       
/* 2261 */       if (EEE instanceof SQLException && ((SQLException)EEE).getErrorCode() == 1820 && !getDisconnectOnExpiredPasswords()) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/* 2266 */       if (this.io != null) {
/* 2267 */         this.io.forceClose();
/*      */       }
/*      */       
/* 2270 */       connectionNotEstablishedBecause = EEE;
/*      */       
/* 2272 */       if (EEE instanceof SQLException) {
/* 2273 */         throw (SQLException)EEE;
/*      */       }
/*      */       
/* 2276 */       SQLException chainedEx = SQLError.createSQLException(Messages.getString("Connection.UnableToConnect"), "08001", getExceptionInterceptor());
/*      */       
/* 2278 */       chainedEx.initCause(connectionNotEstablishedBecause);
/*      */       
/* 2280 */       throw chainedEx;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void createPreparedStatementCaches() throws SQLException {
/* 2285 */     synchronized (getConnectionMutex()) {
/* 2286 */       int cacheSize = getPreparedStatementCacheSize();
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 2291 */         Class<?> factoryClass = Class.forName(getParseInfoCacheFactory());
/*      */ 
/*      */         
/* 2294 */         CacheAdapterFactory<String, PreparedStatement.ParseInfo> cacheFactory = (CacheAdapterFactory<String, PreparedStatement.ParseInfo>)factoryClass.newInstance();
/*      */         
/* 2296 */         this.cachedPreparedStatementParams = cacheFactory.getInstance(this, this.myURL, getPreparedStatementCacheSize(), getPreparedStatementCacheSqlLimit(), this.props);
/*      */       
/*      */       }
/* 2299 */       catch (ClassNotFoundException e) {
/* 2300 */         SQLException sqlEx = SQLError.createSQLException(Messages.getString("Connection.CantFindCacheFactory", new Object[] { getParseInfoCacheFactory(), "parseInfoCacheFactory" }), getExceptionInterceptor());
/*      */ 
/*      */         
/* 2303 */         sqlEx.initCause(e);
/*      */         
/* 2305 */         throw sqlEx;
/* 2306 */       } catch (InstantiationException e) {
/* 2307 */         SQLException sqlEx = SQLError.createSQLException(Messages.getString("Connection.CantLoadCacheFactory", new Object[] { getParseInfoCacheFactory(), "parseInfoCacheFactory" }), getExceptionInterceptor());
/*      */ 
/*      */         
/* 2310 */         sqlEx.initCause(e);
/*      */         
/* 2312 */         throw sqlEx;
/* 2313 */       } catch (IllegalAccessException e) {
/* 2314 */         SQLException sqlEx = SQLError.createSQLException(Messages.getString("Connection.CantLoadCacheFactory", new Object[] { getParseInfoCacheFactory(), "parseInfoCacheFactory" }), getExceptionInterceptor());
/*      */ 
/*      */         
/* 2317 */         sqlEx.initCause(e);
/*      */         
/* 2319 */         throw sqlEx;
/*      */       } 
/*      */       
/* 2322 */       if (getUseServerPreparedStmts()) {
/* 2323 */         this.serverSideStatementCheckCache = new LRUCache(cacheSize);
/*      */         
/* 2325 */         this.serverSideStatementCache = new LRUCache<CompoundCacheKey, ServerPreparedStatement>(cacheSize)
/*      */           {
/*      */             private static final long serialVersionUID = 7692318650375988114L;
/*      */ 
/*      */             
/*      */             protected boolean removeEldestEntry(Map.Entry<ConnectionImpl.CompoundCacheKey, ServerPreparedStatement> eldest) {
/* 2331 */               if (this.maxElements <= 1) {
/* 2332 */                 return false;
/*      */               }
/*      */               
/* 2335 */               boolean removeIt = super.removeEldestEntry(eldest);
/*      */               
/* 2337 */               if (removeIt) {
/* 2338 */                 ServerPreparedStatement ps = eldest.getValue();
/* 2339 */                 ps.isCached = false;
/* 2340 */                 ps.setClosed(false);
/*      */                 
/*      */                 try {
/* 2343 */                   ps.close();
/* 2344 */                 } catch (SQLException sqlEx) {}
/*      */               } 
/*      */ 
/*      */ 
/*      */               
/* 2349 */               return removeIt;
/*      */             }
/*      */           };
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Statement createStatement() throws SQLException {
/* 2366 */     return createStatement(1003, 1007);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Statement createStatement(int resultSetType, int resultSetConcurrency) throws SQLException {
/* 2382 */     checkClosed();
/*      */     
/* 2384 */     StatementImpl stmt = new StatementImpl(getMultiHostSafeProxy(), this.database);
/* 2385 */     stmt.setResultSetType(resultSetType);
/* 2386 */     stmt.setResultSetConcurrency(resultSetConcurrency);
/*      */     
/* 2388 */     return stmt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Statement createStatement(int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/* 2395 */     if (getPedantic() && 
/* 2396 */       resultSetHoldability != 1) {
/* 2397 */       throw SQLError.createSQLException("HOLD_CUSRORS_OVER_COMMIT is only supported holdability level", "S1009", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2402 */     return createStatement(resultSetType, resultSetConcurrency);
/*      */   }
/*      */   
/*      */   public void dumpTestcaseQuery(String query) {
/* 2406 */     System.err.println(query);
/*      */   }
/*      */   
/*      */   public Connection duplicate() throws SQLException {
/* 2410 */     return new ConnectionImpl(this.origHostToConnectTo, this.origPortToConnectTo, this.props, this.origDatabaseToConnectTo, this.myURL);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSetInternalMethods execSQL(StatementImpl callingStatement, String sql, int maxRows, Buffer packet, int resultSetType, int resultSetConcurrency, boolean streamResults, String catalog, Field[] cachedMetadata) throws SQLException {
/* 2449 */     return execSQL(callingStatement, sql, maxRows, packet, resultSetType, resultSetConcurrency, streamResults, catalog, cachedMetadata, false);
/*      */   }
/*      */ 
/*      */   
/*      */   public ResultSetInternalMethods execSQL(StatementImpl callingStatement, String sql, int maxRows, Buffer packet, int resultSetType, int resultSetConcurrency, boolean streamResults, String catalog, Field[] cachedMetadata, boolean isBatch) throws SQLException {
/* 2454 */     synchronized (getConnectionMutex()) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2459 */       long queryStartTime = 0L;
/*      */       
/* 2461 */       int endOfQueryPacketPosition = 0;
/*      */       
/* 2463 */       if (packet != null) {
/* 2464 */         endOfQueryPacketPosition = packet.getPosition();
/*      */       }
/*      */       
/* 2467 */       if (getGatherPerformanceMetrics()) {
/* 2468 */         queryStartTime = System.currentTimeMillis();
/*      */       }
/*      */       
/* 2471 */       this.lastQueryFinishedTime = 0L;
/*      */       
/* 2473 */       if (getHighAvailability() && (this.autoCommit || getAutoReconnectForPools()) && this.needsPing && !isBatch) {
/*      */         try {
/* 2475 */           pingInternal(false, 0);
/*      */           
/* 2477 */           this.needsPing = false;
/* 2478 */         } catch (Exception Ex) {
/* 2479 */           createNewIO(true);
/*      */         } 
/*      */       }
/*      */       
/*      */       try {
/* 2484 */         if (packet == null) {
/* 2485 */           String encoding = null;
/*      */           
/* 2487 */           if (getUseUnicode()) {
/* 2488 */             encoding = getEncoding();
/*      */           }
/*      */           
/* 2491 */           return this.io.sqlQueryDirect(callingStatement, sql, encoding, null, maxRows, resultSetType, resultSetConcurrency, streamResults, catalog, cachedMetadata);
/*      */         } 
/*      */ 
/*      */         
/* 2495 */         return this.io.sqlQueryDirect(callingStatement, null, null, packet, maxRows, resultSetType, resultSetConcurrency, streamResults, catalog, cachedMetadata);
/*      */       }
/* 2497 */       catch (SQLException sqlE) {
/*      */ 
/*      */         
/* 2500 */         if (getDumpQueriesOnException()) {
/* 2501 */           String extractedSql = extractSqlFromPacket(sql, packet, endOfQueryPacketPosition);
/* 2502 */           StringBuilder messageBuf = new StringBuilder(extractedSql.length() + 32);
/* 2503 */           messageBuf.append("\n\nQuery being executed when exception was thrown:\n");
/* 2504 */           messageBuf.append(extractedSql);
/* 2505 */           messageBuf.append("\n\n");
/*      */           
/* 2507 */           sqlE = appendMessageToException(sqlE, messageBuf.toString(), getExceptionInterceptor());
/*      */         } 
/*      */         
/* 2510 */         if (getHighAvailability()) {
/* 2511 */           if ("08S01".equals(sqlE.getSQLState()))
/*      */           {
/* 2513 */             this.io.forceClose();
/*      */           }
/* 2515 */           this.needsPing = true;
/* 2516 */         } else if ("08S01".equals(sqlE.getSQLState())) {
/* 2517 */           cleanup(sqlE);
/*      */         } 
/*      */         
/* 2520 */         throw sqlE;
/* 2521 */       } catch (Exception ex) {
/* 2522 */         if (getHighAvailability()) {
/* 2523 */           if (ex instanceof IOException)
/*      */           {
/* 2525 */             this.io.forceClose();
/*      */           }
/* 2527 */           this.needsPing = true;
/* 2528 */         } else if (ex instanceof IOException) {
/* 2529 */           cleanup(ex);
/*      */         } 
/*      */         
/* 2532 */         SQLException sqlEx = SQLError.createSQLException(Messages.getString("Connection.UnexpectedException"), "S1000", getExceptionInterceptor());
/*      */         
/* 2534 */         sqlEx.initCause(ex);
/*      */         
/* 2536 */         throw sqlEx;
/*      */       } finally {
/* 2538 */         if (getMaintainTimeStats()) {
/* 2539 */           this.lastQueryFinishedTime = System.currentTimeMillis();
/*      */         }
/*      */         
/* 2542 */         if (getGatherPerformanceMetrics()) {
/* 2543 */           long queryTime = System.currentTimeMillis() - queryStartTime;
/*      */           
/* 2545 */           registerQueryExecutionTime(queryTime);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public String extractSqlFromPacket(String possibleSqlQuery, Buffer queryPacket, int endOfQueryPacketPosition) throws SQLException {
/* 2553 */     String extractedSql = null;
/*      */     
/* 2555 */     if (possibleSqlQuery != null) {
/* 2556 */       if (possibleSqlQuery.length() > getMaxQuerySizeToLog()) {
/* 2557 */         StringBuilder truncatedQueryBuf = new StringBuilder(possibleSqlQuery.substring(0, getMaxQuerySizeToLog()));
/* 2558 */         truncatedQueryBuf.append(Messages.getString("MysqlIO.25"));
/* 2559 */         extractedSql = truncatedQueryBuf.toString();
/*      */       } else {
/* 2561 */         extractedSql = possibleSqlQuery;
/*      */       } 
/*      */     }
/*      */     
/* 2565 */     if (extractedSql == null) {
/*      */ 
/*      */       
/* 2568 */       int extractPosition = endOfQueryPacketPosition;
/*      */       
/* 2570 */       boolean truncated = false;
/*      */       
/* 2572 */       if (endOfQueryPacketPosition > getMaxQuerySizeToLog()) {
/* 2573 */         extractPosition = getMaxQuerySizeToLog();
/* 2574 */         truncated = true;
/*      */       } 
/*      */       
/* 2577 */       extractedSql = StringUtils.toString(queryPacket.getByteBuffer(), 5, extractPosition - 5);
/*      */       
/* 2579 */       if (truncated) {
/* 2580 */         extractedSql = extractedSql + Messages.getString("MysqlIO.25");
/*      */       }
/*      */     } 
/*      */     
/* 2584 */     return extractedSql;
/*      */   }
/*      */ 
/*      */   
/*      */   public StringBuilder generateConnectionCommentBlock(StringBuilder buf) {
/* 2589 */     buf.append("/* conn id ");
/* 2590 */     buf.append(getId());
/* 2591 */     buf.append(" clock: ");
/* 2592 */     buf.append(System.currentTimeMillis());
/* 2593 */     buf.append(" */ ");
/*      */     
/* 2595 */     return buf;
/*      */   }
/*      */   
/*      */   public int getActiveStatementCount() {
/* 2599 */     return this.openStatements.size();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getAutoCommit() throws SQLException {
/* 2611 */     synchronized (getConnectionMutex()) {
/* 2612 */       return this.autoCommit;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Calendar getCalendarInstanceForSessionOrNew() {
/* 2621 */     if (getDynamicCalendars()) {
/* 2622 */       return Calendar.getInstance();
/*      */     }
/*      */     
/* 2625 */     return getSessionLockedCalendar();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCatalog() throws SQLException {
/* 2640 */     synchronized (getConnectionMutex()) {
/* 2641 */       return this.database;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCharacterSetMetadata() {
/* 2649 */     synchronized (getConnectionMutex()) {
/* 2650 */       return this.characterSetMetadata;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SingleByteCharsetConverter getCharsetConverter(String javaEncodingName) throws SQLException {
/* 2663 */     if (javaEncodingName == null) {
/* 2664 */       return null;
/*      */     }
/*      */     
/* 2667 */     if (this.usePlatformCharsetConverters) {
/* 2668 */       return null;
/*      */     }
/*      */     
/* 2671 */     SingleByteCharsetConverter converter = null;
/*      */     
/* 2673 */     synchronized (this.charsetConverterMap) {
/* 2674 */       Object asObject = this.charsetConverterMap.get(javaEncodingName);
/*      */       
/* 2676 */       if (asObject == CHARSET_CONVERTER_NOT_AVAILABLE_MARKER) {
/* 2677 */         return null;
/*      */       }
/*      */       
/* 2680 */       converter = (SingleByteCharsetConverter)asObject;
/*      */       
/* 2682 */       if (converter == null) {
/*      */         try {
/* 2684 */           converter = SingleByteCharsetConverter.getInstance(javaEncodingName, this);
/*      */           
/* 2686 */           if (converter == null) {
/* 2687 */             this.charsetConverterMap.put(javaEncodingName, CHARSET_CONVERTER_NOT_AVAILABLE_MARKER);
/*      */           } else {
/* 2689 */             this.charsetConverterMap.put(javaEncodingName, converter);
/*      */           } 
/* 2691 */         } catch (UnsupportedEncodingException unsupEncEx) {
/* 2692 */           this.charsetConverterMap.put(javaEncodingName, CHARSET_CONVERTER_NOT_AVAILABLE_MARKER);
/*      */           
/* 2694 */           converter = null;
/*      */         } 
/*      */       }
/*      */     } 
/*      */     
/* 2699 */     return converter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String getCharsetNameForIndex(int charsetIndex) throws SQLException {
/* 2707 */     return getEncodingForIndex(charsetIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getEncodingForIndex(int charsetIndex) throws SQLException {
/* 2721 */     String javaEncoding = null;
/*      */     
/* 2723 */     if (getUseOldUTF8Behavior()) {
/* 2724 */       return getEncoding();
/*      */     }
/*      */     
/* 2727 */     if (charsetIndex != -1) {
/*      */ 
/*      */       
/*      */       try {
/* 2731 */         if (this.indexToCustomMysqlCharset != null) {
/* 2732 */           String cs = this.indexToCustomMysqlCharset.get(Integer.valueOf(charsetIndex));
/* 2733 */           if (cs != null) {
/* 2734 */             javaEncoding = CharsetMapping.getJavaEncodingForMysqlCharset(cs, getEncoding());
/*      */           }
/*      */         } 
/*      */         
/* 2738 */         if (javaEncoding == null) {
/* 2739 */           javaEncoding = CharsetMapping.getJavaEncodingForCollationIndex(Integer.valueOf(charsetIndex), getEncoding());
/*      */         }
/*      */       }
/* 2742 */       catch (ArrayIndexOutOfBoundsException outOfBoundsEx) {
/* 2743 */         throw SQLError.createSQLException("Unknown character set index for field '" + charsetIndex + "' received from server.", "S1000", getExceptionInterceptor());
/*      */       }
/* 2745 */       catch (RuntimeException ex) {
/* 2746 */         SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", (ExceptionInterceptor)null);
/* 2747 */         sqlEx.initCause(ex);
/* 2748 */         throw sqlEx;
/*      */       } 
/*      */ 
/*      */       
/* 2752 */       if (javaEncoding == null) {
/* 2753 */         javaEncoding = getEncoding();
/*      */       }
/*      */     } else {
/* 2756 */       javaEncoding = getEncoding();
/*      */     } 
/*      */     
/* 2759 */     return javaEncoding;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TimeZone getDefaultTimeZone() {
/* 2767 */     return getCacheDefaultTimezone() ? this.defaultTimeZone : TimeUtil.getDefaultTimeZone(false);
/*      */   }
/*      */   
/*      */   public String getErrorMessageEncoding() {
/* 2771 */     return this.errorMessageEncoding;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getHoldability() throws SQLException {
/* 2778 */     return 2;
/*      */   }
/*      */   
/*      */   public long getId() {
/* 2782 */     return this.connectionId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getIdleFor() {
/* 2794 */     synchronized (getConnectionMutex()) {
/* 2795 */       if (this.lastQueryFinishedTime == 0L) {
/* 2796 */         return 0L;
/*      */       }
/*      */       
/* 2799 */       long now = System.currentTimeMillis();
/* 2800 */       long idleTime = now - this.lastQueryFinishedTime;
/*      */       
/* 2802 */       return idleTime;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MysqlIO getIO() throws SQLException {
/* 2814 */     if (this.io == null || this.isClosed) {
/* 2815 */       throw SQLError.createSQLException("Operation not allowed on closed connection", "08003", getExceptionInterceptor());
/*      */     }
/*      */     
/* 2818 */     return this.io;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Log getLog() throws SQLException {
/* 2830 */     return this.log;
/*      */   }
/*      */   
/*      */   public int getMaxBytesPerChar(String javaCharsetName) throws SQLException {
/* 2834 */     return getMaxBytesPerChar((Integer)null, javaCharsetName);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxBytesPerChar(Integer charsetIndex, String javaCharsetName) throws SQLException {
/* 2839 */     String charset = null;
/* 2840 */     int res = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 2847 */       if (this.indexToCustomMysqlCharset != null) {
/* 2848 */         charset = this.indexToCustomMysqlCharset.get(charsetIndex);
/*      */       }
/*      */       
/* 2851 */       if (charset == null) {
/* 2852 */         charset = CharsetMapping.getMysqlCharsetNameForCollationIndex(charsetIndex);
/*      */       }
/*      */ 
/*      */       
/* 2856 */       if (charset == null) {
/* 2857 */         charset = CharsetMapping.getMysqlCharsetForJavaEncoding(javaCharsetName, this);
/*      */       }
/*      */ 
/*      */       
/* 2861 */       Integer mblen = null;
/* 2862 */       if (this.mysqlCharsetToCustomMblen != null) {
/* 2863 */         mblen = this.mysqlCharsetToCustomMblen.get(charset);
/*      */       }
/*      */ 
/*      */       
/* 2867 */       if (mblen == null) {
/* 2868 */         mblen = Integer.valueOf(CharsetMapping.getMblen(charset));
/*      */       }
/*      */       
/* 2871 */       if (mblen != null) {
/* 2872 */         res = mblen.intValue();
/*      */       }
/* 2874 */     } catch (SQLException ex) {
/* 2875 */       throw ex;
/* 2876 */     } catch (RuntimeException ex) {
/* 2877 */       SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", (ExceptionInterceptor)null);
/* 2878 */       sqlEx.initCause(ex);
/* 2879 */       throw sqlEx;
/*      */     } 
/*      */     
/* 2882 */     return res;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DatabaseMetaData getMetaData() throws SQLException {
/* 2896 */     return getMetaData(true, true);
/*      */   }
/*      */   
/*      */   private DatabaseMetaData getMetaData(boolean checkClosed, boolean checkForInfoSchema) throws SQLException {
/* 2900 */     if (checkClosed) {
/* 2901 */       checkClosed();
/*      */     }
/*      */     
/* 2904 */     return DatabaseMetaData.getInstance(getMultiHostSafeProxy(), this.database, checkForInfoSchema);
/*      */   }
/*      */   
/*      */   public Statement getMetadataSafeStatement() throws SQLException {
/* 2908 */     return getMetadataSafeStatement(0);
/*      */   }
/*      */   
/*      */   public Statement getMetadataSafeStatement(int maxRows) throws SQLException {
/* 2912 */     Statement stmt = createStatement();
/*      */     
/* 2914 */     stmt.setMaxRows((maxRows == -1) ? 0 : maxRows);
/*      */     
/* 2916 */     stmt.setEscapeProcessing(false);
/*      */     
/* 2918 */     if (stmt.getFetchSize() != 0) {
/* 2919 */       stmt.setFetchSize(0);
/*      */     }
/*      */     
/* 2922 */     return stmt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNetBufferLength() {
/* 2929 */     return this.netBufferLength;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String getServerCharacterEncoding() {
/* 2937 */     return getServerCharset();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getServerCharset() {
/* 2946 */     if (this.io.versionMeetsMinimum(4, 1, 0)) {
/* 2947 */       String charset = null;
/* 2948 */       if (this.indexToCustomMysqlCharset != null) {
/* 2949 */         charset = this.indexToCustomMysqlCharset.get(Integer.valueOf(this.io.serverCharsetIndex));
/*      */       }
/* 2951 */       if (charset == null) {
/* 2952 */         charset = CharsetMapping.getMysqlCharsetNameForCollationIndex(Integer.valueOf(this.io.serverCharsetIndex));
/*      */       }
/* 2954 */       return (charset != null) ? charset : this.serverVariables.get("character_set_server");
/*      */     } 
/* 2956 */     return this.serverVariables.get("character_set");
/*      */   }
/*      */   
/*      */   public int getServerMajorVersion() {
/* 2960 */     return this.io.getServerMajorVersion();
/*      */   }
/*      */   
/*      */   public int getServerMinorVersion() {
/* 2964 */     return this.io.getServerMinorVersion();
/*      */   }
/*      */   
/*      */   public int getServerSubMinorVersion() {
/* 2968 */     return this.io.getServerSubMinorVersion();
/*      */   }
/*      */   
/*      */   public TimeZone getServerTimezoneTZ() {
/* 2972 */     return this.serverTimezoneTZ;
/*      */   }
/*      */   
/*      */   public String getServerVariable(String variableName) {
/* 2976 */     if (this.serverVariables != null) {
/* 2977 */       return this.serverVariables.get(variableName);
/*      */     }
/*      */     
/* 2980 */     return null;
/*      */   }
/*      */   
/*      */   public String getServerVersion() {
/* 2984 */     return this.io.getServerVersion();
/*      */   }
/*      */ 
/*      */   
/*      */   public Calendar getSessionLockedCalendar() {
/* 2989 */     return this.sessionCalendar;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTransactionIsolation() throws SQLException {
/* 3001 */     synchronized (getConnectionMutex()) {
/* 3002 */       if (this.hasIsolationLevels && !getUseLocalSessionState()) {
/* 3003 */         Statement stmt = null;
/* 3004 */         ResultSet rs = null;
/*      */         
/*      */         try {
/* 3007 */           stmt = getMetadataSafeStatement(this.sessionMaxRows);
/* 3008 */           String query = (versionMeetsMinimum(8, 0, 3) || (versionMeetsMinimum(5, 7, 20) && !versionMeetsMinimum(8, 0, 0))) ? "SELECT @@session.transaction_isolation" : "SELECT @@session.tx_isolation";
/*      */           
/* 3010 */           rs = stmt.executeQuery(query);
/*      */           
/* 3012 */           if (rs.next()) {
/* 3013 */             String s = rs.getString(1);
/*      */             
/* 3015 */             if (s != null) {
/* 3016 */               Integer intTI = mapTransIsolationNameToValue.get(s);
/*      */               
/* 3018 */               if (intTI != null) {
/* 3019 */                 this.isolationLevel = intTI.intValue();
/* 3020 */                 return this.isolationLevel;
/*      */               } 
/*      */             } 
/*      */             
/* 3024 */             throw SQLError.createSQLException("Could not map transaction isolation '" + s + " to a valid JDBC level.", "S1000", getExceptionInterceptor());
/*      */           } 
/*      */ 
/*      */           
/* 3028 */           throw SQLError.createSQLException("Could not retrieve transaction isolation level from server", "S1000", getExceptionInterceptor());
/*      */         }
/*      */         finally {
/*      */           
/* 3032 */           if (rs != null) {
/*      */             try {
/* 3034 */               rs.close();
/* 3035 */             } catch (Exception ex) {}
/*      */ 
/*      */ 
/*      */             
/* 3039 */             rs = null;
/*      */           } 
/*      */           
/* 3042 */           if (stmt != null) {
/*      */             try {
/* 3044 */               stmt.close();
/* 3045 */             } catch (Exception ex) {}
/*      */ 
/*      */ 
/*      */             
/* 3049 */             stmt = null;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 3054 */       return this.isolationLevel;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, Class<?>> getTypeMap() throws SQLException {
/* 3067 */     synchronized (getConnectionMutex()) {
/* 3068 */       if (this.typeMap == null) {
/* 3069 */         this.typeMap = new HashMap<String, Class<?>>();
/*      */       }
/*      */       
/* 3072 */       return this.typeMap;
/*      */     } 
/*      */   }
/*      */   
/*      */   public String getURL() {
/* 3077 */     return this.myURL;
/*      */   }
/*      */   
/*      */   public String getUser() {
/* 3081 */     return this.user;
/*      */   }
/*      */   
/*      */   public Calendar getUtcCalendar() {
/* 3085 */     return this.utcCalendar;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLWarning getWarnings() throws SQLException {
/* 3098 */     return null;
/*      */   }
/*      */   
/*      */   public boolean hasSameProperties(Connection c) {
/* 3102 */     return this.props.equals(c.getProperties());
/*      */   }
/*      */   
/*      */   public Properties getProperties() {
/* 3106 */     return this.props;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public boolean hasTriedMaster() {
/* 3111 */     return this.hasTriedMasterFlag;
/*      */   }
/*      */   
/*      */   public void incrementNumberOfPreparedExecutes() {
/* 3115 */     if (getGatherPerformanceMetrics()) {
/* 3116 */       this.numberOfPreparedExecutes++;
/*      */ 
/*      */       
/* 3119 */       this.numberOfQueriesIssued++;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void incrementNumberOfPrepares() {
/* 3124 */     if (getGatherPerformanceMetrics()) {
/* 3125 */       this.numberOfPrepares++;
/*      */     }
/*      */   }
/*      */   
/*      */   public void incrementNumberOfResultSetsCreated() {
/* 3130 */     if (getGatherPerformanceMetrics()) {
/* 3131 */       this.numberOfResultSetsCreated++;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initializeDriverProperties(Properties info) throws SQLException {
/* 3143 */     initializeProperties(info);
/*      */     
/* 3145 */     String exceptionInterceptorClasses = getExceptionInterceptors();
/*      */     
/* 3147 */     if (exceptionInterceptorClasses != null && !"".equals(exceptionInterceptorClasses)) {
/* 3148 */       this.exceptionInterceptor = new ExceptionInterceptorChain(exceptionInterceptorClasses);
/*      */     }
/*      */     
/* 3151 */     this.usePlatformCharsetConverters = getUseJvmCharsetConverters();
/*      */     
/* 3153 */     this.log = LogFactory.getLogger(getLogger(), "MySQL", getExceptionInterceptor());
/*      */     
/* 3155 */     if (getProfileSql() || getUseUsageAdvisor()) {
/* 3156 */       this.eventSink = ProfilerEventHandlerFactory.getInstance(getMultiHostSafeProxy());
/*      */     }
/*      */     
/* 3159 */     if (getCachePreparedStatements()) {
/* 3160 */       createPreparedStatementCaches();
/*      */     }
/*      */     
/* 3163 */     if (getNoDatetimeStringSync() && getUseTimezone()) {
/* 3164 */       throw SQLError.createSQLException("Can't enable noDatetimeStringSync and useTimezone configuration properties at the same time", "01S00", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */     
/* 3168 */     if (getCacheCallableStatements()) {
/* 3169 */       this.parsedCallableStatementCache = new LRUCache(getCallableStatementCacheSize());
/*      */     }
/*      */     
/* 3172 */     if (getAllowMultiQueries()) {
/* 3173 */       setCacheResultSetMetadata(false);
/*      */     }
/*      */     
/* 3176 */     if (getCacheResultSetMetadata()) {
/* 3177 */       this.resultSetMetadataCache = new LRUCache(getMetadataCacheSize());
/*      */     }
/*      */     
/* 3180 */     if (getSocksProxyHost() != null) {
/* 3181 */       setSocketFactoryClassName("com.mysql.jdbc.SocksProxySocketFactory");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initializePropsFromServer() throws SQLException {
/* 3193 */     String connectionInterceptorClasses = getConnectionLifecycleInterceptors();
/*      */     
/* 3195 */     this.connectionLifecycleInterceptors = null;
/*      */     
/* 3197 */     if (connectionInterceptorClasses != null) {
/* 3198 */       this.connectionLifecycleInterceptors = Util.loadExtensions(this, this.props, connectionInterceptorClasses, "Connection.badLifecycleInterceptor", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */     
/* 3202 */     setSessionVariables();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3208 */     if (!versionMeetsMinimum(4, 1, 0)) {
/* 3209 */       setTransformedBitIsBoolean(false);
/*      */     }
/*      */     
/* 3212 */     this.parserKnowsUnicode = versionMeetsMinimum(4, 1, 0);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3217 */     if (getUseServerPreparedStmts() && versionMeetsMinimum(4, 1, 0)) {
/* 3218 */       this.useServerPreparedStmts = true;
/*      */       
/* 3220 */       if (versionMeetsMinimum(5, 0, 0) && !versionMeetsMinimum(5, 0, 3)) {
/* 3221 */         this.useServerPreparedStmts = false;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3229 */     if (versionMeetsMinimum(3, 21, 22)) {
/* 3230 */       loadServerVariables();
/*      */       
/* 3232 */       if (versionMeetsMinimum(5, 0, 2)) {
/* 3233 */         this.autoIncrementIncrement = getServerVariableAsInt("auto_increment_increment", 1);
/*      */       } else {
/* 3235 */         this.autoIncrementIncrement = 1;
/*      */       } 
/*      */       
/* 3238 */       buildCollationMapping();
/*      */ 
/*      */ 
/*      */       
/* 3242 */       if (this.io.serverCharsetIndex == 0) {
/* 3243 */         String collationServer = this.serverVariables.get("collation_server");
/* 3244 */         if (collationServer != null) {
/* 3245 */           for (int i = 1; i < CharsetMapping.COLLATION_INDEX_TO_COLLATION_NAME.length; i++) {
/* 3246 */             if (CharsetMapping.COLLATION_INDEX_TO_COLLATION_NAME[i].equals(collationServer)) {
/* 3247 */               this.io.serverCharsetIndex = i;
/*      */               
/*      */               break;
/*      */             } 
/*      */           } 
/*      */         } else {
/* 3253 */           this.io.serverCharsetIndex = 45;
/*      */         } 
/*      */       } 
/*      */       
/* 3257 */       LicenseConfiguration.checkLicenseType(this.serverVariables);
/*      */       
/* 3259 */       String lowerCaseTables = this.serverVariables.get("lower_case_table_names");
/*      */       
/* 3261 */       this.lowerCaseTableNames = ("on".equalsIgnoreCase(lowerCaseTables) || "1".equalsIgnoreCase(lowerCaseTables) || "2".equalsIgnoreCase(lowerCaseTables));
/*      */       
/* 3263 */       this.storesLowerCaseTableName = ("1".equalsIgnoreCase(lowerCaseTables) || "on".equalsIgnoreCase(lowerCaseTables));
/*      */       
/* 3265 */       configureTimezone();
/*      */       
/* 3267 */       if (this.serverVariables.containsKey("max_allowed_packet")) {
/* 3268 */         int serverMaxAllowedPacket = getServerVariableAsInt("max_allowed_packet", -1);
/*      */         
/* 3270 */         if (serverMaxAllowedPacket != -1 && (serverMaxAllowedPacket < getMaxAllowedPacket() || getMaxAllowedPacket() <= 0)) {
/* 3271 */           setMaxAllowedPacket(serverMaxAllowedPacket);
/* 3272 */         } else if (serverMaxAllowedPacket == -1 && getMaxAllowedPacket() == -1) {
/* 3273 */           setMaxAllowedPacket(65535);
/*      */         } 
/*      */         
/* 3276 */         if (getUseServerPrepStmts()) {
/* 3277 */           int preferredBlobSendChunkSize = getBlobSendChunkSize();
/*      */ 
/*      */           
/* 3280 */           int packetHeaderSize = 8203;
/* 3281 */           int allowedBlobSendChunkSize = Math.min(preferredBlobSendChunkSize, getMaxAllowedPacket()) - packetHeaderSize;
/*      */           
/* 3283 */           if (allowedBlobSendChunkSize <= 0) {
/* 3284 */             throw SQLError.createSQLException("Connection setting too low for 'maxAllowedPacket'. When 'useServerPrepStmts=true', 'maxAllowedPacket' must be higher than " + packetHeaderSize + ". Check also 'max_allowed_packet' in MySQL configuration files.", "01S00", getExceptionInterceptor());
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3291 */           setBlobSendChunkSize(String.valueOf(allowedBlobSendChunkSize));
/*      */         } 
/*      */       } 
/*      */       
/* 3295 */       if (this.serverVariables.containsKey("net_buffer_length")) {
/* 3296 */         this.netBufferLength = getServerVariableAsInt("net_buffer_length", 16384);
/*      */       }
/*      */       
/* 3299 */       checkTransactionIsolationLevel();
/*      */       
/* 3301 */       if (!versionMeetsMinimum(4, 1, 0)) {
/* 3302 */         checkServerEncoding();
/*      */       }
/*      */       
/* 3305 */       this.io.checkForCharsetMismatch();
/*      */       
/* 3307 */       if (this.serverVariables.containsKey("sql_mode")) {
/* 3308 */         String sqlModeAsString = this.serverVariables.get("sql_mode");
/* 3309 */         if (StringUtils.isStrictlyNumeric(sqlModeAsString)) {
/*      */           
/* 3311 */           this.useAnsiQuotes = ((Integer.parseInt(sqlModeAsString) & 0x4) > 0);
/* 3312 */         } else if (sqlModeAsString != null) {
/* 3313 */           this.useAnsiQuotes = (sqlModeAsString.indexOf("ANSI_QUOTES") != -1);
/* 3314 */           this.noBackslashEscapes = (sqlModeAsString.indexOf("NO_BACKSLASH_ESCAPES") != -1);
/* 3315 */           this.serverTruncatesFracSecs = (sqlModeAsString.indexOf("TIME_TRUNCATE_FRACTIONAL") != -1);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 3320 */     configureClientCharacterSet(false);
/*      */     
/*      */     try {
/* 3323 */       this.errorMessageEncoding = CharsetMapping.getCharacterEncodingForErrorMessages(this);
/* 3324 */     } catch (SQLException ex) {
/* 3325 */       throw ex;
/* 3326 */     } catch (RuntimeException ex) {
/* 3327 */       SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", (ExceptionInterceptor)null);
/* 3328 */       sqlEx.initCause(ex);
/* 3329 */       throw sqlEx;
/*      */     } 
/*      */     
/* 3332 */     if (versionMeetsMinimum(3, 23, 15)) {
/* 3333 */       this.transactionsSupported = true;
/* 3334 */       handleAutoCommitDefaults();
/*      */     } else {
/* 3336 */       this.transactionsSupported = false;
/*      */     } 
/*      */     
/* 3339 */     if (versionMeetsMinimum(3, 23, 36)) {
/* 3340 */       this.hasIsolationLevels = true;
/*      */     } else {
/* 3342 */       this.hasIsolationLevels = false;
/*      */     } 
/*      */     
/* 3345 */     this.hasQuotedIdentifiers = versionMeetsMinimum(3, 23, 6);
/*      */     
/* 3347 */     this.io.resetMaxBuf();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3353 */     if (this.io.versionMeetsMinimum(4, 1, 0)) {
/* 3354 */       String characterSetResultsOnServerMysql = this.serverVariables.get("jdbc.local.character_set_results");
/*      */       
/* 3356 */       if (characterSetResultsOnServerMysql == null || StringUtils.startsWithIgnoreCaseAndWs(characterSetResultsOnServerMysql, "NULL") || characterSetResultsOnServerMysql.length() == 0) {
/*      */         
/* 3358 */         String defaultMetadataCharsetMysql = this.serverVariables.get("character_set_system");
/* 3359 */         String defaultMetadataCharset = null;
/*      */         
/* 3361 */         if (defaultMetadataCharsetMysql != null) {
/* 3362 */           defaultMetadataCharset = CharsetMapping.getJavaEncodingForMysqlCharset(defaultMetadataCharsetMysql);
/*      */         } else {
/* 3364 */           defaultMetadataCharset = "UTF-8";
/*      */         } 
/*      */         
/* 3367 */         this.characterSetMetadata = defaultMetadataCharset;
/*      */       } else {
/* 3369 */         this.characterSetResultsOnServer = CharsetMapping.getJavaEncodingForMysqlCharset(characterSetResultsOnServerMysql);
/* 3370 */         this.characterSetMetadata = this.characterSetResultsOnServer;
/*      */       } 
/*      */     } else {
/* 3373 */       this.characterSetMetadata = getEncoding();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3380 */     if (versionMeetsMinimum(4, 1, 0) && !versionMeetsMinimum(4, 1, 10) && getAllowMultiQueries() && 
/* 3381 */       isQueryCacheEnabled()) {
/* 3382 */       setAllowMultiQueries(false);
/*      */     }
/*      */ 
/*      */     
/* 3386 */     if (versionMeetsMinimum(5, 0, 0) && (getUseLocalTransactionState() || getElideSetAutoCommits()) && isQueryCacheEnabled() && !versionMeetsMinimum(5, 1, 32)) {
/*      */ 
/*      */       
/* 3389 */       setUseLocalTransactionState(false);
/* 3390 */       setElideSetAutoCommits(false);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3397 */     setupServerForTruncationChecks();
/*      */   }
/*      */   
/*      */   public boolean isQueryCacheEnabled() {
/* 3401 */     return ("ON".equalsIgnoreCase(this.serverVariables.get("query_cache_type")) && !"0".equalsIgnoreCase(this.serverVariables.get("query_cache_size")));
/*      */   }
/*      */   
/*      */   private int getServerVariableAsInt(String variableName, int fallbackValue) throws SQLException {
/*      */     try {
/* 3406 */       return Integer.parseInt(this.serverVariables.get(variableName));
/* 3407 */     } catch (NumberFormatException nfe) {
/* 3408 */       getLog().logWarn(Messages.getString("Connection.BadValueInServerVariables", new Object[] { variableName, this.serverVariables.get(variableName), Integer.valueOf(fallbackValue) }));
/*      */ 
/*      */       
/* 3411 */       return fallbackValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void handleAutoCommitDefaults() throws SQLException {
/* 3420 */     boolean resetAutoCommitDefault = false;
/*      */     
/* 3422 */     if (!getElideSetAutoCommits()) {
/* 3423 */       String initConnectValue = this.serverVariables.get("init_connect");
/* 3424 */       if (versionMeetsMinimum(4, 1, 2) && initConnectValue != null && initConnectValue.length() > 0) {
/*      */         
/* 3426 */         ResultSet rs = null;
/* 3427 */         Statement stmt = null;
/*      */         
/*      */         try {
/* 3430 */           stmt = getMetadataSafeStatement();
/* 3431 */           rs = stmt.executeQuery("SELECT @@session.autocommit");
/* 3432 */           if (rs.next()) {
/* 3433 */             this.autoCommit = rs.getBoolean(1);
/* 3434 */             resetAutoCommitDefault = !this.autoCommit;
/*      */           } 
/*      */         } finally {
/* 3437 */           if (rs != null) {
/*      */             try {
/* 3439 */               rs.close();
/* 3440 */             } catch (SQLException sqlEx) {}
/*      */           }
/*      */ 
/*      */           
/* 3444 */           if (stmt != null) {
/*      */             try {
/* 3446 */               stmt.close();
/* 3447 */             } catch (SQLException sqlEx) {}
/*      */           }
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 3454 */         resetAutoCommitDefault = true;
/*      */       } 
/* 3456 */     } else if (getIO().isSetNeededForAutoCommitMode(true)) {
/*      */       
/* 3458 */       this.autoCommit = false;
/* 3459 */       resetAutoCommitDefault = true;
/*      */     } 
/*      */     
/* 3462 */     if (resetAutoCommitDefault) {
/*      */       try {
/* 3464 */         setAutoCommit(true);
/* 3465 */       } catch (SQLException ex) {
/* 3466 */         if (ex.getErrorCode() != 1820 || getDisconnectOnExpiredPasswords()) {
/* 3467 */           throw ex;
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isClientTzUTC() {
/* 3474 */     return this.isClientTzUTC;
/*      */   }
/*      */   
/*      */   public boolean isClosed() {
/* 3478 */     return this.isClosed;
/*      */   }
/*      */   
/*      */   public boolean isCursorFetchEnabled() throws SQLException {
/* 3482 */     return (versionMeetsMinimum(5, 0, 2) && getUseCursorFetch());
/*      */   }
/*      */   
/*      */   public boolean isInGlobalTx() {
/* 3486 */     return this.isInGlobalTx;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isMasterConnection() {
/* 3497 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isNoBackslashEscapesSet() {
/* 3507 */     return this.noBackslashEscapes;
/*      */   }
/*      */   
/*      */   public boolean isReadInfoMsgEnabled() {
/* 3511 */     return this.readInfoMsg;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isReadOnly() throws SQLException {
/* 3524 */     return isReadOnly(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isReadOnly(boolean useSessionStatus) throws SQLException {
/* 3541 */     if (useSessionStatus && !this.isClosed && versionMeetsMinimum(5, 6, 5) && !getUseLocalSessionState() && getReadOnlyPropagatesToServer()) {
/* 3542 */       Statement stmt = null;
/* 3543 */       ResultSet rs = null;
/*      */ 
/*      */       
/*      */       try {
/* 3547 */         stmt = getMetadataSafeStatement(this.sessionMaxRows);
/*      */         
/* 3549 */         rs = stmt.executeQuery((versionMeetsMinimum(8, 0, 3) || (versionMeetsMinimum(5, 7, 20) && !versionMeetsMinimum(8, 0, 0))) ? "select @@session.transaction_read_only" : "select @@session.tx_read_only");
/*      */         
/* 3551 */         if (rs.next()) {
/* 3552 */           return (rs.getInt(1) != 0);
/*      */         }
/* 3554 */       } catch (SQLException ex1) {
/* 3555 */         if (ex1.getErrorCode() != 1820 || getDisconnectOnExpiredPasswords()) {
/* 3556 */           throw SQLError.createSQLException("Could not retrieve transaction read-only status from server", "S1000", ex1, getExceptionInterceptor());
/*      */         
/*      */         }
/*      */       }
/*      */       finally {
/*      */         
/* 3562 */         if (rs != null) {
/*      */           try {
/* 3564 */             rs.close();
/* 3565 */           } catch (Exception ex) {}
/*      */ 
/*      */ 
/*      */           
/* 3569 */           rs = null;
/*      */         } 
/*      */         
/* 3572 */         if (stmt != null) {
/*      */           try {
/* 3574 */             stmt.close();
/* 3575 */           } catch (Exception ex) {}
/*      */ 
/*      */ 
/*      */           
/* 3579 */           stmt = null;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 3584 */     return this.readOnly;
/*      */   }
/*      */   
/*      */   public boolean isRunningOnJDK13() {
/* 3588 */     return this.isRunningOnJDK13;
/*      */   }
/*      */   
/*      */   public boolean isSameResource(Connection otherConnection) {
/* 3592 */     synchronized (getConnectionMutex()) {
/* 3593 */       if (otherConnection == null) {
/* 3594 */         return false;
/*      */       }
/*      */       
/* 3597 */       boolean directCompare = true;
/*      */       
/* 3599 */       String otherHost = ((ConnectionImpl)otherConnection).origHostToConnectTo;
/* 3600 */       String otherOrigDatabase = ((ConnectionImpl)otherConnection).origDatabaseToConnectTo;
/* 3601 */       String otherCurrentCatalog = ((ConnectionImpl)otherConnection).database;
/*      */       
/* 3603 */       if (!nullSafeCompare(otherHost, this.origHostToConnectTo)) {
/* 3604 */         directCompare = false;
/* 3605 */       } else if (otherHost != null && otherHost.indexOf(',') == -1 && otherHost.indexOf(':') == -1) {
/*      */         
/* 3607 */         directCompare = (((ConnectionImpl)otherConnection).origPortToConnectTo == this.origPortToConnectTo);
/*      */       } 
/*      */       
/* 3610 */       if (directCompare && (
/* 3611 */         !nullSafeCompare(otherOrigDatabase, this.origDatabaseToConnectTo) || !nullSafeCompare(otherCurrentCatalog, this.database))) {
/* 3612 */         directCompare = false;
/*      */       }
/*      */ 
/*      */       
/* 3616 */       if (directCompare) {
/* 3617 */         return true;
/*      */       }
/*      */ 
/*      */       
/* 3621 */       String otherResourceId = ((ConnectionImpl)otherConnection).getResourceId();
/* 3622 */       String myResourceId = getResourceId();
/*      */       
/* 3624 */       if (otherResourceId != null || myResourceId != null) {
/* 3625 */         directCompare = nullSafeCompare(otherResourceId, myResourceId);
/*      */         
/* 3627 */         if (directCompare) {
/* 3628 */           return true;
/*      */         }
/*      */       } 
/*      */       
/* 3632 */       return false;
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean isServerTzUTC() {
/* 3637 */     return this.isServerTzUTC;
/*      */   }
/*      */   
/*      */   private void createConfigCacheIfNeeded() throws SQLException {
/* 3641 */     synchronized (getConnectionMutex()) {
/* 3642 */       if (this.serverConfigCache != null) {
/*      */         return;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 3649 */         Class<?> factoryClass = Class.forName(getServerConfigCacheFactory());
/*      */ 
/*      */         
/* 3652 */         CacheAdapterFactory<String, Map<String, String>> cacheFactory = (CacheAdapterFactory<String, Map<String, String>>)factoryClass.newInstance();
/*      */         
/* 3654 */         this.serverConfigCache = cacheFactory.getInstance(this, this.myURL, 2147483647, 2147483647, this.props);
/*      */         
/* 3656 */         ExceptionInterceptor evictOnCommsError = new ExceptionInterceptor()
/*      */           {
/*      */             public void init(Connection conn, Properties config) throws SQLException {}
/*      */ 
/*      */ 
/*      */             
/*      */             public void destroy() {}
/*      */ 
/*      */             
/*      */             public SQLException interceptException(SQLException sqlEx, Connection conn) {
/* 3666 */               if (sqlEx.getSQLState() != null && sqlEx.getSQLState().startsWith("08")) {
/* 3667 */                 ConnectionImpl.this.serverConfigCache.invalidate(ConnectionImpl.this.getURL());
/*      */               }
/* 3669 */               return null;
/*      */             }
/*      */           };
/*      */         
/* 3673 */         if (this.exceptionInterceptor == null) {
/* 3674 */           this.exceptionInterceptor = evictOnCommsError;
/*      */         } else {
/* 3676 */           ((ExceptionInterceptorChain)this.exceptionInterceptor).addRingZero(evictOnCommsError);
/*      */         } 
/* 3678 */       } catch (ClassNotFoundException e) {
/* 3679 */         SQLException sqlEx = SQLError.createSQLException(Messages.getString("Connection.CantFindCacheFactory", new Object[] { getParseInfoCacheFactory(), "parseInfoCacheFactory" }), getExceptionInterceptor());
/*      */ 
/*      */         
/* 3682 */         sqlEx.initCause(e);
/*      */         
/* 3684 */         throw sqlEx;
/* 3685 */       } catch (InstantiationException e) {
/* 3686 */         SQLException sqlEx = SQLError.createSQLException(Messages.getString("Connection.CantLoadCacheFactory", new Object[] { getParseInfoCacheFactory(), "parseInfoCacheFactory" }), getExceptionInterceptor());
/*      */ 
/*      */         
/* 3689 */         sqlEx.initCause(e);
/*      */         
/* 3691 */         throw sqlEx;
/* 3692 */       } catch (IllegalAccessException e) {
/* 3693 */         SQLException sqlEx = SQLError.createSQLException(Messages.getString("Connection.CantLoadCacheFactory", new Object[] { getParseInfoCacheFactory(), "parseInfoCacheFactory" }), getExceptionInterceptor());
/*      */ 
/*      */         
/* 3696 */         sqlEx.initCause(e);
/*      */         
/* 3698 */         throw sqlEx;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void loadServerVariables() throws SQLException {
/* 3714 */     if (getCacheServerConfiguration()) {
/* 3715 */       createConfigCacheIfNeeded();
/*      */       
/* 3717 */       Map<String, String> cachedVariableMap = this.serverConfigCache.get(getURL());
/*      */       
/* 3719 */       if (cachedVariableMap != null) {
/* 3720 */         String cachedServerVersion = cachedVariableMap.get("server_version_string");
/*      */         
/* 3722 */         if (cachedServerVersion != null && this.io.getServerVersion() != null && cachedServerVersion.equals(this.io.getServerVersion())) {
/* 3723 */           this.serverVariables = cachedVariableMap;
/*      */           
/*      */           return;
/*      */         } 
/*      */         
/* 3728 */         this.serverConfigCache.invalidate(getURL());
/*      */       } 
/*      */     } 
/*      */     
/* 3732 */     Statement stmt = null;
/* 3733 */     ResultSet results = null;
/*      */     
/*      */     try {
/* 3736 */       stmt = getMetadataSafeStatement();
/*      */       
/* 3738 */       String version = this.dbmd.getDriverVersion();
/*      */       
/* 3740 */       if (version != null && version.indexOf('*') != -1) {
/* 3741 */         StringBuilder buf = new StringBuilder(version.length() + 10);
/*      */         
/* 3743 */         for (int i = 0; i < version.length(); i++) {
/* 3744 */           char c = version.charAt(i);
/*      */           
/* 3746 */           if (c == '*') {
/* 3747 */             buf.append("[star]");
/*      */           } else {
/* 3749 */             buf.append(c);
/*      */           } 
/*      */         } 
/*      */         
/* 3753 */         version = buf.toString();
/*      */       } 
/*      */       
/* 3756 */       String versionComment = (getParanoid() || version == null) ? "" : ("/* " + version + " */");
/*      */       
/* 3758 */       this.serverVariables = new HashMap<String, String>();
/*      */       
/* 3760 */       boolean currentJdbcComplTrunc = getJdbcCompliantTruncation();
/* 3761 */       setJdbcCompliantTruncation(false);
/*      */       
/*      */       try {
/* 3764 */         if (versionMeetsMinimum(5, 1, 0)) {
/* 3765 */           StringBuilder queryBuf = (new StringBuilder(versionComment)).append("SELECT");
/* 3766 */           queryBuf.append("  @@session.auto_increment_increment AS auto_increment_increment");
/* 3767 */           queryBuf.append(", @@character_set_client AS character_set_client");
/* 3768 */           queryBuf.append(", @@character_set_connection AS character_set_connection");
/* 3769 */           queryBuf.append(", @@character_set_results AS character_set_results");
/* 3770 */           queryBuf.append(", @@character_set_server AS character_set_server");
/* 3771 */           queryBuf.append(", @@collation_server AS collation_server");
/* 3772 */           queryBuf.append(", @@collation_connection AS collation_connection");
/* 3773 */           queryBuf.append(", @@init_connect AS init_connect");
/* 3774 */           queryBuf.append(", @@interactive_timeout AS interactive_timeout");
/* 3775 */           if (!versionMeetsMinimum(5, 5, 0)) {
/* 3776 */             queryBuf.append(", @@language AS language");
/*      */           }
/* 3778 */           queryBuf.append(", @@license AS license");
/* 3779 */           queryBuf.append(", @@lower_case_table_names AS lower_case_table_names");
/* 3780 */           queryBuf.append(", @@max_allowed_packet AS max_allowed_packet");
/* 3781 */           queryBuf.append(", @@net_buffer_length AS net_buffer_length");
/* 3782 */           queryBuf.append(", @@net_write_timeout AS net_write_timeout");
/* 3783 */           if (!versionMeetsMinimum(8, 0, 3)) {
/* 3784 */             queryBuf.append(", @@query_cache_size AS query_cache_size");
/* 3785 */             queryBuf.append(", @@query_cache_type AS query_cache_type");
/*      */           } 
/* 3787 */           queryBuf.append(", @@sql_mode AS sql_mode");
/* 3788 */           queryBuf.append(", @@system_time_zone AS system_time_zone");
/* 3789 */           queryBuf.append(", @@time_zone AS time_zone");
/* 3790 */           if (versionMeetsMinimum(8, 0, 3) || (versionMeetsMinimum(5, 7, 20) && !versionMeetsMinimum(8, 0, 0))) {
/* 3791 */             queryBuf.append(", @@transaction_isolation AS transaction_isolation");
/*      */           } else {
/* 3793 */             queryBuf.append(", @@tx_isolation AS transaction_isolation");
/*      */           } 
/* 3795 */           queryBuf.append(", @@wait_timeout AS wait_timeout");
/*      */           
/* 3797 */           results = stmt.executeQuery(queryBuf.toString());
/* 3798 */           if (results.next()) {
/* 3799 */             ResultSetMetaData rsmd = results.getMetaData();
/* 3800 */             for (int i = 1; i <= rsmd.getColumnCount(); i++) {
/* 3801 */               this.serverVariables.put(rsmd.getColumnLabel(i), results.getString(i));
/*      */             }
/*      */           } 
/*      */         } else {
/* 3805 */           results = stmt.executeQuery(versionComment + "SHOW VARIABLES");
/* 3806 */           while (results.next()) {
/* 3807 */             this.serverVariables.put(results.getString(1), results.getString(2));
/*      */           }
/*      */         } 
/*      */         
/* 3811 */         results.close();
/* 3812 */         results = null;
/* 3813 */       } catch (SQLException ex) {
/* 3814 */         if (ex.getErrorCode() != 1820 || getDisconnectOnExpiredPasswords()) {
/* 3815 */           throw ex;
/*      */         }
/*      */       } finally {
/* 3818 */         setJdbcCompliantTruncation(currentJdbcComplTrunc);
/*      */       } 
/*      */       
/* 3821 */       if (getCacheServerConfiguration()) {
/* 3822 */         this.serverVariables.put("server_version_string", this.io.getServerVersion());
/*      */         
/* 3824 */         this.serverConfigCache.put(getURL(), this.serverVariables);
/*      */       }
/*      */     
/* 3827 */     } catch (SQLException e) {
/* 3828 */       throw e;
/*      */     } finally {
/* 3830 */       if (results != null) {
/*      */         try {
/* 3832 */           results.close();
/* 3833 */         } catch (SQLException sqlE) {}
/*      */       }
/*      */ 
/*      */       
/* 3837 */       if (stmt != null) {
/*      */         try {
/* 3839 */           stmt.close();
/* 3840 */         } catch (SQLException sqlE) {}
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   protected ConnectionImpl() {
/* 3846 */     this.autoIncrementIncrement = 0; } public ConnectionImpl(String hostToConnectTo, int portToConnectTo, Properties info, String databaseToConnectTo, String url) throws SQLException { this.autoIncrementIncrement = 0; this.connectionCreationTimeMillis = System.currentTimeMillis(); if (databaseToConnectTo == null)
/*      */       databaseToConnectTo = "";  this.origHostToConnectTo = hostToConnectTo; this.origPortToConnectTo = portToConnectTo; this.origDatabaseToConnectTo = databaseToConnectTo; try { Blob.class.getMethod("truncate", new Class[] { long.class }); this.isRunningOnJDK13 = false; } catch (NoSuchMethodException nsme) { this.isRunningOnJDK13 = true; }  this.sessionCalendar = new GregorianCalendar(); this.utcCalendar = new GregorianCalendar(); this.utcCalendar.setTimeZone(TimeZone.getTimeZone("GMT")); this.log = LogFactory.getLogger(getLogger(), "MySQL", getExceptionInterceptor()); if (NonRegisteringDriver.isHostPropertiesList(hostToConnectTo)) { Properties hostSpecificProps = NonRegisteringDriver.expandHostKeyValues(hostToConnectTo); Enumeration<?> propertyNames = hostSpecificProps.propertyNames(); while (propertyNames.hasMoreElements()) { String propertyName = propertyNames.nextElement().toString(); String propertyValue = hostSpecificProps.getProperty(propertyName); info.setProperty(propertyName, propertyValue); }  } else if (hostToConnectTo == null) { this.host = "localhost"; this.hostPortPair = this.host + ":" + portToConnectTo; } else { this.host = hostToConnectTo; if (hostToConnectTo.indexOf(":") == -1) { this.hostPortPair = this.host + ":" + portToConnectTo; } else { this.hostPortPair = this.host; }  }  this.port = portToConnectTo; this.database = databaseToConnectTo; this.myURL = url; this.user = info.getProperty("user"); this.password = info.getProperty("password"); if (this.user == null || this.user.equals(""))
/*      */       this.user = "";  if (this.password == null)
/* 3849 */       this.password = "";  this.props = info; initializeDriverProperties(info); this.defaultTimeZone = TimeUtil.getDefaultTimeZone(getCacheDefaultTimezone()); this.isClientTzUTC = (!this.defaultTimeZone.useDaylightTime() && this.defaultTimeZone.getRawOffset() == 0); if (getUseUsageAdvisor()) { this.pointOfOrigin = LogUtils.findCallingClassAndMethod(new Throwable()); } else { this.pointOfOrigin = ""; }  try { this.dbmd = getMetaData(false, false); initializeSafeStatementInterceptors(); createNewIO(false); unSafeStatementInterceptors(); } catch (SQLException ex) { cleanup(ex); throw ex; } catch (Exception ex) { cleanup(ex); StringBuilder mesg = new StringBuilder(128); if (!getParanoid()) { mesg.append("Cannot connect to MySQL server on "); mesg.append(this.host); mesg.append(":"); mesg.append(this.port); mesg.append(".\n\n"); mesg.append("Make sure that there is a MySQL server "); mesg.append("running on the machine/port you are trying "); mesg.append("to connect to and that the machine this software is running on "); mesg.append("is able to connect to this host/port (i.e. not firewalled). "); mesg.append("Also make sure that the server has not been started with the --skip-networking "); mesg.append("flag.\n\n"); } else { mesg.append("Unable to connect to database."); }  SQLException sqlEx = SQLError.createSQLException(mesg.toString(), "08S01", getExceptionInterceptor()); sqlEx.initCause(ex); throw sqlEx; }  NonRegisteringDriver.trackConnection(this); } public int getAutoIncrementIncrement() { return this.autoIncrementIncrement; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lowerCaseTableNames() {
/* 3858 */     return this.lowerCaseTableNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String nativeSQL(String sql) throws SQLException {
/* 3874 */     if (sql == null) {
/* 3875 */       return null;
/*      */     }
/*      */     
/* 3878 */     Object escapedSqlResult = EscapeProcessor.escapeSQL(sql, serverSupportsConvertFn(), getMultiHostSafeProxy());
/*      */     
/* 3880 */     if (escapedSqlResult instanceof String) {
/* 3881 */       return (String)escapedSqlResult;
/*      */     }
/*      */     
/* 3884 */     return ((EscapeProcessorResult)escapedSqlResult).escapedSql;
/*      */   }
/*      */   
/*      */   private CallableStatement parseCallableStatement(String sql) throws SQLException {
/* 3888 */     Object escapedSqlResult = EscapeProcessor.escapeSQL(sql, serverSupportsConvertFn(), getMultiHostSafeProxy());
/*      */     
/* 3890 */     boolean isFunctionCall = false;
/* 3891 */     String parsedSql = null;
/*      */     
/* 3893 */     if (escapedSqlResult instanceof EscapeProcessorResult) {
/* 3894 */       parsedSql = ((EscapeProcessorResult)escapedSqlResult).escapedSql;
/* 3895 */       isFunctionCall = ((EscapeProcessorResult)escapedSqlResult).callingStoredFunction;
/*      */     } else {
/* 3897 */       parsedSql = (String)escapedSqlResult;
/* 3898 */       isFunctionCall = false;
/*      */     } 
/*      */     
/* 3901 */     return CallableStatement.getInstance(getMultiHostSafeProxy(), parsedSql, this.database, isFunctionCall);
/*      */   }
/*      */   
/*      */   public boolean parserKnowsUnicode() {
/* 3905 */     return this.parserKnowsUnicode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ping() throws SQLException {
/* 3915 */     pingInternal(true, 0);
/*      */   }
/*      */   
/*      */   public void pingInternal(boolean checkForClosedConnection, int timeoutMillis) throws SQLException {
/* 3919 */     if (checkForClosedConnection) {
/* 3920 */       checkClosed();
/*      */     }
/*      */     
/* 3923 */     long pingMillisLifetime = getSelfDestructOnPingSecondsLifetime();
/* 3924 */     int pingMaxOperations = getSelfDestructOnPingMaxOperations();
/*      */     
/* 3926 */     if ((pingMillisLifetime > 0L && System.currentTimeMillis() - this.connectionCreationTimeMillis > pingMillisLifetime) || (pingMaxOperations > 0 && pingMaxOperations <= this.io.getCommandCount())) {
/*      */ 
/*      */       
/* 3929 */       close();
/*      */       
/* 3931 */       throw SQLError.createSQLException(Messages.getString("Connection.exceededConnectionLifetime"), "08S01", getExceptionInterceptor());
/*      */     } 
/*      */ 
/*      */     
/* 3935 */     this.io.sendCommand(14, null, null, false, null, timeoutMillis);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CallableStatement prepareCall(String sql) throws SQLException {
/* 3944 */     return prepareCall(sql, 1003, 1007);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/* 3963 */     if (versionMeetsMinimum(5, 0, 0)) {
/* 3964 */       CallableStatement cStmt = null;
/*      */       
/* 3966 */       if (!getCacheCallableStatements()) {
/*      */         
/* 3968 */         cStmt = parseCallableStatement(sql);
/*      */       } else {
/* 3970 */         synchronized (this.parsedCallableStatementCache) {
/* 3971 */           CompoundCacheKey key = new CompoundCacheKey(getCatalog(), sql);
/*      */           
/* 3973 */           CallableStatement.CallableStatementParamInfo cachedParamInfo = (CallableStatement.CallableStatementParamInfo)this.parsedCallableStatementCache.get(key);
/*      */           
/* 3975 */           if (cachedParamInfo != null) {
/* 3976 */             cStmt = CallableStatement.getInstance(getMultiHostSafeProxy(), cachedParamInfo);
/*      */           } else {
/* 3978 */             cStmt = parseCallableStatement(sql);
/*      */             
/* 3980 */             synchronized (cStmt) {
/* 3981 */               cachedParamInfo = cStmt.paramInfo;
/*      */             } 
/*      */             
/* 3984 */             this.parsedCallableStatementCache.put(key, cachedParamInfo);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 3989 */       cStmt.setResultSetType(resultSetType);
/* 3990 */       cStmt.setResultSetConcurrency(resultSetConcurrency);
/*      */       
/* 3992 */       return cStmt;
/*      */     } 
/*      */     
/* 3995 */     throw SQLError.createSQLException("Callable statements not supported.", "S1C00", getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/* 4002 */     if (getPedantic() && 
/* 4003 */       resultSetHoldability != 1) {
/* 4004 */       throw SQLError.createSQLException("HOLD_CUSRORS_OVER_COMMIT is only supported holdability level", "S1009", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 4009 */     CallableStatement cStmt = (CallableStatement)prepareCall(sql, resultSetType, resultSetConcurrency);
/*      */     
/* 4011 */     return cStmt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PreparedStatement prepareStatement(String sql) throws SQLException {
/* 4036 */     return prepareStatement(sql, 1003, 1007);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PreparedStatement prepareStatement(String sql, int autoGenKeyIndex) throws SQLException {
/* 4043 */     PreparedStatement pStmt = prepareStatement(sql);
/*      */     
/* 4045 */     ((PreparedStatement)pStmt).setRetrieveGeneratedKeys((autoGenKeyIndex == 1));
/*      */     
/* 4047 */     return pStmt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/* 4066 */     synchronized (getConnectionMutex()) {
/* 4067 */       checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4072 */       PreparedStatement pStmt = null;
/*      */       
/* 4074 */       boolean canServerPrepare = true;
/*      */       
/* 4076 */       String nativeSql = getProcessEscapeCodesForPrepStmts() ? nativeSQL(sql) : sql;
/*      */       
/* 4078 */       if (this.useServerPreparedStmts && getEmulateUnsupportedPstmts()) {
/* 4079 */         canServerPrepare = canHandleAsServerPreparedStatement(nativeSql);
/*      */       }
/*      */       
/* 4082 */       if (this.useServerPreparedStmts && canServerPrepare) {
/* 4083 */         if (getCachePreparedStatements()) {
/* 4084 */           synchronized (this.serverSideStatementCache) {
/* 4085 */             pStmt = (PreparedStatement)this.serverSideStatementCache.remove(new CompoundCacheKey(this.database, sql));
/*      */             
/* 4087 */             if (pStmt != null) {
/* 4088 */               ((ServerPreparedStatement)pStmt).setClosed(false);
/* 4089 */               pStmt.clearParameters();
/*      */             } 
/*      */             
/* 4092 */             if (pStmt == null) {
/*      */               try {
/* 4094 */                 pStmt = ServerPreparedStatement.getInstance(getMultiHostSafeProxy(), nativeSql, this.database, resultSetType, resultSetConcurrency);
/*      */                 
/* 4096 */                 if (sql.length() < getPreparedStatementCacheSqlLimit()) {
/* 4097 */                   ((ServerPreparedStatement)pStmt).isCached = true;
/*      */                 }
/*      */                 
/* 4100 */                 pStmt.setResultSetType(resultSetType);
/* 4101 */                 pStmt.setResultSetConcurrency(resultSetConcurrency);
/* 4102 */               } catch (SQLException sqlEx) {
/*      */                 
/* 4104 */                 if (getEmulateUnsupportedPstmts()) {
/* 4105 */                   pStmt = (PreparedStatement)clientPrepareStatement(nativeSql, resultSetType, resultSetConcurrency, false);
/*      */                   
/* 4107 */                   if (sql.length() < getPreparedStatementCacheSqlLimit()) {
/* 4108 */                     this.serverSideStatementCheckCache.put(sql, Boolean.FALSE);
/*      */                   }
/*      */                 } else {
/* 4111 */                   throw sqlEx;
/*      */                 } 
/*      */               } 
/*      */             }
/*      */           } 
/*      */         } else {
/*      */           try {
/* 4118 */             pStmt = ServerPreparedStatement.getInstance(getMultiHostSafeProxy(), nativeSql, this.database, resultSetType, resultSetConcurrency);
/*      */             
/* 4120 */             pStmt.setResultSetType(resultSetType);
/* 4121 */             pStmt.setResultSetConcurrency(resultSetConcurrency);
/* 4122 */           } catch (SQLException sqlEx) {
/*      */             
/* 4124 */             if (getEmulateUnsupportedPstmts()) {
/* 4125 */               pStmt = (PreparedStatement)clientPrepareStatement(nativeSql, resultSetType, resultSetConcurrency, false);
/*      */             } else {
/* 4127 */               throw sqlEx;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } else {
/* 4132 */         pStmt = (PreparedStatement)clientPrepareStatement(nativeSql, resultSetType, resultSetConcurrency, false);
/*      */       } 
/*      */       
/* 4135 */       return pStmt;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/* 4143 */     if (getPedantic() && 
/* 4144 */       resultSetHoldability != 1) {
/* 4145 */       throw SQLError.createSQLException("HOLD_CUSRORS_OVER_COMMIT is only supported holdability level", "S1009", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 4150 */     return prepareStatement(sql, resultSetType, resultSetConcurrency);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PreparedStatement prepareStatement(String sql, int[] autoGenKeyIndexes) throws SQLException {
/* 4157 */     PreparedStatement pStmt = prepareStatement(sql);
/*      */     
/* 4159 */     ((PreparedStatement)pStmt).setRetrieveGeneratedKeys((autoGenKeyIndexes != null && autoGenKeyIndexes.length > 0));
/*      */     
/* 4161 */     return pStmt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PreparedStatement prepareStatement(String sql, String[] autoGenKeyColNames) throws SQLException {
/* 4168 */     PreparedStatement pStmt = prepareStatement(sql);
/*      */     
/* 4170 */     ((PreparedStatement)pStmt).setRetrieveGeneratedKeys((autoGenKeyColNames != null && autoGenKeyColNames.length > 0));
/*      */     
/* 4172 */     return pStmt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void realClose(boolean calledExplicitly, boolean issueRollback, boolean skipLocalTeardown, Throwable reason) throws SQLException {
/* 4186 */     SQLException sqlEx = null;
/*      */     
/* 4188 */     if (isClosed()) {
/*      */       return;
/*      */     }
/*      */     
/* 4192 */     this.forceClosedReason = reason;
/*      */     
/*      */     try {
/* 4195 */       if (!skipLocalTeardown) {
/* 4196 */         if (!getAutoCommit() && issueRollback) {
/*      */           try {
/* 4198 */             rollback();
/* 4199 */           } catch (SQLException ex) {
/* 4200 */             sqlEx = ex;
/*      */           } 
/*      */         }
/*      */         
/* 4204 */         reportMetrics();
/*      */         
/* 4206 */         if (getUseUsageAdvisor()) {
/* 4207 */           if (!calledExplicitly) {
/* 4208 */             String message = "Connection implicitly closed by Driver. You should call Connection.close() from your code to free resources more efficiently and avoid resource leaks.";
/*      */             
/* 4210 */             this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", getCatalog(), getId(), -1, -1, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, message));
/*      */           } 
/*      */ 
/*      */           
/* 4214 */           long connectionLifeTime = System.currentTimeMillis() - this.connectionCreationTimeMillis;
/*      */           
/* 4216 */           if (connectionLifeTime < 500L) {
/* 4217 */             String message = "Connection lifetime of < .5 seconds. You might be un-necessarily creating short-lived connections and should investigate connection pooling to be more efficient.";
/*      */             
/* 4219 */             this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", getCatalog(), getId(), -1, -1, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, message));
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/*      */         try {
/* 4225 */           closeAllOpenStatements();
/* 4226 */         } catch (SQLException ex) {
/* 4227 */           sqlEx = ex;
/*      */         } 
/*      */         
/* 4230 */         if (this.io != null) {
/*      */           try {
/* 4232 */             this.io.quit();
/* 4233 */           } catch (Exception e) {}
/*      */         }
/*      */       }
/*      */       else {
/*      */         
/* 4238 */         this.io.forceClose();
/*      */       } 
/*      */       
/* 4241 */       if (this.statementInterceptors != null) {
/* 4242 */         for (int i = 0; i < this.statementInterceptors.size(); i++) {
/* 4243 */           ((StatementInterceptorV2)this.statementInterceptors.get(i)).destroy();
/*      */         }
/*      */       }
/*      */       
/* 4247 */       if (this.exceptionInterceptor != null) {
/* 4248 */         this.exceptionInterceptor.destroy();
/*      */       }
/*      */     } finally {
/* 4251 */       this.openStatements.clear();
/* 4252 */       if (this.io != null) {
/* 4253 */         this.io.releaseResources();
/* 4254 */         this.io = null;
/*      */       } 
/* 4256 */       this.statementInterceptors = null;
/* 4257 */       this.exceptionInterceptor = null;
/* 4258 */       ProfilerEventHandlerFactory.removeInstance(this);
/*      */       
/* 4260 */       synchronized (getConnectionMutex()) {
/* 4261 */         if (this.cancelTimer != null) {
/* 4262 */           this.cancelTimer.cancel();
/*      */         }
/*      */       } 
/*      */       
/* 4266 */       this.isClosed = true;
/*      */     } 
/*      */     
/* 4269 */     if (sqlEx != null) {
/* 4270 */       throw sqlEx;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void recachePreparedStatement(ServerPreparedStatement pstmt) throws SQLException {
/* 4276 */     synchronized (getConnectionMutex()) {
/* 4277 */       if (getCachePreparedStatements() && pstmt.isPoolable()) {
/* 4278 */         synchronized (this.serverSideStatementCache) {
/* 4279 */           Object oldServerPrepStmt = this.serverSideStatementCache.put(new CompoundCacheKey(pstmt.currentCatalog, pstmt.originalSql), pstmt);
/* 4280 */           if (oldServerPrepStmt != null && oldServerPrepStmt != pstmt) {
/* 4281 */             ((ServerPreparedStatement)oldServerPrepStmt).isCached = false;
/* 4282 */             ((ServerPreparedStatement)oldServerPrepStmt).setClosed(false);
/* 4283 */             ((ServerPreparedStatement)oldServerPrepStmt).realClose(true, true);
/*      */           } 
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   public void decachePreparedStatement(ServerPreparedStatement pstmt) throws SQLException {
/* 4291 */     synchronized (getConnectionMutex()) {
/* 4292 */       if (getCachePreparedStatements() && pstmt.isPoolable()) {
/* 4293 */         synchronized (this.serverSideStatementCache) {
/* 4294 */           this.serverSideStatementCache.remove(new CompoundCacheKey(pstmt.currentCatalog, pstmt.originalSql));
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerQueryExecutionTime(long queryTimeMs) {
/* 4304 */     if (queryTimeMs > this.longestQueryTimeMs) {
/* 4305 */       this.longestQueryTimeMs = queryTimeMs;
/*      */       
/* 4307 */       repartitionPerformanceHistogram();
/*      */     } 
/*      */     
/* 4310 */     addToPerformanceHistogram(queryTimeMs, 1);
/*      */     
/* 4312 */     if (queryTimeMs < this.shortestQueryTimeMs) {
/* 4313 */       this.shortestQueryTimeMs = (queryTimeMs == 0L) ? 1L : queryTimeMs;
/*      */     }
/*      */     
/* 4316 */     this.numberOfQueriesIssued++;
/*      */     
/* 4318 */     this.totalQueryTimeMs += queryTimeMs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerStatement(Statement stmt) {
/* 4328 */     this.openStatements.addIfAbsent(stmt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void releaseSavepoint(Savepoint arg0) throws SQLException {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void repartitionHistogram(int[] histCounts, long[] histBreakpoints, long currentLowerBound, long currentUpperBound) {
/* 4340 */     if (this.oldHistCounts == null) {
/* 4341 */       this.oldHistCounts = new int[histCounts.length];
/* 4342 */       this.oldHistBreakpoints = new long[histBreakpoints.length];
/*      */     } 
/*      */     
/* 4345 */     System.arraycopy(histCounts, 0, this.oldHistCounts, 0, histCounts.length);
/*      */     
/* 4347 */     System.arraycopy(histBreakpoints, 0, this.oldHistBreakpoints, 0, histBreakpoints.length);
/*      */     
/* 4349 */     createInitialHistogram(histBreakpoints, currentLowerBound, currentUpperBound);
/*      */     
/* 4351 */     for (int i = 0; i < 20; i++) {
/* 4352 */       addToHistogram(histCounts, histBreakpoints, this.oldHistBreakpoints[i], this.oldHistCounts[i], currentLowerBound, currentUpperBound);
/*      */     }
/*      */   }
/*      */   
/*      */   private void repartitionPerformanceHistogram() {
/* 4357 */     checkAndCreatePerformanceHistogram();
/*      */     
/* 4359 */     repartitionHistogram(this.perfMetricsHistCounts, this.perfMetricsHistBreakpoints, (this.shortestQueryTimeMs == Long.MAX_VALUE) ? 0L : this.shortestQueryTimeMs, this.longestQueryTimeMs);
/*      */   }
/*      */ 
/*      */   
/*      */   private void repartitionTablesAccessedHistogram() {
/* 4364 */     checkAndCreateTablesAccessedHistogram();
/*      */     
/* 4366 */     repartitionHistogram(this.numTablesMetricsHistCounts, this.numTablesMetricsHistBreakpoints, (this.minimumNumberTablesAccessed == Long.MAX_VALUE) ? 0L : this.minimumNumberTablesAccessed, this.maximumNumberTablesAccessed);
/*      */   }
/*      */ 
/*      */   
/*      */   private void reportMetrics() {
/* 4371 */     if (getGatherPerformanceMetrics()) {
/* 4372 */       StringBuilder logMessage = new StringBuilder(256);
/*      */       
/* 4374 */       logMessage.append("** Performance Metrics Report **\n");
/* 4375 */       logMessage.append("\nLongest reported query: " + this.longestQueryTimeMs + " ms");
/* 4376 */       logMessage.append("\nShortest reported query: " + this.shortestQueryTimeMs + " ms");
/* 4377 */       logMessage.append("\nAverage query execution time: " + (this.totalQueryTimeMs / this.numberOfQueriesIssued) + " ms");
/* 4378 */       logMessage.append("\nNumber of statements executed: " + this.numberOfQueriesIssued);
/* 4379 */       logMessage.append("\nNumber of result sets created: " + this.numberOfResultSetsCreated);
/* 4380 */       logMessage.append("\nNumber of statements prepared: " + this.numberOfPrepares);
/* 4381 */       logMessage.append("\nNumber of prepared statement executions: " + this.numberOfPreparedExecutes);
/*      */       
/* 4383 */       if (this.perfMetricsHistBreakpoints != null) {
/* 4384 */         logMessage.append("\n\n\tTiming Histogram:\n");
/* 4385 */         int maxNumPoints = 20;
/* 4386 */         int highestCount = Integer.MIN_VALUE;
/*      */         int i;
/* 4388 */         for (i = 0; i < 20; i++) {
/* 4389 */           if (this.perfMetricsHistCounts[i] > highestCount) {
/* 4390 */             highestCount = this.perfMetricsHistCounts[i];
/*      */           }
/*      */         } 
/*      */         
/* 4394 */         if (highestCount == 0) {
/* 4395 */           highestCount = 1;
/*      */         }
/*      */         
/* 4398 */         for (i = 0; i < 19; i++) {
/*      */           
/* 4400 */           if (i == 0) {
/* 4401 */             logMessage.append("\n\tless than " + this.perfMetricsHistBreakpoints[i + 1] + " ms: \t" + this.perfMetricsHistCounts[i]);
/*      */           } else {
/* 4403 */             logMessage.append("\n\tbetween " + this.perfMetricsHistBreakpoints[i] + " and " + this.perfMetricsHistBreakpoints[i + 1] + " ms: \t" + this.perfMetricsHistCounts[i]);
/*      */           } 
/*      */ 
/*      */           
/* 4407 */           logMessage.append("\t");
/*      */           
/* 4409 */           int numPointsToGraph = (int)(maxNumPoints * this.perfMetricsHistCounts[i] / highestCount);
/*      */           
/* 4411 */           for (int j = 0; j < numPointsToGraph; j++) {
/* 4412 */             logMessage.append("*");
/*      */           }
/*      */           
/* 4415 */           if (this.longestQueryTimeMs < this.perfMetricsHistCounts[i + 1]) {
/*      */             break;
/*      */           }
/*      */         } 
/*      */         
/* 4420 */         if (this.perfMetricsHistBreakpoints[18] < this.longestQueryTimeMs) {
/* 4421 */           logMessage.append("\n\tbetween ");
/* 4422 */           logMessage.append(this.perfMetricsHistBreakpoints[18]);
/* 4423 */           logMessage.append(" and ");
/* 4424 */           logMessage.append(this.perfMetricsHistBreakpoints[19]);
/* 4425 */           logMessage.append(" ms: \t");
/* 4426 */           logMessage.append(this.perfMetricsHistCounts[19]);
/*      */         } 
/*      */       } 
/*      */       
/* 4430 */       if (this.numTablesMetricsHistBreakpoints != null) {
/* 4431 */         logMessage.append("\n\n\tTable Join Histogram:\n");
/* 4432 */         int maxNumPoints = 20;
/* 4433 */         int highestCount = Integer.MIN_VALUE;
/*      */         int i;
/* 4435 */         for (i = 0; i < 20; i++) {
/* 4436 */           if (this.numTablesMetricsHistCounts[i] > highestCount) {
/* 4437 */             highestCount = this.numTablesMetricsHistCounts[i];
/*      */           }
/*      */         } 
/*      */         
/* 4441 */         if (highestCount == 0) {
/* 4442 */           highestCount = 1;
/*      */         }
/*      */         
/* 4445 */         for (i = 0; i < 19; i++) {
/*      */           
/* 4447 */           if (i == 0) {
/* 4448 */             logMessage.append("\n\t" + this.numTablesMetricsHistBreakpoints[i + 1] + " tables or less: \t\t" + this.numTablesMetricsHistCounts[i]);
/*      */           } else {
/* 4450 */             logMessage.append("\n\tbetween " + this.numTablesMetricsHistBreakpoints[i] + " and " + this.numTablesMetricsHistBreakpoints[i + 1] + " tables: \t" + this.numTablesMetricsHistCounts[i]);
/*      */           } 
/*      */ 
/*      */           
/* 4454 */           logMessage.append("\t");
/*      */           
/* 4456 */           int numPointsToGraph = (int)(maxNumPoints * this.numTablesMetricsHistCounts[i] / highestCount);
/*      */           
/* 4458 */           for (int j = 0; j < numPointsToGraph; j++) {
/* 4459 */             logMessage.append("*");
/*      */           }
/*      */           
/* 4462 */           if (this.maximumNumberTablesAccessed < this.numTablesMetricsHistBreakpoints[i + 1]) {
/*      */             break;
/*      */           }
/*      */         } 
/*      */         
/* 4467 */         if (this.numTablesMetricsHistBreakpoints[18] < this.maximumNumberTablesAccessed) {
/* 4468 */           logMessage.append("\n\tbetween ");
/* 4469 */           logMessage.append(this.numTablesMetricsHistBreakpoints[18]);
/* 4470 */           logMessage.append(" and ");
/* 4471 */           logMessage.append(this.numTablesMetricsHistBreakpoints[19]);
/* 4472 */           logMessage.append(" tables: ");
/* 4473 */           logMessage.append(this.numTablesMetricsHistCounts[19]);
/*      */         } 
/*      */       } 
/*      */       
/* 4477 */       this.log.logInfo(logMessage);
/*      */       
/* 4479 */       this.metricsLastReportedMs = System.currentTimeMillis();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void reportMetricsIfNeeded() {
/* 4488 */     if (getGatherPerformanceMetrics() && 
/* 4489 */       System.currentTimeMillis() - this.metricsLastReportedMs > getReportMetricsIntervalMillis()) {
/* 4490 */       reportMetrics();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void reportNumberOfTablesAccessed(int numTablesAccessed) {
/* 4496 */     if (numTablesAccessed < this.minimumNumberTablesAccessed) {
/* 4497 */       this.minimumNumberTablesAccessed = numTablesAccessed;
/*      */     }
/*      */     
/* 4500 */     if (numTablesAccessed > this.maximumNumberTablesAccessed) {
/* 4501 */       this.maximumNumberTablesAccessed = numTablesAccessed;
/*      */       
/* 4503 */       repartitionTablesAccessedHistogram();
/*      */     } 
/*      */     
/* 4506 */     addToTablesAccessedHistogram(numTablesAccessed, 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resetServerState() throws SQLException {
/* 4518 */     if (!getParanoid() && this.io != null && versionMeetsMinimum(4, 0, 6)) {
/* 4519 */       changeUser(this.user, this.password);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void rollback() throws SQLException {
/* 4533 */     synchronized (getConnectionMutex()) {
/* 4534 */       checkClosed();
/*      */       
/*      */       try {
/* 4537 */         if (this.connectionLifecycleInterceptors != null) {
/* 4538 */           IterateBlock<Extension> iter = new IterateBlock<Extension>(this.connectionLifecycleInterceptors.iterator())
/*      */             {
/*      */               void forEach(Extension each) throws SQLException
/*      */               {
/* 4542 */                 if (!((ConnectionLifecycleInterceptor)each).rollback()) {
/* 4543 */                   this.stopIterating = true;
/*      */                 }
/*      */               }
/*      */             };
/*      */           
/* 4548 */           iter.doForAll();
/*      */           
/* 4550 */           if (!iter.fullIteration()) {
/*      */             return;
/*      */           }
/*      */         } 
/*      */         
/* 4555 */         if (this.autoCommit && !getRelaxAutoCommit()) {
/* 4556 */           throw SQLError.createSQLException("Can't call rollback when autocommit=true", "08003", getExceptionInterceptor());
/*      */         }
/* 4558 */         if (this.transactionsSupported) {
/*      */           try {
/* 4560 */             rollbackNoChecks();
/* 4561 */           } catch (SQLException sqlEx) {
/*      */             
/* 4563 */             if (getIgnoreNonTxTables() && sqlEx.getErrorCode() == 1196) {
/*      */               return;
/*      */             }
/* 4566 */             throw sqlEx;
/*      */           }
/*      */         
/*      */         }
/* 4570 */       } catch (SQLException sqlException) {
/* 4571 */         if ("08S01".equals(sqlException.getSQLState())) {
/* 4572 */           throw SQLError.createSQLException("Communications link failure during rollback(). Transaction resolution unknown.", "08007", getExceptionInterceptor());
/*      */         }
/*      */ 
/*      */         
/* 4576 */         throw sqlException;
/*      */       } finally {
/* 4578 */         this.needsPing = getReconnectAtTxEnd();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void rollback(final Savepoint savepoint) throws SQLException {
/* 4588 */     synchronized (getConnectionMutex()) {
/* 4589 */       if (versionMeetsMinimum(4, 0, 14) || versionMeetsMinimum(4, 1, 1)) {
/* 4590 */         checkClosed();
/*      */         
/*      */         try {
/* 4593 */           if (this.connectionLifecycleInterceptors != null) {
/* 4594 */             IterateBlock<Extension> iter = new IterateBlock<Extension>(this.connectionLifecycleInterceptors.iterator())
/*      */               {
/*      */                 void forEach(Extension each) throws SQLException
/*      */                 {
/* 4598 */                   if (!((ConnectionLifecycleInterceptor)each).rollback(savepoint)) {
/* 4599 */                     this.stopIterating = true;
/*      */                   }
/*      */                 }
/*      */               };
/*      */             
/* 4604 */             iter.doForAll();
/*      */             
/* 4606 */             if (!iter.fullIteration()) {
/*      */               return;
/*      */             }
/*      */           } 
/*      */           
/* 4611 */           StringBuilder rollbackQuery = new StringBuilder("ROLLBACK TO SAVEPOINT ");
/* 4612 */           rollbackQuery.append('`');
/* 4613 */           rollbackQuery.append(savepoint.getSavepointName());
/* 4614 */           rollbackQuery.append('`');
/*      */           
/* 4616 */           Statement stmt = null;
/*      */           
/*      */           try {
/* 4619 */             stmt = getMetadataSafeStatement();
/*      */             
/* 4621 */             stmt.executeUpdate(rollbackQuery.toString());
/* 4622 */           } catch (SQLException sqlEx) {
/* 4623 */             int errno = sqlEx.getErrorCode();
/*      */             
/* 4625 */             if (errno == 1181) {
/* 4626 */               String msg = sqlEx.getMessage();
/*      */               
/* 4628 */               if (msg != null) {
/* 4629 */                 int indexOfError153 = msg.indexOf("153");
/*      */                 
/* 4631 */                 if (indexOfError153 != -1) {
/* 4632 */                   throw SQLError.createSQLException("Savepoint '" + savepoint.getSavepointName() + "' does not exist", "S1009", errno, getExceptionInterceptor());
/*      */                 }
/*      */               } 
/*      */             } 
/*      */ 
/*      */ 
/*      */             
/* 4639 */             if (getIgnoreNonTxTables() && sqlEx.getErrorCode() != 1196) {
/* 4640 */               throw sqlEx;
/*      */             }
/*      */             
/* 4643 */             if ("08S01".equals(sqlEx.getSQLState())) {
/* 4644 */               throw SQLError.createSQLException("Communications link failure during rollback(). Transaction resolution unknown.", "08007", getExceptionInterceptor());
/*      */             }
/*      */ 
/*      */             
/* 4648 */             throw sqlEx;
/*      */           } finally {
/* 4650 */             closeStatement(stmt);
/*      */           } 
/*      */         } finally {
/* 4653 */           this.needsPing = getReconnectAtTxEnd();
/*      */         } 
/*      */       } else {
/* 4656 */         throw SQLError.createSQLFeatureNotSupportedException();
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void rollbackNoChecks() throws SQLException {
/* 4662 */     if (getUseLocalTransactionState() && versionMeetsMinimum(5, 0, 0) && 
/* 4663 */       !this.io.inTransactionOnServer()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 4668 */     execSQL((StatementImpl)null, "rollback", -1, (Buffer)null, 1003, 1007, false, this.database, (Field[])null, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql) throws SQLException {
/* 4675 */     String nativeSql = getProcessEscapeCodesForPrepStmts() ? nativeSQL(sql) : sql;
/*      */     
/* 4677 */     return ServerPreparedStatement.getInstance(getMultiHostSafeProxy(), nativeSql, getCatalog(), 1003, 1007);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, int autoGenKeyIndex) throws SQLException {
/* 4685 */     String nativeSql = getProcessEscapeCodesForPrepStmts() ? nativeSQL(sql) : sql;
/*      */     
/* 4687 */     PreparedStatement pStmt = ServerPreparedStatement.getInstance(getMultiHostSafeProxy(), nativeSql, getCatalog(), 1003, 1007);
/*      */ 
/*      */     
/* 4690 */     pStmt.setRetrieveGeneratedKeys((autoGenKeyIndex == 1));
/*      */     
/* 4692 */     return pStmt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/* 4699 */     String nativeSql = getProcessEscapeCodesForPrepStmts() ? nativeSQL(sql) : sql;
/*      */     
/* 4701 */     return ServerPreparedStatement.getInstance(getMultiHostSafeProxy(), nativeSql, getCatalog(), resultSetType, resultSetConcurrency);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/* 4709 */     if (getPedantic() && 
/* 4710 */       resultSetHoldability != 1) {
/* 4711 */       throw SQLError.createSQLException("HOLD_CUSRORS_OVER_COMMIT is only supported holdability level", "S1009", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 4716 */     return serverPrepareStatement(sql, resultSetType, resultSetConcurrency);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, int[] autoGenKeyIndexes) throws SQLException {
/* 4724 */     PreparedStatement pStmt = (PreparedStatement)serverPrepareStatement(sql);
/*      */     
/* 4726 */     pStmt.setRetrieveGeneratedKeys((autoGenKeyIndexes != null && autoGenKeyIndexes.length > 0));
/*      */     
/* 4728 */     return pStmt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, String[] autoGenKeyColNames) throws SQLException {
/* 4735 */     PreparedStatement pStmt = (PreparedStatement)serverPrepareStatement(sql);
/*      */     
/* 4737 */     pStmt.setRetrieveGeneratedKeys((autoGenKeyColNames != null && autoGenKeyColNames.length > 0));
/*      */     
/* 4739 */     return pStmt;
/*      */   }
/*      */   
/*      */   public boolean serverSupportsConvertFn() throws SQLException {
/* 4743 */     return versionMeetsMinimum(4, 0, 2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAutoCommit(final boolean autoCommitFlag) throws SQLException {
/* 4765 */     synchronized (getConnectionMutex()) {
/* 4766 */       checkClosed();
/*      */       
/* 4768 */       if (this.connectionLifecycleInterceptors != null) {
/* 4769 */         IterateBlock<Extension> iter = new IterateBlock<Extension>(this.connectionLifecycleInterceptors.iterator())
/*      */           {
/*      */             void forEach(Extension each) throws SQLException
/*      */             {
/* 4773 */               if (!((ConnectionLifecycleInterceptor)each).setAutoCommit(autoCommitFlag)) {
/* 4774 */                 this.stopIterating = true;
/*      */               }
/*      */             }
/*      */           };
/*      */         
/* 4779 */         iter.doForAll();
/*      */         
/* 4781 */         if (!iter.fullIteration()) {
/*      */           return;
/*      */         }
/*      */       } 
/*      */       
/* 4786 */       if (getAutoReconnectForPools()) {
/* 4787 */         setHighAvailability(true);
/*      */       }
/*      */       
/*      */       try {
/* 4791 */         if (this.transactionsSupported) {
/*      */           
/* 4793 */           boolean needsSetOnServer = true;
/*      */           
/* 4795 */           if (getUseLocalSessionState() && this.autoCommit == autoCommitFlag) {
/* 4796 */             needsSetOnServer = false;
/* 4797 */           } else if (!getHighAvailability()) {
/* 4798 */             needsSetOnServer = getIO().isSetNeededForAutoCommitMode(autoCommitFlag);
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 4804 */           this.autoCommit = autoCommitFlag;
/*      */           
/* 4806 */           if (needsSetOnServer) {
/* 4807 */             execSQL((StatementImpl)null, autoCommitFlag ? "SET autocommit=1" : "SET autocommit=0", -1, (Buffer)null, 1003, 1007, false, this.database, (Field[])null, false);
/*      */           }
/*      */         }
/*      */         else {
/*      */           
/* 4812 */           if (!autoCommitFlag && !getRelaxAutoCommit()) {
/* 4813 */             throw SQLError.createSQLException("MySQL Versions Older than 3.23.15 do not support transactions", "08003", getExceptionInterceptor());
/*      */           }
/*      */ 
/*      */           
/* 4817 */           this.autoCommit = autoCommitFlag;
/*      */         } 
/*      */       } finally {
/* 4820 */         if (getAutoReconnectForPools()) {
/* 4821 */           setHighAvailability(false);
/*      */         }
/*      */       } 
/*      */       return;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCatalog(final String catalog) throws SQLException {
/* 4843 */     synchronized (getConnectionMutex()) {
/* 4844 */       checkClosed();
/*      */       
/* 4846 */       if (catalog == null) {
/* 4847 */         throw SQLError.createSQLException("Catalog can not be null", "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/* 4850 */       if (this.connectionLifecycleInterceptors != null) {
/* 4851 */         IterateBlock<Extension> iter = new IterateBlock<Extension>(this.connectionLifecycleInterceptors.iterator())
/*      */           {
/*      */             void forEach(Extension each) throws SQLException
/*      */             {
/* 4855 */               if (!((ConnectionLifecycleInterceptor)each).setCatalog(catalog)) {
/* 4856 */                 this.stopIterating = true;
/*      */               }
/*      */             }
/*      */           };
/*      */         
/* 4861 */         iter.doForAll();
/*      */         
/* 4863 */         if (!iter.fullIteration()) {
/*      */           return;
/*      */         }
/*      */       } 
/*      */       
/* 4868 */       if (getUseLocalSessionState()) {
/* 4869 */         if (this.lowerCaseTableNames) {
/* 4870 */           if (this.database.equalsIgnoreCase(catalog)) {
/*      */             return;
/*      */           }
/*      */         }
/* 4874 */         else if (this.database.equals(catalog)) {
/*      */           return;
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/* 4880 */       String quotedId = this.dbmd.getIdentifierQuoteString();
/*      */       
/* 4882 */       if (quotedId == null || quotedId.equals(" ")) {
/* 4883 */         quotedId = "";
/*      */       }
/*      */       
/* 4886 */       StringBuilder query = new StringBuilder("USE ");
/* 4887 */       query.append(StringUtils.quoteIdentifier(catalog, quotedId, getPedantic()));
/*      */       
/* 4889 */       execSQL((StatementImpl)null, query.toString(), -1, (Buffer)null, 1003, 1007, false, this.database, (Field[])null, false);
/*      */       
/* 4891 */       this.database = catalog;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFailedOver(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHoldability(int arg0) throws SQLException {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInGlobalTx(boolean flag) {
/* 4911 */     this.isInGlobalTx = flag;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void setPreferSlaveDuringFailover(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setReadInfoMsgEnabled(boolean flag) {
/* 4925 */     this.readInfoMsg = flag;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setReadOnly(boolean readOnlyFlag) throws SQLException {
/* 4940 */     checkClosed();
/*      */     
/* 4942 */     setReadOnlyInternal(readOnlyFlag);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setReadOnlyInternal(boolean readOnlyFlag) throws SQLException {
/* 4947 */     if (getReadOnlyPropagatesToServer() && versionMeetsMinimum(5, 6, 5) && (
/* 4948 */       !getUseLocalSessionState() || readOnlyFlag != this.readOnly)) {
/* 4949 */       execSQL((StatementImpl)null, "set session transaction " + (readOnlyFlag ? "read only" : "read write"), -1, (Buffer)null, 1003, 1007, false, this.database, (Field[])null, false);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 4954 */     this.readOnly = readOnlyFlag;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Savepoint setSavepoint() throws SQLException {
/* 4961 */     MysqlSavepoint savepoint = new MysqlSavepoint(getExceptionInterceptor());
/*      */     
/* 4963 */     setSavepoint(savepoint);
/*      */     
/* 4965 */     return savepoint;
/*      */   }
/*      */ 
/*      */   
/*      */   private void setSavepoint(MysqlSavepoint savepoint) throws SQLException {
/* 4970 */     synchronized (getConnectionMutex()) {
/* 4971 */       if (versionMeetsMinimum(4, 0, 14) || versionMeetsMinimum(4, 1, 1)) {
/* 4972 */         checkClosed();
/*      */         
/* 4974 */         StringBuilder savePointQuery = new StringBuilder("SAVEPOINT ");
/* 4975 */         savePointQuery.append('`');
/* 4976 */         savePointQuery.append(savepoint.getSavepointName());
/* 4977 */         savePointQuery.append('`');
/*      */         
/* 4979 */         Statement stmt = null;
/*      */         
/*      */         try {
/* 4982 */           stmt = getMetadataSafeStatement();
/*      */           
/* 4984 */           stmt.executeUpdate(savePointQuery.toString());
/*      */         } finally {
/* 4986 */           closeStatement(stmt);
/*      */         } 
/*      */       } else {
/* 4989 */         throw SQLError.createSQLFeatureNotSupportedException();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Savepoint setSavepoint(String name) throws SQLException {
/* 4998 */     synchronized (getConnectionMutex()) {
/* 4999 */       MysqlSavepoint savepoint = new MysqlSavepoint(name, getExceptionInterceptor());
/*      */       
/* 5001 */       setSavepoint(savepoint);
/*      */       
/* 5003 */       return savepoint;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void setSessionVariables() throws SQLException {
/* 5008 */     if (versionMeetsMinimum(4, 0, 0) && getSessionVariables() != null) {
/* 5009 */       List<String> variablesToSet = new ArrayList<String>();
/* 5010 */       for (String part : StringUtils.split(getSessionVariables(), ",", "\"'(", "\"')", "\"'", true)) {
/* 5011 */         variablesToSet.addAll(StringUtils.split(part, ";", "\"'(", "\"')", "\"'", true));
/*      */       }
/*      */       
/* 5014 */       if (!variablesToSet.isEmpty()) {
/* 5015 */         Statement stmt = null;
/*      */         try {
/* 5017 */           stmt = getMetadataSafeStatement();
/* 5018 */           StringBuilder query = new StringBuilder("SET ");
/* 5019 */           String separator = "";
/* 5020 */           for (String variableToSet : variablesToSet) {
/* 5021 */             if (variableToSet.length() > 0) {
/* 5022 */               query.append(separator);
/* 5023 */               if (!variableToSet.startsWith("@")) {
/* 5024 */                 query.append("SESSION ");
/*      */               }
/* 5026 */               query.append(variableToSet);
/* 5027 */               separator = ",";
/*      */             } 
/*      */           } 
/* 5030 */           stmt.executeUpdate(query.toString());
/*      */         } finally {
/* 5032 */           if (stmt != null) {
/* 5033 */             stmt.close();
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTransactionIsolation(int level) throws SQLException {
/* 5045 */     synchronized (getConnectionMutex()) {
/* 5046 */       checkClosed();
/*      */       
/* 5048 */       if (this.hasIsolationLevels) {
/* 5049 */         String sql = null;
/*      */         
/* 5051 */         boolean shouldSendSet = false;
/*      */         
/* 5053 */         if (getAlwaysSendSetIsolation()) {
/* 5054 */           shouldSendSet = true;
/*      */         }
/* 5056 */         else if (level != this.isolationLevel) {
/* 5057 */           shouldSendSet = true;
/*      */         } 
/*      */ 
/*      */         
/* 5061 */         if (getUseLocalSessionState()) {
/* 5062 */           shouldSendSet = (this.isolationLevel != level);
/*      */         }
/*      */         
/* 5065 */         if (shouldSendSet) {
/* 5066 */           switch (level) {
/*      */             case 0:
/* 5068 */               throw SQLError.createSQLException("Transaction isolation level NONE not supported by MySQL", getExceptionInterceptor());
/*      */             
/*      */             case 2:
/* 5071 */               sql = "SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED";
/*      */               break;
/*      */ 
/*      */             
/*      */             case 1:
/* 5076 */               sql = "SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED";
/*      */               break;
/*      */ 
/*      */             
/*      */             case 4:
/* 5081 */               sql = "SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ";
/*      */               break;
/*      */ 
/*      */             
/*      */             case 8:
/* 5086 */               sql = "SET SESSION TRANSACTION ISOLATION LEVEL SERIALIZABLE";
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 5091 */               throw SQLError.createSQLException("Unsupported transaction isolation level '" + level + "'", "S1C00", getExceptionInterceptor());
/*      */           } 
/*      */ 
/*      */           
/* 5095 */           execSQL((StatementImpl)null, sql, -1, (Buffer)null, 1003, 1007, false, this.database, (Field[])null, false);
/*      */           
/* 5097 */           this.isolationLevel = level;
/*      */         } 
/*      */       } else {
/* 5100 */         throw SQLError.createSQLException("Transaction Isolation Levels are not supported on MySQL versions older than 3.23.36.", "S1C00", getExceptionInterceptor());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTypeMap(Map<String, Class<?>> map) throws SQLException {
/* 5116 */     synchronized (getConnectionMutex()) {
/* 5117 */       this.typeMap = map;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void setupServerForTruncationChecks() throws SQLException {
/* 5122 */     if (getJdbcCompliantTruncation() && 
/* 5123 */       versionMeetsMinimum(5, 0, 2)) {
/* 5124 */       String currentSqlMode = this.serverVariables.get("sql_mode");
/*      */       
/* 5126 */       boolean strictTransTablesIsSet = (StringUtils.indexOfIgnoreCase(currentSqlMode, "STRICT_TRANS_TABLES") != -1);
/*      */       
/* 5128 */       if (currentSqlMode == null || currentSqlMode.length() == 0 || !strictTransTablesIsSet) {
/* 5129 */         StringBuilder commandBuf = new StringBuilder("SET sql_mode='");
/*      */         
/* 5131 */         if (currentSqlMode != null && currentSqlMode.length() > 0) {
/* 5132 */           commandBuf.append(currentSqlMode);
/* 5133 */           commandBuf.append(",");
/*      */         } 
/*      */         
/* 5136 */         commandBuf.append("STRICT_TRANS_TABLES'");
/*      */         
/* 5138 */         execSQL((StatementImpl)null, commandBuf.toString(), -1, (Buffer)null, 1003, 1007, false, this.database, (Field[])null, false);
/*      */         
/* 5140 */         setJdbcCompliantTruncation(false);
/* 5141 */       } else if (strictTransTablesIsSet) {
/*      */         
/* 5143 */         setJdbcCompliantTruncation(false);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void shutdownServer() throws SQLException {
/*      */     try {
/* 5158 */       if (versionMeetsMinimum(5, 7, 9)) {
/* 5159 */         execSQL((StatementImpl)null, "SHUTDOWN", -1, (Buffer)null, 1003, 1007, false, this.database, (Field[])null, false);
/*      */       } else {
/* 5161 */         this.io.sendCommand(8, null, null, false, null, 0);
/*      */       } 
/* 5163 */     } catch (Exception ex) {
/* 5164 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString("Connection.UnhandledExceptionDuringShutdown"), "S1000", getExceptionInterceptor());
/*      */ 
/*      */       
/* 5167 */       sqlEx.initCause(ex);
/*      */       
/* 5169 */       throw sqlEx;
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean supportsIsolationLevel() {
/* 5174 */     return this.hasIsolationLevels;
/*      */   }
/*      */   
/*      */   public boolean supportsQuotedIdentifiers() {
/* 5178 */     return this.hasQuotedIdentifiers;
/*      */   }
/*      */   
/*      */   public boolean supportsTransactions() {
/* 5182 */     return this.transactionsSupported;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unregisterStatement(Statement stmt) {
/* 5192 */     this.openStatements.remove(stmt);
/*      */   }
/*      */   
/*      */   public boolean useAnsiQuotedIdentifiers() {
/* 5196 */     synchronized (getConnectionMutex()) {
/* 5197 */       return this.useAnsiQuotes;
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean versionMeetsMinimum(int major, int minor, int subminor) throws SQLException {
/* 5202 */     checkClosed();
/*      */     
/* 5204 */     return this.io.versionMeetsMinimum(major, minor, subminor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CachedResultSetMetaData getCachedMetaData(String sql) {
/* 5222 */     if (this.resultSetMetadataCache != null) {
/* 5223 */       synchronized (this.resultSetMetadataCache) {
/* 5224 */         return (CachedResultSetMetaData)this.resultSetMetadataCache.get(sql);
/*      */       } 
/*      */     }
/*      */     
/* 5228 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void initializeResultsMetadataFromCache(String sql, CachedResultSetMetaData cachedMetaData, ResultSetInternalMethods resultSet) throws SQLException {
/* 5250 */     if (cachedMetaData == null) {
/*      */ 
/*      */       
/* 5253 */       cachedMetaData = new CachedResultSetMetaData();
/*      */ 
/*      */       
/* 5256 */       resultSet.buildIndexMapping();
/* 5257 */       resultSet.initializeWithMetadata();
/*      */       
/* 5259 */       if (resultSet instanceof UpdatableResultSet) {
/* 5260 */         ((UpdatableResultSet)resultSet).checkUpdatability();
/*      */       }
/*      */       
/* 5263 */       resultSet.populateCachedMetaData(cachedMetaData);
/*      */       
/* 5265 */       this.resultSetMetadataCache.put(sql, cachedMetaData);
/*      */     } else {
/* 5267 */       resultSet.initializeFromCachedMetaData(cachedMetaData);
/* 5268 */       resultSet.initializeWithMetadata();
/*      */       
/* 5270 */       if (resultSet instanceof UpdatableResultSet) {
/* 5271 */         ((UpdatableResultSet)resultSet).checkUpdatability();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getStatementComment() {
/* 5284 */     return this.statementComment;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStatementComment(String comment) {
/* 5297 */     this.statementComment = comment;
/*      */   }
/*      */   
/*      */   public void reportQueryTime(long millisOrNanos) {
/* 5301 */     synchronized (getConnectionMutex()) {
/* 5302 */       this.queryTimeCount++;
/* 5303 */       this.queryTimeSum += millisOrNanos;
/* 5304 */       this.queryTimeSumSquares += (millisOrNanos * millisOrNanos);
/* 5305 */       this.queryTimeMean = (this.queryTimeMean * (this.queryTimeCount - 1L) + millisOrNanos) / this.queryTimeCount;
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean isAbonormallyLongQuery(long millisOrNanos) {
/* 5310 */     synchronized (getConnectionMutex()) {
/* 5311 */       if (this.queryTimeCount < 15L) {
/* 5312 */         return false;
/*      */       }
/*      */       
/* 5315 */       double stddev = Math.sqrt((this.queryTimeSumSquares - this.queryTimeSum * this.queryTimeSum / this.queryTimeCount) / (this.queryTimeCount - 1L));
/*      */       
/* 5317 */       return (millisOrNanos > this.queryTimeMean + 5.0D * stddev);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void initializeExtension(Extension ex) throws SQLException {
/* 5322 */     ex.init(this, this.props);
/*      */   }
/*      */   
/*      */   public void transactionBegun() throws SQLException {
/* 5326 */     synchronized (getConnectionMutex()) {
/* 5327 */       if (this.connectionLifecycleInterceptors != null) {
/* 5328 */         IterateBlock<Extension> iter = new IterateBlock<Extension>(this.connectionLifecycleInterceptors.iterator())
/*      */           {
/*      */             void forEach(Extension each) throws SQLException
/*      */             {
/* 5332 */               ((ConnectionLifecycleInterceptor)each).transactionBegun();
/*      */             }
/*      */           };
/*      */         
/* 5336 */         iter.doForAll();
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void transactionCompleted() throws SQLException {
/* 5342 */     synchronized (getConnectionMutex()) {
/* 5343 */       if (this.connectionLifecycleInterceptors != null) {
/* 5344 */         IterateBlock<Extension> iter = new IterateBlock<Extension>(this.connectionLifecycleInterceptors.iterator())
/*      */           {
/*      */             void forEach(Extension each) throws SQLException
/*      */             {
/* 5348 */               ((ConnectionLifecycleInterceptor)each).transactionCompleted();
/*      */             }
/*      */           };
/*      */         
/* 5352 */         iter.doForAll();
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean storesLowerCaseTableName() {
/* 5358 */     return this.storesLowerCaseTableName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ExceptionInterceptor getExceptionInterceptor() {
/* 5365 */     return this.exceptionInterceptor;
/*      */   }
/*      */   
/*      */   public boolean getRequiresEscapingEncoder() {
/* 5369 */     return this.requiresEscapingEncoder;
/*      */   }
/*      */   
/*      */   public boolean isServerLocal() throws SQLException {
/* 5373 */     synchronized (getConnectionMutex()) {
/* 5374 */       SocketFactory factory = (getIO()).socketFactory;
/*      */       
/* 5376 */       if (factory instanceof SocketMetadata) {
/* 5377 */         return ((SocketMetadata)factory).isLocallyConnected(this);
/*      */       }
/* 5379 */       getLog().logWarn(Messages.getString("Connection.NoMetadataOnSocketFactory"));
/* 5380 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getSessionMaxRows() {
/* 5388 */     synchronized (getConnectionMutex()) {
/* 5389 */       return this.sessionMaxRows;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSessionMaxRows(int max) throws SQLException {
/* 5402 */     synchronized (getConnectionMutex()) {
/* 5403 */       if (this.sessionMaxRows != max) {
/* 5404 */         this.sessionMaxRows = max;
/* 5405 */         execSQL((StatementImpl)null, "SET SQL_SELECT_LIMIT=" + ((this.sessionMaxRows == -1) ? "DEFAULT" : (String)Integer.valueOf(this.sessionMaxRows)), -1, (Buffer)null, 1003, 1007, false, this.database, (Field[])null, false);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSchema(String schema) throws SQLException {
/* 5414 */     synchronized (getConnectionMutex()) {
/* 5415 */       checkClosed();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public String getSchema() throws SQLException {
/* 5421 */     synchronized (getConnectionMutex()) {
/* 5422 */       checkClosed();
/*      */       
/* 5424 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void abort(Executor executor) throws SQLException {
/* 5459 */     SecurityManager sec = System.getSecurityManager();
/*      */     
/* 5461 */     if (sec != null) {
/* 5462 */       sec.checkPermission(ABORT_PERM);
/*      */     }
/*      */     
/* 5465 */     if (executor == null) {
/* 5466 */       throw SQLError.createSQLException("Executor can not be null", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/* 5469 */     executor.execute(new Runnable()
/*      */         {
/*      */           public void run() {
/*      */             try {
/* 5473 */               ConnectionImpl.this.abortInternal();
/* 5474 */             } catch (SQLException e) {
/* 5475 */               throw new RuntimeException(e);
/*      */             } 
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   public void setNetworkTimeout(Executor executor, int milliseconds) throws SQLException {
/* 5483 */     synchronized (getConnectionMutex()) {
/* 5484 */       SecurityManager sec = System.getSecurityManager();
/*      */       
/* 5486 */       if (sec != null) {
/* 5487 */         sec.checkPermission(SET_NETWORK_TIMEOUT_PERM);
/*      */       }
/*      */       
/* 5490 */       if (executor == null) {
/* 5491 */         throw SQLError.createSQLException("Executor can not be null", "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/* 5494 */       checkClosed();
/* 5495 */       executor.execute(new NetworkTimeoutSetter(this, this.io, milliseconds));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public int getNetworkTimeout() throws SQLException {
/* 5501 */     synchronized (getConnectionMutex()) {
/* 5502 */       checkClosed();
/* 5503 */       return getSocketTimeout();
/*      */     } 
/*      */   }
/*      */   
/*      */   public ProfilerEventHandler getProfilerEventHandlerInstance() {
/* 5508 */     return this.eventSink;
/*      */   }
/*      */   
/*      */   public void setProfilerEventHandlerInstance(ProfilerEventHandler h) {
/* 5512 */     this.eventSink = h;
/*      */   }
/*      */   
/*      */   public boolean isServerTruncatesFracSecs() {
/* 5516 */     return this.serverTruncatesFracSecs;
/*      */   }
/*      */   
/*      */   private static class NetworkTimeoutSetter implements Runnable {
/*      */     private final WeakReference<ConnectionImpl> connImplRef;
/*      */     private final WeakReference<MysqlIO> mysqlIoRef;
/*      */     private final int milliseconds;
/*      */     
/*      */     public NetworkTimeoutSetter(ConnectionImpl conn, MysqlIO io, int milliseconds) {
/* 5525 */       this.connImplRef = new WeakReference<ConnectionImpl>(conn);
/* 5526 */       this.mysqlIoRef = new WeakReference<MysqlIO>(io);
/* 5527 */       this.milliseconds = milliseconds;
/*      */     }
/*      */     
/*      */     public void run() {
/*      */       try {
/* 5532 */         ConnectionImpl conn = this.connImplRef.get();
/* 5533 */         if (conn != null) {
/* 5534 */           synchronized (conn.getConnectionMutex()) {
/* 5535 */             conn.setSocketTimeout(this.milliseconds);
/* 5536 */             MysqlIO io = this.mysqlIoRef.get();
/* 5537 */             if (io != null) {
/* 5538 */               io.setSocketTimeout(this.milliseconds);
/*      */             }
/*      */           } 
/*      */         }
/* 5542 */       } catch (SQLException e) {
/* 5543 */         throw new RuntimeException(e);
/*      */       } 
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\neons\Desktop\JacobAloSchedulingApp\build\classes\!\lib\mysql-connector-java-5.1.47.jar!\com\mysql\jdbc\ConnectionImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */
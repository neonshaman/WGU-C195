/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import com.mysql.jdbc.util.Base64Decoder;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketException;
/*     */ import java.net.URL;
/*     */ import java.security.InvalidAlgorithmParameterException;
/*     */ import java.security.KeyFactory;
/*     */ import java.security.KeyManagementException;
/*     */ import java.security.KeyStore;
/*     */ import java.security.KeyStoreException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.UnrecoverableKeyException;
/*     */ import java.security.cert.CertPath;
/*     */ import java.security.cert.CertPathValidator;
/*     */ import java.security.cert.CertPathValidatorException;
/*     */ import java.security.cert.CertPathValidatorResult;
/*     */ import java.security.cert.Certificate;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.PKIXCertPathValidatorResult;
/*     */ import java.security.cert.PKIXParameters;
/*     */ import java.security.cert.TrustAnchor;
/*     */ import java.security.cert.X509CertSelector;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.security.interfaces.RSAPublicKey;
/*     */ import java.security.spec.X509EncodedKeySpec;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.net.ssl.KeyManager;
/*     */ import javax.net.ssl.KeyManagerFactory;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import javax.net.ssl.SSLSocket;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ import javax.net.ssl.TrustManager;
/*     */ import javax.net.ssl.TrustManagerFactory;
/*     */ import javax.net.ssl.X509TrustManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExportControlled
/*     */ {
/*     */   private static final String SQL_STATE_BAD_SSL_PARAMS = "08000";
/*     */   private static final String TLSv1 = "TLSv1";
/*     */   private static final String TLSv1_1 = "TLSv1.1";
/*     */   private static final String TLSv1_2 = "TLSv1.2";
/*  82 */   private static final String[] TLS_PROTOCOLS = new String[] { "TLSv1.2", "TLSv1.1", "TLSv1" };
/*     */ 
/*     */   
/*     */   protected static boolean enabled() {
/*  86 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void transformSocketToSSLSocket(MysqlIO mysqlIO) throws SQLException {
/* 103 */     SocketFactory sslFact = new StandardSSLSocketFactory(getSSLSocketFactoryDefaultOrConfigured(mysqlIO), mysqlIO.socketFactory, mysqlIO.mysqlConnection);
/*     */     
/*     */     try {
/* 106 */       mysqlIO.mysqlConnection = sslFact.connect(mysqlIO.host, mysqlIO.port, null);
/*     */       
/* 108 */       String[] tryProtocols = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 115 */       String enabledTLSProtocols = mysqlIO.connection.getEnabledTLSProtocols();
/* 116 */       if (enabledTLSProtocols != null && enabledTLSProtocols.length() > 0) {
/* 117 */         tryProtocols = enabledTLSProtocols.split("\\s*,\\s*");
/* 118 */       } else if (mysqlIO.versionMeetsMinimum(8, 0, 4) || (mysqlIO.versionMeetsMinimum(5, 6, 0) && Util.isEnterpriseEdition(mysqlIO.getServerVersion()))) {
/*     */         
/* 120 */         tryProtocols = TLS_PROTOCOLS;
/*     */       } else {
/*     */         
/* 123 */         tryProtocols = new String[] { "TLSv1.1", "TLSv1" };
/*     */       } 
/*     */ 
/*     */       
/* 127 */       List<String> configuredProtocols = new ArrayList<String>(Arrays.asList(tryProtocols));
/* 128 */       List<String> jvmSupportedProtocols = Arrays.asList(((SSLSocket)mysqlIO.mysqlConnection).getSupportedProtocols());
/* 129 */       List<String> allowedProtocols = new ArrayList<String>();
/* 130 */       for (String protocol : TLS_PROTOCOLS) {
/* 131 */         if (jvmSupportedProtocols.contains(protocol) && configuredProtocols.contains(protocol)) {
/* 132 */           allowedProtocols.add(protocol);
/*     */         }
/*     */       } 
/* 135 */       ((SSLSocket)mysqlIO.mysqlConnection).setEnabledProtocols(allowedProtocols.<String>toArray(new String[0]));
/*     */ 
/*     */       
/* 138 */       String enabledSSLCipherSuites = mysqlIO.connection.getEnabledSSLCipherSuites();
/* 139 */       boolean overrideCiphers = (enabledSSLCipherSuites != null && enabledSSLCipherSuites.length() > 0);
/*     */       
/* 141 */       List<String> allowedCiphers = null;
/* 142 */       if (overrideCiphers) {
/*     */ 
/*     */         
/* 145 */         allowedCiphers = new ArrayList<String>();
/* 146 */         List<String> availableCiphers = Arrays.asList(((SSLSocket)mysqlIO.mysqlConnection).getEnabledCipherSuites());
/* 147 */         for (String cipher : enabledSSLCipherSuites.split("\\s*,\\s*")) {
/* 148 */           if (availableCiphers.contains(cipher)) {
/* 149 */             allowedCiphers.add(cipher);
/*     */           }
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 155 */         boolean disableDHAlgorithm = false;
/* 156 */         if ((mysqlIO.versionMeetsMinimum(5, 5, 45) && !mysqlIO.versionMeetsMinimum(5, 6, 0)) || (mysqlIO.versionMeetsMinimum(5, 6, 26) && !mysqlIO.versionMeetsMinimum(5, 7, 0)) || mysqlIO.versionMeetsMinimum(5, 7, 6)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 162 */           if (Util.getJVMVersion() < 8) {
/* 163 */             disableDHAlgorithm = true;
/*     */           }
/* 165 */         } else if (Util.getJVMVersion() >= 8) {
/*     */ 
/*     */           
/* 168 */           disableDHAlgorithm = true;
/*     */         } 
/*     */         
/* 171 */         if (disableDHAlgorithm) {
/* 172 */           allowedCiphers = new ArrayList<String>();
/* 173 */           for (String cipher : ((SSLSocket)mysqlIO.mysqlConnection).getEnabledCipherSuites()) {
/* 174 */             if (!disableDHAlgorithm || (cipher.indexOf("_DHE_") <= -1 && cipher.indexOf("_DH_") <= -1)) {
/* 175 */               allowedCiphers.add(cipher);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 182 */       if (allowedCiphers != null) {
/* 183 */         ((SSLSocket)mysqlIO.mysqlConnection).setEnabledCipherSuites(allowedCiphers.<String>toArray(new String[0]));
/*     */       }
/*     */       
/* 186 */       ((SSLSocket)mysqlIO.mysqlConnection).startHandshake();
/*     */       
/* 188 */       if (mysqlIO.connection.getUseUnbufferedInput()) {
/* 189 */         mysqlIO.mysqlInput = mysqlIO.mysqlConnection.getInputStream();
/*     */       } else {
/* 191 */         mysqlIO.mysqlInput = new BufferedInputStream(mysqlIO.mysqlConnection.getInputStream(), 16384);
/*     */       } 
/*     */       
/* 194 */       mysqlIO.mysqlOutput = new BufferedOutputStream(mysqlIO.mysqlConnection.getOutputStream(), 16384);
/*     */       
/* 196 */       mysqlIO.mysqlOutput.flush();
/*     */       
/* 198 */       mysqlIO.socketFactory = sslFact;
/*     */     }
/* 200 */     catch (IOException ioEx) {
/* 201 */       throw SQLError.createCommunicationsException(mysqlIO.connection, mysqlIO.getLastPacketSentTimeMs(), mysqlIO.getLastPacketReceivedTimeMs(), ioEx, mysqlIO.getExceptionInterceptor());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class StandardSSLSocketFactory
/*     */     implements SocketFactory, SocketMetadata
/*     */   {
/* 210 */     private SSLSocket rawSocket = null;
/*     */     private final SSLSocketFactory sslFact;
/*     */     private final SocketFactory existingSocketFactory;
/*     */     private final Socket existingSocket;
/*     */     
/*     */     public StandardSSLSocketFactory(SSLSocketFactory sslFact, SocketFactory existingSocketFactory, Socket existingSocket) {
/* 216 */       this.sslFact = sslFact;
/* 217 */       this.existingSocketFactory = existingSocketFactory;
/* 218 */       this.existingSocket = existingSocket;
/*     */     }
/*     */     
/*     */     public Socket afterHandshake() throws SocketException, IOException {
/* 222 */       this.existingSocketFactory.afterHandshake();
/* 223 */       return this.rawSocket;
/*     */     }
/*     */     
/*     */     public Socket beforeHandshake() throws SocketException, IOException {
/* 227 */       return this.rawSocket;
/*     */     }
/*     */     
/*     */     public Socket connect(String host, int portNumber, Properties props) throws SocketException, IOException {
/* 231 */       this.rawSocket = (SSLSocket)this.sslFact.createSocket(this.existingSocket, host, portNumber, true);
/* 232 */       return this.rawSocket;
/*     */     }
/*     */     
/*     */     public boolean isLocallyConnected(ConnectionImpl conn) throws SQLException {
/* 236 */       return SocketMetadata.Helper.isLocallyConnected(conn);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class X509TrustManagerWrapper
/*     */     implements X509TrustManager
/*     */   {
/* 249 */     private X509TrustManager origTm = null;
/*     */     private boolean verifyServerCert = false;
/* 251 */     private CertificateFactory certFactory = null;
/* 252 */     private PKIXParameters validatorParams = null;
/* 253 */     private CertPathValidator validator = null;
/*     */     
/*     */     public X509TrustManagerWrapper(X509TrustManager tm, boolean verifyServerCertificate) throws CertificateException {
/* 256 */       this.origTm = tm;
/* 257 */       this.verifyServerCert = verifyServerCertificate;
/*     */       
/* 259 */       if (verifyServerCertificate) {
/*     */         try {
/* 261 */           Set<TrustAnchor> anch = new HashSet<TrustAnchor>();
/* 262 */           for (X509Certificate cert : tm.getAcceptedIssuers()) {
/* 263 */             anch.add(new TrustAnchor(cert, null));
/*     */           }
/* 265 */           this.validatorParams = new PKIXParameters(anch);
/* 266 */           this.validatorParams.setRevocationEnabled(false);
/* 267 */           this.validator = CertPathValidator.getInstance("PKIX");
/* 268 */           this.certFactory = CertificateFactory.getInstance("X.509");
/* 269 */         } catch (Exception e) {
/* 270 */           throw new CertificateException(e);
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public X509TrustManagerWrapper() {}
/*     */     
/*     */     public X509Certificate[] getAcceptedIssuers() {
/* 279 */       return (this.origTm != null) ? this.origTm.getAcceptedIssuers() : new X509Certificate[0];
/*     */     }
/*     */     
/*     */     public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
/* 283 */       for (int i = 0; i < chain.length; i++) {
/* 284 */         chain[i].checkValidity();
/*     */       }
/*     */       
/* 287 */       if (this.validatorParams != null) {
/*     */         
/* 289 */         X509CertSelector certSelect = new X509CertSelector();
/* 290 */         certSelect.setSerialNumber(chain[0].getSerialNumber());
/*     */         
/*     */         try {
/* 293 */           CertPath certPath = this.certFactory.generateCertPath(Arrays.asList((Certificate[])chain));
/*     */           
/* 295 */           CertPathValidatorResult result = this.validator.validate(certPath, this.validatorParams);
/*     */           
/* 297 */           ((PKIXCertPathValidatorResult)result).getTrustAnchor().getTrustedCert().checkValidity();
/*     */         }
/* 299 */         catch (InvalidAlgorithmParameterException e) {
/* 300 */           throw new CertificateException(e);
/* 301 */         } catch (CertPathValidatorException e) {
/* 302 */           throw new CertificateException(e);
/*     */         } 
/*     */       } 
/*     */       
/* 306 */       if (this.verifyServerCert) {
/* 307 */         this.origTm.checkServerTrusted(chain, authType);
/*     */       }
/*     */     }
/*     */     
/*     */     public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
/* 312 */       this.origTm.checkClientTrusted(chain, authType);
/*     */     }
/*     */   }
/*     */   
/*     */   private static SSLSocketFactory getSSLSocketFactoryDefaultOrConfigured(MysqlIO mysqlIO) throws SQLException {
/* 317 */     String clientCertificateKeyStoreUrl = mysqlIO.connection.getClientCertificateKeyStoreUrl();
/* 318 */     String clientCertificateKeyStorePassword = mysqlIO.connection.getClientCertificateKeyStorePassword();
/* 319 */     String clientCertificateKeyStoreType = mysqlIO.connection.getClientCertificateKeyStoreType();
/* 320 */     String trustCertificateKeyStoreUrl = mysqlIO.connection.getTrustCertificateKeyStoreUrl();
/* 321 */     String trustCertificateKeyStorePassword = mysqlIO.connection.getTrustCertificateKeyStorePassword();
/* 322 */     String trustCertificateKeyStoreType = mysqlIO.connection.getTrustCertificateKeyStoreType();
/*     */     
/* 324 */     if (StringUtils.isNullOrEmpty(clientCertificateKeyStoreUrl)) {
/* 325 */       clientCertificateKeyStoreUrl = System.getProperty("javax.net.ssl.keyStore");
/* 326 */       clientCertificateKeyStorePassword = System.getProperty("javax.net.ssl.keyStorePassword");
/* 327 */       clientCertificateKeyStoreType = System.getProperty("javax.net.ssl.keyStoreType");
/* 328 */       if (StringUtils.isNullOrEmpty(clientCertificateKeyStoreType)) {
/* 329 */         clientCertificateKeyStoreType = "JKS";
/*     */       }
/*     */       
/* 332 */       if (!StringUtils.isNullOrEmpty(clientCertificateKeyStoreUrl)) {
/*     */         try {
/* 334 */           new URL(clientCertificateKeyStoreUrl);
/* 335 */         } catch (MalformedURLException e) {
/* 336 */           clientCertificateKeyStoreUrl = "file:" + clientCertificateKeyStoreUrl;
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 341 */     if (StringUtils.isNullOrEmpty(trustCertificateKeyStoreUrl)) {
/* 342 */       trustCertificateKeyStoreUrl = System.getProperty("javax.net.ssl.trustStore");
/* 343 */       trustCertificateKeyStorePassword = System.getProperty("javax.net.ssl.trustStorePassword");
/* 344 */       trustCertificateKeyStoreType = System.getProperty("javax.net.ssl.trustStoreType");
/* 345 */       if (StringUtils.isNullOrEmpty(trustCertificateKeyStoreType)) {
/* 346 */         trustCertificateKeyStoreType = "JKS";
/*     */       }
/*     */       
/* 349 */       if (!StringUtils.isNullOrEmpty(trustCertificateKeyStoreUrl)) {
/*     */         try {
/* 351 */           new URL(trustCertificateKeyStoreUrl);
/* 352 */         } catch (MalformedURLException e) {
/* 353 */           trustCertificateKeyStoreUrl = "file:" + trustCertificateKeyStoreUrl;
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 358 */     TrustManagerFactory tmf = null;
/* 359 */     KeyManagerFactory kmf = null;
/*     */     
/* 361 */     KeyManager[] kms = null;
/* 362 */     List<TrustManager> tms = new ArrayList<TrustManager>();
/*     */     
/*     */     try {
/* 365 */       tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
/* 366 */       kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
/* 367 */     } catch (NoSuchAlgorithmException nsae) {
/* 368 */       throw SQLError.createSQLException("Default algorithm definitions for TrustManager and/or KeyManager are invalid.  Check java security properties file.", "08000", 0, false, mysqlIO.getExceptionInterceptor());
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 373 */     if (!StringUtils.isNullOrEmpty(clientCertificateKeyStoreUrl)) {
/* 374 */       InputStream ksIS = null;
/*     */       try {
/* 376 */         if (!StringUtils.isNullOrEmpty(clientCertificateKeyStoreType)) {
/* 377 */           KeyStore clientKeyStore = KeyStore.getInstance(clientCertificateKeyStoreType);
/* 378 */           URL ksURL = new URL(clientCertificateKeyStoreUrl);
/* 379 */           char[] password = (clientCertificateKeyStorePassword == null) ? new char[0] : clientCertificateKeyStorePassword.toCharArray();
/* 380 */           ksIS = ksURL.openStream();
/* 381 */           clientKeyStore.load(ksIS, password);
/* 382 */           kmf.init(clientKeyStore, password);
/* 383 */           kms = kmf.getKeyManagers();
/*     */         } 
/* 385 */       } catch (UnrecoverableKeyException uke) {
/* 386 */         throw SQLError.createSQLException("Could not recover keys from client keystore.  Check password?", "08000", 0, false, mysqlIO.getExceptionInterceptor());
/*     */       }
/* 388 */       catch (NoSuchAlgorithmException nsae) {
/* 389 */         throw SQLError.createSQLException("Unsupported keystore algorithm [" + nsae.getMessage() + "]", "08000", 0, false, mysqlIO.getExceptionInterceptor());
/*     */       }
/* 391 */       catch (KeyStoreException kse) {
/* 392 */         throw SQLError.createSQLException("Could not create KeyStore instance [" + kse.getMessage() + "]", "08000", 0, false, mysqlIO.getExceptionInterceptor());
/*     */       }
/* 394 */       catch (CertificateException nsae) {
/* 395 */         throw SQLError.createSQLException("Could not load client" + clientCertificateKeyStoreType + " keystore from " + clientCertificateKeyStoreUrl, mysqlIO.getExceptionInterceptor());
/*     */       }
/* 397 */       catch (MalformedURLException mue) {
/* 398 */         throw SQLError.createSQLException(clientCertificateKeyStoreUrl + " does not appear to be a valid URL.", "08000", 0, false, mysqlIO.getExceptionInterceptor());
/*     */       }
/* 400 */       catch (IOException ioe) {
/* 401 */         SQLException sqlEx = SQLError.createSQLException("Cannot open " + clientCertificateKeyStoreUrl + " [" + ioe.getMessage() + "]", "08000", 0, false, mysqlIO.getExceptionInterceptor());
/*     */         
/* 403 */         sqlEx.initCause(ioe);
/*     */         
/* 405 */         throw sqlEx;
/*     */       } finally {
/* 407 */         if (ksIS != null) {
/*     */           try {
/* 409 */             ksIS.close();
/* 410 */           } catch (IOException e) {}
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 417 */     InputStream trustStoreIS = null;
/*     */     try {
/* 419 */       KeyStore trustKeyStore = null;
/*     */       
/* 421 */       if (!StringUtils.isNullOrEmpty(trustCertificateKeyStoreUrl) && !StringUtils.isNullOrEmpty(trustCertificateKeyStoreType)) {
/* 422 */         trustStoreIS = (new URL(trustCertificateKeyStoreUrl)).openStream();
/* 423 */         char[] trustStorePassword = (trustCertificateKeyStorePassword == null) ? new char[0] : trustCertificateKeyStorePassword.toCharArray();
/*     */         
/* 425 */         trustKeyStore = KeyStore.getInstance(trustCertificateKeyStoreType);
/* 426 */         trustKeyStore.load(trustStoreIS, trustStorePassword);
/*     */       } 
/*     */       
/* 429 */       tmf.init(trustKeyStore);
/*     */ 
/*     */       
/* 432 */       TrustManager[] origTms = tmf.getTrustManagers();
/* 433 */       boolean verifyServerCert = mysqlIO.connection.getVerifyServerCertificate();
/*     */       
/* 435 */       for (TrustManager tm : origTms)
/*     */       {
/* 437 */         tms.add((tm instanceof X509TrustManager) ? new X509TrustManagerWrapper((X509TrustManager)tm, verifyServerCert) : tm);
/*     */       }
/*     */     }
/* 440 */     catch (MalformedURLException e) {
/* 441 */       throw SQLError.createSQLException(trustCertificateKeyStoreUrl + " does not appear to be a valid URL.", "08000", 0, false, mysqlIO.getExceptionInterceptor());
/*     */     }
/* 443 */     catch (KeyStoreException e) {
/* 444 */       throw SQLError.createSQLException("Could not create KeyStore instance [" + e.getMessage() + "]", "08000", 0, false, mysqlIO.getExceptionInterceptor());
/*     */     }
/* 446 */     catch (NoSuchAlgorithmException e) {
/* 447 */       throw SQLError.createSQLException("Unsupported keystore algorithm [" + e.getMessage() + "]", "08000", 0, false, mysqlIO.getExceptionInterceptor());
/*     */     }
/* 449 */     catch (CertificateException e) {
/* 450 */       throw SQLError.createSQLException("Could not load trust" + trustCertificateKeyStoreType + " keystore from " + trustCertificateKeyStoreUrl, "08000", 0, false, mysqlIO.getExceptionInterceptor());
/*     */     }
/* 452 */     catch (IOException e) {
/* 453 */       SQLException sqlEx = SQLError.createSQLException("Cannot open " + trustCertificateKeyStoreType + " [" + e.getMessage() + "]", "08000", 0, false, mysqlIO.getExceptionInterceptor());
/*     */       
/* 455 */       sqlEx.initCause(e);
/* 456 */       throw sqlEx;
/*     */     } finally {
/* 458 */       if (trustStoreIS != null) {
/*     */         try {
/* 460 */           trustStoreIS.close();
/* 461 */         } catch (IOException e) {}
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 468 */     if (tms.size() == 0) {
/* 469 */       tms.add(new X509TrustManagerWrapper());
/*     */     }
/*     */     
/*     */     try {
/* 473 */       SSLContext sslContext = SSLContext.getInstance("TLS");
/* 474 */       sslContext.init(kms, tms.<TrustManager>toArray(new TrustManager[tms.size()]), null);
/* 475 */       return sslContext.getSocketFactory();
/*     */     }
/* 477 */     catch (NoSuchAlgorithmException nsae) {
/* 478 */       throw SQLError.createSQLException("TLS is not a valid SSL protocol.", "08000", 0, false, mysqlIO.getExceptionInterceptor());
/* 479 */     } catch (KeyManagementException kme) {
/* 480 */       throw SQLError.createSQLException("KeyManagementException: " + kme.getMessage(), "08000", 0, false, mysqlIO.getExceptionInterceptor());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isSSLEstablished(MysqlIO mysqlIO) {
/* 486 */     return SSLSocket.class.isAssignableFrom(mysqlIO.mysqlConnection.getClass());
/*     */   }
/*     */ 
/*     */   
/*     */   public static RSAPublicKey decodeRSAPublicKey(String key, ExceptionInterceptor interceptor) throws SQLException {
/*     */     try {
/* 492 */       if (key == null) {
/* 493 */         throw new SQLException("key parameter is null");
/*     */       }
/*     */       
/* 496 */       int offset = key.indexOf("\n") + 1;
/* 497 */       int len = key.indexOf("-----END PUBLIC KEY-----") - offset;
/*     */ 
/*     */       
/* 500 */       byte[] certificateData = Base64Decoder.decode(key.getBytes(), offset, len);
/*     */       
/* 502 */       X509EncodedKeySpec spec = new X509EncodedKeySpec(certificateData);
/* 503 */       KeyFactory kf = KeyFactory.getInstance("RSA");
/* 504 */       return (RSAPublicKey)kf.generatePublic(spec);
/* 505 */     } catch (Exception ex) {
/* 506 */       throw SQLError.createSQLException("Unable to decode public key", "S1009", ex, interceptor);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static byte[] encryptWithRSAPublicKey(byte[] source, RSAPublicKey key, String transformation, ExceptionInterceptor interceptor) throws SQLException {
/*     */     try {
/* 512 */       Cipher cipher = Cipher.getInstance(transformation);
/* 513 */       cipher.init(1, key);
/* 514 */       return cipher.doFinal(source);
/* 515 */     } catch (Exception ex) {
/* 516 */       throw SQLError.createSQLException(ex.getMessage(), "S1009", ex, interceptor);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\neons\Desktop\JacobAloSchedulingApp\build\classes\!\lib\mysql-connector-java-5.1.47.jar!\com\mysql\jdbc\ExportControlled.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */
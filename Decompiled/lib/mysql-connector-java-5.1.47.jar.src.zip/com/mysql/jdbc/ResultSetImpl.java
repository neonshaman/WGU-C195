/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.log.LogUtils;
/*      */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*      */ import com.mysql.jdbc.profiler.ProfilerEventHandler;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.StringReader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.TimeZone;
/*      */ import java.util.TreeMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ResultSetImpl
/*      */   implements ResultSetInternalMethods
/*      */ {
/*      */   private static final Constructor<?> JDBC_4_RS_4_ARG_CTOR;
/*      */   private static final Constructor<?> JDBC_4_RS_5_ARG_CTOR;
/*      */   private static final Constructor<?> JDBC_4_UPD_RS_5_ARG_CTOR;
/*      */   
/*      */   static {
/*  106 */     if (Util.isJdbc4()) {
/*      */       try {
/*  108 */         String jdbc4ClassName = Util.isJdbc42() ? "com.mysql.jdbc.JDBC42ResultSet" : "com.mysql.jdbc.JDBC4ResultSet";
/*  109 */         JDBC_4_RS_4_ARG_CTOR = Class.forName(jdbc4ClassName).getConstructor(new Class[] { long.class, long.class, MySQLConnection.class, StatementImpl.class });
/*      */         
/*  111 */         JDBC_4_RS_5_ARG_CTOR = Class.forName(jdbc4ClassName).getConstructor(new Class[] { String.class, Field[].class, RowData.class, MySQLConnection.class, StatementImpl.class });
/*      */ 
/*      */         
/*  114 */         jdbc4ClassName = Util.isJdbc42() ? "com.mysql.jdbc.JDBC42UpdatableResultSet" : "com.mysql.jdbc.JDBC4UpdatableResultSet";
/*  115 */         JDBC_4_UPD_RS_5_ARG_CTOR = Class.forName(jdbc4ClassName).getConstructor(new Class[] { String.class, Field[].class, RowData.class, MySQLConnection.class, StatementImpl.class });
/*      */       }
/*  117 */       catch (SecurityException e) {
/*  118 */         throw new RuntimeException(e);
/*  119 */       } catch (NoSuchMethodException e) {
/*  120 */         throw new RuntimeException(e);
/*  121 */       } catch (ClassNotFoundException e) {
/*  122 */         throw new RuntimeException(e);
/*      */       } 
/*      */     } else {
/*  125 */       JDBC_4_RS_4_ARG_CTOR = null;
/*  126 */       JDBC_4_RS_5_ARG_CTOR = null;
/*  127 */       JDBC_4_UPD_RS_5_ARG_CTOR = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  134 */   protected static final double MIN_DIFF_PREC = Float.parseFloat(Float.toString(Float.MIN_VALUE)) - Double.parseDouble(Float.toString(Float.MIN_VALUE));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  139 */   protected static final double MAX_DIFF_PREC = Float.parseFloat(Float.toString(Float.MAX_VALUE)) - Double.parseDouble(Float.toString(Float.MAX_VALUE));
/*      */ 
/*      */   
/*  142 */   static int resultCounter = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static BigInteger convertLongToUlong(long longVal) {
/*  148 */     byte[] asBytes = new byte[8];
/*  149 */     asBytes[7] = (byte)(int)(longVal & 0xFFL);
/*  150 */     asBytes[6] = (byte)(int)(longVal >>> 8L);
/*  151 */     asBytes[5] = (byte)(int)(longVal >>> 16L);
/*  152 */     asBytes[4] = (byte)(int)(longVal >>> 24L);
/*  153 */     asBytes[3] = (byte)(int)(longVal >>> 32L);
/*  154 */     asBytes[2] = (byte)(int)(longVal >>> 40L);
/*  155 */     asBytes[1] = (byte)(int)(longVal >>> 48L);
/*  156 */     asBytes[0] = (byte)(int)(longVal >>> 56L);
/*      */     
/*  158 */     return new BigInteger(1, asBytes);
/*      */   }
/*      */ 
/*      */   
/*  162 */   protected String catalog = null;
/*      */ 
/*      */   
/*  165 */   protected Map<String, Integer> columnLabelToIndex = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  171 */   protected Map<String, Integer> columnToIndexCache = null;
/*      */ 
/*      */   
/*  174 */   protected boolean[] columnUsed = null;
/*      */ 
/*      */   
/*      */   protected volatile MySQLConnection connection;
/*      */   
/*  179 */   protected long connectionId = 0L;
/*      */ 
/*      */   
/*  182 */   protected int currentRow = -1;
/*      */ 
/*      */   
/*      */   protected boolean doingUpdates = false;
/*      */   
/*  187 */   protected ProfilerEventHandler eventSink = null;
/*      */   
/*  189 */   Calendar fastDefaultCal = null;
/*  190 */   Calendar fastClientCal = null;
/*      */ 
/*      */   
/*  193 */   protected int fetchDirection = 1000;
/*      */ 
/*      */   
/*  196 */   protected int fetchSize = 0;
/*      */ 
/*      */ 
/*      */   
/*      */   protected Field[] fields;
/*      */ 
/*      */ 
/*      */   
/*      */   protected char firstCharOfQuery;
/*      */ 
/*      */ 
/*      */   
/*  208 */   protected Map<String, Integer> fullColumnNameToIndex = null;
/*      */   
/*  210 */   protected Map<String, Integer> columnNameToIndex = null;
/*      */ 
/*      */   
/*      */   protected boolean hasBuiltIndexMapping = false;
/*      */ 
/*      */   
/*      */   protected boolean isBinaryEncoded = false;
/*      */ 
/*      */   
/*      */   protected boolean isClosed = false;
/*      */ 
/*      */   
/*  222 */   protected ResultSetInternalMethods nextResultSet = null;
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean onInsertRow = false;
/*      */ 
/*      */ 
/*      */   
/*      */   protected StatementImpl owningStatement;
/*      */ 
/*      */ 
/*      */   
/*      */   protected String pointOfOrigin;
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean profileSql = false;
/*      */ 
/*      */   
/*      */   protected boolean reallyResult = false;
/*      */ 
/*      */   
/*      */   protected int resultId;
/*      */ 
/*      */   
/*  247 */   protected int resultSetConcurrency = 0;
/*      */ 
/*      */   
/*  250 */   protected int resultSetType = 0;
/*      */ 
/*      */ 
/*      */   
/*      */   protected RowData rowData;
/*      */ 
/*      */ 
/*      */   
/*  258 */   protected String serverInfo = null;
/*      */ 
/*      */   
/*      */   PreparedStatement statementUsedForFetchingRows;
/*      */   
/*  263 */   protected ResultSetRow thisRow = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected long updateCount;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  277 */   protected long updateId = -1L;
/*      */ 
/*      */   
/*      */   private boolean useStrictFloatingPoint = false;
/*      */   
/*      */   protected boolean useUsageAdvisor = false;
/*      */   
/*  284 */   protected SQLWarning warningChain = null;
/*      */ 
/*      */   
/*      */   protected boolean wasNullFlag = false;
/*      */   
/*      */   protected Statement wrapperStatement;
/*      */   
/*      */   protected boolean retainOwningStatement;
/*      */   
/*  293 */   protected Calendar gmtCalendar = null;
/*      */   
/*      */   protected boolean useFastDateParsing = false;
/*      */   
/*      */   private boolean padCharsWithSpace = false;
/*      */   
/*      */   private boolean jdbcCompliantTruncationForReads;
/*      */   
/*      */   private boolean useFastIntParsing = true;
/*      */   
/*      */   private boolean useColumnNamesInFindColumn;
/*      */   
/*      */   private ExceptionInterceptor exceptionInterceptor;
/*  306 */   static final char[] EMPTY_SPACE = new char[255]; private boolean onValidRow; private String invalidRowReason; protected boolean useLegacyDatetimeCode; private TimeZone serverTimeZoneTz;
/*      */   
/*      */   static {
/*  309 */     for (int i = 0; i < EMPTY_SPACE.length; i++) {
/*  310 */       EMPTY_SPACE[i] = ' ';
/*      */     }
/*      */   }
/*      */   
/*      */   protected static ResultSetImpl getInstance(long updateCount, long updateID, MySQLConnection conn, StatementImpl creatorStmt) throws SQLException {
/*  315 */     if (!Util.isJdbc4()) {
/*  316 */       return new ResultSetImpl(updateCount, updateID, conn, creatorStmt);
/*      */     }
/*      */     
/*  319 */     return (ResultSetImpl)Util.handleNewInstance(JDBC_4_RS_4_ARG_CTOR, new Object[] { Long.valueOf(updateCount), Long.valueOf(updateID), conn, creatorStmt }, conn.getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static ResultSetImpl getInstance(String catalog, Field[] fields, RowData tuples, MySQLConnection conn, StatementImpl creatorStmt, boolean isUpdatable) throws SQLException {
/*  333 */     if (!Util.isJdbc4()) {
/*  334 */       if (!isUpdatable) {
/*  335 */         return new ResultSetImpl(catalog, fields, tuples, conn, creatorStmt);
/*      */       }
/*      */       
/*  338 */       return new UpdatableResultSet(catalog, fields, tuples, conn, creatorStmt);
/*      */     } 
/*      */     
/*  341 */     if (!isUpdatable) {
/*  342 */       return (ResultSetImpl)Util.handleNewInstance(JDBC_4_RS_5_ARG_CTOR, new Object[] { catalog, fields, tuples, conn, creatorStmt }, conn.getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */     
/*  346 */     return (ResultSetImpl)Util.handleNewInstance(JDBC_4_UPD_RS_5_ARG_CTOR, new Object[] { catalog, fields, tuples, conn, creatorStmt }, conn.getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void initializeWithMetadata() throws SQLException {
/*  457 */     synchronized (checkClosed().getConnectionMutex()) {
/*  458 */       this.rowData.setMetadata(this.fields);
/*      */       
/*  460 */       this.columnToIndexCache = new HashMap<String, Integer>();
/*      */       
/*  462 */       if (this.profileSql || this.connection.getUseUsageAdvisor()) {
/*  463 */         this.columnUsed = new boolean[this.fields.length];
/*  464 */         this.pointOfOrigin = LogUtils.findCallingClassAndMethod(new Throwable());
/*  465 */         this.resultId = resultCounter++;
/*  466 */         this.useUsageAdvisor = this.connection.getUseUsageAdvisor();
/*  467 */         this.eventSink = ProfilerEventHandlerFactory.getInstance(this.connection);
/*      */       } 
/*      */       
/*  470 */       if (this.connection.getGatherPerformanceMetrics()) {
/*  471 */         this.connection.incrementNumberOfResultSetsCreated();
/*      */         
/*  473 */         Set<String> tableNamesSet = new HashSet<String>();
/*      */         
/*  475 */         for (int i = 0; i < this.fields.length; i++) {
/*  476 */           Field f = this.fields[i];
/*      */           
/*  478 */           String tableName = f.getOriginalTableName();
/*      */           
/*  480 */           if (tableName == null) {
/*  481 */             tableName = f.getTableName();
/*      */           }
/*      */           
/*  484 */           if (tableName != null) {
/*  485 */             if (this.connection.lowerCaseTableNames()) {
/*  486 */               tableName = tableName.toLowerCase();
/*      */             }
/*      */ 
/*      */             
/*  490 */             tableNamesSet.add(tableName);
/*      */           } 
/*      */         } 
/*      */         
/*  494 */         this.connection.reportNumberOfTablesAccessed(tableNamesSet.size());
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private synchronized Calendar getFastDefaultCalendar() {
/*  500 */     if (this.fastDefaultCal == null) {
/*  501 */       this.fastDefaultCal = new GregorianCalendar(Locale.US);
/*  502 */       this.fastDefaultCal.setTimeZone(getDefaultTimeZone());
/*      */     } 
/*  504 */     return this.fastDefaultCal;
/*      */   }
/*      */   
/*      */   private synchronized Calendar getFastClientCalendar() {
/*  508 */     if (this.fastClientCal == null) {
/*  509 */       this.fastClientCal = new GregorianCalendar(Locale.US);
/*      */     }
/*  511 */     return this.fastClientCal;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean absolute(int row) throws SQLException {
/*  548 */     synchronized (checkClosed().getConnectionMutex()) {
/*      */       boolean b;
/*      */ 
/*      */       
/*  552 */       if (this.rowData.size() == 0) {
/*  553 */         b = false;
/*      */       } else {
/*  555 */         if (this.onInsertRow) {
/*  556 */           this.onInsertRow = false;
/*      */         }
/*      */         
/*  559 */         if (this.doingUpdates) {
/*  560 */           this.doingUpdates = false;
/*      */         }
/*      */         
/*  563 */         if (this.thisRow != null) {
/*  564 */           this.thisRow.closeOpenStreams();
/*      */         }
/*      */         
/*  567 */         if (row == 0) {
/*  568 */           beforeFirst();
/*  569 */           b = false;
/*  570 */         } else if (row == 1) {
/*  571 */           b = first();
/*  572 */         } else if (row == -1) {
/*  573 */           b = last();
/*  574 */         } else if (row > this.rowData.size()) {
/*  575 */           afterLast();
/*  576 */           b = false;
/*      */         }
/*  578 */         else if (row < 0) {
/*      */           
/*  580 */           int newRowPosition = this.rowData.size() + row + 1;
/*      */           
/*  582 */           if (newRowPosition <= 0) {
/*  583 */             beforeFirst();
/*  584 */             b = false;
/*      */           } else {
/*  586 */             b = absolute(newRowPosition);
/*      */           } 
/*      */         } else {
/*  589 */           row--;
/*  590 */           this.rowData.setCurrentRow(row);
/*  591 */           this.thisRow = this.rowData.getAt(row);
/*  592 */           b = true;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  597 */       setRowPositionValidity();
/*      */       
/*  599 */       return b;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void afterLast() throws SQLException {
/*  615 */     synchronized (checkClosed().getConnectionMutex()) {
/*      */       
/*  617 */       if (this.onInsertRow) {
/*  618 */         this.onInsertRow = false;
/*      */       }
/*      */       
/*  621 */       if (this.doingUpdates) {
/*  622 */         this.doingUpdates = false;
/*      */       }
/*      */       
/*  625 */       if (this.thisRow != null) {
/*  626 */         this.thisRow.closeOpenStreams();
/*      */       }
/*      */       
/*  629 */       if (this.rowData.size() != 0) {
/*  630 */         this.rowData.afterLast();
/*  631 */         this.thisRow = null;
/*      */       } 
/*      */       
/*  634 */       setRowPositionValidity();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void beforeFirst() throws SQLException {
/*  650 */     synchronized (checkClosed().getConnectionMutex()) {
/*      */       
/*  652 */       if (this.onInsertRow) {
/*  653 */         this.onInsertRow = false;
/*      */       }
/*      */       
/*  656 */       if (this.doingUpdates) {
/*  657 */         this.doingUpdates = false;
/*      */       }
/*      */       
/*  660 */       if (this.rowData.size() == 0) {
/*      */         return;
/*      */       }
/*      */       
/*  664 */       if (this.thisRow != null) {
/*  665 */         this.thisRow.closeOpenStreams();
/*      */       }
/*      */       
/*  668 */       this.rowData.beforeFirst();
/*  669 */       this.thisRow = null;
/*      */       
/*  671 */       setRowPositionValidity();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void buildIndexMapping() throws SQLException {
/*  683 */     int numFields = this.fields.length;
/*  684 */     this.columnLabelToIndex = new TreeMap<String, Integer>(String.CASE_INSENSITIVE_ORDER);
/*  685 */     this.fullColumnNameToIndex = new TreeMap<String, Integer>(String.CASE_INSENSITIVE_ORDER);
/*  686 */     this.columnNameToIndex = new TreeMap<String, Integer>(String.CASE_INSENSITIVE_ORDER);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  695 */     for (int i = numFields - 1; i >= 0; i--) {
/*  696 */       Integer index = Integer.valueOf(i);
/*  697 */       String columnName = this.fields[i].getOriginalName();
/*  698 */       String columnLabel = this.fields[i].getName();
/*  699 */       String fullColumnName = this.fields[i].getFullName();
/*      */       
/*  701 */       if (columnLabel != null) {
/*  702 */         this.columnLabelToIndex.put(columnLabel, index);
/*      */       }
/*      */       
/*  705 */       if (fullColumnName != null) {
/*  706 */         this.fullColumnNameToIndex.put(fullColumnName, index);
/*      */       }
/*      */       
/*  709 */       if (columnName != null) {
/*  710 */         this.columnNameToIndex.put(columnName, index);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  715 */     this.hasBuiltIndexMapping = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void cancelRowUpdates() throws SQLException {
/*  730 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final MySQLConnection checkClosed() throws SQLException {
/*  740 */     MySQLConnection c = this.connection;
/*      */     
/*  742 */     if (c == null) {
/*  743 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Operation_not_allowed_after_ResultSet_closed_144"), "S1000", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */     
/*  747 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void checkColumnBounds(int columnIndex) throws SQLException {
/*  760 */     synchronized (checkClosed().getConnectionMutex()) {
/*  761 */       if (columnIndex < 1) {
/*  762 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Column_Index_out_of_range_low", new Object[] { Integer.valueOf(columnIndex), Integer.valueOf(this.fields.length) }), "S1009", getExceptionInterceptor());
/*      */       }
/*      */ 
/*      */       
/*  766 */       if (columnIndex > this.fields.length) {
/*  767 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Column_Index_out_of_range_high", new Object[] { Integer.valueOf(columnIndex), Integer.valueOf(this.fields.length) }), "S1009", getExceptionInterceptor());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  773 */       if (this.profileSql || this.useUsageAdvisor) {
/*  774 */         this.columnUsed[columnIndex - 1] = true;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkRowPos() throws SQLException {
/*  787 */     checkClosed();
/*      */     
/*  789 */     if (!this.onValidRow)
/*  790 */       throw SQLError.createSQLException(this.invalidRowReason, "S1000", getExceptionInterceptor()); 
/*      */   }
/*      */   
/*      */   public ResultSetImpl(long updateCount, long updateID, MySQLConnection conn, StatementImpl creatorStmt) {
/*  794 */     this.onValidRow = false;
/*  795 */     this.invalidRowReason = null; this.updateCount = updateCount; this.updateId = updateID; this.reallyResult = false; this.fields = new Field[0]; this.connection = conn; this.owningStatement = creatorStmt; this.retainOwningStatement = false; if (this.connection != null) { this.exceptionInterceptor = this.connection.getExceptionInterceptor(); this.retainOwningStatement = this.connection.getRetainStatementAfterResultSetClose(); this.connectionId = this.connection.getId(); this.serverTimeZoneTz = this.connection.getServerTimezoneTZ(); this.padCharsWithSpace = this.connection.getPadCharsWithSpace(); this.useLegacyDatetimeCode = this.connection.getUseLegacyDatetimeCode(); }  } public ResultSetImpl(String catalog, Field[] fields, RowData tuples, MySQLConnection conn, StatementImpl creatorStmt) throws SQLException { this.onValidRow = false; this.invalidRowReason = null; this.connection = conn; this.retainOwningStatement = false; if (this.connection != null) { this.exceptionInterceptor = this.connection.getExceptionInterceptor(); this.useStrictFloatingPoint = this.connection.getStrictFloatingPoint(); this.connectionId = this.connection.getId(); this.useFastDateParsing = this.connection.getUseFastDateParsing(); this.profileSql = this.connection.getProfileSql(); this.retainOwningStatement = this.connection.getRetainStatementAfterResultSetClose(); this.jdbcCompliantTruncationForReads = this.connection.getJdbcCompliantTruncationForReads(); this.useFastIntParsing = this.connection.getUseFastIntParsing(); this.serverTimeZoneTz = this.connection.getServerTimezoneTZ(); this.padCharsWithSpace = this.connection.getPadCharsWithSpace(); }
/*      */      this.owningStatement = creatorStmt; this.catalog = catalog; this.fields = fields; this.rowData = tuples; this.updateCount = this.rowData.size(); this.reallyResult = true; if (this.rowData.size() > 0) { if (this.updateCount == 1L && this.thisRow == null) { this.rowData.close(); this.updateCount = -1L; }
/*      */        }
/*      */     else { this.thisRow = null; }
/*      */      this.rowData.setOwner(this); if (this.fields != null)
/*  800 */       initializeWithMetadata();  this.useLegacyDatetimeCode = this.connection.getUseLegacyDatetimeCode(); this.useColumnNamesInFindColumn = this.connection.getUseColumnNamesInFindColumn(); setRowPositionValidity(); } private void setRowPositionValidity() throws SQLException { if (!this.rowData.isDynamic() && this.rowData.size() == 0) {
/*  801 */       this.invalidRowReason = Messages.getString("ResultSet.Illegal_operation_on_empty_result_set");
/*  802 */       this.onValidRow = false;
/*  803 */     } else if (this.rowData.isBeforeFirst()) {
/*  804 */       this.invalidRowReason = Messages.getString("ResultSet.Before_start_of_result_set_146");
/*  805 */       this.onValidRow = false;
/*  806 */     } else if (this.rowData.isAfterLast()) {
/*  807 */       this.invalidRowReason = Messages.getString("ResultSet.After_end_of_result_set_148");
/*  808 */       this.onValidRow = false;
/*      */     } else {
/*  810 */       this.onValidRow = true;
/*  811 */       this.invalidRowReason = null;
/*      */     }  }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void clearNextResult() {
/*  820 */     this.nextResultSet = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearWarnings() throws SQLException {
/*  831 */     synchronized (checkClosed().getConnectionMutex()) {
/*  832 */       this.warningChain = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws SQLException {
/*  851 */     realClose(true);
/*      */   }
/*      */   
/*      */   private int convertToZeroWithEmptyCheck() throws SQLException {
/*  855 */     if (this.connection.getEmptyStringsConvertToZero()) {
/*  856 */       return 0;
/*      */     }
/*      */     
/*  859 */     throw SQLError.createSQLException("Can't convert empty string ('') to numeric", "22018", getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private String convertToZeroLiteralStringWithEmptyCheck() throws SQLException {
/*  865 */     if (this.connection.getEmptyStringsConvertToZero()) {
/*  866 */       return "0";
/*      */     }
/*      */     
/*  869 */     throw SQLError.createSQLException("Can't convert empty string ('') to numeric", "22018", getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSetInternalMethods copy() throws SQLException {
/*  877 */     synchronized (checkClosed().getConnectionMutex()) {
/*  878 */       ResultSetImpl rs = getInstance(this.catalog, this.fields, this.rowData, this.connection, this.owningStatement, false);
/*  879 */       if (this.isBinaryEncoded) {
/*  880 */         rs.setBinaryEncoded();
/*      */       }
/*      */       
/*  883 */       return rs;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void redefineFieldsForDBMD(Field[] f) {
/*  888 */     this.fields = f;
/*      */     
/*  890 */     for (int i = 0; i < this.fields.length; i++) {
/*  891 */       this.fields[i].setUseOldNameMetadata(true);
/*  892 */       this.fields[i].setConnection(this.connection);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void populateCachedMetaData(CachedResultSetMetaData cachedMetaData) throws SQLException {
/*  897 */     cachedMetaData.fields = this.fields;
/*  898 */     cachedMetaData.columnNameToIndex = this.columnLabelToIndex;
/*  899 */     cachedMetaData.fullColumnNameToIndex = this.fullColumnNameToIndex;
/*  900 */     cachedMetaData.metadata = getMetaData();
/*      */   }
/*      */   
/*      */   public void initializeFromCachedMetaData(CachedResultSetMetaData cachedMetaData) {
/*  904 */     this.fields = cachedMetaData.fields;
/*  905 */     this.columnLabelToIndex = cachedMetaData.columnNameToIndex;
/*  906 */     this.fullColumnNameToIndex = cachedMetaData.fullColumnNameToIndex;
/*  907 */     this.hasBuiltIndexMapping = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void deleteRow() throws SQLException {
/*  920 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String extractStringFromNativeColumn(int columnIndex, int mysqlType) throws SQLException {
/*  930 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/*  932 */     this.wasNullFlag = false;
/*      */     
/*  934 */     if (this.thisRow.isNull(columnIndexMinusOne)) {
/*  935 */       this.wasNullFlag = true;
/*      */       
/*  937 */       return null;
/*      */     } 
/*      */     
/*  940 */     this.wasNullFlag = false;
/*      */     
/*  942 */     String encoding = this.fields[columnIndexMinusOne].getEncoding();
/*      */     
/*  944 */     return this.thisRow.getString(columnIndex - 1, encoding, this.connection);
/*      */   }
/*      */   
/*      */   protected Date fastDateCreate(Calendar cal, int year, int month, int day) throws SQLException {
/*  948 */     synchronized (checkClosed().getConnectionMutex()) {
/*  949 */       Calendar targetCalendar = cal;
/*      */       
/*  951 */       if (cal == null) {
/*  952 */         if (this.connection.getNoTimezoneConversionForDateType()) {
/*  953 */           targetCalendar = getFastClientCalendar();
/*      */         } else {
/*  955 */           targetCalendar = getFastDefaultCalendar();
/*      */         } 
/*      */       }
/*      */       
/*  959 */       if (!this.useLegacyDatetimeCode) {
/*  960 */         return TimeUtil.fastDateCreate(year, month, day, targetCalendar);
/*      */       }
/*      */       
/*  963 */       boolean useGmtMillis = (cal == null && !this.connection.getNoTimezoneConversionForDateType() && this.connection.getUseGmtMillisForDatetimes());
/*      */       
/*  965 */       return TimeUtil.fastDateCreate(useGmtMillis, useGmtMillis ? getGmtCalendar() : targetCalendar, targetCalendar, year, month, day);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected Time fastTimeCreate(Calendar cal, int hour, int minute, int second) throws SQLException {
/*  970 */     synchronized (checkClosed().getConnectionMutex()) {
/*  971 */       if (!this.useLegacyDatetimeCode) {
/*  972 */         return TimeUtil.fastTimeCreate(hour, minute, second, cal, getExceptionInterceptor());
/*      */       }
/*      */       
/*  975 */       if (cal == null) {
/*  976 */         cal = getFastDefaultCalendar();
/*      */       }
/*      */       
/*  979 */       return TimeUtil.fastTimeCreate(cal, hour, minute, second, getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected Timestamp fastTimestampCreate(Calendar cal, int year, int month, int day, int hour, int minute, int seconds, int secondsPart, boolean useGmtMillis) throws SQLException {
/*  985 */     synchronized (checkClosed().getConnectionMutex()) {
/*  986 */       if (!this.useLegacyDatetimeCode) {
/*  987 */         return TimeUtil.fastTimestampCreate(cal.getTimeZone(), year, month, day, hour, minute, seconds, secondsPart);
/*      */       }
/*      */       
/*  990 */       if (cal == null) {
/*  991 */         cal = getFastDefaultCalendar();
/*      */       }
/*      */       
/*  994 */       return TimeUtil.fastTimestampCreate(useGmtMillis, useGmtMillis ? getGmtCalendar() : null, cal, year, month, day, hour, minute, seconds, secondsPart);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int findColumn(String columnName) throws SQLException {
/* 1039 */     synchronized (checkClosed().getConnectionMutex()) {
/*      */ 
/*      */       
/* 1042 */       if (!this.hasBuiltIndexMapping) {
/* 1043 */         buildIndexMapping();
/*      */       }
/*      */       
/* 1046 */       Integer index = this.columnToIndexCache.get(columnName);
/*      */       
/* 1048 */       if (index != null) {
/* 1049 */         return index.intValue() + 1;
/*      */       }
/*      */       
/* 1052 */       index = this.columnLabelToIndex.get(columnName);
/*      */       
/* 1054 */       if (index == null && this.useColumnNamesInFindColumn) {
/* 1055 */         index = this.columnNameToIndex.get(columnName);
/*      */       }
/*      */       
/* 1058 */       if (index == null) {
/* 1059 */         index = this.fullColumnNameToIndex.get(columnName);
/*      */       }
/*      */       
/* 1062 */       if (index != null) {
/* 1063 */         this.columnToIndexCache.put(columnName, index);
/*      */         
/* 1065 */         return index.intValue() + 1;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1070 */       for (int i = 0; i < this.fields.length; i++) {
/* 1071 */         if (this.fields[i].getName().equalsIgnoreCase(columnName))
/* 1072 */           return i + 1; 
/* 1073 */         if (this.fields[i].getFullName().equalsIgnoreCase(columnName)) {
/* 1074 */           return i + 1;
/*      */         }
/*      */       } 
/*      */       
/* 1078 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Column____112") + columnName + Messages.getString("ResultSet.___not_found._113"), "S0022", getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean first() throws SQLException {
/* 1097 */     synchronized (checkClosed().getConnectionMutex()) {
/*      */       
/* 1099 */       boolean b = true;
/*      */       
/* 1101 */       if (this.rowData.isEmpty()) {
/* 1102 */         b = false;
/*      */       } else {
/*      */         
/* 1105 */         if (this.onInsertRow) {
/* 1106 */           this.onInsertRow = false;
/*      */         }
/*      */         
/* 1109 */         if (this.doingUpdates) {
/* 1110 */           this.doingUpdates = false;
/*      */         }
/*      */         
/* 1113 */         this.rowData.beforeFirst();
/* 1114 */         this.thisRow = this.rowData.next();
/*      */       } 
/*      */       
/* 1117 */       setRowPositionValidity();
/*      */       
/* 1119 */       return b;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Array getArray(int i) throws SQLException {
/* 1136 */     checkColumnBounds(i);
/*      */     
/* 1138 */     throw SQLError.createSQLFeatureNotSupportedException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Array getArray(String colName) throws SQLException {
/* 1154 */     return getArray(findColumn(colName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(int columnIndex) throws SQLException {
/* 1181 */     checkRowPos();
/*      */     
/* 1183 */     if (!this.isBinaryEncoded) {
/* 1184 */       return getBinaryStream(columnIndex);
/*      */     }
/*      */     
/* 1187 */     return getNativeBinaryStream(columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(String columnName) throws SQLException {
/* 1196 */     return getAsciiStream(findColumn(columnName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int columnIndex) throws SQLException {
/* 1213 */     if (!this.isBinaryEncoded) {
/* 1214 */       String stringVal = getString(columnIndex);
/*      */ 
/*      */       
/* 1217 */       if (stringVal != null) {
/* 1218 */         if (stringVal.length() == 0) {
/*      */           
/* 1220 */           BigDecimal val = new BigDecimal(convertToZeroLiteralStringWithEmptyCheck());
/*      */           
/* 1222 */           return val;
/*      */         } 
/*      */         
/*      */         try {
/* 1226 */           BigDecimal val = new BigDecimal(stringVal);
/*      */           
/* 1228 */           return val;
/* 1229 */         } catch (NumberFormatException ex) {
/* 1230 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009", getExceptionInterceptor());
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1236 */       return null;
/*      */     } 
/*      */     
/* 1239 */     return getNativeBigDecimal(columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public BigDecimal getBigDecimal(int columnIndex, int scale) throws SQLException {
/* 1260 */     if (!this.isBinaryEncoded) {
/* 1261 */       String stringVal = getString(columnIndex);
/*      */ 
/*      */       
/* 1264 */       if (stringVal != null) {
/* 1265 */         BigDecimal bigDecimal; if (stringVal.length() == 0) {
/* 1266 */           bigDecimal = new BigDecimal(convertToZeroLiteralStringWithEmptyCheck());
/*      */           
/*      */           try {
/* 1269 */             return bigDecimal.setScale(scale);
/* 1270 */           } catch (ArithmeticException ex) {
/*      */             try {
/* 1272 */               return bigDecimal.setScale(scale, 4);
/* 1273 */             } catch (ArithmeticException arEx) {
/* 1274 */               throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009", getExceptionInterceptor());
/*      */             } 
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/* 1282 */           bigDecimal = new BigDecimal(stringVal);
/* 1283 */         } catch (NumberFormatException ex) {
/* 1284 */           if (this.fields[columnIndex - 1].getMysqlType() == 16) {
/* 1285 */             long valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex);
/*      */             
/* 1287 */             bigDecimal = new BigDecimal(valueAsLong);
/*      */           } else {
/* 1289 */             throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { Integer.valueOf(columnIndex), stringVal }), "S1009", getExceptionInterceptor());
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/* 1296 */           return bigDecimal.setScale(scale);
/* 1297 */         } catch (ArithmeticException ex) {
/*      */           try {
/* 1299 */             return bigDecimal.setScale(scale, 4);
/* 1300 */           } catch (ArithmeticException arithEx) {
/* 1301 */             throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { Integer.valueOf(columnIndex), stringVal }), "S1009", getExceptionInterceptor());
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1308 */       return null;
/*      */     } 
/*      */     
/* 1311 */     return getNativeBigDecimal(columnIndex, scale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(String columnName) throws SQLException {
/* 1327 */     return getBigDecimal(findColumn(columnName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public BigDecimal getBigDecimal(String columnName, int scale) throws SQLException {
/* 1340 */     return getBigDecimal(findColumn(columnName), scale);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final BigDecimal getBigDecimalFromString(String stringVal, int columnIndex, int scale) throws SQLException {
/* 1346 */     if (stringVal != null) {
/* 1347 */       if (stringVal.length() == 0) {
/* 1348 */         BigDecimal bdVal = new BigDecimal(convertToZeroLiteralStringWithEmptyCheck());
/*      */         
/*      */         try {
/* 1351 */           return bdVal.setScale(scale);
/* 1352 */         } catch (ArithmeticException ex) {
/*      */           try {
/* 1354 */             return bdVal.setScale(scale, 4);
/* 1355 */           } catch (ArithmeticException arEx) {
/* 1356 */             throw new SQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009");
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 1365 */         return (new BigDecimal(stringVal)).setScale(scale);
/* 1366 */       } catch (ArithmeticException ex) {
/*      */         try {
/* 1368 */           return (new BigDecimal(stringVal)).setScale(scale, 4);
/* 1369 */         } catch (ArithmeticException arEx) {
/* 1370 */           throw new SQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009");
/*      */         
/*      */         }
/*      */       
/*      */       }
/* 1375 */       catch (NumberFormatException ex) {
/* 1376 */         if (this.fields[columnIndex - 1].getMysqlType() == 16) {
/* 1377 */           long valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex);
/*      */           
/*      */           try {
/* 1380 */             return (new BigDecimal(valueAsLong)).setScale(scale);
/* 1381 */           } catch (ArithmeticException arEx1) {
/*      */             try {
/* 1383 */               return (new BigDecimal(valueAsLong)).setScale(scale, 4);
/* 1384 */             } catch (ArithmeticException arEx2) {
/* 1385 */               throw new SQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009");
/*      */             } 
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1392 */         if (this.fields[columnIndex - 1].getMysqlType() == 1 && this.connection.getTinyInt1isBit() && this.fields[columnIndex - 1].getLength() == 1L)
/*      */         {
/* 1394 */           return (new BigDecimal(stringVal.equalsIgnoreCase("true") ? 1 : 0)).setScale(scale);
/*      */         }
/*      */         
/* 1397 */         throw new SQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009");
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1402 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(int columnIndex) throws SQLException {
/* 1423 */     checkRowPos();
/*      */     
/* 1425 */     if (!this.isBinaryEncoded) {
/* 1426 */       checkColumnBounds(columnIndex);
/*      */       
/* 1428 */       int columnIndexMinusOne = columnIndex - 1;
/*      */       
/* 1430 */       if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 1431 */         this.wasNullFlag = true;
/*      */         
/* 1433 */         return null;
/*      */       } 
/*      */       
/* 1436 */       this.wasNullFlag = false;
/*      */       
/* 1438 */       return this.thisRow.getBinaryInputStream(columnIndexMinusOne);
/*      */     } 
/*      */     
/* 1441 */     return getNativeBinaryStream(columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(String columnName) throws SQLException {
/* 1450 */     return getBinaryStream(findColumn(columnName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Blob getBlob(int columnIndex) throws SQLException {
/* 1465 */     if (!this.isBinaryEncoded) {
/* 1466 */       checkRowPos();
/*      */       
/* 1468 */       checkColumnBounds(columnIndex);
/*      */       
/* 1470 */       int columnIndexMinusOne = columnIndex - 1;
/*      */       
/* 1472 */       if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 1473 */         this.wasNullFlag = true;
/*      */       } else {
/* 1475 */         this.wasNullFlag = false;
/*      */       } 
/*      */       
/* 1478 */       if (this.wasNullFlag) {
/* 1479 */         return null;
/*      */       }
/*      */       
/* 1482 */       if (!this.connection.getEmulateLocators()) {
/* 1483 */         return new Blob(this.thisRow.getColumnValue(columnIndexMinusOne), getExceptionInterceptor());
/*      */       }
/*      */       
/* 1486 */       return new BlobFromLocator(this, columnIndex, getExceptionInterceptor());
/*      */     } 
/*      */     
/* 1489 */     return getNativeBlob(columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Blob getBlob(String colName) throws SQLException {
/* 1504 */     return getBlob(findColumn(colName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(int columnIndex) throws SQLException {
/*      */     long boolVal;
/* 1520 */     checkColumnBounds(columnIndex);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1526 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 1528 */     Field field = this.fields[columnIndexMinusOne];
/*      */     
/* 1530 */     if (field.getMysqlType() == 16) {
/* 1531 */       return byteArrayToBoolean(columnIndexMinusOne);
/*      */     }
/*      */     
/* 1534 */     this.wasNullFlag = false;
/*      */     
/* 1536 */     int sqlType = field.getSQLType();
/*      */     
/* 1538 */     switch (sqlType) {
/*      */       case 16:
/* 1540 */         if (field.getMysqlType() == -1) {
/* 1541 */           String str = getString(columnIndex);
/*      */           
/* 1543 */           return getBooleanFromString(str);
/*      */         } 
/*      */         
/* 1546 */         boolVal = getLong(columnIndex, false);
/*      */         
/* 1548 */         return (boolVal == -1L || boolVal > 0L);
/*      */       case -7:
/*      */       case -6:
/*      */       case -5:
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/* 1559 */         boolVal = getLong(columnIndex, false);
/*      */         
/* 1561 */         return (boolVal == -1L || boolVal > 0L);
/*      */     } 
/* 1563 */     if (this.connection.getPedantic())
/*      */     {
/* 1565 */       switch (sqlType) {
/*      */         case -4:
/*      */         case -3:
/*      */         case -2:
/*      */         case 70:
/*      */         case 91:
/*      */         case 92:
/*      */         case 93:
/*      */         case 2000:
/*      */         case 2002:
/*      */         case 2003:
/*      */         case 2004:
/*      */         case 2005:
/*      */         case 2006:
/* 1579 */           throw SQLError.createSQLException("Required type conversion not allowed", "22018", getExceptionInterceptor());
/*      */       } 
/*      */ 
/*      */     
/*      */     }
/* 1584 */     if (sqlType == -2 || sqlType == -3 || sqlType == -4 || sqlType == 2004) {
/* 1585 */       return byteArrayToBoolean(columnIndexMinusOne);
/*      */     }
/*      */     
/* 1588 */     if (this.useUsageAdvisor) {
/* 1589 */       issueConversionViaParsingWarning("getBoolean()", columnIndex, this.thisRow.getColumnValue(columnIndexMinusOne), this.fields[columnIndex], new int[] { 16, 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1594 */     String stringVal = getString(columnIndex);
/*      */     
/* 1596 */     return getBooleanFromString(stringVal);
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean byteArrayToBoolean(int columnIndexMinusOne) throws SQLException {
/* 1601 */     Object value = this.thisRow.getColumnValue(columnIndexMinusOne);
/*      */     
/* 1603 */     if (value == null) {
/* 1604 */       this.wasNullFlag = true;
/*      */       
/* 1606 */       return false;
/*      */     } 
/*      */     
/* 1609 */     this.wasNullFlag = false;
/*      */     
/* 1611 */     if (((byte[])value).length == 0) {
/* 1612 */       return false;
/*      */     }
/*      */     
/* 1615 */     byte boolVal = ((byte[])value)[0];
/*      */     
/* 1617 */     if (boolVal == 49)
/* 1618 */       return true; 
/* 1619 */     if (boolVal == 48) {
/* 1620 */       return false;
/*      */     }
/*      */     
/* 1623 */     return (boolVal == -1 || boolVal > 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(String columnName) throws SQLException {
/* 1632 */     return getBoolean(findColumn(columnName));
/*      */   }
/*      */   
/*      */   private final boolean getBooleanFromString(String stringVal) throws SQLException {
/* 1636 */     if (stringVal != null && stringVal.length() > 0) {
/* 1637 */       int c = Character.toLowerCase(stringVal.charAt(0));
/*      */       
/* 1639 */       return (c == 116 || c == 121 || c == 49 || stringVal.equals("-1"));
/*      */     } 
/*      */     
/* 1642 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(int columnIndex) throws SQLException {
/* 1657 */     if (!this.isBinaryEncoded) {
/* 1658 */       String stringVal = getString(columnIndex);
/*      */       
/* 1660 */       if (this.wasNullFlag || stringVal == null) {
/* 1661 */         return 0;
/*      */       }
/*      */       
/* 1664 */       return getByteFromString(stringVal, columnIndex);
/*      */     } 
/*      */     
/* 1667 */     return getNativeByte(columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(String columnName) throws SQLException {
/* 1676 */     return getByte(findColumn(columnName));
/*      */   }
/*      */ 
/*      */   
/*      */   private final byte getByteFromString(String stringVal, int columnIndex) throws SQLException {
/* 1681 */     if (stringVal != null && stringVal.length() == 0) {
/* 1682 */       return (byte)convertToZeroWithEmptyCheck();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1692 */     if (stringVal == null) {
/* 1693 */       return 0;
/*      */     }
/*      */     
/* 1696 */     stringVal = stringVal.trim();
/*      */     
/*      */     try {
/* 1699 */       int decimalIndex = stringVal.indexOf(".");
/*      */       
/* 1701 */       if (decimalIndex != -1) {
/* 1702 */         double valueAsDouble = Double.parseDouble(stringVal);
/*      */         
/* 1704 */         if (this.jdbcCompliantTruncationForReads && (
/* 1705 */           valueAsDouble < -128.0D || valueAsDouble > 127.0D)) {
/* 1706 */           throwRangeException(stringVal, columnIndex, -6);
/*      */         }
/*      */ 
/*      */         
/* 1710 */         return (byte)(int)valueAsDouble;
/*      */       } 
/*      */       
/* 1713 */       long valueAsLong = Long.parseLong(stringVal);
/*      */       
/* 1715 */       if (this.jdbcCompliantTruncationForReads && (
/* 1716 */         valueAsLong < -128L || valueAsLong > 127L)) {
/* 1717 */         throwRangeException(String.valueOf(valueAsLong), columnIndex, -6);
/*      */       }
/*      */ 
/*      */       
/* 1721 */       return (byte)(int)valueAsLong;
/* 1722 */     } catch (NumberFormatException NFE) {
/* 1723 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Value____173") + stringVal + Messages.getString("ResultSet.___is_out_of_range_[-127,127]_174"), "S1009", getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytes(int columnIndex) throws SQLException {
/* 1745 */     return getBytes(columnIndex, false);
/*      */   }
/*      */   
/*      */   protected byte[] getBytes(int columnIndex, boolean noConversion) throws SQLException {
/* 1749 */     if (!this.isBinaryEncoded) {
/* 1750 */       checkRowPos();
/*      */       
/* 1752 */       checkColumnBounds(columnIndex);
/*      */       
/* 1754 */       int columnIndexMinusOne = columnIndex - 1;
/*      */       
/* 1756 */       if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 1757 */         this.wasNullFlag = true;
/*      */       } else {
/* 1759 */         this.wasNullFlag = false;
/*      */       } 
/*      */       
/* 1762 */       if (this.wasNullFlag) {
/* 1763 */         return null;
/*      */       }
/*      */       
/* 1766 */       return this.thisRow.getColumnValue(columnIndexMinusOne);
/*      */     } 
/*      */     
/* 1769 */     return getNativeBytes(columnIndex, noConversion);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytes(String columnName) throws SQLException {
/* 1778 */     return getBytes(findColumn(columnName));
/*      */   }
/*      */   
/*      */   private final byte[] getBytesFromString(String stringVal) throws SQLException {
/* 1782 */     if (stringVal != null) {
/* 1783 */       return StringUtils.getBytes(stringVal, this.connection.getEncoding(), this.connection.getServerCharset(), this.connection.parserKnowsUnicode(), this.connection, getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */     
/* 1787 */     return null;
/*      */   }
/*      */   
/*      */   public int getBytesSize() throws SQLException {
/* 1791 */     RowData localRowData = this.rowData;
/*      */     
/* 1793 */     checkClosed();
/*      */     
/* 1795 */     if (localRowData instanceof RowDataStatic) {
/* 1796 */       int bytesSize = 0;
/*      */       
/* 1798 */       int numRows = localRowData.size();
/*      */       
/* 1800 */       for (int i = 0; i < numRows; i++) {
/* 1801 */         bytesSize += localRowData.getAt(i).getBytesSize();
/*      */       }
/*      */       
/* 1804 */       return bytesSize;
/*      */     } 
/*      */     
/* 1807 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Calendar getCalendarInstanceForSessionOrNew() throws SQLException {
/* 1815 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1816 */       if (this.connection != null) {
/* 1817 */         return this.connection.getCalendarInstanceForSessionOrNew();
/*      */       }
/*      */ 
/*      */       
/* 1821 */       return new GregorianCalendar();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getCharacterStream(int columnIndex) throws SQLException {
/* 1841 */     if (!this.isBinaryEncoded) {
/* 1842 */       checkColumnBounds(columnIndex);
/*      */       
/* 1844 */       int columnIndexMinusOne = columnIndex - 1;
/*      */       
/* 1846 */       if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 1847 */         this.wasNullFlag = true;
/*      */         
/* 1849 */         return null;
/*      */       } 
/*      */       
/* 1852 */       this.wasNullFlag = false;
/*      */       
/* 1854 */       return this.thisRow.getReader(columnIndexMinusOne);
/*      */     } 
/*      */     
/* 1857 */     return getNativeCharacterStream(columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getCharacterStream(String columnName) throws SQLException {
/* 1876 */     return getCharacterStream(findColumn(columnName));
/*      */   }
/*      */   
/*      */   private final Reader getCharacterStreamFromString(String stringVal) throws SQLException {
/* 1880 */     if (stringVal != null) {
/* 1881 */       return new StringReader(stringVal);
/*      */     }
/*      */     
/* 1884 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Clob getClob(int i) throws SQLException {
/* 1899 */     if (!this.isBinaryEncoded) {
/* 1900 */       String asString = getStringForClob(i);
/*      */       
/* 1902 */       if (asString == null) {
/* 1903 */         return null;
/*      */       }
/*      */       
/* 1906 */       return new Clob(asString, getExceptionInterceptor());
/*      */     } 
/*      */     
/* 1909 */     return getNativeClob(i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Clob getClob(String colName) throws SQLException {
/* 1924 */     return getClob(findColumn(colName));
/*      */   }
/*      */   
/*      */   private final Clob getClobFromString(String stringVal) throws SQLException {
/* 1928 */     return new Clob(stringVal, getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getConcurrency() throws SQLException {
/* 1941 */     return 1007;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCursorName() throws SQLException {
/* 1967 */     throw SQLError.createSQLException(Messages.getString("ResultSet.Positioned_Update_not_supported"), "S1C00", getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int columnIndex) throws SQLException {
/* 1983 */     return getDate(columnIndex, (Calendar)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int columnIndex, Calendar cal) throws SQLException {
/* 2003 */     if (this.isBinaryEncoded) {
/* 2004 */       return getNativeDate(columnIndex, cal);
/*      */     }
/*      */     
/* 2007 */     if (!this.useFastDateParsing) {
/* 2008 */       String stringVal = getStringInternal(columnIndex, false);
/*      */       
/* 2010 */       if (stringVal == null) {
/* 2011 */         return null;
/*      */       }
/*      */       
/* 2014 */       return getDateFromString(stringVal, columnIndex, cal);
/*      */     } 
/*      */     
/* 2017 */     checkColumnBounds(columnIndex);
/*      */     
/* 2019 */     int columnIndexMinusOne = columnIndex - 1;
/* 2020 */     Date tmpDate = this.thisRow.getDateFast(columnIndexMinusOne, this.connection, this, cal);
/* 2021 */     if (this.thisRow.isNull(columnIndexMinusOne) || tmpDate == null) {
/*      */       
/* 2023 */       this.wasNullFlag = true;
/*      */       
/* 2025 */       return null;
/*      */     } 
/*      */     
/* 2028 */     this.wasNullFlag = false;
/*      */     
/* 2030 */     return tmpDate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(String columnName) throws SQLException {
/* 2039 */     return getDate(findColumn(columnName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(String columnName, Calendar cal) throws SQLException {
/* 2058 */     return getDate(findColumn(columnName), cal);
/*      */   }
/*      */   
/*      */   private final Date getDateFromString(String stringVal, int columnIndex, Calendar targetCalendar) throws SQLException {
/* 2062 */     int year = 0;
/* 2063 */     int month = 0;
/* 2064 */     int day = 0;
/*      */     
/*      */     try {
/* 2067 */       this.wasNullFlag = false;
/*      */       
/* 2069 */       if (stringVal == null) {
/* 2070 */         this.wasNullFlag = true;
/*      */         
/* 2072 */         return null;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2082 */       stringVal = stringVal.trim();
/*      */ 
/*      */       
/* 2085 */       int dec = stringVal.indexOf(".");
/* 2086 */       if (dec > -1) {
/* 2087 */         stringVal = stringVal.substring(0, dec);
/*      */       }
/*      */       
/* 2090 */       if (stringVal.equals("0") || stringVal.equals("0000-00-00") || stringVal.equals("0000-00-00 00:00:00") || stringVal.equals("00000000000000") || stringVal.equals("0")) {
/*      */ 
/*      */         
/* 2093 */         if ("convertToNull".equals(this.connection.getZeroDateTimeBehavior())) {
/* 2094 */           this.wasNullFlag = true;
/*      */           
/* 2096 */           return null;
/* 2097 */         }  if ("exception".equals(this.connection.getZeroDateTimeBehavior())) {
/* 2098 */           throw SQLError.createSQLException("Value '" + stringVal + "' can not be represented as java.sql.Date", "S1009", getExceptionInterceptor());
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 2103 */         return fastDateCreate(targetCalendar, 1, 1, 1);
/*      */       } 
/* 2105 */       if (this.fields[columnIndex - 1].getMysqlType() == 7) {
/*      */         
/* 2107 */         switch (stringVal.length()) {
/*      */           case 19:
/*      */           case 21:
/* 2110 */             year = Integer.parseInt(stringVal.substring(0, 4));
/* 2111 */             month = Integer.parseInt(stringVal.substring(5, 7));
/* 2112 */             day = Integer.parseInt(stringVal.substring(8, 10));
/*      */             
/* 2114 */             return fastDateCreate(targetCalendar, year, month, day);
/*      */ 
/*      */           
/*      */           case 8:
/*      */           case 14:
/* 2119 */             year = Integer.parseInt(stringVal.substring(0, 4));
/* 2120 */             month = Integer.parseInt(stringVal.substring(4, 6));
/* 2121 */             day = Integer.parseInt(stringVal.substring(6, 8));
/*      */             
/* 2123 */             return fastDateCreate(targetCalendar, year, month, day);
/*      */ 
/*      */           
/*      */           case 6:
/*      */           case 10:
/*      */           case 12:
/* 2129 */             year = Integer.parseInt(stringVal.substring(0, 2));
/*      */             
/* 2131 */             if (year <= 69) {
/* 2132 */               year += 100;
/*      */             }
/*      */             
/* 2135 */             month = Integer.parseInt(stringVal.substring(2, 4));
/* 2136 */             day = Integer.parseInt(stringVal.substring(4, 6));
/*      */             
/* 2138 */             return fastDateCreate(targetCalendar, year + 1900, month, day);
/*      */ 
/*      */           
/*      */           case 4:
/* 2142 */             year = Integer.parseInt(stringVal.substring(0, 4));
/*      */             
/* 2144 */             if (year <= 69) {
/* 2145 */               year += 100;
/*      */             }
/*      */             
/* 2148 */             month = Integer.parseInt(stringVal.substring(2, 4));
/*      */             
/* 2150 */             return fastDateCreate(targetCalendar, year + 1900, month, 1);
/*      */ 
/*      */           
/*      */           case 2:
/* 2154 */             year = Integer.parseInt(stringVal.substring(0, 2));
/*      */             
/* 2156 */             if (year <= 69) {
/* 2157 */               year += 100;
/*      */             }
/*      */             
/* 2160 */             return fastDateCreate(targetCalendar, year + 1900, 1, 1);
/*      */         } 
/*      */ 
/*      */         
/* 2164 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_Date", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009", getExceptionInterceptor());
/*      */       } 
/*      */ 
/*      */       
/* 2168 */       if (this.fields[columnIndex - 1].getMysqlType() == 13) {
/*      */         
/* 2170 */         if (stringVal.length() == 2 || stringVal.length() == 1) {
/* 2171 */           year = Integer.parseInt(stringVal);
/*      */           
/* 2173 */           if (year <= 69) {
/* 2174 */             year += 100;
/*      */           }
/*      */           
/* 2177 */           year += 1900;
/*      */         } else {
/* 2179 */           year = Integer.parseInt(stringVal.substring(0, 4));
/*      */         } 
/*      */         
/* 2182 */         return fastDateCreate(targetCalendar, year, 1, 1);
/* 2183 */       }  if (this.fields[columnIndex - 1].getMysqlType() == 11) {
/* 2184 */         return fastDateCreate(targetCalendar, 1970, 1, 1);
/*      */       }
/* 2186 */       if (stringVal.length() < 10) {
/* 2187 */         if (stringVal.length() == 8) {
/* 2188 */           return fastDateCreate(targetCalendar, 1970, 1, 1);
/*      */         }
/*      */         
/* 2191 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_Date", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009", getExceptionInterceptor());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2196 */       if (stringVal.length() != 18) {
/* 2197 */         year = Integer.parseInt(stringVal.substring(0, 4));
/* 2198 */         month = Integer.parseInt(stringVal.substring(5, 7));
/* 2199 */         day = Integer.parseInt(stringVal.substring(8, 10));
/*      */       } else {
/*      */         
/* 2202 */         StringTokenizer st = new StringTokenizer(stringVal, "- ");
/*      */         
/* 2204 */         year = Integer.parseInt(st.nextToken());
/* 2205 */         month = Integer.parseInt(st.nextToken());
/* 2206 */         day = Integer.parseInt(st.nextToken());
/*      */       } 
/*      */ 
/*      */       
/* 2210 */       return fastDateCreate(targetCalendar, year, month, day);
/* 2211 */     } catch (SQLException sqlEx) {
/* 2212 */       throw sqlEx;
/* 2213 */     } catch (Exception e) {
/* 2214 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_Date", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009", getExceptionInterceptor());
/*      */ 
/*      */ 
/*      */       
/* 2218 */       sqlEx.initCause(e);
/*      */       
/* 2220 */       throw sqlEx;
/*      */     } 
/*      */   }
/*      */   
/*      */   private TimeZone getDefaultTimeZone() {
/* 2225 */     return this.useLegacyDatetimeCode ? this.connection.getDefaultTimeZone() : this.serverTimeZoneTz;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(int columnIndex) throws SQLException {
/* 2240 */     if (!this.isBinaryEncoded) {
/* 2241 */       return getDoubleInternal(columnIndex);
/*      */     }
/*      */     
/* 2244 */     return getNativeDouble(columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(String columnName) throws SQLException {
/* 2253 */     return getDouble(findColumn(columnName));
/*      */   }
/*      */   
/*      */   private final double getDoubleFromString(String stringVal, int columnIndex) throws SQLException {
/* 2257 */     return getDoubleInternal(stringVal, columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected double getDoubleInternal(int colIndex) throws SQLException {
/* 2273 */     return getDoubleInternal(getString(colIndex), colIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected double getDoubleInternal(String stringVal, int colIndex) throws SQLException {
/*      */     try {
/* 2292 */       if (stringVal == null) {
/* 2293 */         return 0.0D;
/*      */       }
/*      */       
/* 2296 */       if (stringVal.length() == 0) {
/* 2297 */         return convertToZeroWithEmptyCheck();
/*      */       }
/*      */       
/* 2300 */       double d = Double.parseDouble(stringVal);
/*      */       
/* 2302 */       if (this.useStrictFloatingPoint)
/*      */       {
/* 2304 */         if (d == 2.147483648E9D) {
/*      */           
/* 2306 */           d = 2.147483647E9D;
/* 2307 */         } else if (d == 1.0000000036275E-15D) {
/*      */           
/* 2309 */           d = 1.0E-15D;
/* 2310 */         } else if (d == 9.999999869911E14D) {
/* 2311 */           d = 9.99999999999999E14D;
/* 2312 */         } else if (d == 1.4012984643248E-45D) {
/* 2313 */           d = 1.4E-45D;
/* 2314 */         } else if (d == 1.4013E-45D) {
/* 2315 */           d = 1.4E-45D;
/* 2316 */         } else if (d == 3.4028234663853E37D) {
/* 2317 */           d = 3.4028235E37D;
/* 2318 */         } else if (d == -2.14748E9D) {
/* 2319 */           d = -2.147483648E9D;
/* 2320 */         } else if (d == 3.40282E37D) {
/* 2321 */           d = 3.4028235E37D;
/*      */         } 
/*      */       }
/*      */       
/* 2325 */       return d;
/* 2326 */     } catch (NumberFormatException e) {
/* 2327 */       if (this.fields[colIndex - 1].getMysqlType() == 16) {
/* 2328 */         long valueAsLong = getNumericRepresentationOfSQLBitType(colIndex);
/*      */         
/* 2330 */         return valueAsLong;
/*      */       } 
/*      */       
/* 2333 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_number", new Object[] { stringVal, Integer.valueOf(colIndex) }), "S1009", getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFetchDirection() throws SQLException {
/* 2347 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2348 */       return this.fetchDirection;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFetchSize() throws SQLException {
/* 2361 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2362 */       return this.fetchSize;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char getFirstCharOfQuery() {
/*      */     try {
/* 2374 */       synchronized (checkClosed().getConnectionMutex()) {
/* 2375 */         return this.firstCharOfQuery;
/*      */       } 
/* 2377 */     } catch (SQLException e) {
/* 2378 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(int columnIndex) throws SQLException {
/* 2394 */     if (!this.isBinaryEncoded) {
/* 2395 */       String val = null;
/*      */       
/* 2397 */       val = getString(columnIndex);
/*      */       
/* 2399 */       return getFloatFromString(val, columnIndex);
/*      */     } 
/*      */     
/* 2402 */     return getNativeFloat(columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(String columnName) throws SQLException {
/* 2411 */     return getFloat(findColumn(columnName));
/*      */   }
/*      */   
/*      */   private final float getFloatFromString(String val, int columnIndex) throws SQLException {
/*      */     try {
/* 2416 */       if (val != null) {
/* 2417 */         if (val.length() == 0) {
/* 2418 */           return convertToZeroWithEmptyCheck();
/*      */         }
/*      */         
/* 2421 */         float f = Float.parseFloat(val);
/*      */         
/* 2423 */         if (this.jdbcCompliantTruncationForReads && (
/* 2424 */           f == Float.MIN_VALUE || f == Float.MAX_VALUE)) {
/* 2425 */           double valAsDouble = Double.parseDouble(val);
/*      */ 
/*      */ 
/*      */           
/* 2429 */           if (valAsDouble < 1.401298464324817E-45D - MIN_DIFF_PREC || valAsDouble > 3.4028234663852886E38D - MAX_DIFF_PREC) {
/* 2430 */             throwRangeException(String.valueOf(valAsDouble), columnIndex, 6);
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/* 2435 */         return f;
/*      */       } 
/*      */       
/* 2438 */       return 0.0F;
/* 2439 */     } catch (NumberFormatException nfe) {
/*      */       try {
/* 2441 */         Double valueAsDouble = new Double(val);
/* 2442 */         float valueAsFloat = valueAsDouble.floatValue();
/*      */         
/* 2444 */         if (this.jdbcCompliantTruncationForReads)
/*      */         {
/* 2446 */           if ((this.jdbcCompliantTruncationForReads && valueAsFloat == Float.NEGATIVE_INFINITY) || valueAsFloat == Float.POSITIVE_INFINITY) {
/* 2447 */             throwRangeException(valueAsDouble.toString(), columnIndex, 6);
/*      */           }
/*      */         }
/*      */         
/* 2451 */         return valueAsFloat;
/* 2452 */       } catch (NumberFormatException newNfe) {
/*      */ 
/*      */ 
/*      */         
/* 2456 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getFloat()_-____200") + val + Messages.getString("ResultSet.___in_column__201") + columnIndex, "S1009", getExceptionInterceptor());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(int columnIndex) throws SQLException {
/* 2473 */     checkRowPos();
/* 2474 */     checkColumnBounds(columnIndex);
/*      */     
/* 2476 */     if (!this.isBinaryEncoded) {
/* 2477 */       int columnIndexMinusOne = columnIndex - 1;
/*      */       
/* 2479 */       if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 2480 */         this.wasNullFlag = true;
/* 2481 */         return 0;
/*      */       } 
/* 2483 */       this.wasNullFlag = false;
/*      */       
/* 2485 */       if (this.fields[columnIndexMinusOne].getMysqlType() == 16) {
/* 2486 */         long valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex);
/*      */         
/* 2488 */         if (this.jdbcCompliantTruncationForReads && (valueAsLong < -2147483648L || valueAsLong > 2147483647L)) {
/* 2489 */           throwRangeException(String.valueOf(valueAsLong), columnIndex, 4);
/*      */         }
/*      */         
/* 2492 */         return (int)valueAsLong;
/*      */       } 
/*      */       
/* 2495 */       if (this.useFastIntParsing) {
/* 2496 */         if (this.thisRow.length(columnIndexMinusOne) == 0L) {
/* 2497 */           return convertToZeroWithEmptyCheck();
/*      */         }
/*      */         
/* 2500 */         boolean needsFullParse = this.thisRow.isFloatingPointNumber(columnIndexMinusOne);
/*      */         
/* 2502 */         if (!needsFullParse) {
/*      */           try {
/* 2504 */             return getIntWithOverflowCheck(columnIndexMinusOne);
/* 2505 */           } catch (NumberFormatException nfe) {
/*      */             try {
/* 2507 */               return parseIntAsDouble(columnIndex, this.thisRow.getString(columnIndexMinusOne, this.fields[columnIndexMinusOne].getEncoding(), this.connection));
/*      */             }
/* 2509 */             catch (NumberFormatException newNfe) {
/*      */ 
/*      */ 
/*      */               
/* 2513 */               throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getInt()_-____74") + this.thisRow.getString(columnIndexMinusOne, this.fields[columnIndexMinusOne].getEncoding(), this.connection) + "'", "S1009", getExceptionInterceptor());
/*      */             } 
/*      */           } 
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2521 */       String val = null;
/*      */       try {
/* 2523 */         val = getString(columnIndex);
/* 2524 */         if (val == null) {
/* 2525 */           return 0;
/*      */         }
/*      */         
/* 2528 */         if (val.length() == 0) {
/* 2529 */           return convertToZeroWithEmptyCheck();
/*      */         }
/*      */         
/* 2532 */         if (val.indexOf("e") == -1 && val.indexOf("E") == -1 && val.indexOf(".") == -1) {
/* 2533 */           int i = Integer.parseInt(val);
/*      */           
/* 2535 */           checkForIntegerTruncation(columnIndexMinusOne, null, i);
/*      */           
/* 2537 */           return i;
/*      */         } 
/*      */ 
/*      */         
/* 2541 */         int intVal = parseIntAsDouble(columnIndex, val);
/*      */         
/* 2543 */         checkForIntegerTruncation(columnIndex, null, intVal);
/*      */         
/* 2545 */         return intVal;
/*      */       }
/* 2547 */       catch (NumberFormatException nfe) {
/*      */         try {
/* 2549 */           return parseIntAsDouble(columnIndex, val);
/* 2550 */         } catch (NumberFormatException newNfe) {
/*      */ 
/*      */ 
/*      */           
/* 2554 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getInt()_-____74") + val + "'", "S1009", getExceptionInterceptor());
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 2559 */     return getNativeInt(columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(String columnName) throws SQLException {
/* 2568 */     return getInt(findColumn(columnName));
/*      */   }
/*      */   
/*      */   private final int getIntFromString(String val, int columnIndex) throws SQLException {
/*      */     try {
/* 2573 */       if (val != null) {
/*      */         
/* 2575 */         if (val.length() == 0) {
/* 2576 */           return convertToZeroWithEmptyCheck();
/*      */         }
/*      */         
/* 2579 */         if (val.indexOf("e") == -1 && val.indexOf("E") == -1 && val.indexOf(".") == -1) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2587 */           val = val.trim();
/*      */           
/* 2589 */           int valueAsInt = Integer.parseInt(val);
/*      */           
/* 2591 */           if (this.jdbcCompliantTruncationForReads && (
/* 2592 */             valueAsInt == Integer.MIN_VALUE || valueAsInt == Integer.MAX_VALUE)) {
/* 2593 */             long valueAsLong = Long.parseLong(val);
/*      */             
/* 2595 */             if (valueAsLong < -2147483648L || valueAsLong > 2147483647L) {
/* 2596 */               throwRangeException(String.valueOf(valueAsLong), columnIndex, 4);
/*      */             }
/*      */           } 
/*      */ 
/*      */           
/* 2601 */           return valueAsInt;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 2606 */         double valueAsDouble = Double.parseDouble(val);
/*      */         
/* 2608 */         if (this.jdbcCompliantTruncationForReads && (
/* 2609 */           valueAsDouble < -2.147483648E9D || valueAsDouble > 2.147483647E9D)) {
/* 2610 */           throwRangeException(String.valueOf(valueAsDouble), columnIndex, 4);
/*      */         }
/*      */ 
/*      */         
/* 2614 */         return (int)valueAsDouble;
/*      */       } 
/*      */       
/* 2617 */       return 0;
/* 2618 */     } catch (NumberFormatException nfe) {
/*      */       try {
/* 2620 */         double valueAsDouble = Double.parseDouble(val);
/*      */         
/* 2622 */         if (this.jdbcCompliantTruncationForReads && (
/* 2623 */           valueAsDouble < -2.147483648E9D || valueAsDouble > 2.147483647E9D)) {
/* 2624 */           throwRangeException(String.valueOf(valueAsDouble), columnIndex, 4);
/*      */         }
/*      */ 
/*      */         
/* 2628 */         return (int)valueAsDouble;
/* 2629 */       } catch (NumberFormatException newNfe) {
/*      */ 
/*      */ 
/*      */         
/* 2633 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getInt()_-____206") + val + Messages.getString("ResultSet.___in_column__207") + columnIndex, "S1009", getExceptionInterceptor());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(int columnIndex) throws SQLException {
/* 2651 */     return getLong(columnIndex, true);
/*      */   }
/*      */   
/*      */   private long getLong(int columnIndex, boolean overflowCheck) throws SQLException {
/* 2655 */     checkRowPos();
/* 2656 */     checkColumnBounds(columnIndex);
/*      */     
/* 2658 */     if (!this.isBinaryEncoded) {
/* 2659 */       int columnIndexMinusOne = columnIndex - 1;
/*      */       
/* 2661 */       if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 2662 */         this.wasNullFlag = true;
/* 2663 */         return 0L;
/*      */       } 
/* 2665 */       this.wasNullFlag = false;
/*      */       
/* 2667 */       if (this.fields[columnIndexMinusOne].getMysqlType() == 16) {
/* 2668 */         return getNumericRepresentationOfSQLBitType(columnIndex);
/*      */       }
/*      */       
/* 2671 */       if (this.useFastIntParsing) {
/* 2672 */         if (this.thisRow.length(columnIndexMinusOne) == 0L) {
/* 2673 */           return convertToZeroWithEmptyCheck();
/*      */         }
/*      */         
/* 2676 */         boolean needsFullParse = this.thisRow.isFloatingPointNumber(columnIndexMinusOne);
/*      */         
/* 2678 */         if (!needsFullParse) {
/*      */           try {
/* 2680 */             return getLongWithOverflowCheck(columnIndexMinusOne, overflowCheck);
/* 2681 */           } catch (NumberFormatException nfe) {
/*      */             try {
/* 2683 */               return parseLongAsDouble(columnIndexMinusOne, this.thisRow.getString(columnIndexMinusOne, this.fields[columnIndexMinusOne].getEncoding(), this.connection));
/*      */             }
/* 2685 */             catch (NumberFormatException newNfe) {
/*      */ 
/*      */ 
/*      */               
/* 2689 */               throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getLong()_-____79") + this.thisRow.getString(columnIndexMinusOne, this.fields[columnIndexMinusOne].getEncoding(), this.connection) + "'", "S1009", getExceptionInterceptor());
/*      */             } 
/*      */           } 
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2697 */       String val = null;
/*      */       try {
/* 2699 */         val = getString(columnIndex);
/* 2700 */         if (val == null) {
/* 2701 */           return 0L;
/*      */         }
/*      */         
/* 2704 */         if (val.length() == 0) {
/* 2705 */           return convertToZeroWithEmptyCheck();
/*      */         }
/*      */         
/* 2708 */         if (val.indexOf("e") == -1 && val.indexOf("E") == -1) {
/* 2709 */           return parseLongWithOverflowCheck(columnIndexMinusOne, null, val, overflowCheck);
/*      */         }
/*      */ 
/*      */         
/* 2713 */         return parseLongAsDouble(columnIndexMinusOne, val);
/*      */       }
/* 2715 */       catch (NumberFormatException nfe) {
/*      */         try {
/* 2717 */           return parseLongAsDouble(columnIndexMinusOne, val);
/* 2718 */         } catch (NumberFormatException newNfe) {
/*      */ 
/*      */ 
/*      */           
/* 2722 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getLong()_-____79") + val + "'", "S1009", getExceptionInterceptor());
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 2727 */     return getNativeLong(columnIndex, overflowCheck, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(String columnName) throws SQLException {
/* 2736 */     return getLong(findColumn(columnName));
/*      */   }
/*      */   
/*      */   private final long getLongFromString(String val, int columnIndexZeroBased) throws SQLException {
/*      */     try {
/* 2741 */       if (val != null) {
/*      */         
/* 2743 */         if (val.length() == 0) {
/* 2744 */           return convertToZeroWithEmptyCheck();
/*      */         }
/*      */         
/* 2747 */         if (val.indexOf("e") == -1 && val.indexOf("E") == -1) {
/* 2748 */           return parseLongWithOverflowCheck(columnIndexZeroBased, null, val, true);
/*      */         }
/*      */ 
/*      */         
/* 2752 */         return parseLongAsDouble(columnIndexZeroBased, val);
/*      */       } 
/*      */       
/* 2755 */       return 0L;
/* 2756 */     } catch (NumberFormatException nfe) {
/*      */       
/*      */       try {
/* 2759 */         return parseLongAsDouble(columnIndexZeroBased, val);
/* 2760 */       } catch (NumberFormatException newNfe) {
/*      */ 
/*      */ 
/*      */         
/* 2764 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getLong()_-____211") + val + Messages.getString("ResultSet.___in_column__212") + (columnIndexZeroBased + 1), "S1009", getExceptionInterceptor());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSetMetaData getMetaData() throws SQLException {
/* 2780 */     checkClosed();
/*      */     
/* 2782 */     return new ResultSetMetaData(this.fields, this.connection.getUseOldAliasMetadataBehavior(), this.connection.getYearIsDateType(), getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Array getNativeArray(int i) throws SQLException {
/* 2799 */     throw SQLError.createSQLFeatureNotSupportedException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected InputStream getNativeAsciiStream(int columnIndex) throws SQLException {
/* 2826 */     checkRowPos();
/*      */     
/* 2828 */     return getNativeBinaryStream(columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BigDecimal getNativeBigDecimal(int columnIndex) throws SQLException {
/* 2846 */     checkColumnBounds(columnIndex);
/*      */     
/* 2848 */     int scale = this.fields[columnIndex - 1].getDecimals();
/*      */     
/* 2850 */     return getNativeBigDecimal(columnIndex, scale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BigDecimal getNativeBigDecimal(int columnIndex, int scale) throws SQLException {
/* 2868 */     checkColumnBounds(columnIndex);
/*      */     
/* 2870 */     String stringVal = null;
/*      */     
/* 2872 */     Field f = this.fields[columnIndex - 1];
/*      */     
/* 2874 */     Object value = this.thisRow.getColumnValue(columnIndex - 1);
/*      */     
/* 2876 */     if (value == null) {
/* 2877 */       this.wasNullFlag = true;
/*      */       
/* 2879 */       return null;
/*      */     } 
/*      */     
/* 2882 */     this.wasNullFlag = false;
/*      */     
/* 2884 */     switch (f.getSQLType())
/*      */     { case 2:
/*      */       case 3:
/* 2887 */         stringVal = StringUtils.toAsciiString((byte[])value);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2893 */         return getBigDecimalFromString(stringVal, columnIndex, scale); }  stringVal = getNativeString(columnIndex); return getBigDecimalFromString(stringVal, columnIndex, scale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected InputStream getNativeBinaryStream(int columnIndex) throws SQLException {
/* 2914 */     checkRowPos();
/*      */     
/* 2916 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 2918 */     if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 2919 */       this.wasNullFlag = true;
/*      */       
/* 2921 */       return null;
/*      */     } 
/*      */     
/* 2924 */     this.wasNullFlag = false;
/*      */     
/* 2926 */     switch (this.fields[columnIndexMinusOne].getSQLType()) {
/*      */       case -7:
/*      */       case -4:
/*      */       case -3:
/*      */       case -2:
/*      */       case 2004:
/* 2932 */         return this.thisRow.getBinaryInputStream(columnIndexMinusOne);
/*      */     } 
/*      */     
/* 2935 */     byte[] b = getNativeBytes(columnIndex, false);
/*      */     
/* 2937 */     if (b != null) {
/* 2938 */       return new ByteArrayInputStream(b);
/*      */     }
/*      */     
/* 2941 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Blob getNativeBlob(int columnIndex) throws SQLException {
/* 2956 */     checkRowPos();
/*      */     
/* 2958 */     checkColumnBounds(columnIndex);
/*      */     
/* 2960 */     Object value = this.thisRow.getColumnValue(columnIndex - 1);
/*      */     
/* 2962 */     if (value == null) {
/* 2963 */       this.wasNullFlag = true;
/*      */     } else {
/* 2965 */       this.wasNullFlag = false;
/*      */     } 
/*      */     
/* 2968 */     if (this.wasNullFlag) {
/* 2969 */       return null;
/*      */     }
/*      */     
/* 2972 */     int mysqlType = this.fields[columnIndex - 1].getMysqlType();
/*      */     
/* 2974 */     byte[] dataAsBytes = null;
/*      */     
/* 2976 */     switch (mysqlType) {
/*      */       case 249:
/*      */       case 250:
/*      */       case 251:
/*      */       case 252:
/* 2981 */         dataAsBytes = (byte[])value;
/*      */         break;
/*      */       
/*      */       default:
/* 2985 */         dataAsBytes = getNativeBytes(columnIndex, false);
/*      */         break;
/*      */     } 
/* 2988 */     if (!this.connection.getEmulateLocators()) {
/* 2989 */       return new Blob(dataAsBytes, getExceptionInterceptor());
/*      */     }
/*      */     
/* 2992 */     return new BlobFromLocator(this, columnIndex, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */   public static boolean arraysEqual(byte[] left, byte[] right) {
/* 2996 */     if (left == null) {
/* 2997 */       return (right == null);
/*      */     }
/* 2999 */     if (right == null) {
/* 3000 */       return false;
/*      */     }
/* 3002 */     if (left.length != right.length) {
/* 3003 */       return false;
/*      */     }
/* 3005 */     for (int i = 0; i < left.length; i++) {
/* 3006 */       if (left[i] != right[i]) {
/* 3007 */         return false;
/*      */       }
/*      */     } 
/* 3010 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected byte getNativeByte(int columnIndex) throws SQLException {
/* 3025 */     return getNativeByte(columnIndex, true); } protected byte getNativeByte(int columnIndex, boolean overflowCheck) throws SQLException { long valueAsLong; byte valueAsByte; short valueAsShort;
/*      */     int valueAsInt;
/*      */     float valueAsFloat;
/*      */     double valueAsDouble;
/* 3029 */     checkRowPos();
/*      */     
/* 3031 */     checkColumnBounds(columnIndex);
/*      */     
/* 3033 */     Object value = this.thisRow.getColumnValue(columnIndex - 1);
/*      */     
/* 3035 */     if (value == null) {
/* 3036 */       this.wasNullFlag = true;
/*      */       
/* 3038 */       return 0;
/*      */     } 
/*      */     
/* 3041 */     this.wasNullFlag = false;
/*      */     
/* 3043 */     columnIndex--;
/*      */     
/* 3045 */     Field field = this.fields[columnIndex];
/*      */     
/* 3047 */     switch (field.getMysqlType()) {
/*      */       case 16:
/* 3049 */         valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex + 1);
/*      */         
/* 3051 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (valueAsLong < -128L || valueAsLong > 127L)) {
/* 3052 */           throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, -6);
/*      */         }
/*      */         
/* 3055 */         return (byte)(int)valueAsLong;
/*      */       case 1:
/* 3057 */         valueAsByte = ((byte[])value)[0];
/*      */         
/* 3059 */         if (!field.isUnsigned()) {
/* 3060 */           return valueAsByte;
/*      */         }
/*      */         
/* 3063 */         valueAsShort = (valueAsByte >= 0) ? (short)valueAsByte : (short)(valueAsByte + 256);
/*      */         
/* 3065 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && 
/* 3066 */           valueAsShort > 127) {
/* 3067 */           throwRangeException(String.valueOf(valueAsShort), columnIndex + 1, -6);
/*      */         }
/*      */ 
/*      */         
/* 3071 */         return (byte)valueAsShort;
/*      */       
/*      */       case 2:
/*      */       case 13:
/* 3075 */         valueAsShort = getNativeShort(columnIndex + 1);
/*      */         
/* 3077 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (
/* 3078 */           valueAsShort < -128 || valueAsShort > 127)) {
/* 3079 */           throwRangeException(String.valueOf(valueAsShort), columnIndex + 1, -6);
/*      */         }
/*      */ 
/*      */         
/* 3083 */         return (byte)valueAsShort;
/*      */       case 3:
/*      */       case 9:
/* 3086 */         valueAsInt = getNativeInt(columnIndex + 1, false);
/*      */         
/* 3088 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (
/* 3089 */           valueAsInt < -128 || valueAsInt > 127)) {
/* 3090 */           throwRangeException(String.valueOf(valueAsInt), columnIndex + 1, -6);
/*      */         }
/*      */ 
/*      */         
/* 3094 */         return (byte)valueAsInt;
/*      */       
/*      */       case 4:
/* 3097 */         valueAsFloat = getNativeFloat(columnIndex + 1);
/*      */         
/* 3099 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (
/* 3100 */           valueAsFloat < -128.0F || valueAsFloat > 127.0F))
/*      */         {
/* 3102 */           throwRangeException(String.valueOf(valueAsFloat), columnIndex + 1, -6);
/*      */         }
/*      */ 
/*      */         
/* 3106 */         return (byte)(int)valueAsFloat;
/*      */       
/*      */       case 5:
/* 3109 */         valueAsDouble = getNativeDouble(columnIndex + 1);
/*      */         
/* 3111 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (
/* 3112 */           valueAsDouble < -128.0D || valueAsDouble > 127.0D)) {
/* 3113 */           throwRangeException(String.valueOf(valueAsDouble), columnIndex + 1, -6);
/*      */         }
/*      */ 
/*      */         
/* 3117 */         return (byte)(int)valueAsDouble;
/*      */       
/*      */       case 8:
/* 3120 */         valueAsLong = getNativeLong(columnIndex + 1, false, true);
/*      */         
/* 3122 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (
/* 3123 */           valueAsLong < -128L || valueAsLong > 127L)) {
/* 3124 */           throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, -6);
/*      */         }
/*      */ 
/*      */         
/* 3128 */         return (byte)(int)valueAsLong;
/*      */     } 
/*      */     
/* 3131 */     if (this.useUsageAdvisor) {
/* 3132 */       issueConversionViaParsingWarning("getByte()", columnIndex, this.thisRow.getColumnValue(columnIndex - 1), this.fields[columnIndex], new int[] { 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 3137 */     return getByteFromString(getNativeString(columnIndex + 1), columnIndex + 1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected byte[] getNativeBytes(int columnIndex, boolean noConversion) throws SQLException {
/* 3157 */     checkRowPos();
/*      */     
/* 3159 */     checkColumnBounds(columnIndex);
/*      */     
/* 3161 */     Object value = this.thisRow.getColumnValue(columnIndex - 1);
/*      */     
/* 3163 */     if (value == null) {
/* 3164 */       this.wasNullFlag = true;
/*      */     } else {
/* 3166 */       this.wasNullFlag = false;
/*      */     } 
/*      */     
/* 3169 */     if (this.wasNullFlag) {
/* 3170 */       return null;
/*      */     }
/*      */     
/* 3173 */     Field field = this.fields[columnIndex - 1];
/*      */     
/* 3175 */     int mysqlType = field.getMysqlType();
/*      */ 
/*      */     
/* 3178 */     if (noConversion) {
/* 3179 */       mysqlType = 252;
/*      */     }
/*      */     
/* 3182 */     switch (mysqlType) {
/*      */       case 16:
/*      */       case 249:
/*      */       case 250:
/*      */       case 251:
/*      */       case 252:
/* 3188 */         return (byte[])value;
/*      */       
/*      */       case 15:
/*      */       case 253:
/*      */       case 254:
/* 3193 */         if (value instanceof byte[]) {
/* 3194 */           return (byte[])value;
/*      */         }
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/* 3200 */     int sqlType = field.getSQLType();
/*      */     
/* 3202 */     if (sqlType == -3 || sqlType == -2) {
/* 3203 */       return (byte[])value;
/*      */     }
/*      */     
/* 3206 */     return getBytesFromString(getNativeString(columnIndex));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Reader getNativeCharacterStream(int columnIndex) throws SQLException {
/* 3225 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 3227 */     switch (this.fields[columnIndexMinusOne].getSQLType()) {
/*      */       case -1:
/*      */       case 1:
/*      */       case 12:
/*      */       case 2005:
/* 3232 */         if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 3233 */           this.wasNullFlag = true;
/*      */           
/* 3235 */           return null;
/*      */         } 
/*      */         
/* 3238 */         this.wasNullFlag = false;
/*      */         
/* 3240 */         return this.thisRow.getReader(columnIndexMinusOne);
/*      */     } 
/*      */     
/* 3243 */     String asString = getStringForClob(columnIndex);
/*      */     
/* 3245 */     if (asString == null) {
/* 3246 */       return null;
/*      */     }
/*      */     
/* 3249 */     return getCharacterStreamFromString(asString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Clob getNativeClob(int columnIndex) throws SQLException {
/* 3264 */     String stringVal = getStringForClob(columnIndex);
/*      */     
/* 3266 */     if (stringVal == null) {
/* 3267 */       return null;
/*      */     }
/*      */     
/* 3270 */     return getClobFromString(stringVal);
/*      */   }
/*      */   
/*      */   private String getNativeConvertToString(int columnIndex, Field field) throws SQLException {
/* 3274 */     synchronized (checkClosed().getConnectionMutex()) {
/*      */       boolean booleanVal; byte tinyintVal; short unsignedTinyVal; int intVal; long longVal; float floatVal; double doubleVal; String stringVal; byte[] data; Date dt; Object obj; Time tm; Timestamp tstamp; String result;
/* 3276 */       int sqlType = field.getSQLType();
/* 3277 */       int mysqlType = field.getMysqlType();
/*      */       
/* 3279 */       switch (sqlType) {
/*      */         case -7:
/* 3281 */           return String.valueOf(getNumericRepresentationOfSQLBitType(columnIndex));
/*      */         case 16:
/* 3283 */           booleanVal = getBoolean(columnIndex);
/*      */           
/* 3285 */           if (this.wasNullFlag) {
/* 3286 */             return null;
/*      */           }
/*      */           
/* 3289 */           return String.valueOf(booleanVal);
/*      */         
/*      */         case -6:
/* 3292 */           tinyintVal = getNativeByte(columnIndex, false);
/*      */           
/* 3294 */           if (this.wasNullFlag) {
/* 3295 */             return null;
/*      */           }
/*      */           
/* 3298 */           if (!field.isUnsigned() || tinyintVal >= 0) {
/* 3299 */             return String.valueOf(tinyintVal);
/*      */           }
/*      */           
/* 3302 */           unsignedTinyVal = (short)(tinyintVal & 0xFF);
/*      */           
/* 3304 */           return String.valueOf(unsignedTinyVal);
/*      */ 
/*      */         
/*      */         case 5:
/* 3308 */           intVal = getNativeInt(columnIndex, false);
/*      */           
/* 3310 */           if (this.wasNullFlag) {
/* 3311 */             return null;
/*      */           }
/*      */           
/* 3314 */           if (!field.isUnsigned() || intVal >= 0) {
/* 3315 */             return String.valueOf(intVal);
/*      */           }
/*      */           
/* 3318 */           intVal &= 0xFFFF;
/*      */           
/* 3320 */           return String.valueOf(intVal);
/*      */         
/*      */         case 4:
/* 3323 */           intVal = getNativeInt(columnIndex, false);
/*      */           
/* 3325 */           if (this.wasNullFlag) {
/* 3326 */             return null;
/*      */           }
/*      */           
/* 3329 */           if (!field.isUnsigned() || intVal >= 0 || field.getMysqlType() == 9)
/*      */           {
/* 3331 */             return String.valueOf(intVal);
/*      */           }
/*      */           
/* 3334 */           longVal = intVal & 0xFFFFFFFFL;
/*      */           
/* 3336 */           return String.valueOf(longVal);
/*      */ 
/*      */         
/*      */         case -5:
/* 3340 */           if (!field.isUnsigned()) {
/* 3341 */             longVal = getNativeLong(columnIndex, false, true);
/*      */             
/* 3343 */             if (this.wasNullFlag) {
/* 3344 */               return null;
/*      */             }
/*      */             
/* 3347 */             return String.valueOf(longVal);
/*      */           } 
/*      */           
/* 3350 */           longVal = getNativeLong(columnIndex, false, false);
/*      */           
/* 3352 */           if (this.wasNullFlag) {
/* 3353 */             return null;
/*      */           }
/*      */           
/* 3356 */           return String.valueOf(convertLongToUlong(longVal));
/*      */         case 7:
/* 3358 */           floatVal = getNativeFloat(columnIndex);
/*      */           
/* 3360 */           if (this.wasNullFlag) {
/* 3361 */             return null;
/*      */           }
/*      */           
/* 3364 */           return String.valueOf(floatVal);
/*      */         
/*      */         case 6:
/*      */         case 8:
/* 3368 */           doubleVal = getNativeDouble(columnIndex);
/*      */           
/* 3370 */           if (this.wasNullFlag) {
/* 3371 */             return null;
/*      */           }
/*      */           
/* 3374 */           return String.valueOf(doubleVal);
/*      */         
/*      */         case 2:
/*      */         case 3:
/* 3378 */           stringVal = StringUtils.toAsciiString(this.thisRow.getColumnValue(columnIndex - 1));
/*      */ 
/*      */ 
/*      */           
/* 3382 */           if (stringVal != null) {
/* 3383 */             BigDecimal val; this.wasNullFlag = false;
/*      */             
/* 3385 */             if (stringVal.length() == 0) {
/* 3386 */               val = new BigDecimal(0);
/*      */               
/* 3388 */               return val.toString();
/*      */             } 
/*      */             
/*      */             try {
/* 3392 */               val = new BigDecimal(stringVal);
/* 3393 */             } catch (NumberFormatException ex) {
/* 3394 */               throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009", getExceptionInterceptor());
/*      */             } 
/*      */ 
/*      */ 
/*      */             
/* 3399 */             return val.toString();
/*      */           } 
/*      */           
/* 3402 */           this.wasNullFlag = true;
/*      */           
/* 3404 */           return null;
/*      */ 
/*      */         
/*      */         case -1:
/*      */         case 1:
/*      */         case 12:
/* 3410 */           return extractStringFromNativeColumn(columnIndex, mysqlType);
/*      */         
/*      */         case -4:
/*      */         case -3:
/*      */         case -2:
/* 3415 */           if (!field.isBlob())
/* 3416 */             return extractStringFromNativeColumn(columnIndex, mysqlType); 
/* 3417 */           if (!field.isBinary()) {
/* 3418 */             return extractStringFromNativeColumn(columnIndex, mysqlType);
/*      */           }
/* 3420 */           data = getBytes(columnIndex);
/* 3421 */           obj = data;
/*      */           
/* 3423 */           if (this.connection.getAutoDeserialize() && 
/* 3424 */             data != null && data.length >= 2) {
/* 3425 */             if (data[0] == -84 && data[1] == -19) {
/*      */               
/*      */               try {
/* 3428 */                 ByteArrayInputStream bytesIn = new ByteArrayInputStream(data);
/* 3429 */                 ObjectInputStream objIn = new ObjectInputStream(bytesIn);
/* 3430 */                 obj = objIn.readObject();
/* 3431 */                 objIn.close();
/* 3432 */                 bytesIn.close();
/* 3433 */               } catch (ClassNotFoundException cnfe) {
/* 3434 */                 throw SQLError.createSQLException(Messages.getString("ResultSet.Class_not_found___91") + cnfe.toString() + Messages.getString("ResultSet._while_reading_serialized_object_92"), getExceptionInterceptor());
/*      */               }
/* 3436 */               catch (IOException ex) {
/* 3437 */                 obj = data;
/*      */               } 
/*      */             }
/*      */             
/* 3441 */             return obj.toString();
/*      */           } 
/*      */ 
/*      */           
/* 3445 */           return extractStringFromNativeColumn(columnIndex, mysqlType);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 91:
/* 3451 */           if (mysqlType == 13) {
/* 3452 */             short shortVal = getNativeShort(columnIndex);
/*      */             
/* 3454 */             if (!this.connection.getYearIsDateType()) {
/*      */               
/* 3456 */               if (this.wasNullFlag) {
/* 3457 */                 return null;
/*      */               }
/*      */               
/* 3460 */               return String.valueOf(shortVal);
/*      */             } 
/*      */             
/* 3463 */             if (field.getLength() == 2L) {
/*      */               
/* 3465 */               if (shortVal <= 69) {
/* 3466 */                 shortVal = (short)(shortVal + 100);
/*      */               }
/*      */               
/* 3469 */               shortVal = (short)(shortVal + 1900);
/*      */             } 
/*      */             
/* 3472 */             return fastDateCreate(null, shortVal, 1, 1).toString();
/*      */           } 
/*      */ 
/*      */           
/* 3476 */           if (this.connection.getNoDatetimeStringSync()) {
/* 3477 */             byte[] asBytes = getNativeBytes(columnIndex, true);
/*      */             
/* 3479 */             if (asBytes == null) {
/* 3480 */               return null;
/*      */             }
/*      */             
/* 3483 */             if (asBytes.length == 0)
/*      */             {
/*      */ 
/*      */               
/* 3487 */               return "0000-00-00";
/*      */             }
/*      */             
/* 3490 */             int year = asBytes[0] & 0xFF | (asBytes[1] & 0xFF) << 8;
/* 3491 */             int month = asBytes[2];
/* 3492 */             int day = asBytes[3];
/*      */             
/* 3494 */             if (year == 0 && month == 0 && day == 0) {
/* 3495 */               return "0000-00-00";
/*      */             }
/*      */           } 
/*      */           
/* 3499 */           dt = getNativeDate(columnIndex);
/*      */           
/* 3501 */           if (dt == null) {
/* 3502 */             return null;
/*      */           }
/*      */           
/* 3505 */           return String.valueOf(dt);
/*      */         
/*      */         case 92:
/* 3508 */           tm = getNativeTime(columnIndex, null, this.connection.getDefaultTimeZone(), false);
/*      */           
/* 3510 */           if (tm == null) {
/* 3511 */             return null;
/*      */           }
/*      */           
/* 3514 */           return String.valueOf(tm);
/*      */         
/*      */         case 93:
/* 3517 */           if (this.connection.getNoDatetimeStringSync()) {
/* 3518 */             byte[] asBytes = getNativeBytes(columnIndex, true);
/*      */             
/* 3520 */             if (asBytes == null) {
/* 3521 */               return null;
/*      */             }
/*      */             
/* 3524 */             if (asBytes.length == 0)
/*      */             {
/*      */ 
/*      */               
/* 3528 */               return "0000-00-00 00:00:00";
/*      */             }
/*      */             
/* 3531 */             int year = asBytes[0] & 0xFF | (asBytes[1] & 0xFF) << 8;
/* 3532 */             int month = asBytes[2];
/* 3533 */             int day = asBytes[3];
/*      */             
/* 3535 */             if (year == 0 && month == 0 && day == 0) {
/* 3536 */               return "0000-00-00 00:00:00";
/*      */             }
/*      */           } 
/*      */           
/* 3540 */           tstamp = getNativeTimestamp(columnIndex, null, this.connection.getDefaultTimeZone(), false);
/*      */           
/* 3542 */           if (tstamp == null) {
/* 3543 */             return null;
/*      */           }
/*      */           
/* 3546 */           result = String.valueOf(tstamp);
/*      */           
/* 3548 */           if (!this.connection.getNoDatetimeStringSync()) {
/* 3549 */             return result;
/*      */           }
/*      */           
/* 3552 */           if (result.endsWith(".0")) {
/* 3553 */             return result.substring(0, result.length() - 2);
/*      */           }
/* 3555 */           return extractStringFromNativeColumn(columnIndex, mysqlType);
/*      */       } 
/*      */       
/* 3558 */       return extractStringFromNativeColumn(columnIndex, mysqlType);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Date getNativeDate(int columnIndex) throws SQLException {
/* 3575 */     return getNativeDate(columnIndex, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Date getNativeDate(int columnIndex, Calendar cal) throws SQLException {
/* 3595 */     checkRowPos();
/* 3596 */     checkColumnBounds(columnIndex);
/*      */     
/* 3598 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 3600 */     int mysqlType = this.fields[columnIndexMinusOne].getMysqlType();
/*      */     
/* 3602 */     Date dateToReturn = null;
/*      */     
/* 3604 */     if (mysqlType == 10) {
/*      */       
/* 3606 */       dateToReturn = this.thisRow.getNativeDate(columnIndexMinusOne, this.connection, this, cal);
/*      */     } else {
/* 3608 */       TimeZone tz = (cal != null) ? cal.getTimeZone() : getDefaultTimeZone();
/*      */       
/* 3610 */       boolean rollForward = (tz != null && !tz.equals(getDefaultTimeZone()));
/*      */       
/* 3612 */       dateToReturn = (Date)this.thisRow.getNativeDateTimeValue(columnIndexMinusOne, null, 91, mysqlType, tz, rollForward, this.connection, this);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3620 */     if (dateToReturn == null) {
/*      */       
/* 3622 */       this.wasNullFlag = true;
/*      */       
/* 3624 */       return null;
/*      */     } 
/*      */     
/* 3627 */     this.wasNullFlag = false;
/*      */     
/* 3629 */     return dateToReturn;
/*      */   }
/*      */   
/*      */   Date getNativeDateViaParseConversion(int columnIndex) throws SQLException {
/* 3633 */     if (this.useUsageAdvisor) {
/* 3634 */       issueConversionViaParsingWarning("getDate()", columnIndex, this.thisRow.getColumnValue(columnIndex - 1), this.fields[columnIndex - 1], new int[] { 10 });
/*      */     }
/*      */ 
/*      */     
/* 3638 */     String stringVal = getNativeString(columnIndex);
/*      */     
/* 3640 */     return getDateFromString(stringVal, columnIndex, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected double getNativeDouble(int columnIndex) throws SQLException {
/*      */     long valueAsLong;
/*      */     BigInteger asBigInt;
/* 3655 */     checkRowPos();
/* 3656 */     checkColumnBounds(columnIndex);
/*      */     
/* 3658 */     columnIndex--;
/*      */     
/* 3660 */     if (this.thisRow.isNull(columnIndex)) {
/* 3661 */       this.wasNullFlag = true;
/*      */       
/* 3663 */       return 0.0D;
/*      */     } 
/*      */     
/* 3666 */     this.wasNullFlag = false;
/*      */     
/* 3668 */     Field f = this.fields[columnIndex];
/*      */     
/* 3670 */     switch (f.getMysqlType()) {
/*      */       case 5:
/* 3672 */         return this.thisRow.getNativeDouble(columnIndex);
/*      */       case 1:
/* 3674 */         if (!f.isUnsigned()) {
/* 3675 */           return getNativeByte(columnIndex + 1);
/*      */         }
/*      */         
/* 3678 */         return getNativeShort(columnIndex + 1);
/*      */       case 2:
/*      */       case 13:
/* 3681 */         if (!f.isUnsigned()) {
/* 3682 */           return getNativeShort(columnIndex + 1);
/*      */         }
/*      */         
/* 3685 */         return getNativeInt(columnIndex + 1);
/*      */       case 3:
/*      */       case 9:
/* 3688 */         if (!f.isUnsigned()) {
/* 3689 */           return getNativeInt(columnIndex + 1);
/*      */         }
/*      */         
/* 3692 */         return getNativeLong(columnIndex + 1);
/*      */       case 8:
/* 3694 */         valueAsLong = getNativeLong(columnIndex + 1);
/*      */         
/* 3696 */         if (!f.isUnsigned()) {
/* 3697 */           return valueAsLong;
/*      */         }
/*      */         
/* 3700 */         asBigInt = convertLongToUlong(valueAsLong);
/*      */ 
/*      */ 
/*      */         
/* 3704 */         return asBigInt.doubleValue();
/*      */       case 4:
/* 3706 */         return getNativeFloat(columnIndex + 1);
/*      */       case 16:
/* 3708 */         return getNumericRepresentationOfSQLBitType(columnIndex + 1);
/*      */     } 
/* 3710 */     String stringVal = getNativeString(columnIndex + 1);
/*      */     
/* 3712 */     if (this.useUsageAdvisor) {
/* 3713 */       issueConversionViaParsingWarning("getDouble()", columnIndex, stringVal, this.fields[columnIndex], new int[] { 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 3718 */     return getDoubleFromString(stringVal, columnIndex + 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected float getNativeFloat(int columnIndex) throws SQLException {
/*      */     long valueAsLong;
/*      */     Double valueAsDouble;
/*      */     float valueAsFloat;
/*      */     BigInteger asBigInt;
/* 3734 */     checkRowPos();
/* 3735 */     checkColumnBounds(columnIndex);
/*      */     
/* 3737 */     columnIndex--;
/*      */     
/* 3739 */     if (this.thisRow.isNull(columnIndex)) {
/* 3740 */       this.wasNullFlag = true;
/*      */       
/* 3742 */       return 0.0F;
/*      */     } 
/*      */     
/* 3745 */     this.wasNullFlag = false;
/*      */     
/* 3747 */     Field f = this.fields[columnIndex];
/*      */     
/* 3749 */     switch (f.getMysqlType()) {
/*      */       case 16:
/* 3751 */         valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex + 1);
/*      */         
/* 3753 */         return (float)valueAsLong;
/*      */ 
/*      */ 
/*      */       
/*      */       case 5:
/* 3758 */         valueAsDouble = new Double(getNativeDouble(columnIndex + 1));
/*      */         
/* 3760 */         valueAsFloat = valueAsDouble.floatValue();
/*      */         
/* 3762 */         if ((this.jdbcCompliantTruncationForReads && valueAsFloat == Float.NEGATIVE_INFINITY) || valueAsFloat == Float.POSITIVE_INFINITY) {
/* 3763 */           throwRangeException(valueAsDouble.toString(), columnIndex + 1, 6);
/*      */         }
/*      */         
/* 3766 */         return (float)getNativeDouble(columnIndex + 1);
/*      */       case 1:
/* 3768 */         if (!f.isUnsigned()) {
/* 3769 */           return getNativeByte(columnIndex + 1);
/*      */         }
/*      */         
/* 3772 */         return getNativeShort(columnIndex + 1);
/*      */       case 2:
/*      */       case 13:
/* 3775 */         if (!f.isUnsigned()) {
/* 3776 */           return getNativeShort(columnIndex + 1);
/*      */         }
/*      */         
/* 3779 */         return getNativeInt(columnIndex + 1);
/*      */       case 3:
/*      */       case 9:
/* 3782 */         if (!f.isUnsigned()) {
/* 3783 */           return getNativeInt(columnIndex + 1);
/*      */         }
/*      */         
/* 3786 */         return (float)getNativeLong(columnIndex + 1);
/*      */       case 8:
/* 3788 */         valueAsLong = getNativeLong(columnIndex + 1);
/*      */         
/* 3790 */         if (!f.isUnsigned()) {
/* 3791 */           return (float)valueAsLong;
/*      */         }
/*      */         
/* 3794 */         asBigInt = convertLongToUlong(valueAsLong);
/*      */ 
/*      */ 
/*      */         
/* 3798 */         return asBigInt.floatValue();
/*      */       
/*      */       case 4:
/* 3801 */         return this.thisRow.getNativeFloat(columnIndex);
/*      */     } 
/*      */     
/* 3804 */     String stringVal = getNativeString(columnIndex + 1);
/*      */     
/* 3806 */     if (this.useUsageAdvisor) {
/* 3807 */       issueConversionViaParsingWarning("getFloat()", columnIndex, stringVal, this.fields[columnIndex], new int[] { 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 3812 */     return getFloatFromString(stringVal, columnIndex + 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getNativeInt(int columnIndex) throws SQLException {
/* 3828 */     return getNativeInt(columnIndex, true); } protected int getNativeInt(int columnIndex, boolean overflowCheck) throws SQLException { long valueAsLong; byte tinyintVal;
/*      */     short asShort;
/*      */     int valueAsInt;
/*      */     double valueAsDouble;
/* 3832 */     checkRowPos();
/* 3833 */     checkColumnBounds(columnIndex);
/*      */     
/* 3835 */     columnIndex--;
/*      */     
/* 3837 */     if (this.thisRow.isNull(columnIndex)) {
/* 3838 */       this.wasNullFlag = true;
/*      */       
/* 3840 */       return 0;
/*      */     } 
/*      */     
/* 3843 */     this.wasNullFlag = false;
/*      */     
/* 3845 */     Field f = this.fields[columnIndex];
/*      */     
/* 3847 */     switch (f.getMysqlType()) {
/*      */       case 16:
/* 3849 */         valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex + 1);
/*      */         
/* 3851 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (valueAsLong < -2147483648L || valueAsLong > 2147483647L)) {
/* 3852 */           throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, 4);
/*      */         }
/*      */         
/* 3855 */         return (int)valueAsLong;
/*      */       case 1:
/* 3857 */         tinyintVal = getNativeByte(columnIndex + 1, false);
/*      */         
/* 3859 */         if (!f.isUnsigned() || tinyintVal >= 0) {
/* 3860 */           return tinyintVal;
/*      */         }
/*      */         
/* 3863 */         return tinyintVal + 256;
/*      */       case 2:
/*      */       case 13:
/* 3866 */         asShort = getNativeShort(columnIndex + 1, false);
/*      */         
/* 3868 */         if (!f.isUnsigned() || asShort >= 0) {
/* 3869 */           return asShort;
/*      */         }
/*      */         
/* 3872 */         return asShort + 65536;
/*      */       
/*      */       case 3:
/*      */       case 9:
/* 3876 */         valueAsInt = this.thisRow.getNativeInt(columnIndex);
/*      */         
/* 3878 */         if (!f.isUnsigned()) {
/* 3879 */           return valueAsInt;
/*      */         }
/*      */         
/* 3882 */         valueAsLong = (valueAsInt >= 0) ? valueAsInt : (valueAsInt + 4294967296L);
/*      */         
/* 3884 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && valueAsLong > 2147483647L) {
/* 3885 */           throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, 4);
/*      */         }
/*      */         
/* 3888 */         return (int)valueAsLong;
/*      */       case 8:
/* 3890 */         valueAsLong = getNativeLong(columnIndex + 1, false, true);
/*      */         
/* 3892 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (
/* 3893 */           valueAsLong < -2147483648L || valueAsLong > 2147483647L)) {
/* 3894 */           throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, 4);
/*      */         }
/*      */ 
/*      */         
/* 3898 */         return (int)valueAsLong;
/*      */       case 5:
/* 3900 */         valueAsDouble = getNativeDouble(columnIndex + 1);
/*      */         
/* 3902 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (
/* 3903 */           valueAsDouble < -2.147483648E9D || valueAsDouble > 2.147483647E9D)) {
/* 3904 */           throwRangeException(String.valueOf(valueAsDouble), columnIndex + 1, 4);
/*      */         }
/*      */ 
/*      */         
/* 3908 */         return (int)valueAsDouble;
/*      */       case 4:
/* 3910 */         valueAsDouble = getNativeFloat(columnIndex + 1);
/*      */         
/* 3912 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (
/* 3913 */           valueAsDouble < -2.147483648E9D || valueAsDouble > 2.147483647E9D)) {
/* 3914 */           throwRangeException(String.valueOf(valueAsDouble), columnIndex + 1, 4);
/*      */         }
/*      */ 
/*      */         
/* 3918 */         return (int)valueAsDouble;
/*      */     } 
/*      */     
/* 3921 */     String stringVal = getNativeString(columnIndex + 1);
/*      */     
/* 3923 */     if (this.useUsageAdvisor) {
/* 3924 */       issueConversionViaParsingWarning("getInt()", columnIndex, stringVal, this.fields[columnIndex], new int[] { 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 3929 */     return getIntFromString(stringVal, columnIndex + 1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected long getNativeLong(int columnIndex) throws SQLException {
/* 3945 */     return getNativeLong(columnIndex, true, true); } protected long getNativeLong(int columnIndex, boolean overflowCheck, boolean expandUnsignedLong) throws SQLException { int asInt;
/*      */     long valueAsLong;
/*      */     BigInteger asBigInt;
/*      */     double valueAsDouble;
/* 3949 */     checkRowPos();
/* 3950 */     checkColumnBounds(columnIndex);
/*      */     
/* 3952 */     columnIndex--;
/*      */     
/* 3954 */     if (this.thisRow.isNull(columnIndex)) {
/* 3955 */       this.wasNullFlag = true;
/*      */       
/* 3957 */       return 0L;
/*      */     } 
/*      */     
/* 3960 */     this.wasNullFlag = false;
/*      */     
/* 3962 */     Field f = this.fields[columnIndex];
/*      */     
/* 3964 */     switch (f.getMysqlType()) {
/*      */       case 16:
/* 3966 */         return getNumericRepresentationOfSQLBitType(columnIndex + 1);
/*      */       case 1:
/* 3968 */         if (!f.isUnsigned()) {
/* 3969 */           return getNativeByte(columnIndex + 1);
/*      */         }
/*      */         
/* 3972 */         return getNativeInt(columnIndex + 1);
/*      */       case 2:
/* 3974 */         if (!f.isUnsigned()) {
/* 3975 */           return getNativeShort(columnIndex + 1);
/*      */         }
/*      */         
/* 3978 */         return getNativeInt(columnIndex + 1, false);
/*      */       
/*      */       case 13:
/* 3981 */         return getNativeShort(columnIndex + 1);
/*      */       case 3:
/*      */       case 9:
/* 3984 */         asInt = getNativeInt(columnIndex + 1, false);
/*      */         
/* 3986 */         if (!f.isUnsigned() || asInt >= 0) {
/* 3987 */           return asInt;
/*      */         }
/*      */         
/* 3990 */         return asInt + 4294967296L;
/*      */       case 8:
/* 3992 */         valueAsLong = this.thisRow.getNativeLong(columnIndex);
/*      */         
/* 3994 */         if (!f.isUnsigned() || !expandUnsignedLong) {
/* 3995 */           return valueAsLong;
/*      */         }
/*      */         
/* 3998 */         asBigInt = convertLongToUlong(valueAsLong);
/*      */         
/* 4000 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (asBigInt.compareTo(new BigInteger(String.valueOf(Long.MAX_VALUE))) > 0 || asBigInt.compareTo(new BigInteger(String.valueOf(Long.MIN_VALUE))) < 0))
/*      */         {
/* 4002 */           throwRangeException(asBigInt.toString(), columnIndex + 1, -5);
/*      */         }
/*      */         
/* 4005 */         return getLongFromString(asBigInt.toString(), columnIndex);
/*      */       
/*      */       case 5:
/* 4008 */         valueAsDouble = getNativeDouble(columnIndex + 1);
/*      */         
/* 4010 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (
/* 4011 */           valueAsDouble < -9.223372036854776E18D || valueAsDouble > 9.223372036854776E18D)) {
/* 4012 */           throwRangeException(String.valueOf(valueAsDouble), columnIndex + 1, -5);
/*      */         }
/*      */ 
/*      */         
/* 4016 */         return (long)valueAsDouble;
/*      */       case 4:
/* 4018 */         valueAsDouble = getNativeFloat(columnIndex + 1);
/*      */         
/* 4020 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (
/* 4021 */           valueAsDouble < -9.223372036854776E18D || valueAsDouble > 9.223372036854776E18D)) {
/* 4022 */           throwRangeException(String.valueOf(valueAsDouble), columnIndex + 1, -5);
/*      */         }
/*      */ 
/*      */         
/* 4026 */         return (long)valueAsDouble;
/*      */     } 
/* 4028 */     String stringVal = getNativeString(columnIndex + 1);
/*      */     
/* 4030 */     if (this.useUsageAdvisor) {
/* 4031 */       issueConversionViaParsingWarning("getLong()", columnIndex, stringVal, this.fields[columnIndex], new int[] { 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 4036 */     return getLongFromString(stringVal, columnIndex + 1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Ref getNativeRef(int i) throws SQLException {
/* 4053 */     throw SQLError.createSQLFeatureNotSupportedException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected short getNativeShort(int columnIndex) throws SQLException {
/* 4068 */     return getNativeShort(columnIndex, true); } protected short getNativeShort(int columnIndex, boolean overflowCheck) throws SQLException { long valueAsLong; byte tinyintVal; short asShort; int valueAsInt;
/*      */     BigInteger asBigInt;
/*      */     double valueAsDouble;
/*      */     float valueAsFloat;
/* 4072 */     checkRowPos();
/* 4073 */     checkColumnBounds(columnIndex);
/*      */     
/* 4075 */     columnIndex--;
/*      */     
/* 4077 */     if (this.thisRow.isNull(columnIndex)) {
/* 4078 */       this.wasNullFlag = true;
/*      */       
/* 4080 */       return 0;
/*      */     } 
/*      */     
/* 4083 */     this.wasNullFlag = false;
/*      */     
/* 4085 */     Field f = this.fields[columnIndex];
/*      */     
/* 4087 */     switch (f.getMysqlType()) {
/*      */       case 16:
/* 4089 */         valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex + 1);
/*      */         
/* 4091 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (valueAsLong < -32768L || valueAsLong > 32767L)) {
/* 4092 */           throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, 5);
/*      */         }
/*      */         
/* 4095 */         return (short)(int)valueAsLong;
/*      */       
/*      */       case 1:
/* 4098 */         tinyintVal = getNativeByte(columnIndex + 1, false);
/*      */         
/* 4100 */         if (!f.isUnsigned() || tinyintVal >= 0) {
/* 4101 */           return (short)tinyintVal;
/*      */         }
/*      */         
/* 4104 */         return (short)(tinyintVal + 256);
/*      */       
/*      */       case 2:
/*      */       case 13:
/* 4108 */         asShort = this.thisRow.getNativeShort(columnIndex);
/*      */         
/* 4110 */         if (!f.isUnsigned()) {
/* 4111 */           return asShort;
/*      */         }
/*      */         
/* 4114 */         valueAsInt = asShort & 0xFFFF;
/*      */         
/* 4116 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && valueAsInt > 32767) {
/* 4117 */           throwRangeException(String.valueOf(valueAsInt), columnIndex + 1, 5);
/*      */         }
/*      */         
/* 4120 */         return (short)valueAsInt;
/*      */       case 3:
/*      */       case 9:
/* 4123 */         if (!f.isUnsigned()) {
/* 4124 */           valueAsInt = getNativeInt(columnIndex + 1, false);
/*      */           
/* 4126 */           if ((overflowCheck && this.jdbcCompliantTruncationForReads && valueAsInt > 32767) || valueAsInt < -32768) {
/* 4127 */             throwRangeException(String.valueOf(valueAsInt), columnIndex + 1, 5);
/*      */           }
/*      */           
/* 4130 */           return (short)valueAsInt;
/*      */         } 
/*      */         
/* 4133 */         valueAsLong = getNativeLong(columnIndex + 1, false, true);
/*      */         
/* 4135 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && valueAsLong > 32767L) {
/* 4136 */           throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, 5);
/*      */         }
/*      */         
/* 4139 */         return (short)(int)valueAsLong;
/*      */       
/*      */       case 8:
/* 4142 */         valueAsLong = getNativeLong(columnIndex + 1, false, false);
/*      */         
/* 4144 */         if (!f.isUnsigned()) {
/* 4145 */           if (overflowCheck && this.jdbcCompliantTruncationForReads && (
/* 4146 */             valueAsLong < -32768L || valueAsLong > 32767L)) {
/* 4147 */             throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, 5);
/*      */           }
/*      */ 
/*      */           
/* 4151 */           return (short)(int)valueAsLong;
/*      */         } 
/*      */         
/* 4154 */         asBigInt = convertLongToUlong(valueAsLong);
/*      */         
/* 4156 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (asBigInt.compareTo(new BigInteger(String.valueOf(32767))) > 0 || asBigInt.compareTo(new BigInteger(String.valueOf(-32768))) < 0))
/*      */         {
/* 4158 */           throwRangeException(asBigInt.toString(), columnIndex + 1, 5);
/*      */         }
/*      */         
/* 4161 */         return (short)getIntFromString(asBigInt.toString(), columnIndex + 1);
/*      */       
/*      */       case 5:
/* 4164 */         valueAsDouble = getNativeDouble(columnIndex + 1);
/*      */         
/* 4166 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (
/* 4167 */           valueAsDouble < -32768.0D || valueAsDouble > 32767.0D)) {
/* 4168 */           throwRangeException(String.valueOf(valueAsDouble), columnIndex + 1, 5);
/*      */         }
/*      */ 
/*      */         
/* 4172 */         return (short)(int)valueAsDouble;
/*      */       case 4:
/* 4174 */         valueAsFloat = getNativeFloat(columnIndex + 1);
/*      */         
/* 4176 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (
/* 4177 */           valueAsFloat < -32768.0F || valueAsFloat > 32767.0F)) {
/* 4178 */           throwRangeException(String.valueOf(valueAsFloat), columnIndex + 1, 5);
/*      */         }
/*      */ 
/*      */         
/* 4182 */         return (short)(int)valueAsFloat;
/*      */     } 
/* 4184 */     String stringVal = getNativeString(columnIndex + 1);
/*      */     
/* 4186 */     if (this.useUsageAdvisor) {
/* 4187 */       issueConversionViaParsingWarning("getShort()", columnIndex, stringVal, this.fields[columnIndex], new int[] { 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 4192 */     return getShortFromString(stringVal, columnIndex + 1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getNativeString(int columnIndex) throws SQLException {
/* 4208 */     checkRowPos();
/* 4209 */     checkColumnBounds(columnIndex);
/*      */     
/* 4211 */     if (this.fields == null) {
/* 4212 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Query_generated_no_fields_for_ResultSet_133"), "S1002", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */     
/* 4216 */     if (this.thisRow.isNull(columnIndex - 1)) {
/* 4217 */       this.wasNullFlag = true;
/*      */       
/* 4219 */       return null;
/*      */     } 
/*      */     
/* 4222 */     this.wasNullFlag = false;
/*      */     
/* 4224 */     String stringVal = null;
/*      */     
/* 4226 */     Field field = this.fields[columnIndex - 1];
/*      */ 
/*      */     
/* 4229 */     stringVal = getNativeConvertToString(columnIndex, field);
/* 4230 */     int mysqlType = field.getMysqlType();
/*      */     
/* 4232 */     if (mysqlType != 7 && mysqlType != 10 && field.isZeroFill() && stringVal != null) {
/* 4233 */       int origLength = stringVal.length();
/*      */       
/* 4235 */       StringBuilder zeroFillBuf = new StringBuilder(origLength);
/*      */       
/* 4237 */       long numZeros = field.getLength() - origLength;
/*      */       long i;
/* 4239 */       for (i = 0L; i < numZeros; i++) {
/* 4240 */         zeroFillBuf.append('0');
/*      */       }
/*      */       
/* 4243 */       zeroFillBuf.append(stringVal);
/*      */       
/* 4245 */       stringVal = zeroFillBuf.toString();
/*      */     } 
/*      */     
/* 4248 */     return stringVal;
/*      */   }
/*      */   
/*      */   private Time getNativeTime(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward) throws SQLException {
/* 4252 */     checkRowPos();
/* 4253 */     checkColumnBounds(columnIndex);
/*      */     
/* 4255 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 4257 */     int mysqlType = this.fields[columnIndexMinusOne].getMysqlType();
/*      */     
/* 4259 */     Time timeVal = null;
/*      */     
/* 4261 */     if (mysqlType == 11) {
/* 4262 */       timeVal = this.thisRow.getNativeTime(columnIndexMinusOne, targetCalendar, tz, rollForward, this.connection, this);
/*      */     } else {
/*      */       
/* 4265 */       timeVal = (Time)this.thisRow.getNativeDateTimeValue(columnIndexMinusOne, null, 92, mysqlType, tz, rollForward, this.connection, this);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4273 */     if (timeVal == null) {
/*      */       
/* 4275 */       this.wasNullFlag = true;
/*      */       
/* 4277 */       return null;
/*      */     } 
/*      */     
/* 4280 */     this.wasNullFlag = false;
/*      */     
/* 4282 */     return timeVal;
/*      */   }
/*      */   
/*      */   Time getNativeTimeViaParseConversion(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward) throws SQLException {
/* 4286 */     if (this.useUsageAdvisor) {
/* 4287 */       issueConversionViaParsingWarning("getTime()", columnIndex, this.thisRow.getColumnValue(columnIndex - 1), this.fields[columnIndex - 1], new int[] { 11 });
/*      */     }
/*      */ 
/*      */     
/* 4291 */     String strTime = getNativeString(columnIndex);
/*      */     
/* 4293 */     return getTimeFromString(strTime, targetCalendar, columnIndex, tz, rollForward);
/*      */   }
/*      */   
/*      */   private Timestamp getNativeTimestamp(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward) throws SQLException {
/* 4297 */     checkRowPos();
/* 4298 */     checkColumnBounds(columnIndex);
/*      */     
/* 4300 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 4302 */     Timestamp tsVal = null;
/*      */     
/* 4304 */     int mysqlType = this.fields[columnIndexMinusOne].getMysqlType();
/*      */     
/* 4306 */     switch (mysqlType) {
/*      */       case 7:
/*      */       case 12:
/* 4309 */         tsVal = this.thisRow.getNativeTimestamp(columnIndexMinusOne, targetCalendar, tz, rollForward, this.connection, this);
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 4314 */         tsVal = (Timestamp)this.thisRow.getNativeDateTimeValue(columnIndexMinusOne, null, 93, mysqlType, tz, rollForward, this.connection, this);
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4323 */     if (tsVal == null) {
/*      */       
/* 4325 */       this.wasNullFlag = true;
/*      */       
/* 4327 */       return null;
/*      */     } 
/*      */     
/* 4330 */     this.wasNullFlag = false;
/*      */     
/* 4332 */     return tsVal;
/*      */   }
/*      */   
/*      */   Timestamp getNativeTimestampViaParseConversion(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward) throws SQLException {
/* 4336 */     if (this.useUsageAdvisor) {
/* 4337 */       issueConversionViaParsingWarning("getTimestamp()", columnIndex, this.thisRow.getColumnValue(columnIndex - 1), this.fields[columnIndex - 1], new int[] { 7, 12 });
/*      */     }
/*      */ 
/*      */     
/* 4341 */     String strTimestamp = getNativeString(columnIndex);
/*      */     
/* 4343 */     return getTimestampFromString(columnIndex, targetCalendar, strTimestamp, tz, rollForward);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected InputStream getNativeUnicodeStream(int columnIndex) throws SQLException {
/* 4368 */     checkRowPos();
/*      */     
/* 4370 */     return getBinaryStream(columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected URL getNativeURL(int colIndex) throws SQLException {
/* 4377 */     String val = getString(colIndex);
/*      */     
/* 4379 */     if (val == null) {
/* 4380 */       return null;
/*      */     }
/*      */     
/*      */     try {
/* 4384 */       return new URL(val);
/* 4385 */     } catch (MalformedURLException mfe) {
/* 4386 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Malformed_URL____141") + val + "'", "S1009", getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized ResultSetInternalMethods getNextResultSet() {
/* 4395 */     return this.nextResultSet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int columnIndex) throws SQLException {
/*      */     String stringVal;
/* 4419 */     checkRowPos();
/* 4420 */     checkColumnBounds(columnIndex);
/*      */     
/* 4422 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 4424 */     if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 4425 */       this.wasNullFlag = true;
/*      */       
/* 4427 */       return null;
/*      */     } 
/*      */     
/* 4430 */     this.wasNullFlag = false;
/*      */ 
/*      */     
/* 4433 */     Field field = this.fields[columnIndexMinusOne];
/*      */     
/* 4435 */     switch (field.getSQLType()) {
/*      */       case -7:
/* 4437 */         if (field.getMysqlType() == 16 && !field.isSingleBit()) {
/* 4438 */           return getObjectDeserializingIfNeeded(columnIndex);
/*      */         }
/* 4440 */         return Boolean.valueOf(getBoolean(columnIndex));
/*      */       
/*      */       case 16:
/* 4443 */         return Boolean.valueOf(getBoolean(columnIndex));
/*      */       
/*      */       case -6:
/* 4446 */         if (!field.isUnsigned()) {
/* 4447 */           return Integer.valueOf(getByte(columnIndex));
/*      */         }
/*      */         
/* 4450 */         return Integer.valueOf(getInt(columnIndex));
/*      */ 
/*      */       
/*      */       case 5:
/* 4454 */         return Integer.valueOf(getInt(columnIndex));
/*      */ 
/*      */       
/*      */       case 4:
/* 4458 */         if (!field.isUnsigned() || field.getMysqlType() == 9) {
/* 4459 */           return Integer.valueOf(getInt(columnIndex));
/*      */         }
/*      */         
/* 4462 */         return Long.valueOf(getLong(columnIndex));
/*      */ 
/*      */       
/*      */       case -5:
/* 4466 */         if (!field.isUnsigned()) {
/* 4467 */           return Long.valueOf(getLong(columnIndex));
/*      */         }
/*      */         
/* 4470 */         stringVal = getString(columnIndex);
/*      */         
/* 4472 */         if (stringVal == null) {
/* 4473 */           return null;
/*      */         }
/*      */         
/*      */         try {
/* 4477 */           return new BigInteger(stringVal);
/* 4478 */         } catch (NumberFormatException nfe) {
/* 4479 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigInteger", new Object[] { Integer.valueOf(columnIndex), stringVal }), "S1009", getExceptionInterceptor());
/*      */         } 
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/*      */       case 3:
/* 4486 */         stringVal = getString(columnIndex);
/*      */ 
/*      */ 
/*      */         
/* 4490 */         if (stringVal != null) {
/* 4491 */           BigDecimal val; if (stringVal.length() == 0) {
/* 4492 */             val = new BigDecimal(0);
/*      */             
/* 4494 */             return val;
/*      */           } 
/*      */           
/*      */           try {
/* 4498 */             val = new BigDecimal(stringVal);
/* 4499 */           } catch (NumberFormatException ex) {
/* 4500 */             throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009", getExceptionInterceptor());
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/* 4505 */           return val;
/*      */         } 
/*      */         
/* 4508 */         return null;
/*      */       
/*      */       case 7:
/* 4511 */         return new Float(getFloat(columnIndex));
/*      */       
/*      */       case 6:
/*      */       case 8:
/* 4515 */         return new Double(getDouble(columnIndex));
/*      */       
/*      */       case 1:
/*      */       case 12:
/* 4519 */         if (!field.isOpaqueBinary()) {
/* 4520 */           return getString(columnIndex);
/*      */         }
/*      */         
/* 4523 */         return getBytes(columnIndex);
/*      */       case -1:
/* 4525 */         if (!field.isOpaqueBinary()) {
/* 4526 */           return getStringForClob(columnIndex);
/*      */         }
/*      */         
/* 4529 */         return getBytes(columnIndex);
/*      */       
/*      */       case -4:
/*      */       case -3:
/*      */       case -2:
/* 4534 */         if (field.getMysqlType() == 255) {
/* 4535 */           return getBytes(columnIndex);
/*      */         }
/* 4537 */         return getObjectDeserializingIfNeeded(columnIndex);
/*      */       
/*      */       case 91:
/* 4540 */         if (field.getMysqlType() == 13 && !this.connection.getYearIsDateType()) {
/* 4541 */           return Short.valueOf(getShort(columnIndex));
/*      */         }
/*      */         
/* 4544 */         return getDate(columnIndex);
/*      */       
/*      */       case 92:
/* 4547 */         return getTime(columnIndex);
/*      */       
/*      */       case 93:
/* 4550 */         return getTimestamp(columnIndex);
/*      */     } 
/*      */     
/* 4553 */     return getString(columnIndex);
/*      */   }
/*      */ 
/*      */   
/*      */   private Object getObjectDeserializingIfNeeded(int columnIndex) throws SQLException {
/* 4558 */     Field field = this.fields[columnIndex - 1];
/*      */     
/* 4560 */     if (field.isBinary() || field.isBlob()) {
/* 4561 */       byte[] data = getBytes(columnIndex);
/*      */       
/* 4563 */       if (this.connection.getAutoDeserialize()) {
/* 4564 */         Object obj = data;
/*      */         
/* 4566 */         if (data != null && data.length >= 2) {
/* 4567 */           if (data[0] == -84 && data[1] == -19) {
/*      */             
/*      */             try {
/* 4570 */               ByteArrayInputStream bytesIn = new ByteArrayInputStream(data);
/* 4571 */               ObjectInputStream objIn = new ObjectInputStream(bytesIn);
/* 4572 */               obj = objIn.readObject();
/* 4573 */               objIn.close();
/* 4574 */               bytesIn.close();
/* 4575 */             } catch (ClassNotFoundException cnfe) {
/* 4576 */               throw SQLError.createSQLException(Messages.getString("ResultSet.Class_not_found___91") + cnfe.toString() + Messages.getString("ResultSet._while_reading_serialized_object_92"), getExceptionInterceptor());
/*      */             }
/* 4578 */             catch (IOException ex) {
/* 4579 */               obj = data;
/*      */             } 
/*      */           } else {
/* 4582 */             return getString(columnIndex);
/*      */           } 
/*      */         }
/*      */         
/* 4586 */         return obj;
/*      */       } 
/*      */       
/* 4589 */       return data;
/*      */     } 
/*      */     
/* 4592 */     return getBytes(columnIndex);
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> T getObject(int columnIndex, Class<T> type) throws SQLException {
/* 4597 */     if (type == null) {
/* 4598 */       throw SQLError.createSQLException("Type parameter can not be null", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/* 4601 */     if (type.equals(String.class))
/* 4602 */       return (T)getString(columnIndex); 
/* 4603 */     if (type.equals(BigDecimal.class))
/* 4604 */       return (T)getBigDecimal(columnIndex); 
/* 4605 */     if (type.equals(Boolean.class) || type.equals(boolean.class))
/* 4606 */       return (T)Boolean.valueOf(getBoolean(columnIndex)); 
/* 4607 */     if (type.equals(Integer.class) || type.equals(int.class))
/* 4608 */       return (T)Integer.valueOf(getInt(columnIndex)); 
/* 4609 */     if (type.equals(Long.class) || type.equals(long.class))
/* 4610 */       return (T)Long.valueOf(getLong(columnIndex)); 
/* 4611 */     if (type.equals(Float.class) || type.equals(float.class))
/* 4612 */       return (T)Float.valueOf(getFloat(columnIndex)); 
/* 4613 */     if (type.equals(Double.class) || type.equals(double.class))
/* 4614 */       return (T)Double.valueOf(getDouble(columnIndex)); 
/* 4615 */     if (type.equals(byte[].class))
/* 4616 */       return (T)getBytes(columnIndex); 
/* 4617 */     if (type.equals(Date.class))
/* 4618 */       return (T)getDate(columnIndex); 
/* 4619 */     if (type.equals(Time.class))
/* 4620 */       return (T)getTime(columnIndex); 
/* 4621 */     if (type.equals(Timestamp.class))
/* 4622 */       return (T)getTimestamp(columnIndex); 
/* 4623 */     if (type.equals(Clob.class))
/* 4624 */       return (T)getClob(columnIndex); 
/* 4625 */     if (type.equals(Blob.class))
/* 4626 */       return (T)getBlob(columnIndex); 
/* 4627 */     if (type.equals(Array.class))
/* 4628 */       return (T)getArray(columnIndex); 
/* 4629 */     if (type.equals(Ref.class))
/* 4630 */       return (T)getRef(columnIndex); 
/* 4631 */     if (type.equals(URL.class)) {
/* 4632 */       return (T)getURL(columnIndex);
/*      */     }
/* 4634 */     if (this.connection.getAutoDeserialize()) {
/*      */       try {
/* 4636 */         return type.cast(getObject(columnIndex));
/* 4637 */       } catch (ClassCastException cce) {
/* 4638 */         SQLException sqlEx = SQLError.createSQLException("Conversion not supported for type " + type.getName(), "S1009", getExceptionInterceptor());
/*      */         
/* 4640 */         sqlEx.initCause(cce);
/*      */         
/* 4642 */         throw sqlEx;
/*      */       } 
/*      */     }
/*      */     
/* 4646 */     throw SQLError.createSQLException("Conversion not supported for type " + type.getName(), "S1009", getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T getObject(String columnLabel, Class<T> type) throws SQLException {
/* 4653 */     return getObject(findColumn(columnLabel), type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int i, Map<String, Class<?>> map) throws SQLException {
/* 4672 */     return getObject(i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(String columnName) throws SQLException {
/* 4696 */     return getObject(findColumn(columnName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(String colName, Map<String, Class<?>> map) throws SQLException {
/* 4715 */     return getObject(findColumn(colName), map);
/*      */   }
/*      */   public Object getObjectStoredProc(int columnIndex, int desiredSqlType) throws SQLException {
/*      */     String stringVal;
/* 4719 */     checkRowPos();
/* 4720 */     checkColumnBounds(columnIndex);
/*      */     
/* 4722 */     Object value = this.thisRow.getColumnValue(columnIndex - 1);
/*      */     
/* 4724 */     if (value == null) {
/* 4725 */       this.wasNullFlag = true;
/*      */       
/* 4727 */       return null;
/*      */     } 
/*      */     
/* 4730 */     this.wasNullFlag = false;
/*      */ 
/*      */     
/* 4733 */     Field field = this.fields[columnIndex - 1];
/*      */     
/* 4735 */     switch (desiredSqlType) {
/*      */       
/*      */       case -7:
/*      */       case 16:
/* 4739 */         return Boolean.valueOf(getBoolean(columnIndex));
/*      */       
/*      */       case -6:
/* 4742 */         return Integer.valueOf(getInt(columnIndex));
/*      */       
/*      */       case 5:
/* 4745 */         return Integer.valueOf(getInt(columnIndex));
/*      */ 
/*      */       
/*      */       case 4:
/* 4749 */         if (!field.isUnsigned() || field.getMysqlType() == 9) {
/* 4750 */           return Integer.valueOf(getInt(columnIndex));
/*      */         }
/*      */         
/* 4753 */         return Long.valueOf(getLong(columnIndex));
/*      */ 
/*      */       
/*      */       case -5:
/* 4757 */         if (field.isUnsigned()) {
/* 4758 */           return getBigDecimal(columnIndex);
/*      */         }
/*      */         
/* 4761 */         return Long.valueOf(getLong(columnIndex));
/*      */ 
/*      */       
/*      */       case 2:
/*      */       case 3:
/* 4766 */         stringVal = getString(columnIndex);
/*      */ 
/*      */         
/* 4769 */         if (stringVal != null) {
/* 4770 */           BigDecimal val; if (stringVal.length() == 0) {
/* 4771 */             val = new BigDecimal(0);
/*      */             
/* 4773 */             return val;
/*      */           } 
/*      */           
/*      */           try {
/* 4777 */             val = new BigDecimal(stringVal);
/* 4778 */           } catch (NumberFormatException ex) {
/* 4779 */             throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009", getExceptionInterceptor());
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/* 4784 */           return val;
/*      */         } 
/*      */         
/* 4787 */         return null;
/*      */       
/*      */       case 7:
/* 4790 */         return new Float(getFloat(columnIndex));
/*      */ 
/*      */       
/*      */       case 6:
/* 4794 */         if (!this.connection.getRunningCTS13()) {
/* 4795 */           return new Double(getFloat(columnIndex));
/*      */         }
/* 4797 */         return new Float(getFloat(columnIndex));
/*      */ 
/*      */       
/*      */       case 8:
/* 4801 */         return new Double(getDouble(columnIndex));
/*      */       
/*      */       case 1:
/*      */       case 12:
/* 4805 */         return getString(columnIndex);
/*      */       case -1:
/* 4807 */         return getStringForClob(columnIndex);
/*      */       case -4:
/*      */       case -3:
/*      */       case -2:
/* 4811 */         return getBytes(columnIndex);
/*      */       
/*      */       case 91:
/* 4814 */         if (field.getMysqlType() == 13 && !this.connection.getYearIsDateType()) {
/* 4815 */           return Short.valueOf(getShort(columnIndex));
/*      */         }
/*      */         
/* 4818 */         return getDate(columnIndex);
/*      */       
/*      */       case 92:
/* 4821 */         return getTime(columnIndex);
/*      */       
/*      */       case 93:
/* 4824 */         return getTimestamp(columnIndex);
/*      */     } 
/*      */     
/* 4827 */     return getString(columnIndex);
/*      */   }
/*      */ 
/*      */   
/*      */   public Object getObjectStoredProc(int i, Map<Object, Object> map, int desiredSqlType) throws SQLException {
/* 4832 */     return getObjectStoredProc(i, desiredSqlType);
/*      */   }
/*      */   
/*      */   public Object getObjectStoredProc(String columnName, int desiredSqlType) throws SQLException {
/* 4836 */     return getObjectStoredProc(findColumn(columnName), desiredSqlType);
/*      */   }
/*      */   
/*      */   public Object getObjectStoredProc(String colName, Map<Object, Object> map, int desiredSqlType) throws SQLException {
/* 4840 */     return getObjectStoredProc(findColumn(colName), map, desiredSqlType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Ref getRef(int i) throws SQLException {
/* 4856 */     checkColumnBounds(i);
/* 4857 */     throw SQLError.createSQLFeatureNotSupportedException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Ref getRef(String colName) throws SQLException {
/* 4873 */     return getRef(findColumn(colName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRow() throws SQLException {
/* 4889 */     checkClosed();
/*      */     
/* 4891 */     int currentRowNumber = this.rowData.getCurrentRowNumber();
/* 4892 */     int row = 0;
/*      */ 
/*      */     
/* 4895 */     if (!this.rowData.isDynamic()) {
/* 4896 */       if (currentRowNumber < 0 || this.rowData.isAfterLast() || this.rowData.isEmpty()) {
/* 4897 */         row = 0;
/*      */       } else {
/* 4899 */         row = currentRowNumber + 1;
/*      */       } 
/*      */     } else {
/*      */       
/* 4903 */       row = currentRowNumber + 1;
/*      */     } 
/*      */     
/* 4906 */     return row;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getServerInfo() {
/*      */     try {
/* 4916 */       synchronized (checkClosed().getConnectionMutex()) {
/* 4917 */         return this.serverInfo;
/*      */       } 
/* 4919 */     } catch (SQLException e) {
/* 4920 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private long getNumericRepresentationOfSQLBitType(int columnIndex) throws SQLException {
/* 4926 */     Object value = this.thisRow.getColumnValue(columnIndex - 1);
/*      */     
/* 4928 */     if (this.fields[columnIndex - 1].isSingleBit() || ((byte[])value).length == 1) {
/* 4929 */       return ((byte[])value)[0];
/*      */     }
/*      */     
/* 4932 */     byte[] asBytes = (byte[])value;
/*      */     
/* 4934 */     int shift = 0;
/*      */     
/* 4936 */     long[] steps = new long[asBytes.length];
/*      */     
/* 4938 */     for (int i = asBytes.length - 1; i >= 0; i--) {
/* 4939 */       steps[i] = (asBytes[i] & 0xFF) << shift;
/* 4940 */       shift += 8;
/*      */     } 
/*      */     
/* 4943 */     long valueAsLong = 0L;
/*      */     
/* 4945 */     for (int j = 0; j < asBytes.length; j++) {
/* 4946 */       valueAsLong |= steps[j];
/*      */     }
/*      */     
/* 4949 */     return valueAsLong;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(int columnIndex) throws SQLException {
/* 4964 */     checkRowPos();
/* 4965 */     checkColumnBounds(columnIndex);
/*      */     
/* 4967 */     if (!this.isBinaryEncoded) {
/* 4968 */       if (this.thisRow.isNull(columnIndex - 1)) {
/* 4969 */         this.wasNullFlag = true;
/* 4970 */         return 0;
/*      */       } 
/* 4972 */       this.wasNullFlag = false;
/*      */       
/* 4974 */       if (this.fields[columnIndex - 1].getMysqlType() == 16) {
/* 4975 */         long valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex);
/*      */         
/* 4977 */         if (this.jdbcCompliantTruncationForReads && (valueAsLong < -32768L || valueAsLong > 32767L)) {
/* 4978 */           throwRangeException(String.valueOf(valueAsLong), columnIndex, 5);
/*      */         }
/*      */         
/* 4981 */         return (short)(int)valueAsLong;
/*      */       } 
/*      */       
/* 4984 */       if (this.useFastIntParsing) {
/* 4985 */         byte[] shortAsBytes = this.thisRow.getColumnValue(columnIndex - 1);
/*      */         
/* 4987 */         if (shortAsBytes.length == 0) {
/* 4988 */           return (short)convertToZeroWithEmptyCheck();
/*      */         }
/*      */         
/* 4991 */         boolean needsFullParse = false;
/*      */         
/* 4993 */         for (int i = 0; i < shortAsBytes.length; i++) {
/* 4994 */           if ((char)shortAsBytes[i] == 'e' || (char)shortAsBytes[i] == 'E') {
/* 4995 */             needsFullParse = true;
/*      */             
/*      */             break;
/*      */           } 
/*      */         } 
/*      */         
/* 5001 */         if (!needsFullParse) {
/*      */           try {
/* 5003 */             return parseShortWithOverflowCheck(columnIndex, shortAsBytes, null);
/* 5004 */           } catch (NumberFormatException nfe) {
/*      */             try {
/* 5006 */               return parseShortAsDouble(columnIndex, StringUtils.toString(shortAsBytes));
/* 5007 */             } catch (NumberFormatException newNfe) {
/*      */ 
/*      */ 
/*      */               
/* 5011 */               throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getShort()_-____96") + StringUtils.toString(shortAsBytes) + "'", "S1009", getExceptionInterceptor());
/*      */             } 
/*      */           } 
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 5018 */       String val = null;
/*      */       try {
/* 5020 */         val = getString(columnIndex);
/* 5021 */         if (val == null) {
/* 5022 */           return 0;
/*      */         }
/*      */         
/* 5025 */         if (val.length() == 0) {
/* 5026 */           return (short)convertToZeroWithEmptyCheck();
/*      */         }
/*      */         
/* 5029 */         if (val.indexOf("e") == -1 && val.indexOf("E") == -1 && val.indexOf(".") == -1) {
/* 5030 */           return parseShortWithOverflowCheck(columnIndex, null, val);
/*      */         }
/*      */ 
/*      */         
/* 5034 */         return parseShortAsDouble(columnIndex, val);
/*      */       }
/* 5036 */       catch (NumberFormatException nfe) {
/*      */         try {
/* 5038 */           return parseShortAsDouble(columnIndex, val);
/* 5039 */         } catch (NumberFormatException newNfe) {
/*      */ 
/*      */ 
/*      */           
/* 5043 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getShort()_-____96") + val + "'", "S1009", getExceptionInterceptor());
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 5048 */     return getNativeShort(columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(String columnName) throws SQLException {
/* 5057 */     return getShort(findColumn(columnName));
/*      */   }
/*      */   
/*      */   private final short getShortFromString(String val, int columnIndex) throws SQLException {
/*      */     try {
/* 5062 */       if (val != null) {
/*      */         
/* 5064 */         if (val.length() == 0) {
/* 5065 */           return (short)convertToZeroWithEmptyCheck();
/*      */         }
/*      */         
/* 5068 */         if (val.indexOf("e") == -1 && val.indexOf("E") == -1 && val.indexOf(".") == -1) {
/* 5069 */           return parseShortWithOverflowCheck(columnIndex, null, val);
/*      */         }
/*      */ 
/*      */         
/* 5073 */         return parseShortAsDouble(columnIndex, val);
/*      */       } 
/*      */       
/* 5076 */       return 0;
/* 5077 */     } catch (NumberFormatException nfe) {
/*      */       try {
/* 5079 */         return parseShortAsDouble(columnIndex, val);
/* 5080 */       } catch (NumberFormatException newNfe) {
/*      */ 
/*      */ 
/*      */         
/* 5084 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getShort()_-____217") + val + Messages.getString("ResultSet.___in_column__218") + columnIndex, "S1009", getExceptionInterceptor());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Statement getStatement() throws SQLException {
/*      */     try {
/* 5100 */       synchronized (checkClosed().getConnectionMutex()) {
/* 5101 */         if (this.wrapperStatement != null) {
/* 5102 */           return this.wrapperStatement;
/*      */         }
/*      */         
/* 5105 */         return this.owningStatement;
/*      */       }
/*      */     
/* 5108 */     } catch (SQLException sqlEx) {
/* 5109 */       if (!this.retainOwningStatement) {
/* 5110 */         throw SQLError.createSQLException("Operation not allowed on closed ResultSet. Statements can be retained over result set closure by setting the connection property \"retainStatementAfterResultSetClose\" to \"true\".", "S1000", getExceptionInterceptor());
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 5115 */       if (this.wrapperStatement != null) {
/* 5116 */         return this.wrapperStatement;
/*      */       }
/*      */       
/* 5119 */       return this.owningStatement;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(int columnIndex) throws SQLException {
/* 5136 */     String stringVal = getStringInternal(columnIndex, true);
/*      */     
/* 5138 */     if (this.padCharsWithSpace && stringVal != null) {
/* 5139 */       Field f = this.fields[columnIndex - 1];
/*      */       
/* 5141 */       if (f.getMysqlType() == 254) {
/* 5142 */         int fieldLength = (int)f.getLength() / f.getMaxBytesPerCharacter();
/*      */         
/* 5144 */         int currentLength = stringVal.length();
/*      */         
/* 5146 */         if (currentLength < fieldLength) {
/* 5147 */           StringBuilder paddedBuf = new StringBuilder(fieldLength);
/* 5148 */           paddedBuf.append(stringVal);
/*      */           
/* 5150 */           int difference = fieldLength - currentLength;
/*      */           
/* 5152 */           paddedBuf.append(EMPTY_SPACE, 0, difference);
/*      */           
/* 5154 */           stringVal = paddedBuf.toString();
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 5159 */     return stringVal;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(String columnName) throws SQLException {
/* 5175 */     return getString(findColumn(columnName));
/*      */   }
/*      */   
/*      */   private String getStringForClob(int columnIndex) throws SQLException {
/* 5179 */     String asString = null;
/*      */     
/* 5181 */     String forcedEncoding = this.connection.getClobCharacterEncoding();
/*      */     
/* 5183 */     if (forcedEncoding == null) {
/* 5184 */       if (!this.isBinaryEncoded) {
/* 5185 */         asString = getString(columnIndex);
/*      */       } else {
/* 5187 */         asString = getNativeString(columnIndex);
/*      */       } 
/*      */     } else {
/*      */       try {
/* 5191 */         byte[] asBytes = null;
/*      */         
/* 5193 */         if (!this.isBinaryEncoded) {
/* 5194 */           asBytes = getBytes(columnIndex);
/*      */         } else {
/* 5196 */           asBytes = getNativeBytes(columnIndex, true);
/*      */         } 
/*      */         
/* 5199 */         if (asBytes != null) {
/* 5200 */           asString = StringUtils.toString(asBytes, forcedEncoding);
/*      */         }
/* 5202 */       } catch (UnsupportedEncodingException uee) {
/* 5203 */         throw SQLError.createSQLException("Unsupported character encoding " + forcedEncoding, "S1009", getExceptionInterceptor());
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 5208 */     return asString;
/*      */   }
/*      */   
/*      */   protected String getStringInternal(int columnIndex, boolean checkDateTypes) throws SQLException {
/* 5212 */     if (!this.isBinaryEncoded) {
/* 5213 */       checkRowPos();
/* 5214 */       checkColumnBounds(columnIndex);
/*      */       
/* 5216 */       if (this.fields == null) {
/* 5217 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Query_generated_no_fields_for_ResultSet_99"), "S1002", getExceptionInterceptor());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 5223 */       int internalColumnIndex = columnIndex - 1;
/*      */       
/* 5225 */       if (this.thisRow.isNull(internalColumnIndex)) {
/* 5226 */         this.wasNullFlag = true;
/*      */         
/* 5228 */         return null;
/*      */       } 
/*      */       
/* 5231 */       this.wasNullFlag = false;
/*      */       
/* 5233 */       Field metadata = this.fields[internalColumnIndex];
/*      */       
/* 5235 */       String stringVal = null;
/*      */       
/* 5237 */       if (metadata.getMysqlType() == 16) {
/* 5238 */         if (metadata.isSingleBit()) {
/* 5239 */           byte[] value = this.thisRow.getColumnValue(internalColumnIndex);
/*      */           
/* 5241 */           if (value.length == 0) {
/* 5242 */             return String.valueOf(convertToZeroWithEmptyCheck());
/*      */           }
/*      */           
/* 5245 */           return String.valueOf(value[0]);
/*      */         } 
/*      */         
/* 5248 */         return String.valueOf(getNumericRepresentationOfSQLBitType(columnIndex));
/*      */       } 
/*      */       
/* 5251 */       String encoding = metadata.getEncoding();
/*      */       
/* 5253 */       stringVal = this.thisRow.getString(internalColumnIndex, encoding, this.connection);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 5259 */       if (metadata.getMysqlType() == 13) {
/* 5260 */         if (!this.connection.getYearIsDateType()) {
/* 5261 */           return stringVal;
/*      */         }
/*      */         
/* 5264 */         Date dt = getDateFromString(stringVal, columnIndex, null);
/*      */         
/* 5266 */         if (dt == null) {
/* 5267 */           this.wasNullFlag = true;
/*      */           
/* 5269 */           return null;
/*      */         } 
/*      */         
/* 5272 */         this.wasNullFlag = false;
/*      */         
/* 5274 */         return dt.toString();
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 5279 */       if (checkDateTypes && !this.connection.getNoDatetimeStringSync()) {
/* 5280 */         Time tm; Date dt; Timestamp ts; switch (metadata.getSQLType()) {
/*      */           case 92:
/* 5282 */             tm = getTimeFromString(stringVal, null, columnIndex, getDefaultTimeZone(), false);
/*      */             
/* 5284 */             if (tm == null) {
/* 5285 */               this.wasNullFlag = true;
/*      */               
/* 5287 */               return null;
/*      */             } 
/*      */             
/* 5290 */             this.wasNullFlag = false;
/*      */             
/* 5292 */             return tm.toString();
/*      */           
/*      */           case 91:
/* 5295 */             dt = getDateFromString(stringVal, columnIndex, null);
/*      */             
/* 5297 */             if (dt == null) {
/* 5298 */               this.wasNullFlag = true;
/*      */               
/* 5300 */               return null;
/*      */             } 
/*      */             
/* 5303 */             this.wasNullFlag = false;
/*      */             
/* 5305 */             return dt.toString();
/*      */           case 93:
/* 5307 */             ts = getTimestampFromString(columnIndex, null, stringVal, getDefaultTimeZone(), false);
/*      */             
/* 5309 */             if (ts == null) {
/* 5310 */               this.wasNullFlag = true;
/*      */               
/* 5312 */               return null;
/*      */             } 
/*      */             
/* 5315 */             this.wasNullFlag = false;
/*      */             
/* 5317 */             return ts.toString();
/*      */         } 
/*      */ 
/*      */ 
/*      */       
/*      */       } 
/* 5323 */       return stringVal;
/*      */     } 
/*      */     
/* 5326 */     return getNativeString(columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int columnIndex) throws SQLException {
/* 5341 */     return getTimeInternal(columnIndex, null, getDefaultTimeZone(), false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int columnIndex, Calendar cal) throws SQLException {
/* 5360 */     return getTimeInternal(columnIndex, cal, (cal != null) ? cal.getTimeZone() : getDefaultTimeZone(), true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(String columnName) throws SQLException {
/* 5375 */     return getTime(findColumn(columnName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(String columnName, Calendar cal) throws SQLException {
/* 5394 */     return getTime(findColumn(columnName), cal);
/*      */   }
/*      */   
/*      */   private Time getTimeFromString(String timeAsString, Calendar targetCalendar, int columnIndex, TimeZone tz, boolean rollForward) throws SQLException {
/* 5398 */     synchronized (checkClosed().getConnectionMutex()) {
/* 5399 */       int hr = 0;
/* 5400 */       int min = 0;
/* 5401 */       int sec = 0;
/*      */ 
/*      */       
/*      */       try {
/* 5405 */         if (timeAsString == null) {
/* 5406 */           this.wasNullFlag = true;
/*      */           
/* 5408 */           return null;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5418 */         timeAsString = timeAsString.trim();
/*      */ 
/*      */         
/* 5421 */         int dec = timeAsString.indexOf(".");
/* 5422 */         if (dec > -1) {
/* 5423 */           timeAsString = timeAsString.substring(0, dec);
/*      */         }
/*      */         
/* 5426 */         if (timeAsString.equals("0") || timeAsString.equals("0000-00-00") || timeAsString.equals("0000-00-00 00:00:00") || timeAsString.equals("00000000000000")) {
/*      */           
/* 5428 */           if ("convertToNull".equals(this.connection.getZeroDateTimeBehavior())) {
/* 5429 */             this.wasNullFlag = true;
/*      */             
/* 5431 */             return null;
/* 5432 */           }  if ("exception".equals(this.connection.getZeroDateTimeBehavior())) {
/* 5433 */             throw SQLError.createSQLException("Value '" + timeAsString + "' can not be represented as java.sql.Time", "S1009", getExceptionInterceptor());
/*      */           }
/*      */ 
/*      */ 
/*      */           
/* 5438 */           return fastTimeCreate(targetCalendar, 0, 0, 0);
/*      */         } 
/*      */         
/* 5441 */         this.wasNullFlag = false;
/*      */         
/* 5443 */         Field timeColField = this.fields[columnIndex - 1];
/*      */         
/* 5445 */         if (timeColField.getMysqlType() == 7)
/*      */         
/* 5447 */         { int length = timeAsString.length();
/*      */           
/* 5449 */           switch (length) {
/*      */             
/*      */             case 19:
/* 5452 */               hr = Integer.parseInt(timeAsString.substring(length - 8, length - 6));
/* 5453 */               min = Integer.parseInt(timeAsString.substring(length - 5, length - 3));
/* 5454 */               sec = Integer.parseInt(timeAsString.substring(length - 2, length));
/*      */               break;
/*      */ 
/*      */             
/*      */             case 12:
/*      */             case 14:
/* 5460 */               hr = Integer.parseInt(timeAsString.substring(length - 6, length - 4));
/* 5461 */               min = Integer.parseInt(timeAsString.substring(length - 4, length - 2));
/* 5462 */               sec = Integer.parseInt(timeAsString.substring(length - 2, length));
/*      */               break;
/*      */ 
/*      */ 
/*      */             
/*      */             case 10:
/* 5468 */               hr = Integer.parseInt(timeAsString.substring(6, 8));
/* 5469 */               min = Integer.parseInt(timeAsString.substring(8, 10));
/* 5470 */               sec = 0;
/*      */               break;
/*      */ 
/*      */ 
/*      */             
/*      */             default:
/* 5476 */               throw SQLError.createSQLException(Messages.getString("ResultSet.Timestamp_too_small_to_convert_to_Time_value_in_column__257") + columnIndex + "(" + this.fields[columnIndex - 1] + ").", "S1009", getExceptionInterceptor());
/*      */           } 
/*      */ 
/*      */           
/* 5480 */           SQLWarning precisionLost = new SQLWarning(Messages.getString("ResultSet.Precision_lost_converting_TIMESTAMP_to_Time_with_getTime()_on_column__261") + columnIndex + "(" + this.fields[columnIndex - 1] + ").");
/*      */ 
/*      */ 
/*      */           
/* 5484 */           if (this.warningChain == null) {
/* 5485 */             this.warningChain = precisionLost;
/*      */           } else {
/* 5487 */             this.warningChain.setNextWarning(precisionLost);
/*      */           }  }
/* 5489 */         else if (timeColField.getMysqlType() == 12)
/* 5490 */         { hr = Integer.parseInt(timeAsString.substring(11, 13));
/* 5491 */           min = Integer.parseInt(timeAsString.substring(14, 16));
/* 5492 */           sec = Integer.parseInt(timeAsString.substring(17, 19));
/*      */           
/* 5494 */           SQLWarning precisionLost = new SQLWarning(Messages.getString("ResultSet.Precision_lost_converting_DATETIME_to_Time_with_getTime()_on_column__264") + columnIndex + "(" + this.fields[columnIndex - 1] + ").");
/*      */ 
/*      */ 
/*      */           
/* 5498 */           if (this.warningChain == null) {
/* 5499 */             this.warningChain = precisionLost;
/*      */           } else {
/* 5501 */             this.warningChain.setNextWarning(precisionLost);
/*      */           }  }
/* 5503 */         else { if (timeColField.getMysqlType() == 10) {
/* 5504 */             return fastTimeCreate(targetCalendar, 0, 0, 0);
/*      */           }
/*      */ 
/*      */           
/* 5508 */           if (timeAsString.length() != 5 && timeAsString.length() != 8) {
/* 5509 */             throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_Time____267") + timeAsString + Messages.getString("ResultSet.___in_column__268") + columnIndex, "S1009", getExceptionInterceptor());
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 5516 */           hr = Integer.parseInt(timeAsString.substring(0, 2));
/* 5517 */           min = Integer.parseInt(timeAsString.substring(3, 5));
/* 5518 */           sec = (timeAsString.length() == 5) ? 0 : Integer.parseInt(timeAsString.substring(6)); }
/*      */ 
/*      */         
/* 5521 */         Calendar sessionCalendar = getCalendarInstanceForSessionOrNew();
/*      */         
/* 5523 */         return TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, fastTimeCreate(sessionCalendar, hr, min, sec), this.connection.getServerTimezoneTZ(), tz, rollForward);
/*      */       }
/* 5525 */       catch (RuntimeException ex) {
/* 5526 */         SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", getExceptionInterceptor());
/* 5527 */         sqlEx.initCause(ex);
/*      */         
/* 5529 */         throw sqlEx;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Time getTimeInternal(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward) throws SQLException {
/* 5549 */     checkRowPos();
/*      */     
/* 5551 */     if (this.isBinaryEncoded) {
/* 5552 */       return getNativeTime(columnIndex, targetCalendar, tz, rollForward);
/*      */     }
/*      */     
/* 5555 */     if (!this.useFastDateParsing) {
/* 5556 */       String timeAsString = getStringInternal(columnIndex, false);
/*      */       
/* 5558 */       return getTimeFromString(timeAsString, targetCalendar, columnIndex, tz, rollForward);
/*      */     } 
/*      */     
/* 5561 */     checkColumnBounds(columnIndex);
/*      */     
/* 5563 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 5565 */     if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 5566 */       this.wasNullFlag = true;
/*      */       
/* 5568 */       return null;
/*      */     } 
/*      */     
/* 5571 */     this.wasNullFlag = false;
/*      */     
/* 5573 */     return this.thisRow.getTimeFast(columnIndexMinusOne, targetCalendar, tz, rollForward, this.connection, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int columnIndex) throws SQLException {
/* 5589 */     return getTimestampInternal(columnIndex, null, getDefaultTimeZone(), false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int columnIndex, Calendar cal) throws SQLException {
/* 5609 */     return getTimestampInternal(columnIndex, cal, (cal != null) ? cal.getTimeZone() : getDefaultTimeZone(), true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(String columnName) throws SQLException {
/* 5618 */     return getTimestamp(findColumn(columnName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(String columnName, Calendar cal) throws SQLException {
/* 5638 */     return getTimestamp(findColumn(columnName), cal);
/*      */   }
/*      */ 
/*      */   
/*      */   private Timestamp getTimestampFromString(int columnIndex, Calendar targetCalendar, String timestampValue, TimeZone tz, boolean rollForward) throws SQLException {
/*      */     try {
/* 5644 */       this.wasNullFlag = false;
/*      */       
/* 5646 */       if (timestampValue == null) {
/* 5647 */         this.wasNullFlag = true;
/*      */         
/* 5649 */         return null;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 5659 */       timestampValue = timestampValue.trim();
/*      */       
/* 5661 */       int length = timestampValue.length();
/*      */       
/* 5663 */       Calendar sessionCalendar = this.connection.getUseJDBCCompliantTimezoneShift() ? this.connection.getUtcCalendar() : getCalendarInstanceForSessionOrNew();
/*      */ 
/*      */       
/* 5666 */       boolean useGmtMillis = this.connection.getUseGmtMillisForDatetimes();
/*      */       
/* 5668 */       if (length > 0 && timestampValue.charAt(0) == '0' && (timestampValue.equals("0000-00-00") || timestampValue.equals("0000-00-00 00:00:00") || timestampValue.equals("00000000000000") || timestampValue.equals("0"))) {
/*      */ 
/*      */         
/* 5671 */         if ("convertToNull".equals(this.connection.getZeroDateTimeBehavior())) {
/* 5672 */           this.wasNullFlag = true;
/*      */           
/* 5674 */           return null;
/* 5675 */         }  if ("exception".equals(this.connection.getZeroDateTimeBehavior())) {
/* 5676 */           throw SQLError.createSQLException("Value '" + timestampValue + "' can not be represented as java.sql.Timestamp", "S1009", getExceptionInterceptor());
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 5681 */         return fastTimestampCreate(null, 1, 1, 1, 0, 0, 0, 0, useGmtMillis);
/*      */       } 
/* 5683 */       if (this.fields[columnIndex - 1].getMysqlType() == 13) {
/*      */         
/* 5685 */         if (!this.useLegacyDatetimeCode) {
/* 5686 */           return TimeUtil.fastTimestampCreate(tz, Integer.parseInt(timestampValue.substring(0, 4)), 1, 1, 0, 0, 0, 0);
/*      */         }
/*      */         
/* 5689 */         return TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, fastTimestampCreate(sessionCalendar, Integer.parseInt(timestampValue.substring(0, 4)), 1, 1, 0, 0, 0, 0, useGmtMillis), this.connection.getServerTimezoneTZ(), tz, rollForward);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 5696 */       int year = 0;
/* 5697 */       int month = 0;
/* 5698 */       int day = 0;
/* 5699 */       int hour = 0;
/* 5700 */       int minutes = 0;
/* 5701 */       int seconds = 0;
/* 5702 */       int nanos = 0;
/*      */ 
/*      */       
/* 5705 */       int decimalIndex = timestampValue.indexOf(".");
/*      */       
/* 5707 */       if (decimalIndex == length - 1) {
/*      */         
/* 5709 */         length--;
/*      */       }
/* 5711 */       else if (decimalIndex != -1) {
/*      */         
/* 5713 */         if (decimalIndex + 2 <= length) {
/* 5714 */           nanos = Integer.parseInt(timestampValue.substring(decimalIndex + 1));
/*      */           
/* 5716 */           int numDigits = length - decimalIndex + 1;
/*      */           
/* 5718 */           if (numDigits < 9) {
/* 5719 */             int factor = (int)Math.pow(10.0D, (9 - numDigits));
/* 5720 */             nanos *= factor;
/*      */           } 
/*      */           
/* 5723 */           length = decimalIndex;
/*      */         } else {
/* 5725 */           throw new IllegalArgumentException();
/*      */         } 
/*      */       } 
/*      */       
/* 5729 */       switch (length) {
/*      */         case 19:
/*      */         case 20:
/*      */         case 21:
/*      */         case 22:
/*      */         case 23:
/*      */         case 24:
/*      */         case 25:
/*      */         case 26:
/* 5738 */           year = Integer.parseInt(timestampValue.substring(0, 4));
/* 5739 */           month = Integer.parseInt(timestampValue.substring(5, 7));
/* 5740 */           day = Integer.parseInt(timestampValue.substring(8, 10));
/* 5741 */           hour = Integer.parseInt(timestampValue.substring(11, 13));
/* 5742 */           minutes = Integer.parseInt(timestampValue.substring(14, 16));
/* 5743 */           seconds = Integer.parseInt(timestampValue.substring(17, 19));
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case 14:
/* 5749 */           year = Integer.parseInt(timestampValue.substring(0, 4));
/* 5750 */           month = Integer.parseInt(timestampValue.substring(4, 6));
/* 5751 */           day = Integer.parseInt(timestampValue.substring(6, 8));
/* 5752 */           hour = Integer.parseInt(timestampValue.substring(8, 10));
/* 5753 */           minutes = Integer.parseInt(timestampValue.substring(10, 12));
/* 5754 */           seconds = Integer.parseInt(timestampValue.substring(12, 14));
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case 12:
/* 5760 */           year = Integer.parseInt(timestampValue.substring(0, 2));
/*      */           
/* 5762 */           if (year <= 69) {
/* 5763 */             year += 100;
/*      */           }
/*      */           
/* 5766 */           year += 1900;
/*      */           
/* 5768 */           month = Integer.parseInt(timestampValue.substring(2, 4));
/* 5769 */           day = Integer.parseInt(timestampValue.substring(4, 6));
/* 5770 */           hour = Integer.parseInt(timestampValue.substring(6, 8));
/* 5771 */           minutes = Integer.parseInt(timestampValue.substring(8, 10));
/* 5772 */           seconds = Integer.parseInt(timestampValue.substring(10, 12));
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case 10:
/* 5778 */           if (this.fields[columnIndex - 1].getMysqlType() == 10 || timestampValue.indexOf("-") != -1) {
/* 5779 */             year = Integer.parseInt(timestampValue.substring(0, 4));
/* 5780 */             month = Integer.parseInt(timestampValue.substring(5, 7));
/* 5781 */             day = Integer.parseInt(timestampValue.substring(8, 10));
/* 5782 */             hour = 0;
/* 5783 */             minutes = 0; break;
/*      */           } 
/* 5785 */           year = Integer.parseInt(timestampValue.substring(0, 2));
/*      */           
/* 5787 */           if (year <= 69) {
/* 5788 */             year += 100;
/*      */           }
/*      */           
/* 5791 */           month = Integer.parseInt(timestampValue.substring(2, 4));
/* 5792 */           day = Integer.parseInt(timestampValue.substring(4, 6));
/* 5793 */           hour = Integer.parseInt(timestampValue.substring(6, 8));
/* 5794 */           minutes = Integer.parseInt(timestampValue.substring(8, 10));
/*      */           
/* 5796 */           year += 1900;
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 8:
/* 5803 */           if (timestampValue.indexOf(":") != -1) {
/* 5804 */             hour = Integer.parseInt(timestampValue.substring(0, 2));
/* 5805 */             minutes = Integer.parseInt(timestampValue.substring(3, 5));
/* 5806 */             seconds = Integer.parseInt(timestampValue.substring(6, 8));
/* 5807 */             year = 1970;
/* 5808 */             month = 1;
/* 5809 */             day = 1;
/*      */             
/*      */             break;
/*      */           } 
/* 5813 */           year = Integer.parseInt(timestampValue.substring(0, 4));
/* 5814 */           month = Integer.parseInt(timestampValue.substring(4, 6));
/* 5815 */           day = Integer.parseInt(timestampValue.substring(6, 8));
/*      */           
/* 5817 */           year -= 1900;
/* 5818 */           month--;
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case 6:
/* 5824 */           year = Integer.parseInt(timestampValue.substring(0, 2));
/*      */           
/* 5826 */           if (year <= 69) {
/* 5827 */             year += 100;
/*      */           }
/*      */           
/* 5830 */           year += 1900;
/*      */           
/* 5832 */           month = Integer.parseInt(timestampValue.substring(2, 4));
/* 5833 */           day = Integer.parseInt(timestampValue.substring(4, 6));
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case 4:
/* 5839 */           year = Integer.parseInt(timestampValue.substring(0, 2));
/*      */           
/* 5841 */           if (year <= 69) {
/* 5842 */             year += 100;
/*      */           }
/*      */           
/* 5845 */           year += 1900;
/*      */           
/* 5847 */           month = Integer.parseInt(timestampValue.substring(2, 4));
/*      */           
/* 5849 */           day = 1;
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case 2:
/* 5855 */           year = Integer.parseInt(timestampValue.substring(0, 2));
/*      */           
/* 5857 */           if (year <= 69) {
/* 5858 */             year += 100;
/*      */           }
/*      */           
/* 5861 */           year += 1900;
/* 5862 */           month = 1;
/* 5863 */           day = 1;
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         default:
/* 5869 */           throw new SQLException("Bad format for Timestamp '" + timestampValue + "' in column " + columnIndex + ".", "S1009");
/*      */       } 
/*      */ 
/*      */       
/* 5873 */       if (!this.useLegacyDatetimeCode) {
/* 5874 */         return TimeUtil.fastTimestampCreate(tz, year, month, day, hour, minutes, seconds, nanos);
/*      */       }
/*      */       
/* 5877 */       return TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, fastTimestampCreate(sessionCalendar, year, month, day, hour, minutes, seconds, nanos, useGmtMillis), this.connection.getServerTimezoneTZ(), tz, rollForward);
/*      */ 
/*      */     
/*      */     }
/* 5881 */     catch (RuntimeException e) {
/* 5882 */       SQLException sqlEx = SQLError.createSQLException("Cannot convert value '" + timestampValue + "' from column " + columnIndex + " to TIMESTAMP.", "S1009", getExceptionInterceptor());
/*      */       
/* 5884 */       sqlEx.initCause(e);
/*      */       
/* 5886 */       throw sqlEx;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Timestamp getTimestampInternal(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward) throws SQLException {
/* 5906 */     if (this.isBinaryEncoded) {
/* 5907 */       return getNativeTimestamp(columnIndex, targetCalendar, tz, rollForward);
/*      */     }
/*      */     
/* 5910 */     Timestamp tsVal = null;
/*      */     
/* 5912 */     if (!this.useFastDateParsing) {
/* 5913 */       String timestampValue = getStringInternal(columnIndex, false);
/*      */       
/* 5915 */       tsVal = getTimestampFromString(columnIndex, targetCalendar, timestampValue, tz, rollForward);
/*      */     } else {
/* 5917 */       checkClosed();
/* 5918 */       checkRowPos();
/* 5919 */       checkColumnBounds(columnIndex);
/*      */       
/* 5921 */       tsVal = this.thisRow.getTimestampFast(columnIndex - 1, targetCalendar, tz, rollForward, this.connection, this, this.connection.getUseGmtMillisForDatetimes(), this.connection.getUseJDBCCompliantTimezoneShift());
/*      */     } 
/*      */ 
/*      */     
/* 5925 */     if (tsVal == null) {
/* 5926 */       this.wasNullFlag = true;
/*      */     } else {
/* 5928 */       this.wasNullFlag = false;
/*      */     } 
/*      */     
/* 5931 */     return tsVal;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getType() throws SQLException {
/* 5945 */     return this.resultSetType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public InputStream getUnicodeStream(int columnIndex) throws SQLException {
/* 5968 */     if (!this.isBinaryEncoded) {
/* 5969 */       checkRowPos();
/*      */       
/* 5971 */       return getBinaryStream(columnIndex);
/*      */     } 
/*      */     
/* 5974 */     return getNativeBinaryStream(columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public InputStream getUnicodeStream(String columnName) throws SQLException {
/* 5986 */     return getUnicodeStream(findColumn(columnName));
/*      */   }
/*      */   
/*      */   public long getUpdateCount() {
/* 5990 */     return this.updateCount;
/*      */   }
/*      */   
/*      */   public long getUpdateID() {
/* 5994 */     return this.updateId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL(int colIndex) throws SQLException {
/* 6001 */     String val = getString(colIndex);
/*      */     
/* 6003 */     if (val == null) {
/* 6004 */       return null;
/*      */     }
/*      */     
/*      */     try {
/* 6008 */       return new URL(val);
/* 6009 */     } catch (MalformedURLException mfe) {
/* 6010 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Malformed_URL____104") + val + "'", "S1009", getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL(String colName) throws SQLException {
/* 6019 */     String val = getString(colName);
/*      */     
/* 6021 */     if (val == null) {
/* 6022 */       return null;
/*      */     }
/*      */     
/*      */     try {
/* 6026 */       return new URL(val);
/* 6027 */     } catch (MalformedURLException mfe) {
/* 6028 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Malformed_URL____107") + val + "'", "S1009", getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLWarning getWarnings() throws SQLException {
/* 6053 */     synchronized (checkClosed().getConnectionMutex()) {
/* 6054 */       return this.warningChain;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void insertRow() throws SQLException {
/* 6069 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAfterLast() throws SQLException {
/* 6086 */     synchronized (checkClosed().getConnectionMutex()) {
/* 6087 */       boolean b = this.rowData.isAfterLast();
/*      */       
/* 6089 */       return b;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isBeforeFirst() throws SQLException {
/* 6107 */     synchronized (checkClosed().getConnectionMutex()) {
/* 6108 */       return this.rowData.isBeforeFirst();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isFirst() throws SQLException {
/* 6125 */     synchronized (checkClosed().getConnectionMutex()) {
/* 6126 */       return this.rowData.isFirst();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isLast() throws SQLException {
/* 6144 */     synchronized (checkClosed().getConnectionMutex()) {
/* 6145 */       return this.rowData.isLast();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void issueConversionViaParsingWarning(String methodName, int columnIndex, Object value, Field fieldInfo, int[] typesWithNoParseConversion) throws SQLException {
/* 6156 */     synchronized (checkClosed().getConnectionMutex()) {
/* 6157 */       StringBuilder originalQueryBuf = new StringBuilder();
/*      */       
/* 6159 */       if (this.owningStatement != null && this.owningStatement instanceof PreparedStatement) {
/* 6160 */         originalQueryBuf.append(Messages.getString("ResultSet.CostlyConversionCreatedFromQuery"));
/* 6161 */         originalQueryBuf.append(((PreparedStatement)this.owningStatement).originalSql);
/* 6162 */         originalQueryBuf.append("\n\n");
/*      */       } else {
/* 6164 */         originalQueryBuf.append(".");
/*      */       } 
/*      */       
/* 6167 */       StringBuilder convertibleTypesBuf = new StringBuilder();
/*      */       
/* 6169 */       for (int i = 0; i < typesWithNoParseConversion.length; i++) {
/* 6170 */         convertibleTypesBuf.append(MysqlDefs.typeToName(typesWithNoParseConversion[i]));
/* 6171 */         convertibleTypesBuf.append("\n");
/*      */       } 
/*      */       
/* 6174 */       String message = Messages.getString("ResultSet.CostlyConversion", new Object[] { methodName, Integer.valueOf(columnIndex + 1), fieldInfo.getOriginalName(), fieldInfo.getOriginalTableName(), originalQueryBuf.toString(), (value != null) ? value.getClass().getName() : ResultSetMetaData.getClassNameForJavaType(fieldInfo.getSQLType(), fieldInfo.isUnsigned(), fieldInfo.getMysqlType(), (fieldInfo.isBinary() || fieldInfo.isBlob()), fieldInfo.isOpaqueBinary(), this.connection.getYearIsDateType()), MysqlDefs.typeToName(fieldInfo.getMysqlType()), convertibleTypesBuf.toString() });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6182 */       this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", (this.owningStatement == null) ? "N/A" : this.owningStatement.currentCatalog, this.connectionId, (this.owningStatement == null) ? -1 : this.owningStatement.getId(), this.resultId, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, message));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean last() throws SQLException {
/* 6203 */     synchronized (checkClosed().getConnectionMutex()) {
/*      */       
/* 6205 */       boolean b = true;
/*      */       
/* 6207 */       if (this.rowData.size() == 0) {
/* 6208 */         b = false;
/*      */       } else {
/*      */         
/* 6211 */         if (this.onInsertRow) {
/* 6212 */           this.onInsertRow = false;
/*      */         }
/*      */         
/* 6215 */         if (this.doingUpdates) {
/* 6216 */           this.doingUpdates = false;
/*      */         }
/*      */         
/* 6219 */         if (this.thisRow != null) {
/* 6220 */           this.thisRow.closeOpenStreams();
/*      */         }
/*      */         
/* 6223 */         this.rowData.beforeLast();
/* 6224 */         this.thisRow = this.rowData.next();
/*      */       } 
/*      */       
/* 6227 */       setRowPositionValidity();
/*      */       
/* 6229 */       return b;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void moveToCurrentRow() throws SQLException {
/* 6251 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void moveToInsertRow() throws SQLException {
/* 6271 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean next() throws SQLException {
/* 6289 */     synchronized (checkClosed().getConnectionMutex()) {
/*      */       boolean b;
/* 6291 */       if (this.onInsertRow) {
/* 6292 */         this.onInsertRow = false;
/*      */       }
/*      */       
/* 6295 */       if (this.doingUpdates) {
/* 6296 */         this.doingUpdates = false;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 6301 */       if (!reallyResult()) {
/* 6302 */         throw SQLError.createSQLException(Messages.getString("ResultSet.ResultSet_is_from_UPDATE._No_Data_115"), "S1000", getExceptionInterceptor());
/*      */       }
/*      */ 
/*      */       
/* 6306 */       if (this.thisRow != null) {
/* 6307 */         this.thisRow.closeOpenStreams();
/*      */       }
/*      */       
/* 6310 */       if (this.rowData.size() == 0) {
/* 6311 */         b = false;
/*      */       } else {
/* 6313 */         this.thisRow = this.rowData.next();
/*      */         
/* 6315 */         if (this.thisRow == null) {
/* 6316 */           b = false;
/*      */         } else {
/* 6318 */           clearWarnings();
/*      */           
/* 6320 */           b = true;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 6325 */       setRowPositionValidity();
/*      */       
/* 6327 */       return b;
/*      */     } 
/*      */   }
/*      */   
/*      */   private int parseIntAsDouble(int columnIndex, String val) throws NumberFormatException, SQLException {
/* 6332 */     if (val == null) {
/* 6333 */       return 0;
/*      */     }
/*      */     
/* 6336 */     double valueAsDouble = Double.parseDouble(val);
/*      */     
/* 6338 */     if (this.jdbcCompliantTruncationForReads && (
/* 6339 */       valueAsDouble < -2.147483648E9D || valueAsDouble > 2.147483647E9D)) {
/* 6340 */       throwRangeException(String.valueOf(valueAsDouble), columnIndex, 4);
/*      */     }
/*      */ 
/*      */     
/* 6344 */     return (int)valueAsDouble;
/*      */   }
/*      */   
/*      */   private int getIntWithOverflowCheck(int columnIndex) throws SQLException {
/* 6348 */     int intValue = this.thisRow.getInt(columnIndex);
/*      */     
/* 6350 */     checkForIntegerTruncation(columnIndex, null, intValue);
/*      */     
/* 6352 */     return intValue;
/*      */   }
/*      */   
/*      */   private void checkForIntegerTruncation(int columnIndex, byte[] valueAsBytes, int intValue) throws SQLException {
/* 6356 */     if (this.jdbcCompliantTruncationForReads && (
/* 6357 */       intValue == Integer.MIN_VALUE || intValue == Integer.MAX_VALUE)) {
/* 6358 */       String valueAsString = null;
/*      */       
/* 6360 */       if (valueAsBytes == null) {
/* 6361 */         valueAsString = this.thisRow.getString(columnIndex, this.fields[columnIndex].getEncoding(), this.connection);
/*      */       }
/*      */       
/* 6364 */       long valueAsLong = Long.parseLong((valueAsString == null) ? StringUtils.toString(valueAsBytes) : valueAsString);
/*      */       
/* 6366 */       if (valueAsLong < -2147483648L || valueAsLong > 2147483647L) {
/* 6367 */         throwRangeException((valueAsString == null) ? StringUtils.toString(valueAsBytes) : valueAsString, columnIndex + 1, 4);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private long parseLongAsDouble(int columnIndexZeroBased, String val) throws NumberFormatException, SQLException {
/* 6374 */     if (val == null) {
/* 6375 */       return 0L;
/*      */     }
/*      */     
/* 6378 */     double valueAsDouble = Double.parseDouble(val);
/*      */     
/* 6380 */     if (this.jdbcCompliantTruncationForReads && (
/* 6381 */       valueAsDouble < -9.223372036854776E18D || valueAsDouble > 9.223372036854776E18D)) {
/* 6382 */       throwRangeException(val, columnIndexZeroBased + 1, -5);
/*      */     }
/*      */ 
/*      */     
/* 6386 */     return (long)valueAsDouble;
/*      */   }
/*      */   
/*      */   private long getLongWithOverflowCheck(int columnIndexZeroBased, boolean doOverflowCheck) throws SQLException {
/* 6390 */     long longValue = this.thisRow.getLong(columnIndexZeroBased);
/*      */     
/* 6392 */     if (doOverflowCheck) {
/* 6393 */       checkForLongTruncation(columnIndexZeroBased, null, longValue);
/*      */     }
/*      */     
/* 6396 */     return longValue;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private long parseLongWithOverflowCheck(int columnIndexZeroBased, byte[] valueAsBytes, String valueAsString, boolean doCheck) throws NumberFormatException, SQLException {
/* 6402 */     long longValue = 0L;
/*      */     
/* 6404 */     if (valueAsBytes == null && valueAsString == null) {
/* 6405 */       return 0L;
/*      */     }
/*      */     
/* 6408 */     if (valueAsBytes != null) {
/* 6409 */       longValue = StringUtils.getLong(valueAsBytes);
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */       
/* 6418 */       valueAsString = valueAsString.trim();
/*      */       
/* 6420 */       longValue = Long.parseLong(valueAsString);
/*      */     } 
/*      */     
/* 6423 */     if (doCheck && this.jdbcCompliantTruncationForReads) {
/* 6424 */       checkForLongTruncation(columnIndexZeroBased, valueAsBytes, longValue);
/*      */     }
/*      */     
/* 6427 */     return longValue;
/*      */   }
/*      */   
/*      */   private void checkForLongTruncation(int columnIndexZeroBased, byte[] valueAsBytes, long longValue) throws SQLException {
/* 6431 */     if (longValue == Long.MIN_VALUE || longValue == Long.MAX_VALUE) {
/* 6432 */       String valueAsString = null;
/*      */       
/* 6434 */       if (valueAsBytes == null) {
/* 6435 */         valueAsString = this.thisRow.getString(columnIndexZeroBased, this.fields[columnIndexZeroBased].getEncoding(), this.connection);
/*      */       }
/*      */       
/* 6438 */       double valueAsDouble = Double.parseDouble((valueAsString == null) ? StringUtils.toString(valueAsBytes) : valueAsString);
/*      */       
/* 6440 */       if (valueAsDouble < -9.223372036854776E18D || valueAsDouble > 9.223372036854776E18D) {
/* 6441 */         throwRangeException((valueAsString == null) ? StringUtils.toString(valueAsBytes) : valueAsString, columnIndexZeroBased + 1, -5);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private short parseShortAsDouble(int columnIndex, String val) throws NumberFormatException, SQLException {
/* 6447 */     if (val == null) {
/* 6448 */       return 0;
/*      */     }
/*      */     
/* 6451 */     double valueAsDouble = Double.parseDouble(val);
/*      */     
/* 6453 */     if (this.jdbcCompliantTruncationForReads && (
/* 6454 */       valueAsDouble < -32768.0D || valueAsDouble > 32767.0D)) {
/* 6455 */       throwRangeException(String.valueOf(valueAsDouble), columnIndex, 5);
/*      */     }
/*      */ 
/*      */     
/* 6459 */     return (short)(int)valueAsDouble;
/*      */   }
/*      */ 
/*      */   
/*      */   private short parseShortWithOverflowCheck(int columnIndex, byte[] valueAsBytes, String valueAsString) throws NumberFormatException, SQLException {
/* 6464 */     short shortValue = 0;
/*      */     
/* 6466 */     if (valueAsBytes == null && valueAsString == null) {
/* 6467 */       return 0;
/*      */     }
/*      */     
/* 6470 */     if (valueAsBytes != null) {
/* 6471 */       shortValue = StringUtils.getShort(valueAsBytes);
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */       
/* 6480 */       valueAsString = valueAsString.trim();
/*      */       
/* 6482 */       shortValue = Short.parseShort(valueAsString);
/*      */     } 
/*      */     
/* 6485 */     if (this.jdbcCompliantTruncationForReads && (
/* 6486 */       shortValue == Short.MIN_VALUE || shortValue == Short.MAX_VALUE)) {
/* 6487 */       long valueAsLong = Long.parseLong((valueAsString == null) ? StringUtils.toString(valueAsBytes) : valueAsString);
/*      */       
/* 6489 */       if (valueAsLong < -32768L || valueAsLong > 32767L) {
/* 6490 */         throwRangeException((valueAsString == null) ? StringUtils.toString(valueAsBytes) : valueAsString, columnIndex, 5);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 6495 */     return shortValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean prev() throws SQLException {
/* 6518 */     synchronized (checkClosed().getConnectionMutex()) {
/*      */       
/* 6520 */       int rowIndex = this.rowData.getCurrentRowNumber();
/*      */       
/* 6522 */       if (this.thisRow != null) {
/* 6523 */         this.thisRow.closeOpenStreams();
/*      */       }
/*      */       
/* 6526 */       boolean b = true;
/*      */       
/* 6528 */       if (rowIndex - 1 >= 0) {
/* 6529 */         rowIndex--;
/* 6530 */         this.rowData.setCurrentRow(rowIndex);
/* 6531 */         this.thisRow = this.rowData.getAt(rowIndex);
/*      */         
/* 6533 */         b = true;
/* 6534 */       } else if (rowIndex - 1 == -1) {
/* 6535 */         rowIndex--;
/* 6536 */         this.rowData.setCurrentRow(rowIndex);
/* 6537 */         this.thisRow = null;
/*      */         
/* 6539 */         b = false;
/*      */       } else {
/* 6541 */         b = false;
/*      */       } 
/*      */       
/* 6544 */       setRowPositionValidity();
/*      */       
/* 6546 */       return b;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean previous() throws SQLException {
/* 6568 */     synchronized (checkClosed().getConnectionMutex()) {
/* 6569 */       if (this.onInsertRow) {
/* 6570 */         this.onInsertRow = false;
/*      */       }
/*      */       
/* 6573 */       if (this.doingUpdates) {
/* 6574 */         this.doingUpdates = false;
/*      */       }
/*      */       
/* 6577 */       return prev();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void realClose(boolean calledExplicitly) throws SQLException {
/* 6592 */     MySQLConnection locallyScopedConn = this.connection;
/*      */     
/* 6594 */     if (locallyScopedConn == null) {
/*      */       return;
/*      */     }
/*      */     
/* 6598 */     synchronized (locallyScopedConn.getConnectionMutex()) {
/*      */ 
/*      */ 
/*      */       
/* 6602 */       if (this.isClosed) {
/*      */         return;
/*      */       }
/*      */       
/*      */       try {
/* 6607 */         if (this.useUsageAdvisor)
/*      */         {
/*      */ 
/*      */           
/* 6611 */           if (!calledExplicitly) {
/* 6612 */             this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", (this.owningStatement == null) ? "N/A" : this.owningStatement.currentCatalog, this.connectionId, (this.owningStatement == null) ? -1 : this.owningStatement.getId(), this.resultId, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, Messages.getString("ResultSet.ResultSet_implicitly_closed_by_driver")));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 6618 */           if (this.rowData instanceof RowDataStatic) {
/*      */ 
/*      */ 
/*      */             
/* 6622 */             if (this.rowData.size() > this.connection.getResultSetSizeThreshold()) {
/* 6623 */               this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", (this.owningStatement == null) ? Messages.getString("ResultSet.N/A_159") : this.owningStatement.currentCatalog, this.connectionId, (this.owningStatement == null) ? -1 : this.owningStatement.getId(), this.resultId, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, Messages.getString("ResultSet.Too_Large_Result_Set", new Object[] { Integer.valueOf(this.rowData.size()), Integer.valueOf(this.connection.getResultSetSizeThreshold()) })));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 6631 */             if (!isLast() && !isAfterLast() && this.rowData.size() != 0)
/*      */             {
/* 6633 */               this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", (this.owningStatement == null) ? Messages.getString("ResultSet.N/A_159") : this.owningStatement.currentCatalog, this.connectionId, (this.owningStatement == null) ? -1 : this.owningStatement.getId(), this.resultId, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, Messages.getString("ResultSet.Possible_incomplete_traversal_of_result_set", new Object[] { Integer.valueOf(getRow()), Integer.valueOf(this.rowData.size()) })));
/*      */             }
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 6646 */           if (this.columnUsed.length > 0 && !this.rowData.wasEmpty()) {
/* 6647 */             StringBuilder buf = new StringBuilder(Messages.getString("ResultSet.The_following_columns_were_never_referenced"));
/*      */             
/* 6649 */             boolean issueWarn = false;
/*      */             
/* 6651 */             for (int i = 0; i < this.columnUsed.length; i++) {
/* 6652 */               if (!this.columnUsed[i]) {
/* 6653 */                 if (!issueWarn) {
/* 6654 */                   issueWarn = true;
/*      */                 } else {
/* 6656 */                   buf.append(", ");
/*      */                 } 
/*      */                 
/* 6659 */                 buf.append(this.fields[i].getFullName());
/*      */               } 
/*      */             } 
/*      */             
/* 6663 */             if (issueWarn) {
/* 6664 */               this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", (this.owningStatement == null) ? "N/A" : this.owningStatement.currentCatalog, this.connectionId, (this.owningStatement == null) ? -1 : this.owningStatement.getId(), 0, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, buf.toString()));
/*      */             }
/*      */           }
/*      */         
/*      */         }
/*      */       
/*      */       } finally {
/*      */         
/* 6672 */         if (this.owningStatement != null && calledExplicitly) {
/* 6673 */           this.owningStatement.removeOpenResultSet(this);
/*      */         }
/*      */         
/* 6676 */         SQLException exceptionDuringClose = null;
/*      */         
/* 6678 */         if (this.rowData != null) {
/*      */           try {
/* 6680 */             this.rowData.close();
/* 6681 */           } catch (SQLException sqlEx) {
/* 6682 */             exceptionDuringClose = sqlEx;
/*      */           } 
/*      */         }
/*      */         
/* 6686 */         if (this.statementUsedForFetchingRows != null) {
/*      */           try {
/* 6688 */             this.statementUsedForFetchingRows.realClose(true, false);
/* 6689 */           } catch (SQLException sqlEx) {
/* 6690 */             if (exceptionDuringClose != null) {
/* 6691 */               exceptionDuringClose.setNextException(sqlEx);
/*      */             } else {
/* 6693 */               exceptionDuringClose = sqlEx;
/*      */             } 
/*      */           } 
/*      */         }
/*      */         
/* 6698 */         this.rowData = null;
/* 6699 */         this.fields = null;
/* 6700 */         this.columnLabelToIndex = null;
/* 6701 */         this.fullColumnNameToIndex = null;
/* 6702 */         this.columnToIndexCache = null;
/* 6703 */         this.eventSink = null;
/* 6704 */         this.warningChain = null;
/*      */         
/* 6706 */         if (!this.retainOwningStatement) {
/* 6707 */           this.owningStatement = null;
/*      */         }
/*      */         
/* 6710 */         this.catalog = null;
/* 6711 */         this.serverInfo = null;
/* 6712 */         this.thisRow = null;
/* 6713 */         this.fastDefaultCal = null;
/* 6714 */         this.fastClientCal = null;
/* 6715 */         this.connection = null;
/*      */         
/* 6717 */         this.isClosed = true;
/*      */         
/* 6719 */         if (exceptionDuringClose != null) {
/* 6720 */           throw exceptionDuringClose;
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isClosed() throws SQLException {
/* 6730 */     return this.isClosed;
/*      */   }
/*      */   
/*      */   public boolean reallyResult() {
/* 6734 */     if (this.rowData != null) {
/* 6735 */       return true;
/*      */     }
/*      */     
/* 6738 */     return this.reallyResult;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void refreshRow() throws SQLException {
/* 6761 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean relative(int rows) throws SQLException {
/* 6787 */     synchronized (checkClosed().getConnectionMutex()) {
/*      */       
/* 6789 */       if (this.rowData.size() == 0) {
/* 6790 */         setRowPositionValidity();
/*      */         
/* 6792 */         return false;
/*      */       } 
/*      */       
/* 6795 */       if (this.thisRow != null) {
/* 6796 */         this.thisRow.closeOpenStreams();
/*      */       }
/*      */       
/* 6799 */       this.rowData.moveRowRelative(rows);
/* 6800 */       this.thisRow = this.rowData.getAt(this.rowData.getCurrentRowNumber());
/*      */       
/* 6802 */       setRowPositionValidity();
/*      */       
/* 6804 */       return (!this.rowData.isAfterLast() && !this.rowData.isBeforeFirst());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean rowDeleted() throws SQLException {
/* 6823 */     throw SQLError.createSQLFeatureNotSupportedException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean rowInserted() throws SQLException {
/* 6840 */     throw SQLError.createSQLFeatureNotSupportedException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean rowUpdated() throws SQLException {
/* 6857 */     throw SQLError.createSQLFeatureNotSupportedException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setBinaryEncoded() {
/* 6865 */     this.isBinaryEncoded = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchDirection(int direction) throws SQLException {
/* 6884 */     synchronized (checkClosed().getConnectionMutex()) {
/* 6885 */       if (direction != 1000 && direction != 1001 && direction != 1002) {
/* 6886 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Illegal_value_for_fetch_direction_64"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */ 
/*      */       
/* 6890 */       this.fetchDirection = direction;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchSize(int rows) throws SQLException {
/* 6911 */     synchronized (checkClosed().getConnectionMutex()) {
/* 6912 */       if (rows < 0) {
/* 6913 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Value_must_be_between_0_and_getMaxRows()_66"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */ 
/*      */       
/* 6917 */       this.fetchSize = rows;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFirstCharOfQuery(char c) {
/*      */     try {
/* 6930 */       synchronized (checkClosed().getConnectionMutex()) {
/* 6931 */         this.firstCharOfQuery = c;
/*      */       } 
/* 6933 */     } catch (SQLException e) {
/* 6934 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized void setNextResultSet(ResultSetInternalMethods nextResultSet) {
/* 6944 */     this.nextResultSet = nextResultSet;
/*      */   }
/*      */   
/*      */   public void setOwningStatement(StatementImpl owningStatement) {
/*      */     try {
/* 6949 */       synchronized (checkClosed().getConnectionMutex()) {
/* 6950 */         this.owningStatement = owningStatement;
/*      */       } 
/* 6952 */     } catch (SQLException e) {
/* 6953 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized void setResultSetConcurrency(int concurrencyFlag) {
/*      */     try {
/* 6965 */       synchronized (checkClosed().getConnectionMutex()) {
/* 6966 */         this.resultSetConcurrency = concurrencyFlag;
/*      */       } 
/* 6968 */     } catch (SQLException e) {
/* 6969 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized void setResultSetType(int typeFlag) {
/*      */     try {
/* 6982 */       synchronized (checkClosed().getConnectionMutex()) {
/* 6983 */         this.resultSetType = typeFlag;
/*      */       } 
/* 6985 */     } catch (SQLException e) {
/* 6986 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setServerInfo(String info) {
/*      */     try {
/* 6998 */       synchronized (checkClosed().getConnectionMutex()) {
/* 6999 */         this.serverInfo = info;
/*      */       } 
/* 7001 */     } catch (SQLException e) {
/* 7002 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   public synchronized void setStatementUsedForFetchingRows(PreparedStatement stmt) {
/*      */     try {
/* 7008 */       synchronized (checkClosed().getConnectionMutex()) {
/* 7009 */         this.statementUsedForFetchingRows = stmt;
/*      */       } 
/* 7011 */     } catch (SQLException e) {
/* 7012 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setWrapperStatement(Statement wrapperStatement) {
/*      */     try {
/* 7022 */       synchronized (checkClosed().getConnectionMutex()) {
/* 7023 */         this.wrapperStatement = wrapperStatement;
/*      */       } 
/* 7025 */     } catch (SQLException e) {
/* 7026 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void throwRangeException(String valueAsString, int columnIndex, int jdbcType) throws SQLException {
/* 7031 */     String datatype = null;
/*      */     
/* 7033 */     switch (jdbcType)
/*      */     { case -6:
/* 7035 */         datatype = "TINYINT";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 7062 */         throw SQLError.createSQLException("'" + valueAsString + "' in column '" + columnIndex + "' is outside valid range for the datatype " + datatype + ".", "22003", getExceptionInterceptor());case 5: datatype = "SMALLINT"; throw SQLError.createSQLException("'" + valueAsString + "' in column '" + columnIndex + "' is outside valid range for the datatype " + datatype + ".", "22003", getExceptionInterceptor());case 4: datatype = "INTEGER"; throw SQLError.createSQLException("'" + valueAsString + "' in column '" + columnIndex + "' is outside valid range for the datatype " + datatype + ".", "22003", getExceptionInterceptor());case -5: datatype = "BIGINT"; throw SQLError.createSQLException("'" + valueAsString + "' in column '" + columnIndex + "' is outside valid range for the datatype " + datatype + ".", "22003", getExceptionInterceptor());case 7: datatype = "REAL"; throw SQLError.createSQLException("'" + valueAsString + "' in column '" + columnIndex + "' is outside valid range for the datatype " + datatype + ".", "22003", getExceptionInterceptor());case 6: datatype = "FLOAT"; throw SQLError.createSQLException("'" + valueAsString + "' in column '" + columnIndex + "' is outside valid range for the datatype " + datatype + ".", "22003", getExceptionInterceptor());case 8: datatype = "DOUBLE"; throw SQLError.createSQLException("'" + valueAsString + "' in column '" + columnIndex + "' is outside valid range for the datatype " + datatype + ".", "22003", getExceptionInterceptor());case 3: datatype = "DECIMAL"; throw SQLError.createSQLException("'" + valueAsString + "' in column '" + columnIndex + "' is outside valid range for the datatype " + datatype + ".", "22003", getExceptionInterceptor()); }  datatype = " (JDBC type '" + jdbcType + "')"; throw SQLError.createSQLException("'" + valueAsString + "' in column '" + columnIndex + "' is outside valid range for the datatype " + datatype + ".", "22003", getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 7068 */     if (this.reallyResult) {
/* 7069 */       return super.toString();
/*      */     }
/*      */     
/* 7072 */     return "Result set representing update count of " + this.updateCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateArray(int arg0, Array arg1) throws SQLException {
/* 7079 */     throw SQLError.createSQLFeatureNotSupportedException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateArray(String arg0, Array arg1) throws SQLException {
/* 7086 */     throw SQLError.createSQLFeatureNotSupportedException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateAsciiStream(int columnIndex, InputStream x, int length) throws SQLException {
/* 7108 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateAsciiStream(String columnName, InputStream x, int length) throws SQLException {
/* 7129 */     updateAsciiStream(findColumn(columnName), x, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBigDecimal(int columnIndex, BigDecimal x) throws SQLException {
/* 7148 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBigDecimal(String columnName, BigDecimal x) throws SQLException {
/* 7166 */     updateBigDecimal(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBinaryStream(int columnIndex, InputStream x, int length) throws SQLException {
/* 7188 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBinaryStream(String columnName, InputStream x, int length) throws SQLException {
/* 7209 */     updateBinaryStream(findColumn(columnName), x, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBlob(int arg0, Blob arg1) throws SQLException {
/* 7216 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBlob(String arg0, Blob arg1) throws SQLException {
/* 7223 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBoolean(int columnIndex, boolean x) throws SQLException {
/* 7242 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBoolean(String columnName, boolean x) throws SQLException {
/* 7260 */     updateBoolean(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateByte(int columnIndex, byte x) throws SQLException {
/* 7279 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateByte(String columnName, byte x) throws SQLException {
/* 7297 */     updateByte(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBytes(int columnIndex, byte[] x) throws SQLException {
/* 7316 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBytes(String columnName, byte[] x) throws SQLException {
/* 7334 */     updateBytes(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateCharacterStream(int columnIndex, Reader x, int length) throws SQLException {
/* 7356 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateCharacterStream(String columnName, Reader reader, int length) throws SQLException {
/* 7377 */     updateCharacterStream(findColumn(columnName), reader, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateClob(int arg0, Clob arg1) throws SQLException {
/* 7384 */     throw SQLError.createSQLFeatureNotSupportedException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateClob(String columnName, Clob clob) throws SQLException {
/* 7391 */     updateClob(findColumn(columnName), clob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateDate(int columnIndex, Date x) throws SQLException {
/* 7410 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateDate(String columnName, Date x) throws SQLException {
/* 7428 */     updateDate(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateDouble(int columnIndex, double x) throws SQLException {
/* 7447 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateDouble(String columnName, double x) throws SQLException {
/* 7465 */     updateDouble(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateFloat(int columnIndex, float x) throws SQLException {
/* 7484 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateFloat(String columnName, float x) throws SQLException {
/* 7502 */     updateFloat(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateInt(int columnIndex, int x) throws SQLException {
/* 7521 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateInt(String columnName, int x) throws SQLException {
/* 7539 */     updateInt(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateLong(int columnIndex, long x) throws SQLException {
/* 7558 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateLong(String columnName, long x) throws SQLException {
/* 7576 */     updateLong(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateNull(int columnIndex) throws SQLException {
/* 7593 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateNull(String columnName) throws SQLException {
/* 7609 */     updateNull(findColumn(columnName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateObject(int columnIndex, Object x) throws SQLException {
/* 7628 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateObject(int columnIndex, Object x, int scale) throws SQLException {
/* 7651 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateObject(String columnName, Object x) throws SQLException {
/* 7669 */     updateObject(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateObject(String columnName, Object x, int scale) throws SQLException {
/* 7691 */     updateObject(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateRef(int arg0, Ref arg1) throws SQLException {
/* 7698 */     throw SQLError.createSQLFeatureNotSupportedException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateRef(String arg0, Ref arg1) throws SQLException {
/* 7705 */     throw SQLError.createSQLFeatureNotSupportedException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateRow() throws SQLException {
/* 7718 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateShort(int columnIndex, short x) throws SQLException {
/* 7737 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateShort(String columnName, short x) throws SQLException {
/* 7755 */     updateShort(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateString(int columnIndex, String x) throws SQLException {
/* 7774 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateString(String columnName, String x) throws SQLException {
/* 7792 */     updateString(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTime(int columnIndex, Time x) throws SQLException {
/* 7811 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTime(String columnName, Time x) throws SQLException {
/* 7829 */     updateTime(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTimestamp(int columnIndex, Timestamp x) throws SQLException {
/* 7848 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTimestamp(String columnName, Timestamp x) throws SQLException {
/* 7866 */     updateTimestamp(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean wasNull() throws SQLException {
/* 7881 */     return this.wasNullFlag;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected Calendar getGmtCalendar() {
/* 7887 */     if (this.gmtCalendar == null) {
/* 7888 */       this.gmtCalendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
/*      */     }
/*      */     
/* 7891 */     return this.gmtCalendar;
/*      */   }
/*      */   
/*      */   protected ExceptionInterceptor getExceptionInterceptor() {
/* 7895 */     return this.exceptionInterceptor;
/*      */   }
/*      */ }


/* Location:              C:\Users\neons\Desktop\JacobAloSchedulingApp\build\classes\!\lib\mysql-connector-java-5.1.47.jar!\com\mysql\jdbc\ResultSetImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */
package com.mysql.jdbc;

import java.sql.SQLException;
import java.util.Map;

class LicenseConfiguration {
  static void checkLicenseType(Map<String, String> serverVariables) throws SQLException {}
}


/* Location:              C:\Users\neons\Desktop\JacobAloSchedulingApp\build\classes\!\lib\mysql-connector-java-5.1.47.jar!\com\mysql\jdbc\LicenseConfiguration.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */
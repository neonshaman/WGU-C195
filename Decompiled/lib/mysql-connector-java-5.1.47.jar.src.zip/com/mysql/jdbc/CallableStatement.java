/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.Clob;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.Date;
/*      */ import java.sql.ParameterMetaData;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CallableStatement
/*      */   extends PreparedStatement
/*      */   implements CallableStatement
/*      */ {
/*      */   protected static final Constructor<?> JDBC_4_CSTMT_2_ARGS_CTOR;
/*      */   protected static final Constructor<?> JDBC_4_CSTMT_4_ARGS_CTOR;
/*      */   private static final int NOT_OUTPUT_PARAMETER_INDICATOR = -2147483648;
/*      */   private static final String PARAMETER_NAMESPACE_PREFIX = "@com_mysql_jdbc_outparam_";
/*      */   
/*      */   static {
/*   59 */     if (Util.isJdbc4()) {
/*      */       try {
/*   61 */         String jdbc4ClassName = Util.isJdbc42() ? "com.mysql.jdbc.JDBC42CallableStatement" : "com.mysql.jdbc.JDBC4CallableStatement";
/*   62 */         JDBC_4_CSTMT_2_ARGS_CTOR = Class.forName(jdbc4ClassName).getConstructor(new Class[] { MySQLConnection.class, CallableStatementParamInfo.class });
/*      */         
/*   64 */         JDBC_4_CSTMT_4_ARGS_CTOR = Class.forName(jdbc4ClassName).getConstructor(new Class[] { MySQLConnection.class, String.class, String.class, boolean.class });
/*      */       }
/*   66 */       catch (SecurityException e) {
/*   67 */         throw new RuntimeException(e);
/*   68 */       } catch (NoSuchMethodException e) {
/*   69 */         throw new RuntimeException(e);
/*   70 */       } catch (ClassNotFoundException e) {
/*   71 */         throw new RuntimeException(e);
/*      */       } 
/*      */     } else {
/*   74 */       JDBC_4_CSTMT_4_ARGS_CTOR = null;
/*   75 */       JDBC_4_CSTMT_2_ARGS_CTOR = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected static class CallableStatementParam
/*      */   {
/*      */     int desiredJdbcType;
/*      */     
/*      */     int index;
/*      */     
/*      */     int inOutModifier;
/*      */     
/*      */     boolean isIn;
/*      */     
/*      */     boolean isOut;
/*      */     
/*      */     int jdbcType;
/*      */     
/*      */     short nullability;
/*      */     
/*      */     String paramName;
/*      */     
/*      */     int precision;
/*      */     
/*      */     int scale;
/*      */     String typeName;
/*      */     
/*      */     CallableStatementParam(String name, int idx, boolean in, boolean out, int jdbcType, String typeName, int precision, int scale, short nullability, int inOutModifier) {
/*  104 */       this.paramName = name;
/*  105 */       this.isIn = in;
/*  106 */       this.isOut = out;
/*  107 */       this.index = idx;
/*      */       
/*  109 */       this.jdbcType = jdbcType;
/*  110 */       this.typeName = typeName;
/*  111 */       this.precision = precision;
/*  112 */       this.scale = scale;
/*  113 */       this.nullability = nullability;
/*  114 */       this.inOutModifier = inOutModifier;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected Object clone() throws CloneNotSupportedException {
/*  124 */       return super.clone();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected class CallableStatementParamInfo
/*      */     implements ParameterMetaData
/*      */   {
/*      */     String catalogInUse;
/*      */ 
/*      */     
/*      */     boolean isFunctionCall;
/*      */ 
/*      */     
/*      */     String nativeSql;
/*      */ 
/*      */     
/*      */     int numParameters;
/*      */ 
/*      */     
/*      */     List<CallableStatement.CallableStatementParam> parameterList;
/*      */ 
/*      */     
/*      */     Map<String, CallableStatement.CallableStatementParam> parameterMap;
/*      */ 
/*      */     
/*      */     boolean isReadOnlySafeProcedure = false;
/*      */ 
/*      */     
/*      */     boolean isReadOnlySafeChecked = false;
/*      */ 
/*      */ 
/*      */     
/*      */     CallableStatementParamInfo(CallableStatementParamInfo fullParamInfo) {
/*  160 */       this.nativeSql = CallableStatement.this.originalSql;
/*  161 */       this.catalogInUse = CallableStatement.this.currentCatalog;
/*  162 */       this.isFunctionCall = fullParamInfo.isFunctionCall;
/*      */       
/*  164 */       int[] localParameterMap = CallableStatement.this.placeholderToParameterIndexMap;
/*  165 */       int parameterMapLength = localParameterMap.length;
/*      */       
/*  167 */       this.isReadOnlySafeProcedure = fullParamInfo.isReadOnlySafeProcedure;
/*  168 */       this.isReadOnlySafeChecked = fullParamInfo.isReadOnlySafeChecked;
/*  169 */       this.parameterList = new ArrayList<CallableStatement.CallableStatementParam>(fullParamInfo.numParameters);
/*  170 */       this.parameterMap = new HashMap<String, CallableStatement.CallableStatementParam>(fullParamInfo.numParameters);
/*      */       
/*  172 */       if (this.isFunctionCall)
/*      */       {
/*  174 */         this.parameterList.add(fullParamInfo.parameterList.get(0));
/*      */       }
/*      */       
/*  177 */       int offset = this.isFunctionCall ? 1 : 0;
/*      */       
/*  179 */       for (int i = 0; i < parameterMapLength; i++) {
/*  180 */         if (localParameterMap[i] != 0) {
/*  181 */           CallableStatement.CallableStatementParam param = fullParamInfo.parameterList.get(localParameterMap[i] + offset);
/*      */           
/*  183 */           this.parameterList.add(param);
/*  184 */           this.parameterMap.put(param.paramName, param);
/*      */         } 
/*      */       } 
/*      */       
/*  188 */       this.numParameters = this.parameterList.size();
/*      */     }
/*      */ 
/*      */     
/*      */     CallableStatementParamInfo(ResultSet paramTypesRs) throws SQLException {
/*  193 */       boolean hadRows = paramTypesRs.last();
/*      */       
/*  195 */       this.nativeSql = CallableStatement.this.originalSql;
/*  196 */       this.catalogInUse = CallableStatement.this.currentCatalog;
/*  197 */       this.isFunctionCall = CallableStatement.this.callingStoredFunction;
/*      */       
/*  199 */       if (hadRows) {
/*  200 */         this.numParameters = paramTypesRs.getRow();
/*      */         
/*  202 */         this.parameterList = new ArrayList<CallableStatement.CallableStatementParam>(this.numParameters);
/*  203 */         this.parameterMap = new HashMap<String, CallableStatement.CallableStatementParam>(this.numParameters);
/*      */         
/*  205 */         paramTypesRs.beforeFirst();
/*      */         
/*  207 */         addParametersFromDBMD(paramTypesRs);
/*      */       } else {
/*  209 */         this.numParameters = 0;
/*      */       } 
/*      */       
/*  212 */       if (this.isFunctionCall) {
/*  213 */         this.numParameters++;
/*      */       }
/*      */     }
/*      */     
/*      */     private void addParametersFromDBMD(ResultSet paramTypesRs) throws SQLException {
/*  218 */       int i = 0;
/*      */       
/*  220 */       while (paramTypesRs.next()) {
/*  221 */         int inOutModifier; String paramName = paramTypesRs.getString(4);
/*      */         
/*  223 */         switch (paramTypesRs.getInt(5)) {
/*      */           case 1:
/*  225 */             inOutModifier = 1;
/*      */             break;
/*      */           case 2:
/*  228 */             inOutModifier = 2;
/*      */             break;
/*      */           case 4:
/*      */           case 5:
/*  232 */             inOutModifier = 4;
/*      */             break;
/*      */           default:
/*  235 */             inOutModifier = 0;
/*      */             break;
/*      */         } 
/*  238 */         boolean isOutParameter = false;
/*  239 */         boolean isInParameter = false;
/*      */         
/*  241 */         if (i == 0 && this.isFunctionCall) {
/*  242 */           isOutParameter = true;
/*  243 */           isInParameter = false;
/*  244 */         } else if (inOutModifier == 2) {
/*  245 */           isOutParameter = true;
/*  246 */           isInParameter = true;
/*  247 */         } else if (inOutModifier == 1) {
/*  248 */           isOutParameter = false;
/*  249 */           isInParameter = true;
/*  250 */         } else if (inOutModifier == 4) {
/*  251 */           isOutParameter = true;
/*  252 */           isInParameter = false;
/*      */         } 
/*      */         
/*  255 */         int jdbcType = paramTypesRs.getInt(6);
/*  256 */         String typeName = paramTypesRs.getString(7);
/*  257 */         int precision = paramTypesRs.getInt(8);
/*  258 */         int scale = paramTypesRs.getInt(10);
/*  259 */         short nullability = paramTypesRs.getShort(12);
/*      */         
/*  261 */         CallableStatement.CallableStatementParam paramInfoToAdd = new CallableStatement.CallableStatementParam(paramName, i++, isInParameter, isOutParameter, jdbcType, typeName, precision, scale, nullability, inOutModifier);
/*      */ 
/*      */         
/*  264 */         this.parameterList.add(paramInfoToAdd);
/*  265 */         this.parameterMap.put(paramName, paramInfoToAdd);
/*      */       } 
/*      */     }
/*      */     
/*      */     protected void checkBounds(int paramIndex) throws SQLException {
/*  270 */       int localParamIndex = paramIndex - 1;
/*      */       
/*  272 */       if (paramIndex < 0 || localParamIndex >= this.numParameters) {
/*  273 */         throw SQLError.createSQLException(Messages.getString("CallableStatement.11") + paramIndex + Messages.getString("CallableStatement.12") + this.numParameters + Messages.getString("CallableStatement.13"), "S1009", CallableStatement.this.getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected Object clone() throws CloneNotSupportedException {
/*  285 */       return super.clone();
/*      */     }
/*      */     
/*      */     CallableStatement.CallableStatementParam getParameter(int index) {
/*  289 */       return this.parameterList.get(index);
/*      */     }
/*      */     
/*      */     CallableStatement.CallableStatementParam getParameter(String name) {
/*  293 */       return this.parameterMap.get(name);
/*      */     }
/*      */     
/*      */     public String getParameterClassName(int arg0) throws SQLException {
/*  297 */       String mysqlTypeName = getParameterTypeName(arg0);
/*      */       
/*  299 */       boolean isBinaryOrBlob = (StringUtils.indexOfIgnoreCase(mysqlTypeName, "BLOB") != -1 || StringUtils.indexOfIgnoreCase(mysqlTypeName, "BINARY") != -1);
/*      */       
/*  301 */       boolean isUnsigned = (StringUtils.indexOfIgnoreCase(mysqlTypeName, "UNSIGNED") != -1);
/*      */       
/*  303 */       int mysqlTypeIfKnown = 0;
/*      */       
/*  305 */       if (StringUtils.startsWithIgnoreCase(mysqlTypeName, "MEDIUMINT")) {
/*  306 */         mysqlTypeIfKnown = 9;
/*      */       }
/*      */       
/*  309 */       return ResultSetMetaData.getClassNameForJavaType(getParameterType(arg0), isUnsigned, mysqlTypeIfKnown, isBinaryOrBlob, false, CallableStatement.this.connection.getYearIsDateType());
/*      */     }
/*      */ 
/*      */     
/*      */     public int getParameterCount() throws SQLException {
/*  314 */       if (this.parameterList == null) {
/*  315 */         return 0;
/*      */       }
/*      */       
/*  318 */       return this.parameterList.size();
/*      */     }
/*      */     
/*      */     public int getParameterMode(int arg0) throws SQLException {
/*  322 */       checkBounds(arg0);
/*      */       
/*  324 */       return (getParameter(arg0 - 1)).inOutModifier;
/*      */     }
/*      */     
/*      */     public int getParameterType(int arg0) throws SQLException {
/*  328 */       checkBounds(arg0);
/*      */       
/*  330 */       return (getParameter(arg0 - 1)).jdbcType;
/*      */     }
/*      */     
/*      */     public String getParameterTypeName(int arg0) throws SQLException {
/*  334 */       checkBounds(arg0);
/*      */       
/*  336 */       return (getParameter(arg0 - 1)).typeName;
/*      */     }
/*      */     
/*      */     public int getPrecision(int arg0) throws SQLException {
/*  340 */       checkBounds(arg0);
/*      */       
/*  342 */       return (getParameter(arg0 - 1)).precision;
/*      */     }
/*      */     
/*      */     public int getScale(int arg0) throws SQLException {
/*  346 */       checkBounds(arg0);
/*      */       
/*  348 */       return (getParameter(arg0 - 1)).scale;
/*      */     }
/*      */     
/*      */     public int isNullable(int arg0) throws SQLException {
/*  352 */       checkBounds(arg0);
/*      */       
/*  354 */       return (getParameter(arg0 - 1)).nullability;
/*      */     }
/*      */     
/*      */     public boolean isSigned(int arg0) throws SQLException {
/*  358 */       checkBounds(arg0);
/*      */       
/*  360 */       return false;
/*      */     }
/*      */     
/*      */     Iterator<CallableStatement.CallableStatementParam> iterator() {
/*  364 */       return this.parameterList.iterator();
/*      */     }
/*      */     
/*      */     int numberOfParameters() {
/*  368 */       return this.numParameters;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isWrapperFor(Class<?> iface) throws SQLException {
/*  375 */       CallableStatement.this.checkClosed();
/*      */ 
/*      */       
/*  378 */       return iface.isInstance(this);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public <T> T unwrap(Class<T> iface) throws SQLException {
/*      */       try {
/*  387 */         return iface.cast(this);
/*  388 */       } catch (ClassCastException cce) {
/*  389 */         throw SQLError.createSQLException("Unable to unwrap to " + iface.toString(), "S1009", CallableStatement.this.getExceptionInterceptor());
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String mangleParameterName(String origParameterName) {
/*  400 */     if (origParameterName == null) {
/*  401 */       return null;
/*      */     }
/*      */     
/*  404 */     int offset = 0;
/*      */     
/*  406 */     if (origParameterName.length() > 0 && origParameterName.charAt(0) == '@') {
/*  407 */       offset = 1;
/*      */     }
/*      */     
/*  410 */     StringBuilder paramNameBuf = new StringBuilder("@com_mysql_jdbc_outparam_".length() + origParameterName.length());
/*  411 */     paramNameBuf.append("@com_mysql_jdbc_outparam_");
/*  412 */     paramNameBuf.append(origParameterName.substring(offset));
/*      */     
/*  414 */     return paramNameBuf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean callingStoredFunction = false;
/*      */ 
/*      */   
/*      */   private ResultSetInternalMethods functionReturnValueResults;
/*      */ 
/*      */   
/*      */   private boolean hasOutputParams = false;
/*      */ 
/*      */   
/*      */   private ResultSetInternalMethods outputParameterResults;
/*      */ 
/*      */   
/*      */   protected boolean outputParamWasNull = false;
/*      */ 
/*      */   
/*      */   private int[] parameterIndexToRsIndex;
/*      */ 
/*      */   
/*      */   protected CallableStatementParamInfo paramInfo;
/*      */ 
/*      */   
/*      */   private CallableStatementParam returnValueParam;
/*      */ 
/*      */   
/*      */   private int[] placeholderToParameterIndexMap;
/*      */ 
/*      */   
/*      */   public CallableStatement(MySQLConnection conn, CallableStatementParamInfo paramInfo) throws SQLException {
/*  447 */     super(conn, paramInfo.nativeSql, paramInfo.catalogInUse);
/*      */     
/*  449 */     this.paramInfo = paramInfo;
/*  450 */     this.callingStoredFunction = this.paramInfo.isFunctionCall;
/*      */     
/*  452 */     if (this.callingStoredFunction) {
/*  453 */       this.parameterCount++;
/*      */     }
/*      */     
/*  456 */     this.retrieveGeneratedKeys = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static CallableStatement getInstance(MySQLConnection conn, String sql, String catalog, boolean isFunctionCall) throws SQLException {
/*  467 */     if (!Util.isJdbc4()) {
/*  468 */       return new CallableStatement(conn, sql, catalog, isFunctionCall);
/*      */     }
/*      */     
/*  471 */     return (CallableStatement)Util.handleNewInstance(JDBC_4_CSTMT_4_ARGS_CTOR, new Object[] { conn, sql, catalog, Boolean.valueOf(isFunctionCall) }, conn.getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static CallableStatement getInstance(MySQLConnection conn, CallableStatementParamInfo paramInfo) throws SQLException {
/*  483 */     if (!Util.isJdbc4()) {
/*  484 */       return new CallableStatement(conn, paramInfo);
/*      */     }
/*      */     
/*  487 */     return (CallableStatement)Util.handleNewInstance(JDBC_4_CSTMT_2_ARGS_CTOR, new Object[] { conn, paramInfo }, conn.getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void generateParameterMap() throws SQLException {
/*  494 */     synchronized (checkClosed().getConnectionMutex()) {
/*  495 */       if (this.paramInfo == null) {
/*      */         return;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  501 */       int parameterCountFromMetaData = this.paramInfo.getParameterCount();
/*      */ 
/*      */ 
/*      */       
/*  505 */       if (this.callingStoredFunction) {
/*  506 */         parameterCountFromMetaData--;
/*      */       }
/*      */       
/*  509 */       if (this.paramInfo != null && this.parameterCount != parameterCountFromMetaData) {
/*  510 */         this.placeholderToParameterIndexMap = new int[this.parameterCount];
/*      */         
/*  512 */         int startPos = this.callingStoredFunction ? StringUtils.indexOfIgnoreCase(this.originalSql, "SELECT") : StringUtils.indexOfIgnoreCase(this.originalSql, "CALL");
/*      */ 
/*      */         
/*  515 */         if (startPos != -1) {
/*  516 */           int parenOpenPos = this.originalSql.indexOf('(', startPos + 4);
/*      */           
/*  518 */           if (parenOpenPos != -1) {
/*  519 */             int parenClosePos = StringUtils.indexOfIgnoreCase(parenOpenPos, this.originalSql, ")", "'", "'", StringUtils.SEARCH_MODE__ALL);
/*      */             
/*  521 */             if (parenClosePos != -1) {
/*  522 */               List<?> parsedParameters = StringUtils.split(this.originalSql.substring(parenOpenPos + 1, parenClosePos), ",", "'\"", "'\"", true);
/*      */               
/*  524 */               int numParsedParameters = parsedParameters.size();
/*      */ 
/*      */ 
/*      */               
/*  528 */               if (numParsedParameters != this.parameterCount);
/*      */ 
/*      */ 
/*      */               
/*  532 */               int placeholderCount = 0;
/*      */               
/*  534 */               for (int i = 0; i < numParsedParameters; i++) {
/*  535 */                 if (((String)parsedParameters.get(i)).equals("?")) {
/*  536 */                   this.placeholderToParameterIndexMap[placeholderCount++] = i;
/*      */                 }
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CallableStatement(MySQLConnection conn, String sql, String catalog, boolean isFunctionCall) throws SQLException {
/*  560 */     super(conn, sql, catalog);
/*      */     
/*  562 */     this.callingStoredFunction = isFunctionCall;
/*      */     
/*  564 */     if (!this.callingStoredFunction) {
/*  565 */       if (!StringUtils.startsWithIgnoreCaseAndWs(sql, "CALL")) {
/*      */         
/*  567 */         fakeParameterTypes(false);
/*      */       } else {
/*  569 */         determineParameterTypes();
/*      */       } 
/*      */       
/*  572 */       generateParameterMap();
/*      */     } else {
/*  574 */       determineParameterTypes();
/*  575 */       generateParameterMap();
/*      */       
/*  577 */       this.parameterCount++;
/*      */     } 
/*      */     
/*  580 */     this.retrieveGeneratedKeys = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBatch() throws SQLException {
/*  590 */     setOutParams();
/*      */     
/*  592 */     super.addBatch();
/*      */   }
/*      */ 
/*      */   
/*      */   private CallableStatementParam checkIsOutputParam(int paramIndex) throws SQLException {
/*  597 */     synchronized (checkClosed().getConnectionMutex()) {
/*  598 */       if (this.callingStoredFunction) {
/*  599 */         if (paramIndex == 1) {
/*      */           
/*  601 */           if (this.returnValueParam == null) {
/*  602 */             this.returnValueParam = new CallableStatementParam("", 0, false, true, 12, "VARCHAR", 0, 0, (short)2, 5);
/*      */           }
/*      */ 
/*      */           
/*  606 */           return this.returnValueParam;
/*      */         } 
/*      */ 
/*      */         
/*  610 */         paramIndex--;
/*      */       } 
/*      */       
/*  613 */       checkParameterIndexBounds(paramIndex);
/*      */       
/*  615 */       int localParamIndex = paramIndex - 1;
/*      */       
/*  617 */       if (this.placeholderToParameterIndexMap != null) {
/*  618 */         localParamIndex = this.placeholderToParameterIndexMap[localParamIndex];
/*      */       }
/*      */       
/*  621 */       CallableStatementParam paramDescriptor = this.paramInfo.getParameter(localParamIndex);
/*      */ 
/*      */ 
/*      */       
/*  625 */       if (this.connection.getNoAccessToProcedureBodies()) {
/*  626 */         paramDescriptor.isOut = true;
/*  627 */         paramDescriptor.isIn = true;
/*  628 */         paramDescriptor.inOutModifier = 2;
/*  629 */       } else if (!paramDescriptor.isOut) {
/*  630 */         throw SQLError.createSQLException(Messages.getString("CallableStatement.9") + paramIndex + Messages.getString("CallableStatement.10"), "S1009", getExceptionInterceptor());
/*      */       } 
/*      */ 
/*      */       
/*  634 */       this.hasOutputParams = true;
/*      */       
/*  636 */       return paramDescriptor;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkParameterIndexBounds(int paramIndex) throws SQLException {
/*  646 */     synchronized (checkClosed().getConnectionMutex()) {
/*  647 */       this.paramInfo.checkBounds(paramIndex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkStreamability() throws SQLException {
/*  659 */     if (this.hasOutputParams && createStreamingResultSet()) {
/*  660 */       throw SQLError.createSQLException(Messages.getString("CallableStatement.14"), "S1C00", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void clearParameters() throws SQLException {
/*  666 */     synchronized (checkClosed().getConnectionMutex()) {
/*  667 */       super.clearParameters();
/*      */       
/*      */       try {
/*  670 */         if (this.outputParameterResults != null) {
/*  671 */           this.outputParameterResults.close();
/*      */         }
/*      */       } finally {
/*  674 */         this.outputParameterResults = null;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fakeParameterTypes(boolean isReallyProcedure) throws SQLException {
/*  687 */     synchronized (checkClosed().getConnectionMutex()) {
/*  688 */       Field[] fields = new Field[13];
/*      */       
/*  690 */       fields[0] = new Field("", "PROCEDURE_CAT", 1, 0);
/*  691 */       fields[1] = new Field("", "PROCEDURE_SCHEM", 1, 0);
/*  692 */       fields[2] = new Field("", "PROCEDURE_NAME", 1, 0);
/*  693 */       fields[3] = new Field("", "COLUMN_NAME", 1, 0);
/*  694 */       fields[4] = new Field("", "COLUMN_TYPE", 1, 0);
/*  695 */       fields[5] = new Field("", "DATA_TYPE", 5, 0);
/*  696 */       fields[6] = new Field("", "TYPE_NAME", 1, 0);
/*  697 */       fields[7] = new Field("", "PRECISION", 4, 0);
/*  698 */       fields[8] = new Field("", "LENGTH", 4, 0);
/*  699 */       fields[9] = new Field("", "SCALE", 5, 0);
/*  700 */       fields[10] = new Field("", "RADIX", 5, 0);
/*  701 */       fields[11] = new Field("", "NULLABLE", 5, 0);
/*  702 */       fields[12] = new Field("", "REMARKS", 1, 0);
/*      */       
/*  704 */       String procName = isReallyProcedure ? extractProcedureName() : null;
/*      */       
/*  706 */       byte[] procNameAsBytes = null;
/*      */       
/*      */       try {
/*  709 */         procNameAsBytes = (procName == null) ? null : StringUtils.getBytes(procName, "UTF-8");
/*  710 */       } catch (UnsupportedEncodingException ueEx) {
/*  711 */         procNameAsBytes = StringUtils.s2b(procName, this.connection);
/*      */       } 
/*      */       
/*  714 */       ArrayList<ResultSetRow> resultRows = new ArrayList<ResultSetRow>();
/*      */       
/*  716 */       for (int i = 0; i < this.parameterCount; i++) {
/*  717 */         byte[][] row = new byte[13][];
/*  718 */         row[0] = null;
/*  719 */         row[1] = null;
/*  720 */         row[2] = procNameAsBytes;
/*  721 */         row[3] = StringUtils.s2b(String.valueOf(i), this.connection);
/*      */         
/*  723 */         row[4] = StringUtils.s2b(String.valueOf(1), this.connection);
/*      */         
/*  725 */         row[5] = StringUtils.s2b(String.valueOf(12), this.connection);
/*  726 */         row[6] = StringUtils.s2b("VARCHAR", this.connection);
/*  727 */         row[7] = StringUtils.s2b(Integer.toString(65535), this.connection);
/*  728 */         row[8] = StringUtils.s2b(Integer.toString(65535), this.connection);
/*  729 */         row[9] = StringUtils.s2b(Integer.toString(0), this.connection);
/*  730 */         row[10] = StringUtils.s2b(Integer.toString(10), this.connection);
/*      */         
/*  732 */         row[11] = StringUtils.s2b(Integer.toString(2), this.connection);
/*      */         
/*  734 */         row[12] = null;
/*      */         
/*  736 */         resultRows.add(new ByteArrayRow(row, getExceptionInterceptor()));
/*      */       } 
/*      */       
/*  739 */       ResultSet paramTypesRs = DatabaseMetaData.buildResultSet(fields, resultRows, this.connection);
/*      */       
/*  741 */       convertGetProcedureColumnsToInternalDescriptors(paramTypesRs);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void determineParameterTypes() throws SQLException {
/*  746 */     synchronized (checkClosed().getConnectionMutex()) {
/*  747 */       ResultSet paramTypesRs = null;
/*      */ 
/*      */       
/*      */       try {
/*  751 */         String procName = extractProcedureName();
/*  752 */         String quotedId = "";
/*      */         try {
/*  754 */           quotedId = this.connection.supportsQuotedIdentifiers() ? this.connection.getMetaData().getIdentifierQuoteString() : "";
/*  755 */         } catch (SQLException sqlEx) {
/*      */ 
/*      */           
/*  758 */           AssertionFailedException.shouldNotHappen(sqlEx);
/*      */         } 
/*      */         
/*  761 */         List<?> parseList = StringUtils.splitDBdotName(procName, "", quotedId, this.connection.isNoBackslashEscapesSet());
/*  762 */         String tmpCatalog = "";
/*      */         
/*  764 */         if (parseList.size() == 2) {
/*  765 */           tmpCatalog = (String)parseList.get(0);
/*  766 */           procName = (String)parseList.get(1);
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  771 */         DatabaseMetaData dbmd = this.connection.getMetaData();
/*      */         
/*  773 */         boolean useCatalog = false;
/*      */         
/*  775 */         if (tmpCatalog.length() <= 0) {
/*  776 */           useCatalog = true;
/*      */         }
/*      */         
/*  779 */         paramTypesRs = dbmd.getProcedureColumns((this.connection.versionMeetsMinimum(5, 0, 2) && useCatalog) ? this.currentCatalog : tmpCatalog, null, procName, "%");
/*      */ 
/*      */         
/*  782 */         boolean hasResults = false;
/*      */         try {
/*  784 */           if (paramTypesRs.next()) {
/*  785 */             paramTypesRs.previous();
/*  786 */             hasResults = true;
/*      */           } 
/*  788 */         } catch (Exception e) {}
/*      */ 
/*      */         
/*  791 */         if (hasResults) {
/*  792 */           convertGetProcedureColumnsToInternalDescriptors(paramTypesRs);
/*      */         } else {
/*  794 */           fakeParameterTypes(true);
/*      */         } 
/*      */       } finally {
/*  797 */         SQLException sqlExRethrow = null;
/*      */         
/*  799 */         if (paramTypesRs != null) {
/*      */           try {
/*  801 */             paramTypesRs.close();
/*  802 */           } catch (SQLException sqlEx) {
/*  803 */             sqlExRethrow = sqlEx;
/*      */           } 
/*      */           
/*  806 */           paramTypesRs = null;
/*      */         } 
/*      */         
/*  809 */         if (sqlExRethrow != null) {
/*  810 */           throw sqlExRethrow;
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void convertGetProcedureColumnsToInternalDescriptors(ResultSet paramTypesRs) throws SQLException {
/*  817 */     synchronized (checkClosed().getConnectionMutex()) {
/*  818 */       this.paramInfo = new CallableStatementParamInfo(paramTypesRs);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean execute() throws SQLException {
/*  829 */     synchronized (checkClosed().getConnectionMutex()) {
/*  830 */       boolean returnVal = false;
/*      */       
/*  832 */       checkStreamability();
/*      */       
/*  834 */       setInOutParamsOnServer();
/*  835 */       setOutParams();
/*      */       
/*  837 */       returnVal = super.execute();
/*      */       
/*  839 */       if (this.callingStoredFunction) {
/*  840 */         this.functionReturnValueResults = this.results;
/*  841 */         this.functionReturnValueResults.next();
/*  842 */         this.results = null;
/*      */       } 
/*      */       
/*  845 */       retrieveOutParams();
/*      */       
/*  847 */       if (!this.callingStoredFunction) {
/*  848 */         return returnVal;
/*      */       }
/*      */ 
/*      */       
/*  852 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet executeQuery() throws SQLException {
/*  863 */     synchronized (checkClosed().getConnectionMutex()) {
/*      */       
/*  865 */       checkStreamability();
/*      */       
/*  867 */       ResultSet execResults = null;
/*      */       
/*  869 */       setInOutParamsOnServer();
/*  870 */       setOutParams();
/*      */       
/*  872 */       execResults = super.executeQuery();
/*      */       
/*  874 */       retrieveOutParams();
/*      */       
/*  876 */       return execResults;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int executeUpdate() throws SQLException {
/*  887 */     return Util.truncateAndConvertToInt(executeLargeUpdate());
/*      */   }
/*      */   
/*      */   private String extractProcedureName() throws SQLException {
/*  891 */     String sanitizedSql = StringUtils.stripComments(this.originalSql, "`\"'", "`\"'", true, false, true, true);
/*      */ 
/*      */     
/*  894 */     int endCallIndex = StringUtils.indexOfIgnoreCase(sanitizedSql, "CALL ");
/*  895 */     int offset = 5;
/*      */     
/*  897 */     if (endCallIndex == -1) {
/*  898 */       endCallIndex = StringUtils.indexOfIgnoreCase(sanitizedSql, "SELECT ");
/*  899 */       offset = 7;
/*      */     } 
/*      */     
/*  902 */     if (endCallIndex != -1) {
/*  903 */       StringBuilder nameBuf = new StringBuilder();
/*      */       
/*  905 */       String trimmedStatement = sanitizedSql.substring(endCallIndex + offset).trim();
/*      */       
/*  907 */       int statementLength = trimmedStatement.length();
/*      */       
/*  909 */       for (int i = 0; i < statementLength; i++) {
/*  910 */         char c = trimmedStatement.charAt(i);
/*      */         
/*  912 */         if (Character.isWhitespace(c) || c == '(' || c == '?') {
/*      */           break;
/*      */         }
/*  915 */         nameBuf.append(c);
/*      */       } 
/*      */ 
/*      */       
/*  919 */       return nameBuf.toString();
/*      */     } 
/*      */     
/*  922 */     throw SQLError.createSQLException(Messages.getString("CallableStatement.1"), "S1000", getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String fixParameterName(String paramNameIn) throws SQLException {
/*  937 */     synchronized (checkClosed().getConnectionMutex()) {
/*      */       
/*  939 */       if ((paramNameIn == null || paramNameIn.length() == 0) && !hasParametersView()) {
/*  940 */         throw SQLError.createSQLException((Messages.getString("CallableStatement.0") + paramNameIn == null) ? Messages.getString("CallableStatement.15") : Messages.getString("CallableStatement.16"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  945 */       if (paramNameIn == null && hasParametersView()) {
/*  946 */         paramNameIn = "nullpn";
/*      */       }
/*      */       
/*  949 */       if (this.connection.getNoAccessToProcedureBodies()) {
/*  950 */         throw SQLError.createSQLException("No access to parameters by name when connection has been configured not to access procedure bodies", "S1009", getExceptionInterceptor());
/*      */       }
/*      */ 
/*      */       
/*  954 */       return mangleParameterName(paramNameIn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Array getArray(int i) throws SQLException {
/*  962 */     synchronized (checkClosed().getConnectionMutex()) {
/*  963 */       ResultSetInternalMethods rs = getOutputParameters(i);
/*      */       
/*  965 */       Array retValue = rs.getArray(mapOutputParameterIndexToRsIndex(i));
/*      */       
/*  967 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/*  969 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Array getArray(String parameterName) throws SQLException {
/*  977 */     synchronized (checkClosed().getConnectionMutex()) {
/*  978 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/*  980 */       Array retValue = rs.getArray(fixParameterName(parameterName));
/*      */       
/*  982 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/*  984 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int parameterIndex) throws SQLException {
/*  992 */     synchronized (checkClosed().getConnectionMutex()) {
/*  993 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/*  995 */       BigDecimal retValue = rs.getBigDecimal(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/*  997 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/*  999 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public BigDecimal getBigDecimal(int parameterIndex, int scale) throws SQLException {
/* 1014 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1015 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1017 */       BigDecimal retValue = rs.getBigDecimal(mapOutputParameterIndexToRsIndex(parameterIndex), scale);
/*      */       
/* 1019 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1021 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(String parameterName) throws SQLException {
/* 1029 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1030 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1032 */       BigDecimal retValue = rs.getBigDecimal(fixParameterName(parameterName));
/*      */       
/* 1034 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1036 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Blob getBlob(int parameterIndex) throws SQLException {
/* 1044 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1045 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1047 */       Blob retValue = rs.getBlob(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1049 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1051 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Blob getBlob(String parameterName) throws SQLException {
/* 1059 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1060 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1062 */       Blob retValue = rs.getBlob(fixParameterName(parameterName));
/*      */       
/* 1064 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1066 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(int parameterIndex) throws SQLException {
/* 1074 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1075 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1077 */       boolean retValue = rs.getBoolean(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1079 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1081 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(String parameterName) throws SQLException {
/* 1089 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1090 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1092 */       boolean retValue = rs.getBoolean(fixParameterName(parameterName));
/*      */       
/* 1094 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1096 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(int parameterIndex) throws SQLException {
/* 1104 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1105 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1107 */       byte retValue = rs.getByte(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1109 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1111 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(String parameterName) throws SQLException {
/* 1119 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1120 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1122 */       byte retValue = rs.getByte(fixParameterName(parameterName));
/*      */       
/* 1124 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1126 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytes(int parameterIndex) throws SQLException {
/* 1134 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1135 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1137 */       byte[] retValue = rs.getBytes(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1139 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1141 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytes(String parameterName) throws SQLException {
/* 1149 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1150 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1152 */       byte[] retValue = rs.getBytes(fixParameterName(parameterName));
/*      */       
/* 1154 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1156 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Clob getClob(int parameterIndex) throws SQLException {
/* 1164 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1165 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1167 */       Clob retValue = rs.getClob(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1169 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1171 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Clob getClob(String parameterName) throws SQLException {
/* 1179 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1180 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1182 */       Clob retValue = rs.getClob(fixParameterName(parameterName));
/*      */       
/* 1184 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1186 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int parameterIndex) throws SQLException {
/* 1194 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1195 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1197 */       Date retValue = rs.getDate(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1199 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1201 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int parameterIndex, Calendar cal) throws SQLException {
/* 1209 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1210 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1212 */       Date retValue = rs.getDate(mapOutputParameterIndexToRsIndex(parameterIndex), cal);
/*      */       
/* 1214 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1216 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(String parameterName) throws SQLException {
/* 1224 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1225 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1227 */       Date retValue = rs.getDate(fixParameterName(parameterName));
/*      */       
/* 1229 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1231 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(String parameterName, Calendar cal) throws SQLException {
/* 1239 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1240 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1242 */       Date retValue = rs.getDate(fixParameterName(parameterName), cal);
/*      */       
/* 1244 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1246 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(int parameterIndex) throws SQLException {
/* 1254 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1255 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1257 */       double retValue = rs.getDouble(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1259 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1261 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(String parameterName) throws SQLException {
/* 1269 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1270 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1272 */       double retValue = rs.getDouble(fixParameterName(parameterName));
/*      */       
/* 1274 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1276 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(int parameterIndex) throws SQLException {
/* 1284 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1285 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1287 */       float retValue = rs.getFloat(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1289 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1291 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(String parameterName) throws SQLException {
/* 1299 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1300 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1302 */       float retValue = rs.getFloat(fixParameterName(parameterName));
/*      */       
/* 1304 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1306 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(int parameterIndex) throws SQLException {
/* 1314 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1315 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1317 */       int retValue = rs.getInt(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1319 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1321 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(String parameterName) throws SQLException {
/* 1329 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1330 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1332 */       int retValue = rs.getInt(fixParameterName(parameterName));
/*      */       
/* 1334 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1336 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(int parameterIndex) throws SQLException {
/* 1344 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1345 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1347 */       long retValue = rs.getLong(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1349 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1351 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(String parameterName) throws SQLException {
/* 1359 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1360 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1362 */       long retValue = rs.getLong(fixParameterName(parameterName));
/*      */       
/* 1364 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1366 */       return retValue;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected int getNamedParamIndex(String paramName, boolean forOut) throws SQLException {
/* 1371 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1372 */       if (this.connection.getNoAccessToProcedureBodies()) {
/* 1373 */         throw SQLError.createSQLException("No access to parameters by name when connection has been configured not to access procedure bodies", "S1009", getExceptionInterceptor());
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1378 */       if (paramName == null || paramName.length() == 0) {
/* 1379 */         throw SQLError.createSQLException(Messages.getString("CallableStatement.2"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */       CallableStatementParam namedParamInfo;
/* 1383 */       if (this.paramInfo == null || (namedParamInfo = this.paramInfo.getParameter(paramName)) == null) {
/* 1384 */         throw SQLError.createSQLException(Messages.getString("CallableStatement.3") + paramName + Messages.getString("CallableStatement.4"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */ 
/*      */       
/* 1388 */       if (forOut && !namedParamInfo.isOut) {
/* 1389 */         throw SQLError.createSQLException(Messages.getString("CallableStatement.5") + paramName + Messages.getString("CallableStatement.6"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */ 
/*      */       
/* 1393 */       if (this.placeholderToParameterIndexMap == null) {
/* 1394 */         return namedParamInfo.index + 1;
/*      */       }
/*      */       
/* 1397 */       for (int i = 0; i < this.placeholderToParameterIndexMap.length; i++) {
/* 1398 */         if (this.placeholderToParameterIndexMap[i] == namedParamInfo.index) {
/* 1399 */           return i + 1;
/*      */         }
/*      */       } 
/*      */       
/* 1403 */       throw SQLError.createSQLException("Can't find local placeholder mapping for parameter named \"" + paramName + "\".", "S1009", getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int parameterIndex) throws SQLException {
/* 1412 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1413 */       CallableStatementParam paramDescriptor = checkIsOutputParam(parameterIndex);
/*      */       
/* 1415 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1417 */       Object retVal = rs.getObjectStoredProc(mapOutputParameterIndexToRsIndex(parameterIndex), paramDescriptor.desiredJdbcType);
/*      */       
/* 1419 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1421 */       return retVal;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int parameterIndex, Map<String, Class<?>> map) throws SQLException {
/* 1429 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1430 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1432 */       Object retVal = rs.getObject(mapOutputParameterIndexToRsIndex(parameterIndex), map);
/*      */       
/* 1434 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1436 */       return retVal;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(String parameterName) throws SQLException {
/* 1444 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1445 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1447 */       Object retValue = rs.getObject(fixParameterName(parameterName));
/*      */       
/* 1449 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1451 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(String parameterName, Map<String, Class<?>> map) throws SQLException {
/* 1459 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1460 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1462 */       Object retValue = rs.getObject(fixParameterName(parameterName), map);
/*      */       
/* 1464 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1466 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> T getObject(int parameterIndex, Class<T> type) throws SQLException {
/* 1472 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1473 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */ 
/*      */       
/* 1476 */       T retVal = ((ResultSetImpl)rs).getObject(mapOutputParameterIndexToRsIndex(parameterIndex), type);
/*      */       
/* 1478 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1480 */       return retVal;
/*      */     } 
/*      */   }
/*      */   
/*      */   public <T> T getObject(String parameterName, Class<T> type) throws SQLException {
/* 1485 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1486 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1488 */       T retValue = ((ResultSetImpl)rs).getObject(fixParameterName(parameterName), type);
/*      */       
/* 1490 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1492 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ResultSetInternalMethods getOutputParameters(int paramIndex) throws SQLException {
/* 1507 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1508 */       this.outputParamWasNull = false;
/*      */       
/* 1510 */       if (paramIndex == 1 && this.callingStoredFunction && this.returnValueParam != null) {
/* 1511 */         return this.functionReturnValueResults;
/*      */       }
/*      */       
/* 1514 */       if (this.outputParameterResults == null) {
/* 1515 */         if (this.paramInfo.numberOfParameters() == 0) {
/* 1516 */           throw SQLError.createSQLException(Messages.getString("CallableStatement.7"), "S1009", getExceptionInterceptor());
/*      */         }
/*      */         
/* 1519 */         throw SQLError.createSQLException(Messages.getString("CallableStatement.8"), "S1000", getExceptionInterceptor());
/*      */       } 
/*      */       
/* 1522 */       return this.outputParameterResults;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public ParameterMetaData getParameterMetaData() throws SQLException {
/* 1528 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1529 */       if (this.placeholderToParameterIndexMap == null) {
/* 1530 */         return this.paramInfo;
/*      */       }
/*      */       
/* 1533 */       return new CallableStatementParamInfo(this.paramInfo);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Ref getRef(int parameterIndex) throws SQLException {
/* 1541 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1542 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1544 */       Ref retValue = rs.getRef(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1546 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1548 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Ref getRef(String parameterName) throws SQLException {
/* 1556 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1557 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1559 */       Ref retValue = rs.getRef(fixParameterName(parameterName));
/*      */       
/* 1561 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1563 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(int parameterIndex) throws SQLException {
/* 1571 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1572 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1574 */       short retValue = rs.getShort(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1576 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1578 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(String parameterName) throws SQLException {
/* 1586 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1587 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1589 */       short retValue = rs.getShort(fixParameterName(parameterName));
/*      */       
/* 1591 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1593 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(int parameterIndex) throws SQLException {
/* 1601 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1602 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1604 */       String retValue = rs.getString(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1606 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1608 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(String parameterName) throws SQLException {
/* 1616 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1617 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1619 */       String retValue = rs.getString(fixParameterName(parameterName));
/*      */       
/* 1621 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1623 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int parameterIndex) throws SQLException {
/* 1631 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1632 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1634 */       Time retValue = rs.getTime(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1636 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1638 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int parameterIndex, Calendar cal) throws SQLException {
/* 1646 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1647 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1649 */       Time retValue = rs.getTime(mapOutputParameterIndexToRsIndex(parameterIndex), cal);
/*      */       
/* 1651 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1653 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(String parameterName) throws SQLException {
/* 1661 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1662 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1664 */       Time retValue = rs.getTime(fixParameterName(parameterName));
/*      */       
/* 1666 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1668 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(String parameterName, Calendar cal) throws SQLException {
/* 1676 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1677 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1679 */       Time retValue = rs.getTime(fixParameterName(parameterName), cal);
/*      */       
/* 1681 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1683 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int parameterIndex) throws SQLException {
/* 1691 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1692 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1694 */       Timestamp retValue = rs.getTimestamp(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1696 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1698 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int parameterIndex, Calendar cal) throws SQLException {
/* 1706 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1707 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1709 */       Timestamp retValue = rs.getTimestamp(mapOutputParameterIndexToRsIndex(parameterIndex), cal);
/*      */       
/* 1711 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1713 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(String parameterName) throws SQLException {
/* 1721 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1722 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1724 */       Timestamp retValue = rs.getTimestamp(fixParameterName(parameterName));
/*      */       
/* 1726 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1728 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(String parameterName, Calendar cal) throws SQLException {
/* 1736 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1737 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1739 */       Timestamp retValue = rs.getTimestamp(fixParameterName(parameterName), cal);
/*      */       
/* 1741 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1743 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL(int parameterIndex) throws SQLException {
/* 1751 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1752 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1754 */       URL retValue = rs.getURL(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1756 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1758 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL(String parameterName) throws SQLException {
/* 1766 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1767 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1769 */       URL retValue = rs.getURL(fixParameterName(parameterName));
/*      */       
/* 1771 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1773 */       return retValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected int mapOutputParameterIndexToRsIndex(int paramIndex) throws SQLException {
/* 1779 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1780 */       if (this.returnValueParam != null && paramIndex == 1) {
/* 1781 */         return 1;
/*      */       }
/*      */       
/* 1784 */       checkParameterIndexBounds(paramIndex);
/*      */       
/* 1786 */       int localParamIndex = paramIndex - 1;
/*      */       
/* 1788 */       if (this.placeholderToParameterIndexMap != null) {
/* 1789 */         localParamIndex = this.placeholderToParameterIndexMap[localParamIndex];
/*      */       }
/*      */       
/* 1792 */       int rsIndex = this.parameterIndexToRsIndex[localParamIndex];
/*      */       
/* 1794 */       if (rsIndex == Integer.MIN_VALUE) {
/* 1795 */         throw SQLError.createSQLException(Messages.getString("CallableStatement.21") + paramIndex + Messages.getString("CallableStatement.22"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */ 
/*      */       
/* 1799 */       return rsIndex + 1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int parameterIndex, int sqlType) throws SQLException {
/* 1807 */     CallableStatementParam paramDescriptor = checkIsOutputParam(parameterIndex);
/* 1808 */     paramDescriptor.desiredJdbcType = sqlType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int parameterIndex, int sqlType, int scale) throws SQLException {
/* 1815 */     registerOutParameter(parameterIndex, sqlType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int parameterIndex, int sqlType, String typeName) throws SQLException {
/* 1822 */     checkIsOutputParam(parameterIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String parameterName, int sqlType) throws SQLException {
/* 1829 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1830 */       registerOutParameter(getNamedParamIndex(parameterName, true), sqlType);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String parameterName, int sqlType, int scale) throws SQLException {
/* 1838 */     registerOutParameter(getNamedParamIndex(parameterName, true), sqlType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String parameterName, int sqlType, String typeName) throws SQLException {
/* 1845 */     registerOutParameter(getNamedParamIndex(parameterName, true), sqlType, typeName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void retrieveOutParams() throws SQLException {
/* 1855 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1856 */       int numParameters = this.paramInfo.numberOfParameters();
/*      */       
/* 1858 */       this.parameterIndexToRsIndex = new int[numParameters];
/*      */       
/* 1860 */       for (int i = 0; i < numParameters; i++) {
/* 1861 */         this.parameterIndexToRsIndex[i] = Integer.MIN_VALUE;
/*      */       }
/*      */       
/* 1864 */       int localParamIndex = 0;
/*      */       
/* 1866 */       if (numParameters > 0) {
/* 1867 */         StringBuilder outParameterQuery = new StringBuilder("SELECT ");
/*      */         
/* 1869 */         boolean firstParam = true;
/* 1870 */         boolean hadOutputParams = false;
/*      */         
/* 1872 */         for (Iterator<CallableStatementParam> paramIter = this.paramInfo.iterator(); paramIter.hasNext(); ) {
/* 1873 */           CallableStatementParam retrParamInfo = paramIter.next();
/*      */           
/* 1875 */           if (retrParamInfo.isOut) {
/* 1876 */             hadOutputParams = true;
/*      */             
/* 1878 */             this.parameterIndexToRsIndex[retrParamInfo.index] = localParamIndex++;
/*      */             
/* 1880 */             if (retrParamInfo.paramName == null && hasParametersView()) {
/* 1881 */               retrParamInfo.paramName = "nullnp" + retrParamInfo.index;
/*      */             }
/*      */             
/* 1884 */             String outParameterName = mangleParameterName(retrParamInfo.paramName);
/*      */             
/* 1886 */             if (!firstParam) {
/* 1887 */               outParameterQuery.append(",");
/*      */             } else {
/* 1889 */               firstParam = false;
/*      */             } 
/*      */             
/* 1892 */             if (!outParameterName.startsWith("@")) {
/* 1893 */               outParameterQuery.append('@');
/*      */             }
/*      */             
/* 1896 */             outParameterQuery.append(outParameterName);
/*      */           } 
/*      */         } 
/*      */         
/* 1900 */         if (hadOutputParams) {
/*      */           
/* 1902 */           Statement outParameterStmt = null;
/* 1903 */           ResultSet outParamRs = null;
/*      */           
/*      */           try {
/* 1906 */             outParameterStmt = this.connection.createStatement();
/* 1907 */             outParamRs = outParameterStmt.executeQuery(outParameterQuery.toString());
/* 1908 */             this.outputParameterResults = ((ResultSetInternalMethods)outParamRs).copy();
/*      */             
/* 1910 */             if (!this.outputParameterResults.next()) {
/* 1911 */               this.outputParameterResults.close();
/* 1912 */               this.outputParameterResults = null;
/*      */             } 
/*      */           } finally {
/* 1915 */             if (outParameterStmt != null) {
/* 1916 */               outParameterStmt.close();
/*      */             }
/*      */           } 
/*      */         } else {
/* 1920 */           this.outputParameterResults = null;
/*      */         } 
/*      */       } else {
/* 1923 */         this.outputParameterResults = null;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStream(String parameterName, InputStream x, int length) throws SQLException {
/* 1932 */     setAsciiStream(getNamedParamIndex(parameterName, false), x, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBigDecimal(String parameterName, BigDecimal x) throws SQLException {
/* 1939 */     setBigDecimal(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStream(String parameterName, InputStream x, int length) throws SQLException {
/* 1946 */     setBinaryStream(getNamedParamIndex(parameterName, false), x, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBoolean(String parameterName, boolean x) throws SQLException {
/* 1953 */     setBoolean(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setByte(String parameterName, byte x) throws SQLException {
/* 1960 */     setByte(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytes(String parameterName, byte[] x) throws SQLException {
/* 1967 */     setBytes(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStream(String parameterName, Reader reader, int length) throws SQLException {
/* 1974 */     setCharacterStream(getNamedParamIndex(parameterName, false), reader, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(String parameterName, Date x) throws SQLException {
/* 1981 */     setDate(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(String parameterName, Date x, Calendar cal) throws SQLException {
/* 1988 */     setDate(getNamedParamIndex(parameterName, false), x, cal);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDouble(String parameterName, double x) throws SQLException {
/* 1995 */     setDouble(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFloat(String parameterName, float x) throws SQLException {
/* 2002 */     setFloat(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */   private void setInOutParamsOnServer() throws SQLException {
/* 2006 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2007 */       if (this.paramInfo.numParameters > 0) {
/* 2008 */         for (Iterator<CallableStatementParam> paramIter = this.paramInfo.iterator(); paramIter.hasNext(); ) {
/*      */           
/* 2010 */           CallableStatementParam inParamInfo = paramIter.next();
/*      */ 
/*      */           
/* 2013 */           if (inParamInfo.isOut && inParamInfo.isIn) {
/* 2014 */             if (inParamInfo.paramName == null && hasParametersView()) {
/* 2015 */               inParamInfo.paramName = "nullnp" + inParamInfo.index;
/*      */             }
/*      */             
/* 2018 */             String inOutParameterName = mangleParameterName(inParamInfo.paramName);
/* 2019 */             StringBuilder queryBuf = new StringBuilder(4 + inOutParameterName.length() + 1 + 1);
/* 2020 */             queryBuf.append("SET ");
/* 2021 */             queryBuf.append(inOutParameterName);
/* 2022 */             queryBuf.append("=?");
/*      */             
/* 2024 */             PreparedStatement setPstmt = null;
/*      */             
/*      */             try {
/* 2027 */               setPstmt = ((Wrapper)this.connection.clientPrepareStatement(queryBuf.toString())).<PreparedStatement>unwrap(PreparedStatement.class);
/*      */               
/* 2029 */               if (this.isNull[inParamInfo.index]) {
/* 2030 */                 setPstmt.setBytesNoEscapeNoQuotes(1, "NULL".getBytes());
/*      */               } else {
/*      */                 
/* 2033 */                 byte[] parameterAsBytes = getBytesRepresentation(inParamInfo.index);
/*      */                 
/* 2035 */                 if (parameterAsBytes != null)
/* 2036 */                 { if (parameterAsBytes.length > 8) { if (parameterAsBytes[0] == 95) { if (parameterAsBytes[1] == 98) { if (parameterAsBytes[2] == 105) { if (parameterAsBytes[3] == 110) { if (parameterAsBytes[4] == 97) { if (parameterAsBytes[5] == 114) { if (parameterAsBytes[6] == 121) { if (parameterAsBytes[7] == 39)
/*      */                                   
/*      */                                   { 
/* 2039 */                                     setPstmt.setBytesNoEscapeNoQuotes(1, parameterAsBytes); } else { continue; }  } else { continue; }  } else { continue; }  } else { continue; }  } else { continue; }  } else { continue; }
/*      */                          }
/* 2041 */                       else { int sqlType = inParamInfo.desiredJdbcType;
/*      */                         
/* 2043 */                         switch (sqlType)
/*      */                         { case -7:
/*      */                           case -4:
/*      */                           case -3:
/*      */                           case -2:
/*      */                           case 2000:
/*      */                           case 2004:
/* 2050 */                             setPstmt.setBytes(1, parameterAsBytes);
/*      */                             break;
/*      */                           
/*      */                           default:
/* 2054 */                             setPstmt.setBytesNoEscape(1, parameterAsBytes); break; }  }  } else { continue; }
/*      */                      }
/*      */                   else { continue; }
/*      */                    }
/* 2058 */                 else { setPstmt.setNull(1, 0); }
/*      */               
/*      */               } 
/*      */               
/* 2062 */               setPstmt.executeUpdate();
/*      */             } finally {
/* 2064 */               if (setPstmt != null) {
/* 2065 */                 setPstmt.close();
/*      */               }
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInt(String parameterName, int x) throws SQLException {
/* 2078 */     setInt(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLong(String parameterName, long x) throws SQLException {
/* 2085 */     setLong(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNull(String parameterName, int sqlType) throws SQLException {
/* 2092 */     setNull(getNamedParamIndex(parameterName, false), sqlType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNull(String parameterName, int sqlType, String typeName) throws SQLException {
/* 2099 */     setNull(getNamedParamIndex(parameterName, false), sqlType, typeName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(String parameterName, Object x) throws SQLException {
/* 2106 */     setObject(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(String parameterName, Object x, int targetSqlType) throws SQLException {
/* 2113 */     setObject(getNamedParamIndex(parameterName, false), x, targetSqlType);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(String parameterName, Object x, int targetSqlType, int scale) throws SQLException {}
/*      */ 
/*      */ 
/*      */   
/*      */   private void setOutParams() throws SQLException {
/* 2123 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2124 */       if (this.paramInfo.numParameters > 0) {
/* 2125 */         for (Iterator<CallableStatementParam> paramIter = this.paramInfo.iterator(); paramIter.hasNext(); ) {
/* 2126 */           CallableStatementParam outParamInfo = paramIter.next();
/*      */           
/* 2128 */           if (!this.callingStoredFunction && outParamInfo.isOut) {
/*      */             
/* 2130 */             if (outParamInfo.paramName == null && hasParametersView()) {
/* 2131 */               outParamInfo.paramName = "nullnp" + outParamInfo.index;
/*      */             }
/*      */             
/* 2134 */             String outParameterName = mangleParameterName(outParamInfo.paramName);
/*      */             
/* 2136 */             int outParamIndex = 0;
/*      */             
/* 2138 */             if (this.placeholderToParameterIndexMap == null) {
/* 2139 */               outParamIndex = outParamInfo.index + 1;
/*      */             } else {
/*      */               
/* 2142 */               boolean found = false;
/*      */               
/* 2144 */               for (int i = 0; i < this.placeholderToParameterIndexMap.length; i++) {
/* 2145 */                 if (this.placeholderToParameterIndexMap[i] == outParamInfo.index) {
/* 2146 */                   outParamIndex = i + 1;
/* 2147 */                   found = true;
/*      */                   
/*      */                   break;
/*      */                 } 
/*      */               } 
/* 2152 */               if (!found) {
/* 2153 */                 throw SQLError.createSQLException(Messages.getString("CallableStatement.21") + outParamInfo.paramName + Messages.getString("CallableStatement.22"), "S1009", getExceptionInterceptor());
/*      */               }
/*      */             } 
/*      */ 
/*      */ 
/*      */             
/* 2159 */             setBytesNoEscapeNoQuotes(outParamIndex, StringUtils.getBytes(outParameterName, this.charConverter, this.charEncoding, this.connection.getServerCharset(), this.connection.parserKnowsUnicode(), getExceptionInterceptor()));
/*      */           } 
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setShort(String parameterName, short x) throws SQLException {
/* 2171 */     setShort(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setString(String parameterName, String x) throws SQLException {
/* 2178 */     setString(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(String parameterName, Time x) throws SQLException {
/* 2185 */     setTime(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(String parameterName, Time x, Calendar cal) throws SQLException {
/* 2192 */     setTime(getNamedParamIndex(parameterName, false), x, cal);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(String parameterName, Timestamp x) throws SQLException {
/* 2199 */     setTimestamp(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(String parameterName, Timestamp x, Calendar cal) throws SQLException {
/* 2206 */     setTimestamp(getNamedParamIndex(parameterName, false), x, cal);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setURL(String parameterName, URL val) throws SQLException {
/* 2213 */     setURL(getNamedParamIndex(parameterName, false), val);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean wasNull() throws SQLException {
/* 2220 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2221 */       return this.outputParamWasNull;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public int[] executeBatch() throws SQLException {
/* 2227 */     return Util.truncateAndConvertToInt(executeLargeBatch());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getParameterIndexOffset() {
/* 2233 */     if (this.callingStoredFunction) {
/* 2234 */       return -1;
/*      */     }
/*      */     
/* 2237 */     return super.getParameterIndexOffset();
/*      */   }
/*      */   
/*      */   public void setAsciiStream(String parameterName, InputStream x) throws SQLException {
/* 2241 */     setAsciiStream(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setAsciiStream(String parameterName, InputStream x, long length) throws SQLException {
/* 2246 */     setAsciiStream(getNamedParamIndex(parameterName, false), x, length);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBinaryStream(String parameterName, InputStream x) throws SQLException {
/* 2251 */     setBinaryStream(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBinaryStream(String parameterName, InputStream x, long length) throws SQLException {
/* 2256 */     setBinaryStream(getNamedParamIndex(parameterName, false), x, length);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBlob(String parameterName, Blob x) throws SQLException {
/* 2261 */     setBlob(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBlob(String parameterName, InputStream inputStream) throws SQLException {
/* 2266 */     setBlob(getNamedParamIndex(parameterName, false), inputStream);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBlob(String parameterName, InputStream inputStream, long length) throws SQLException {
/* 2271 */     setBlob(getNamedParamIndex(parameterName, false), inputStream, length);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setCharacterStream(String parameterName, Reader reader) throws SQLException {
/* 2276 */     setCharacterStream(getNamedParamIndex(parameterName, false), reader);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setCharacterStream(String parameterName, Reader reader, long length) throws SQLException {
/* 2281 */     setCharacterStream(getNamedParamIndex(parameterName, false), reader, length);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setClob(String parameterName, Clob x) throws SQLException {
/* 2286 */     setClob(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setClob(String parameterName, Reader reader) throws SQLException {
/* 2291 */     setClob(getNamedParamIndex(parameterName, false), reader);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setClob(String parameterName, Reader reader, long length) throws SQLException {
/* 2296 */     setClob(getNamedParamIndex(parameterName, false), reader, length);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setNCharacterStream(String parameterName, Reader value) throws SQLException {
/* 2301 */     setNCharacterStream(getNamedParamIndex(parameterName, false), value);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setNCharacterStream(String parameterName, Reader value, long length) throws SQLException {
/* 2306 */     setNCharacterStream(getNamedParamIndex(parameterName, false), value, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean checkReadOnlyProcedure() throws SQLException {
/* 2317 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2318 */       if (this.connection.getNoAccessToProcedureBodies()) {
/* 2319 */         return false;
/*      */       }
/*      */       
/* 2322 */       if (this.paramInfo.isReadOnlySafeChecked) {
/* 2323 */         return this.paramInfo.isReadOnlySafeProcedure;
/*      */       }
/*      */       
/* 2326 */       ResultSet rs = null;
/* 2327 */       PreparedStatement ps = null;
/*      */       
/*      */       try {
/* 2330 */         String procName = extractProcedureName();
/*      */         
/* 2332 */         String catalog = this.currentCatalog;
/*      */         
/* 2334 */         if (procName.indexOf(".") != -1) {
/* 2335 */           catalog = procName.substring(0, procName.indexOf("."));
/*      */           
/* 2337 */           if (StringUtils.startsWithIgnoreCaseAndWs(catalog, "`") && catalog.trim().endsWith("`")) {
/* 2338 */             catalog = catalog.substring(1, catalog.length() - 1);
/*      */           }
/*      */           
/* 2341 */           procName = procName.substring(procName.indexOf(".") + 1);
/* 2342 */           procName = StringUtils.toString(StringUtils.stripEnclosure(StringUtils.getBytes(procName), "`", "`"));
/*      */         } 
/* 2344 */         ps = this.connection.prepareStatement("SELECT SQL_DATA_ACCESS FROM information_schema.routines WHERE routine_schema = ? AND routine_name = ?");
/* 2345 */         ps.setMaxRows(0);
/* 2346 */         ps.setFetchSize(0);
/*      */         
/* 2348 */         ps.setString(1, catalog);
/* 2349 */         ps.setString(2, procName);
/* 2350 */         rs = ps.executeQuery();
/* 2351 */         if (rs.next()) {
/* 2352 */           String sqlDataAccess = rs.getString(1);
/* 2353 */           if ("READS SQL DATA".equalsIgnoreCase(sqlDataAccess) || "NO SQL".equalsIgnoreCase(sqlDataAccess)) {
/* 2354 */             synchronized (this.paramInfo) {
/* 2355 */               this.paramInfo.isReadOnlySafeChecked = true;
/* 2356 */               this.paramInfo.isReadOnlySafeProcedure = true;
/*      */             } 
/* 2358 */             return true;
/*      */           } 
/*      */         } 
/* 2361 */       } catch (SQLException e) {
/*      */       
/*      */       } finally {
/* 2364 */         if (rs != null) {
/* 2365 */           rs.close();
/*      */         }
/* 2367 */         if (ps != null) {
/* 2368 */           ps.close();
/*      */         }
/*      */       } 
/*      */       
/* 2372 */       this.paramInfo.isReadOnlySafeChecked = false;
/* 2373 */       this.paramInfo.isReadOnlySafeProcedure = false;
/*      */     } 
/* 2375 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean checkReadOnlySafeStatement() throws SQLException {
/* 2381 */     return (super.checkReadOnlySafeStatement() || checkReadOnlyProcedure());
/*      */   }
/*      */   
/*      */   private boolean hasParametersView() throws SQLException {
/* 2385 */     synchronized (checkClosed().getConnectionMutex()) {
/*      */       
/* 2387 */       if (this.connection.versionMeetsMinimum(5, 5, 0)) {
/* 2388 */         DatabaseMetaData dbmd1 = new DatabaseMetaDataUsingInfoSchema(this.connection, this.connection.getCatalog());
/* 2389 */         return ((DatabaseMetaDataUsingInfoSchema)dbmd1).gethasParametersView();
/*      */       } 
/*      */       
/* 2392 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long executeLargeUpdate() throws SQLException {
/* 2404 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2405 */       long returnVal = -1L;
/*      */       
/* 2407 */       checkStreamability();
/*      */       
/* 2409 */       if (this.callingStoredFunction) {
/* 2410 */         execute();
/*      */         
/* 2412 */         return -1L;
/*      */       } 
/*      */       
/* 2415 */       setInOutParamsOnServer();
/* 2416 */       setOutParams();
/*      */       
/* 2418 */       returnVal = super.executeLargeUpdate();
/*      */       
/* 2420 */       retrieveOutParams();
/*      */       
/* 2422 */       return returnVal;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public long[] executeLargeBatch() throws SQLException {
/* 2428 */     if (this.hasOutputParams) {
/* 2429 */       throw SQLError.createSQLException("Can't call executeBatch() on CallableStatement with OUTPUT parameters", "S1009", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */     
/* 2433 */     return super.executeLargeBatch();
/*      */   }
/*      */ }


/* Location:              C:\Users\neons\Desktop\JacobAloSchedulingApp\build\classes\!\lib\mysql-connector-java-5.1.47.jar!\com\mysql\jdbc\CallableStatement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */
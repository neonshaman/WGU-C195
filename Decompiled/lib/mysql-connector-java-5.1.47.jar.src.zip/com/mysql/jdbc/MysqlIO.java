/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.authentication.CachingSha2PasswordPlugin;
/*      */ import com.mysql.jdbc.authentication.MysqlClearPasswordPlugin;
/*      */ import com.mysql.jdbc.authentication.MysqlNativePasswordPlugin;
/*      */ import com.mysql.jdbc.authentication.MysqlOldPasswordPlugin;
/*      */ import com.mysql.jdbc.authentication.Sha256PasswordPlugin;
/*      */ import com.mysql.jdbc.exceptions.MySQLStatementCancelledException;
/*      */ import com.mysql.jdbc.exceptions.MySQLTimeoutException;
/*      */ import com.mysql.jdbc.log.LogUtils;
/*      */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*      */ import com.mysql.jdbc.profiler.ProfilerEventHandler;
/*      */ import com.mysql.jdbc.util.ReadAheadInputStream;
/*      */ import com.mysql.jdbc.util.ResultSetUtil;
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.EOFException;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStreamWriter;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.management.ManagementFactory;
/*      */ import java.lang.management.ThreadInfo;
/*      */ import java.lang.management.ThreadMXBean;
/*      */ import java.lang.ref.SoftReference;
/*      */ import java.math.BigInteger;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.Socket;
/*      */ import java.net.SocketException;
/*      */ import java.net.URL;
/*      */ import java.security.NoSuchAlgorithmException;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.zip.Deflater;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MysqlIO
/*      */ {
/*      */   private static final String CODE_PAGE_1252 = "Cp1252";
/*      */   protected static final int NULL_LENGTH = -1;
/*      */   protected static final int COMP_HEADER_LENGTH = 3;
/*      */   protected static final int MIN_COMPRESS_LEN = 50;
/*      */   protected static final int HEADER_LENGTH = 4;
/*      */   protected static final int AUTH_411_OVERHEAD = 33;
/*      */   public static final int SEED_LENGTH = 20;
/*   81 */   private static int maxBufferSize = 65535;
/*      */   
/*      */   private static final String NONE = "none";
/*      */   
/*      */   private static final int CLIENT_LONG_PASSWORD = 1;
/*      */   
/*      */   private static final int CLIENT_FOUND_ROWS = 2;
/*      */   
/*      */   private static final int CLIENT_LONG_FLAG = 4;
/*      */   
/*      */   protected static final int CLIENT_CONNECT_WITH_DB = 8;
/*      */   
/*      */   private static final int CLIENT_COMPRESS = 32;
/*      */   private static final int CLIENT_LOCAL_FILES = 128;
/*      */   private static final int CLIENT_PROTOCOL_41 = 512;
/*      */   private static final int CLIENT_INTERACTIVE = 1024;
/*      */   protected static final int CLIENT_SSL = 2048;
/*      */   private static final int CLIENT_TRANSACTIONS = 8192;
/*      */   protected static final int CLIENT_RESERVED = 16384;
/*      */   protected static final int CLIENT_SECURE_CONNECTION = 32768;
/*      */   private static final int CLIENT_MULTI_STATEMENTS = 65536;
/*      */   private static final int CLIENT_MULTI_RESULTS = 131072;
/*      */   private static final int CLIENT_PLUGIN_AUTH = 524288;
/*      */   private static final int CLIENT_CONNECT_ATTRS = 1048576;
/*      */   private static final int CLIENT_PLUGIN_AUTH_LENENC_CLIENT_DATA = 2097152;
/*      */   private static final int CLIENT_CAN_HANDLE_EXPIRED_PASSWORD = 4194304;
/*      */   private static final int CLIENT_SESSION_TRACK = 8388608;
/*      */   private static final int CLIENT_DEPRECATE_EOF = 16777216;
/*      */   private static final int SERVER_STATUS_IN_TRANS = 1;
/*      */   private static final int SERVER_STATUS_AUTOCOMMIT = 2;
/*      */   static final int SERVER_MORE_RESULTS_EXISTS = 8;
/*      */   private static final int SERVER_QUERY_NO_GOOD_INDEX_USED = 16;
/*      */   private static final int SERVER_QUERY_NO_INDEX_USED = 32;
/*      */   private static final int SERVER_QUERY_WAS_SLOW = 2048;
/*      */   private static final int SERVER_STATUS_CURSOR_EXISTS = 64;
/*      */   private static final String FALSE_SCRAMBLE = "xxxxxxxx";
/*      */   protected static final int MAX_QUERY_SIZE_TO_LOG = 1024;
/*      */   protected static final int MAX_QUERY_SIZE_TO_EXPLAIN = 1048576;
/*      */   protected static final int INITIAL_PACKET_SIZE = 1024;
/*  120 */   private static String jvmPlatformCharset = null;
/*      */ 
/*      */   
/*      */   protected static final String ZERO_DATE_VALUE_MARKER = "0000-00-00";
/*      */   
/*      */   protected static final String ZERO_DATETIME_VALUE_MARKER = "0000-00-00 00:00:00";
/*      */   
/*      */   private static final String EXPLAINABLE_STATEMENT = "SELECT";
/*      */   
/*  129 */   private static final String[] EXPLAINABLE_STATEMENT_EXTENSION = new String[] { "INSERT", "UPDATE", "REPLACE", "DELETE" }; private static final int MAX_PACKET_DUMP_LENGTH = 1024;
/*      */   
/*      */   static {
/*  132 */     OutputStreamWriter outWriter = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  139 */       outWriter = new OutputStreamWriter(new ByteArrayOutputStream());
/*  140 */       jvmPlatformCharset = outWriter.getEncoding();
/*      */     } finally {
/*      */       try {
/*  143 */         if (outWriter != null) {
/*  144 */           outWriter.close();
/*      */         }
/*  146 */       } catch (IOException ioEx) {}
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean packetSequenceReset = false;
/*      */ 
/*      */ 
/*      */   
/*      */   protected int serverCharsetIndex;
/*      */ 
/*      */   
/*  160 */   private Buffer reusablePacket = null;
/*  161 */   private Buffer sendPacket = null;
/*  162 */   private Buffer sharedSendPacket = null;
/*      */ 
/*      */   
/*  165 */   protected BufferedOutputStream mysqlOutput = null;
/*      */   protected MySQLConnection connection;
/*  167 */   private Deflater deflater = null;
/*  168 */   protected InputStream mysqlInput = null;
/*  169 */   private LinkedList<StringBuilder> packetDebugRingBuffer = null;
/*  170 */   private RowData streamingData = null;
/*      */ 
/*      */   
/*  173 */   public Socket mysqlConnection = null;
/*  174 */   protected SocketFactory socketFactory = null;
/*      */ 
/*      */ 
/*      */   
/*      */   private SoftReference<Buffer> loadFileBufRef;
/*      */ 
/*      */ 
/*      */   
/*      */   private SoftReference<Buffer> splitBufRef;
/*      */ 
/*      */ 
/*      */   
/*      */   private SoftReference<Buffer> compressBufRef;
/*      */ 
/*      */   
/*  189 */   protected String host = null;
/*      */   protected String seed;
/*  191 */   private String serverVersion = null;
/*  192 */   private String socketFactoryClassName = null;
/*  193 */   private byte[] packetHeaderBuf = new byte[4];
/*      */   
/*      */   private boolean colDecimalNeedsBump = false;
/*      */   
/*      */   private boolean hadWarnings = false;
/*      */   
/*      */   private boolean has41NewNewProt = false;
/*      */   
/*      */   private boolean hasLongColumnInfo = false;
/*      */   
/*      */   private boolean isInteractiveClient = false;
/*      */   
/*      */   private boolean logSlowQueries = false;
/*      */   
/*      */   private boolean platformDbCharsetMatches = true;
/*      */   
/*      */   private boolean profileSql = false;
/*      */   
/*      */   private boolean queryBadIndexUsed = false;
/*      */   private boolean queryNoIndexUsed = false;
/*      */   private boolean serverQueryWasSlow = false;
/*      */   private boolean use41Extensions = false;
/*      */   private boolean useCompression = false;
/*      */   private boolean useNewLargePackets = false;
/*      */   private boolean useNewUpdateCounts = false;
/*  218 */   private byte packetSequence = 0;
/*  219 */   private byte compressedPacketSequence = 0;
/*  220 */   private byte readPacketSequence = -1;
/*      */   private boolean checkPacketSequence = false;
/*  222 */   private byte protocolVersion = 0;
/*  223 */   private int maxAllowedPacket = 1048576;
/*  224 */   protected int maxThreeBytes = 16581375;
/*  225 */   protected int port = 3306;
/*      */   protected int serverCapabilities;
/*  227 */   private int serverMajorVersion = 0;
/*  228 */   private int serverMinorVersion = 0;
/*  229 */   private int oldServerStatus = 0;
/*  230 */   private int serverStatus = 0;
/*  231 */   private int serverSubMinorVersion = 0;
/*  232 */   private int warningCount = 0;
/*  233 */   protected long clientParam = 0L;
/*  234 */   protected long lastPacketSentTimeMs = 0L;
/*  235 */   protected long lastPacketReceivedTimeMs = 0L;
/*      */   private boolean traceProtocol = false;
/*      */   private boolean enablePacketDebug = false;
/*      */   private boolean useConnectWithDb;
/*      */   private boolean needToGrabQueryFromPacket;
/*      */   private boolean autoGenerateTestcaseScript;
/*      */   private long threadId;
/*      */   private boolean useNanosForElapsedTime;
/*      */   private long slowQueryThreshold;
/*      */   private String queryTimingUnits;
/*      */   private boolean useDirectRowUnpack = true;
/*      */   private int useBufferRowSizeThreshold;
/*  247 */   private int commandCount = 0;
/*      */   private List<StatementInterceptorV2> statementInterceptors;
/*      */   private ExceptionInterceptor exceptionInterceptor;
/*  250 */   private int authPluginDataLength = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Map<String, AuthenticationPlugin> authenticationPlugins;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<String> disabledAuthenticationPlugins;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String clientDefaultAuthenticationPlugin;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String clientDefaultAuthenticationPluginName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String serverDefaultAuthenticationPluginName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int statementExecutionDepth;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean useAutoSlowLog;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasLongColumnInfo() {
/*  352 */     return this.hasLongColumnInfo;
/*      */   }
/*      */   
/*      */   protected boolean isDataAvailable() throws SQLException {
/*      */     try {
/*  357 */       return (this.mysqlInput.available() > 0);
/*  358 */     } catch (IOException ioEx) {
/*  359 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected long getLastPacketSentTimeMs() {
/*  368 */     return this.lastPacketSentTimeMs;
/*      */   }
/*      */   
/*      */   protected long getLastPacketReceivedTimeMs() {
/*  372 */     return this.lastPacketReceivedTimeMs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ResultSetImpl getResultSet(StatementImpl callingStatement, long columnCount, int maxRows, int resultSetType, int resultSetConcurrency, boolean streamResults, String catalog, boolean isBinaryEncoded, Field[] metadataFromCache) throws SQLException {
/*  408 */     Field[] fields = null;
/*      */ 
/*      */ 
/*      */     
/*  412 */     if (metadataFromCache == null) {
/*  413 */       fields = new Field[(int)columnCount];
/*      */       
/*  415 */       for (int i = 0; i < columnCount; i++) {
/*  416 */         Buffer fieldPacket = null;
/*      */         
/*  418 */         fieldPacket = readPacket();
/*  419 */         fields[i] = unpackField(fieldPacket, false);
/*      */       } 
/*      */     } else {
/*  422 */       for (int i = 0; i < columnCount; i++) {
/*  423 */         skipPacket();
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  428 */     if (!isEOFDeprecated() || (this.connection.versionMeetsMinimum(5, 0, 2) && callingStatement != null && isBinaryEncoded && callingStatement.isCursorRequired())) {
/*      */ 
/*      */ 
/*      */       
/*  432 */       Buffer packet = reuseAndReadPacket(this.reusablePacket);
/*  433 */       readServerStatusForResultSets(packet);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  440 */     if (this.connection.versionMeetsMinimum(5, 0, 2) && this.connection.getUseCursorFetch() && isBinaryEncoded && callingStatement != null && callingStatement.getFetchSize() != 0 && callingStatement.getResultSetType() == 1003) {
/*      */       
/*  442 */       ServerPreparedStatement prepStmt = (ServerPreparedStatement)callingStatement;
/*      */       
/*  444 */       boolean usingCursor = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  451 */       if (this.connection.versionMeetsMinimum(5, 0, 5)) {
/*  452 */         usingCursor = ((this.serverStatus & 0x40) != 0);
/*      */       }
/*      */       
/*  455 */       if (usingCursor) {
/*  456 */         RowData rows = new RowDataCursor(this, prepStmt, fields);
/*      */         
/*  458 */         ResultSetImpl resultSetImpl = buildResultSetWithRows(callingStatement, catalog, fields, rows, resultSetType, resultSetConcurrency, isBinaryEncoded);
/*      */         
/*  460 */         if (usingCursor) {
/*  461 */           resultSetImpl.setFetchSize(callingStatement.getFetchSize());
/*      */         }
/*      */         
/*  464 */         return resultSetImpl;
/*      */       } 
/*      */     } 
/*      */     
/*  468 */     RowData rowData = null;
/*      */     
/*  470 */     if (!streamResults) {
/*  471 */       rowData = readSingleRowSet(columnCount, maxRows, resultSetConcurrency, isBinaryEncoded, (metadataFromCache == null) ? fields : metadataFromCache);
/*      */     } else {
/*  473 */       rowData = new RowDataDynamic(this, (int)columnCount, (metadataFromCache == null) ? fields : metadataFromCache, isBinaryEncoded);
/*  474 */       this.streamingData = rowData;
/*      */     } 
/*      */     
/*  477 */     ResultSetImpl rs = buildResultSetWithRows(callingStatement, catalog, (metadataFromCache == null) ? fields : metadataFromCache, rowData, resultSetType, resultSetConcurrency, isBinaryEncoded);
/*      */ 
/*      */     
/*  480 */     return rs;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected NetworkResources getNetworkResources() {
/*  486 */     return new NetworkResources(this.mysqlConnection, this.mysqlInput, this.mysqlOutput);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void forceClose() {
/*      */     try {
/*  494 */       getNetworkResources().forceClose();
/*      */     } finally {
/*  496 */       this.mysqlConnection = null;
/*  497 */       this.mysqlInput = null;
/*  498 */       this.mysqlOutput = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void skipPacket() throws SQLException {
/*      */     try {
/*  512 */       int lengthRead = readFully(this.mysqlInput, this.packetHeaderBuf, 0, 4);
/*      */       
/*  514 */       if (lengthRead < 4) {
/*  515 */         forceClose();
/*  516 */         throw new IOException(Messages.getString("MysqlIO.1"));
/*      */       } 
/*      */       
/*  519 */       int packetLength = (this.packetHeaderBuf[0] & 0xFF) + ((this.packetHeaderBuf[1] & 0xFF) << 8) + ((this.packetHeaderBuf[2] & 0xFF) << 16);
/*      */       
/*  521 */       if (this.traceProtocol) {
/*  522 */         StringBuilder traceMessageBuf = new StringBuilder();
/*      */         
/*  524 */         traceMessageBuf.append(Messages.getString("MysqlIO.2"));
/*  525 */         traceMessageBuf.append(packetLength);
/*  526 */         traceMessageBuf.append(Messages.getString("MysqlIO.3"));
/*  527 */         traceMessageBuf.append(StringUtils.dumpAsHex(this.packetHeaderBuf, 4));
/*      */         
/*  529 */         this.connection.getLog().logTrace(traceMessageBuf.toString());
/*      */       } 
/*      */       
/*  532 */       byte multiPacketSeq = this.packetHeaderBuf[3];
/*      */       
/*  534 */       if (!this.packetSequenceReset) {
/*  535 */         if (this.enablePacketDebug && this.checkPacketSequence) {
/*  536 */           checkPacketSequencing(multiPacketSeq);
/*      */         }
/*      */       } else {
/*  539 */         this.packetSequenceReset = false;
/*      */       } 
/*      */       
/*  542 */       this.readPacketSequence = multiPacketSeq;
/*      */       
/*  544 */       skipFully(this.mysqlInput, packetLength);
/*  545 */     } catch (IOException ioEx) {
/*  546 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor());
/*      */     }
/*  548 */     catch (OutOfMemoryError oom) {
/*      */       try {
/*  550 */         this.connection.realClose(false, false, true, oom);
/*  551 */       } catch (Exception ex) {}
/*      */       
/*  553 */       throw oom;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Buffer readPacket() throws SQLException {
/*      */     try {
/*  568 */       int lengthRead = readFully(this.mysqlInput, this.packetHeaderBuf, 0, 4);
/*      */       
/*  570 */       if (lengthRead < 4) {
/*  571 */         forceClose();
/*  572 */         throw new IOException(Messages.getString("MysqlIO.1"));
/*      */       } 
/*      */       
/*  575 */       int packetLength = (this.packetHeaderBuf[0] & 0xFF) + ((this.packetHeaderBuf[1] & 0xFF) << 8) + ((this.packetHeaderBuf[2] & 0xFF) << 16);
/*      */       
/*  577 */       if (packetLength > this.maxAllowedPacket) {
/*  578 */         throw new PacketTooBigException(packetLength, this.maxAllowedPacket);
/*      */       }
/*      */       
/*  581 */       if (this.traceProtocol) {
/*  582 */         StringBuilder traceMessageBuf = new StringBuilder();
/*      */         
/*  584 */         traceMessageBuf.append(Messages.getString("MysqlIO.2"));
/*  585 */         traceMessageBuf.append(packetLength);
/*  586 */         traceMessageBuf.append(Messages.getString("MysqlIO.3"));
/*  587 */         traceMessageBuf.append(StringUtils.dumpAsHex(this.packetHeaderBuf, 4));
/*      */         
/*  589 */         this.connection.getLog().logTrace(traceMessageBuf.toString());
/*      */       } 
/*      */       
/*  592 */       byte multiPacketSeq = this.packetHeaderBuf[3];
/*      */       
/*  594 */       if (!this.packetSequenceReset) {
/*  595 */         if (this.enablePacketDebug && this.checkPacketSequence) {
/*  596 */           checkPacketSequencing(multiPacketSeq);
/*      */         }
/*      */       } else {
/*  599 */         this.packetSequenceReset = false;
/*      */       } 
/*      */       
/*  602 */       this.readPacketSequence = multiPacketSeq;
/*      */ 
/*      */       
/*  605 */       byte[] buffer = new byte[packetLength];
/*  606 */       int numBytesRead = readFully(this.mysqlInput, buffer, 0, packetLength);
/*      */       
/*  608 */       if (numBytesRead != packetLength) {
/*  609 */         throw new IOException("Short read, expected " + packetLength + " bytes, only read " + numBytesRead);
/*      */       }
/*      */       
/*  612 */       Buffer packet = new Buffer(buffer);
/*      */       
/*  614 */       if (this.traceProtocol) {
/*  615 */         StringBuilder traceMessageBuf = new StringBuilder();
/*      */         
/*  617 */         traceMessageBuf.append(Messages.getString("MysqlIO.4"));
/*  618 */         traceMessageBuf.append(getPacketDumpToLog(packet, packetLength));
/*      */         
/*  620 */         this.connection.getLog().logTrace(traceMessageBuf.toString());
/*      */       } 
/*      */       
/*  623 */       if (this.enablePacketDebug) {
/*  624 */         enqueuePacketForDebugging(false, false, 0, this.packetHeaderBuf, packet);
/*      */       }
/*      */       
/*  627 */       if (this.connection.getMaintainTimeStats()) {
/*  628 */         this.lastPacketReceivedTimeMs = System.currentTimeMillis();
/*      */       }
/*      */       
/*  631 */       return packet;
/*  632 */     } catch (IOException ioEx) {
/*  633 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor());
/*      */     }
/*  635 */     catch (OutOfMemoryError oom) {
/*      */       try {
/*  637 */         this.connection.realClose(false, false, true, oom);
/*  638 */       } catch (Exception ex) {}
/*      */       
/*  640 */       throw oom;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Field unpackField(Buffer packet, boolean extractDefaultValues) throws SQLException {
/*  658 */     if (this.use41Extensions) {
/*      */ 
/*      */       
/*  661 */       if (this.has41NewNewProt) {
/*      */         
/*  663 */         int catalogNameStart = packet.getPosition() + 1;
/*  664 */         int catalogNameLength = packet.fastSkipLenString();
/*  665 */         catalogNameStart = adjustStartForFieldLength(catalogNameStart, catalogNameLength);
/*      */       } 
/*      */       
/*  668 */       int databaseNameStart = packet.getPosition() + 1;
/*  669 */       int databaseNameLength = packet.fastSkipLenString();
/*  670 */       databaseNameStart = adjustStartForFieldLength(databaseNameStart, databaseNameLength);
/*      */       
/*  672 */       int i = packet.getPosition() + 1;
/*  673 */       int j = packet.fastSkipLenString();
/*  674 */       i = adjustStartForFieldLength(i, j);
/*      */ 
/*      */       
/*  677 */       int originalTableNameStart = packet.getPosition() + 1;
/*  678 */       int originalTableNameLength = packet.fastSkipLenString();
/*  679 */       originalTableNameStart = adjustStartForFieldLength(originalTableNameStart, originalTableNameLength);
/*      */ 
/*      */       
/*  682 */       int k = packet.getPosition() + 1;
/*  683 */       int m = packet.fastSkipLenString();
/*      */       
/*  685 */       k = adjustStartForFieldLength(k, m);
/*      */ 
/*      */       
/*  688 */       int originalColumnNameStart = packet.getPosition() + 1;
/*  689 */       int originalColumnNameLength = packet.fastSkipLenString();
/*  690 */       originalColumnNameStart = adjustStartForFieldLength(originalColumnNameStart, originalColumnNameLength);
/*      */       
/*  692 */       packet.readByte();
/*      */       
/*  694 */       short charSetNumber = (short)packet.readInt();
/*      */       
/*  696 */       long l = 0L;
/*      */       
/*  698 */       if (this.has41NewNewProt) {
/*  699 */         l = packet.readLong();
/*      */       } else {
/*  701 */         l = packet.readLongInt();
/*      */       } 
/*      */       
/*  704 */       int n = packet.readByte() & 0xFF;
/*      */       
/*  706 */       short s1 = 0;
/*      */       
/*  708 */       if (this.hasLongColumnInfo) {
/*  709 */         s1 = (short)packet.readInt();
/*      */       } else {
/*  711 */         s1 = (short)(packet.readByte() & 0xFF);
/*      */       } 
/*      */       
/*  714 */       int i1 = packet.readByte() & 0xFF;
/*      */       
/*  716 */       int defaultValueStart = -1;
/*  717 */       int defaultValueLength = -1;
/*      */       
/*  719 */       if (extractDefaultValues) {
/*  720 */         defaultValueStart = packet.getPosition() + 1;
/*  721 */         defaultValueLength = packet.fastSkipLenString();
/*      */       } 
/*      */       
/*  724 */       Field field1 = new Field(this.connection, packet.getByteBuffer(), databaseNameStart, databaseNameLength, i, j, originalTableNameStart, originalTableNameLength, k, m, originalColumnNameStart, originalColumnNameLength, l, n, s1, i1, defaultValueStart, defaultValueLength, charSetNumber);
/*      */ 
/*      */ 
/*      */       
/*  728 */       return field1;
/*      */     } 
/*      */     
/*  731 */     int tableNameStart = packet.getPosition() + 1;
/*  732 */     int tableNameLength = packet.fastSkipLenString();
/*  733 */     tableNameStart = adjustStartForFieldLength(tableNameStart, tableNameLength);
/*      */     
/*  735 */     int nameStart = packet.getPosition() + 1;
/*  736 */     int nameLength = packet.fastSkipLenString();
/*  737 */     nameStart = adjustStartForFieldLength(nameStart, nameLength);
/*      */     
/*  739 */     int colLength = packet.readnBytes();
/*  740 */     int colType = packet.readnBytes();
/*  741 */     packet.readByte();
/*      */     
/*  743 */     short colFlag = 0;
/*      */     
/*  745 */     if (this.hasLongColumnInfo) {
/*  746 */       colFlag = (short)packet.readInt();
/*      */     } else {
/*  748 */       colFlag = (short)(packet.readByte() & 0xFF);
/*      */     } 
/*      */     
/*  751 */     int colDecimals = packet.readByte() & 0xFF;
/*      */     
/*  753 */     if (this.colDecimalNeedsBump) {
/*  754 */       colDecimals++;
/*      */     }
/*      */     
/*  757 */     Field field = new Field(this.connection, packet.getByteBuffer(), nameStart, nameLength, tableNameStart, tableNameLength, colLength, colType, colFlag, colDecimals);
/*      */ 
/*      */     
/*  760 */     return field;
/*      */   }
/*      */   
/*      */   private int adjustStartForFieldLength(int nameStart, int nameLength) {
/*  764 */     if (nameLength < 251) {
/*  765 */       return nameStart;
/*      */     }
/*      */     
/*  768 */     if (nameLength >= 251 && nameLength < 65536) {
/*  769 */       return nameStart + 2;
/*      */     }
/*      */     
/*  772 */     if (nameLength >= 65536 && nameLength < 16777216) {
/*  773 */       return nameStart + 3;
/*      */     }
/*      */     
/*  776 */     return nameStart + 8;
/*      */   }
/*      */   
/*      */   protected boolean isSetNeededForAutoCommitMode(boolean autoCommitFlag) {
/*  780 */     if (this.use41Extensions && this.connection.getElideSetAutoCommits()) {
/*  781 */       boolean autoCommitModeOnServer = ((this.serverStatus & 0x2) != 0);
/*      */       
/*  783 */       if (!autoCommitFlag && versionMeetsMinimum(5, 0, 0))
/*      */       {
/*      */ 
/*      */         
/*  787 */         return !inTransactionOnServer();
/*      */       }
/*      */       
/*  790 */       return (autoCommitModeOnServer != autoCommitFlag);
/*      */     } 
/*      */     
/*  793 */     return true;
/*      */   }
/*      */   
/*      */   protected boolean inTransactionOnServer() {
/*  797 */     return ((this.serverStatus & 0x1) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void changeUser(String userName, String password, String database) throws SQLException {
/*  810 */     this.packetSequence = -1;
/*  811 */     this.compressedPacketSequence = -1;
/*      */     
/*  813 */     int passwordLength = 16;
/*  814 */     int userLength = (userName != null) ? userName.length() : 0;
/*  815 */     int databaseLength = (database != null) ? database.length() : 0;
/*      */     
/*  817 */     int packLength = (userLength + passwordLength + databaseLength) * 3 + 7 + 4 + 33;
/*      */     
/*  819 */     if ((this.serverCapabilities & 0x80000) != 0) {
/*      */       
/*  821 */       proceedHandshakeWithPluggableAuthentication(userName, password, database, null);
/*      */     }
/*  823 */     else if ((this.serverCapabilities & 0x8000) != 0) {
/*  824 */       Buffer changeUserPacket = new Buffer(packLength + 1);
/*  825 */       changeUserPacket.writeByte((byte)17);
/*      */       
/*  827 */       if (versionMeetsMinimum(4, 1, 1)) {
/*  828 */         secureAuth411(changeUserPacket, packLength, userName, password, database, false, true);
/*      */       } else {
/*  830 */         secureAuth(changeUserPacket, packLength, userName, password, database, false);
/*      */       } 
/*      */     } else {
/*      */       
/*  834 */       Buffer packet = new Buffer(packLength);
/*  835 */       packet.writeByte((byte)17);
/*      */ 
/*      */       
/*  838 */       packet.writeString(userName);
/*      */       
/*  840 */       if (this.protocolVersion > 9) {
/*  841 */         packet.writeString(Util.newCrypt(password, this.seed, this.connection.getPasswordCharacterEncoding()));
/*      */       } else {
/*  843 */         packet.writeString(Util.oldCrypt(password, this.seed));
/*      */       } 
/*      */       
/*  846 */       boolean localUseConnectWithDb = (this.useConnectWithDb && database != null && database.length() > 0);
/*      */       
/*  848 */       if (localUseConnectWithDb) {
/*  849 */         packet.writeString(database);
/*      */       }
/*      */       
/*  852 */       send(packet, packet.getPosition());
/*  853 */       checkErrorPacket();
/*      */       
/*  855 */       if (!localUseConnectWithDb) {
/*  856 */         changeDatabaseTo(database);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Buffer checkErrorPacket() throws SQLException {
/*  871 */     return checkErrorPacket(-1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkForCharsetMismatch() {
/*  878 */     if (this.connection.getUseUnicode() && this.connection.getEncoding() != null) {
/*  879 */       String encodingToCheck = jvmPlatformCharset;
/*      */       
/*  881 */       if (encodingToCheck == null) {
/*  882 */         encodingToCheck = System.getProperty("file.encoding");
/*      */       }
/*      */       
/*  885 */       if (encodingToCheck == null) {
/*  886 */         this.platformDbCharsetMatches = false;
/*      */       } else {
/*  888 */         this.platformDbCharsetMatches = encodingToCheck.equals(this.connection.getEncoding());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void clearInputStream() throws SQLException {
/*      */     try {
/*      */       int len;
/*  899 */       while ((len = this.mysqlInput.available()) > 0 && this.mysqlInput.skip(len) > 0L);
/*      */     
/*      */     }
/*  902 */     catch (IOException ioEx) {
/*  903 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void resetReadPacketSequence() {
/*  909 */     this.readPacketSequence = 0;
/*      */   }
/*      */   
/*      */   protected void dumpPacketRingBuffer() throws SQLException {
/*  913 */     if (this.packetDebugRingBuffer != null && this.connection.getEnablePacketDebug()) {
/*  914 */       StringBuilder dumpBuffer = new StringBuilder();
/*      */       
/*  916 */       dumpBuffer.append("Last " + this.packetDebugRingBuffer.size() + " packets received from server, from oldest->newest:\n");
/*  917 */       dumpBuffer.append("\n");
/*      */       
/*  919 */       for (Iterator<StringBuilder> ringBufIter = this.packetDebugRingBuffer.iterator(); ringBufIter.hasNext(); ) {
/*  920 */         dumpBuffer.append(ringBufIter.next());
/*  921 */         dumpBuffer.append("\n");
/*      */       } 
/*      */       
/*  924 */       this.connection.getLog().logTrace(dumpBuffer.toString());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void explainSlowQuery(byte[] querySQL, String truncatedQuery) throws SQLException {
/*  937 */     if (StringUtils.startsWithIgnoreCaseAndWs(truncatedQuery, "SELECT") || (versionMeetsMinimum(5, 6, 3) && StringUtils.startsWithIgnoreCaseAndWs(truncatedQuery, EXPLAINABLE_STATEMENT_EXTENSION) != -1)) {
/*      */ 
/*      */       
/*  940 */       PreparedStatement stmt = null;
/*  941 */       ResultSet rs = null;
/*      */ 
/*      */       
/*  944 */       try { stmt = (PreparedStatement)this.connection.clientPrepareStatement("EXPLAIN ?");
/*  945 */         stmt.setBytesNoEscapeNoQuotes(1, querySQL);
/*  946 */         rs = stmt.executeQuery();
/*      */         
/*  948 */         StringBuilder explainResults = new StringBuilder(Messages.getString("MysqlIO.8") + truncatedQuery + Messages.getString("MysqlIO.9"));
/*      */         
/*  950 */         ResultSetUtil.appendResultSetSlashGStyle(explainResults, rs);
/*      */         
/*  952 */         this.connection.getLog().logWarn(explainResults.toString()); }
/*  953 */       catch (SQLException sqlEx) {  }
/*      */       finally
/*  955 */       { if (rs != null) {
/*  956 */           rs.close();
/*      */         }
/*      */         
/*  959 */         if (stmt != null) {
/*  960 */           stmt.close();
/*      */         } }
/*      */     
/*      */     } 
/*      */   }
/*      */   
/*      */   static int getMaxBuf() {
/*  967 */     return maxBufferSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int getServerMajorVersion() {
/*  974 */     return this.serverMajorVersion;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int getServerMinorVersion() {
/*  981 */     return this.serverMinorVersion;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int getServerSubMinorVersion() {
/*  988 */     return this.serverSubMinorVersion;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getServerVersion() {
/*  995 */     return this.serverVersion;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doHandshake(String user, String password, String database) throws SQLException {
/* 1011 */     this.checkPacketSequence = false;
/* 1012 */     this.readPacketSequence = 0;
/*      */     
/* 1014 */     Buffer buf = readPacket();
/*      */ 
/*      */     
/* 1017 */     this.protocolVersion = buf.readByte();
/*      */     
/* 1019 */     if (this.protocolVersion == -1) {
/*      */       try {
/* 1021 */         this.mysqlConnection.close();
/* 1022 */       } catch (Exception e) {}
/*      */ 
/*      */ 
/*      */       
/* 1026 */       int errno = 2000;
/*      */       
/* 1028 */       errno = buf.readInt();
/*      */       
/* 1030 */       String serverErrorMessage = buf.readString("ASCII", getExceptionInterceptor());
/*      */       
/* 1032 */       StringBuilder errorBuf = new StringBuilder(Messages.getString("MysqlIO.10"));
/* 1033 */       errorBuf.append(serverErrorMessage);
/* 1034 */       errorBuf.append("\"");
/*      */       
/* 1036 */       String xOpen = SQLError.mysqlToSqlState(errno, this.connection.getUseSqlStateCodes());
/*      */       
/* 1038 */       throw SQLError.createSQLException(SQLError.get(xOpen) + ", " + errorBuf.toString(), xOpen, errno, getExceptionInterceptor());
/*      */     } 
/*      */     
/* 1041 */     this.serverVersion = buf.readString("ASCII", getExceptionInterceptor());
/*      */ 
/*      */     
/* 1044 */     int point = this.serverVersion.indexOf('.');
/*      */     
/* 1046 */     if (point != -1) {
/*      */       try {
/* 1048 */         int n = Integer.parseInt(this.serverVersion.substring(0, point));
/* 1049 */         this.serverMajorVersion = n;
/* 1050 */       } catch (NumberFormatException NFE1) {}
/*      */ 
/*      */ 
/*      */       
/* 1054 */       String remaining = this.serverVersion.substring(point + 1, this.serverVersion.length());
/* 1055 */       point = remaining.indexOf('.');
/*      */       
/* 1057 */       if (point != -1) {
/*      */         try {
/* 1059 */           int n = Integer.parseInt(remaining.substring(0, point));
/* 1060 */           this.serverMinorVersion = n;
/* 1061 */         } catch (NumberFormatException nfe) {}
/*      */ 
/*      */ 
/*      */         
/* 1065 */         remaining = remaining.substring(point + 1, remaining.length());
/*      */         
/* 1067 */         int pos = 0;
/*      */         
/* 1069 */         while (pos < remaining.length() && 
/* 1070 */           remaining.charAt(pos) >= '0' && remaining.charAt(pos) <= '9')
/*      */         {
/*      */ 
/*      */           
/* 1074 */           pos++;
/*      */         }
/*      */         
/*      */         try {
/* 1078 */           int n = Integer.parseInt(remaining.substring(0, pos));
/* 1079 */           this.serverSubMinorVersion = n;
/* 1080 */         } catch (NumberFormatException nfe) {}
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1086 */     if (versionMeetsMinimum(4, 0, 8)) {
/* 1087 */       this.maxThreeBytes = 16777215;
/* 1088 */       this.useNewLargePackets = true;
/*      */     } else {
/* 1090 */       this.maxThreeBytes = 16581375;
/* 1091 */       this.useNewLargePackets = false;
/*      */     } 
/*      */     
/* 1094 */     this.colDecimalNeedsBump = versionMeetsMinimum(3, 23, 0);
/* 1095 */     this.colDecimalNeedsBump = !versionMeetsMinimum(3, 23, 15);
/* 1096 */     this.useNewUpdateCounts = versionMeetsMinimum(3, 22, 5);
/*      */ 
/*      */     
/* 1099 */     this.threadId = buf.readLong();
/*      */     
/* 1101 */     if (this.protocolVersion > 9) {
/*      */       
/* 1103 */       this.seed = buf.readString("ASCII", getExceptionInterceptor(), 8);
/*      */       
/* 1105 */       buf.readByte();
/*      */     } else {
/*      */       
/* 1108 */       this.seed = buf.readString("ASCII", getExceptionInterceptor());
/*      */     } 
/*      */     
/* 1111 */     this.serverCapabilities = 0;
/*      */ 
/*      */     
/* 1114 */     if (buf.getPosition() < buf.getBufLength()) {
/* 1115 */       this.serverCapabilities = buf.readInt();
/*      */     }
/*      */     
/* 1118 */     if (versionMeetsMinimum(4, 1, 1) || (this.protocolVersion > 9 && (this.serverCapabilities & 0x200) != 0)) {
/*      */ 
/*      */ 
/*      */       
/* 1122 */       this.serverCharsetIndex = buf.readByte() & 0xFF;
/*      */       
/* 1124 */       this.serverStatus = buf.readInt();
/* 1125 */       checkTransactionState(0);
/*      */ 
/*      */       
/* 1128 */       this.serverCapabilities |= buf.readInt() << 16;
/*      */       
/* 1130 */       if ((this.serverCapabilities & 0x80000) != 0) {
/*      */         
/* 1132 */         this.authPluginDataLength = buf.readByte() & 0xFF;
/*      */       } else {
/*      */         
/* 1135 */         buf.readByte();
/*      */       } 
/*      */       
/* 1138 */       buf.setPosition(buf.getPosition() + 10);
/*      */       
/* 1140 */       if ((this.serverCapabilities & 0x8000) != 0) {
/*      */         String seedPart2;
/*      */         
/*      */         StringBuilder newSeed;
/* 1144 */         if (this.authPluginDataLength > 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1151 */           seedPart2 = buf.readString("ASCII", getExceptionInterceptor(), this.authPluginDataLength - 8);
/* 1152 */           newSeed = new StringBuilder(this.authPluginDataLength);
/*      */         } else {
/* 1154 */           seedPart2 = buf.readString("ASCII", getExceptionInterceptor());
/* 1155 */           newSeed = new StringBuilder(20);
/*      */         } 
/* 1157 */         newSeed.append(this.seed);
/* 1158 */         newSeed.append(seedPart2);
/* 1159 */         this.seed = newSeed.toString();
/*      */       } 
/*      */     } 
/*      */     
/* 1163 */     if ((this.serverCapabilities & 0x20) != 0 && this.connection.getUseCompression()) {
/* 1164 */       this.clientParam |= 0x20L;
/*      */     }
/*      */     
/* 1167 */     this.useConnectWithDb = (database != null && database.length() > 0 && !this.connection.getCreateDatabaseIfNotExist());
/*      */     
/* 1169 */     if (this.useConnectWithDb) {
/* 1170 */       this.clientParam |= 0x8L;
/*      */     }
/*      */ 
/*      */     
/* 1174 */     if (versionMeetsMinimum(5, 7, 0) && !this.connection.getUseSSL() && !this.connection.isUseSSLExplicit()) {
/* 1175 */       this.connection.setUseSSL(true);
/* 1176 */       this.connection.setVerifyServerCertificate(false);
/* 1177 */       this.connection.getLog().logWarn(Messages.getString("MysqlIO.SSLWarning"));
/*      */     } 
/*      */ 
/*      */     
/* 1181 */     if ((this.serverCapabilities & 0x800) == 0 && this.connection.getUseSSL()) {
/* 1182 */       if (this.connection.getRequireSSL()) {
/* 1183 */         this.connection.close();
/* 1184 */         forceClose();
/* 1185 */         throw SQLError.createSQLException(Messages.getString("MysqlIO.15"), "08001", getExceptionInterceptor());
/*      */       } 
/*      */ 
/*      */       
/* 1189 */       this.connection.setUseSSL(false);
/*      */     } 
/*      */     
/* 1192 */     if ((this.serverCapabilities & 0x4) != 0) {
/*      */       
/* 1194 */       this.clientParam |= 0x4L;
/* 1195 */       this.hasLongColumnInfo = true;
/*      */     } 
/*      */ 
/*      */     
/* 1199 */     if (!this.connection.getUseAffectedRows()) {
/* 1200 */       this.clientParam |= 0x2L;
/*      */     }
/*      */     
/* 1203 */     if (this.connection.getAllowLoadLocalInfile()) {
/* 1204 */       this.clientParam |= 0x80L;
/*      */     }
/*      */     
/* 1207 */     if (this.isInteractiveClient) {
/* 1208 */       this.clientParam |= 0x400L;
/*      */     }
/*      */     
/* 1211 */     if ((this.serverCapabilities & 0x800000) != 0);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1216 */     if ((this.serverCapabilities & 0x1000000) != 0) {
/* 1217 */       this.clientParam |= 0x1000000L;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1223 */     if ((this.serverCapabilities & 0x80000) != 0) {
/* 1224 */       proceedHandshakeWithPluggableAuthentication(user, password, database, buf);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1229 */     if (this.protocolVersion > 9) {
/* 1230 */       this.clientParam |= 0x1L;
/*      */     } else {
/* 1232 */       this.clientParam &= 0xFFFFFFFFFFFFFFFEL;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1238 */     if (versionMeetsMinimum(4, 1, 0) || (this.protocolVersion > 9 && (this.serverCapabilities & 0x4000) != 0)) {
/* 1239 */       if (versionMeetsMinimum(4, 1, 1) || (this.protocolVersion > 9 && (this.serverCapabilities & 0x200) != 0)) {
/* 1240 */         this.clientParam |= 0x200L;
/* 1241 */         this.has41NewNewProt = true;
/*      */ 
/*      */         
/* 1244 */         this.clientParam |= 0x2000L;
/*      */ 
/*      */         
/* 1247 */         this.clientParam |= 0x20000L;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1252 */         if (this.connection.getAllowMultiQueries()) {
/* 1253 */           this.clientParam |= 0x10000L;
/*      */         }
/*      */       } else {
/* 1256 */         this.clientParam |= 0x4000L;
/* 1257 */         this.has41NewNewProt = false;
/*      */       } 
/*      */       
/* 1260 */       this.use41Extensions = true;
/*      */     } 
/*      */     
/* 1263 */     int passwordLength = 16;
/* 1264 */     int userLength = (user != null) ? user.length() : 0;
/* 1265 */     int databaseLength = (database != null) ? database.length() : 0;
/*      */     
/* 1267 */     int packLength = (userLength + passwordLength + databaseLength) * 3 + 7 + 4 + 33;
/*      */     
/* 1269 */     Buffer packet = null;
/*      */     
/* 1271 */     if (!this.connection.getUseSSL()) {
/* 1272 */       if ((this.serverCapabilities & 0x8000) != 0) {
/* 1273 */         this.clientParam |= 0x8000L;
/*      */         
/* 1275 */         if (versionMeetsMinimum(4, 1, 1) || (this.protocolVersion > 9 && (this.serverCapabilities & 0x200) != 0)) {
/* 1276 */           secureAuth411(null, packLength, user, password, database, true, false);
/*      */         } else {
/* 1278 */           secureAuth(null, packLength, user, password, database, true);
/*      */         } 
/*      */       } else {
/*      */         
/* 1282 */         packet = new Buffer(packLength);
/*      */         
/* 1284 */         if ((this.clientParam & 0x4000L) != 0L) {
/* 1285 */           if (versionMeetsMinimum(4, 1, 1) || (this.protocolVersion > 9 && (this.serverCapabilities & 0x200) != 0)) {
/* 1286 */             packet.writeLong(this.clientParam);
/* 1287 */             packet.writeLong(this.maxThreeBytes);
/*      */ 
/*      */             
/* 1290 */             packet.writeByte((byte)8);
/*      */ 
/*      */             
/* 1293 */             packet.writeBytesNoNull(new byte[23]);
/*      */           } else {
/* 1295 */             packet.writeLong(this.clientParam);
/* 1296 */             packet.writeLong(this.maxThreeBytes);
/*      */           } 
/*      */         } else {
/* 1299 */           packet.writeInt((int)this.clientParam);
/* 1300 */           packet.writeLongInt(this.maxThreeBytes);
/*      */         } 
/*      */ 
/*      */         
/* 1304 */         packet.writeString(user, "Cp1252", this.connection);
/*      */         
/* 1306 */         if (this.protocolVersion > 9) {
/* 1307 */           packet.writeString(Util.newCrypt(password, this.seed, this.connection.getPasswordCharacterEncoding()), "Cp1252", this.connection);
/*      */         } else {
/* 1309 */           packet.writeString(Util.oldCrypt(password, this.seed), "Cp1252", this.connection);
/*      */         } 
/*      */         
/* 1312 */         if (this.useConnectWithDb) {
/* 1313 */           packet.writeString(database, "Cp1252", this.connection);
/*      */         }
/*      */         
/* 1316 */         send(packet, packet.getPosition());
/*      */       } 
/*      */     } else {
/* 1319 */       negotiateSSLConnection(user, password, database, packLength);
/*      */       
/* 1321 */       if ((this.serverCapabilities & 0x8000) != 0) {
/* 1322 */         if (versionMeetsMinimum(4, 1, 1)) {
/* 1323 */           secureAuth411(null, packLength, user, password, database, true, false);
/*      */         } else {
/* 1325 */           secureAuth411(null, packLength, user, password, database, true, false);
/*      */         } 
/*      */       } else {
/*      */         
/* 1329 */         packet = new Buffer(packLength);
/*      */         
/* 1331 */         if (this.use41Extensions) {
/* 1332 */           packet.writeLong(this.clientParam);
/* 1333 */           packet.writeLong(this.maxThreeBytes);
/*      */         } else {
/* 1335 */           packet.writeInt((int)this.clientParam);
/* 1336 */           packet.writeLongInt(this.maxThreeBytes);
/*      */         } 
/*      */ 
/*      */         
/* 1340 */         packet.writeString(user);
/*      */         
/* 1342 */         if (this.protocolVersion > 9) {
/* 1343 */           packet.writeString(Util.newCrypt(password, this.seed, this.connection.getPasswordCharacterEncoding()));
/*      */         } else {
/* 1345 */           packet.writeString(Util.oldCrypt(password, this.seed));
/*      */         } 
/*      */         
/* 1348 */         if ((this.serverCapabilities & 0x8) != 0 && database != null && database.length() > 0) {
/* 1349 */           packet.writeString(database);
/*      */         }
/*      */         
/* 1352 */         send(packet, packet.getPosition());
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1357 */     if (!versionMeetsMinimum(4, 1, 1) || this.protocolVersion <= 9 || (this.serverCapabilities & 0x200) == 0) {
/* 1358 */       checkErrorPacket();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1364 */     if ((this.serverCapabilities & 0x20) != 0 && this.connection.getUseCompression() && !(this.mysqlInput instanceof CompressedInputStream)) {
/*      */       
/* 1366 */       this.deflater = new Deflater();
/* 1367 */       this.useCompression = true;
/* 1368 */       this.mysqlInput = new CompressedInputStream(this.connection, this.mysqlInput);
/*      */     } 
/*      */     
/* 1371 */     if (!this.useConnectWithDb) {
/* 1372 */       changeDatabaseTo(database);
/*      */     }
/*      */ 
/*      */     
/* 1376 */     try { this.mysqlConnection = this.socketFactory.afterHandshake(); }
/* 1377 */     catch (IOException ioEx)
/* 1378 */     { throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor()); } 
/*      */   } private void loadAuthenticationPlugins() throws SQLException { this.clientDefaultAuthenticationPlugin = this.connection.getDefaultAuthenticationPlugin(); if (this.clientDefaultAuthenticationPlugin == null || "".equals(this.clientDefaultAuthenticationPlugin.trim())) throw SQLError.createSQLException(Messages.getString("Connection.BadDefaultAuthenticationPlugin", new Object[] { this.clientDefaultAuthenticationPlugin }), getExceptionInterceptor());  String disabledPlugins = this.connection.getDisabledAuthenticationPlugins(); if (disabledPlugins != null && !"".equals(disabledPlugins)) { this.disabledAuthenticationPlugins = new ArrayList<String>(); List<String> pluginsToDisable = StringUtils.split(disabledPlugins, ",", true); Iterator<String> iter = pluginsToDisable.iterator(); while (iter.hasNext()) this.disabledAuthenticationPlugins.add(iter.next());  }  this.authenticationPlugins = new HashMap<String, AuthenticationPlugin>(); MysqlOldPasswordPlugin mysqlOldPasswordPlugin = new MysqlOldPasswordPlugin(); mysqlOldPasswordPlugin.init(this.connection, this.connection.getProperties()); boolean defaultIsFound = addAuthenticationPlugin((AuthenticationPlugin)mysqlOldPasswordPlugin); MysqlNativePasswordPlugin mysqlNativePasswordPlugin = new MysqlNativePasswordPlugin(); mysqlNativePasswordPlugin.init(this.connection, this.connection.getProperties()); if (addAuthenticationPlugin((AuthenticationPlugin)mysqlNativePasswordPlugin)) defaultIsFound = true;  MysqlClearPasswordPlugin mysqlClearPasswordPlugin = new MysqlClearPasswordPlugin(); mysqlClearPasswordPlugin.init(this.connection, this.connection.getProperties()); if (addAuthenticationPlugin((AuthenticationPlugin)mysqlClearPasswordPlugin)) defaultIsFound = true;  Sha256PasswordPlugin sha256PasswordPlugin = new Sha256PasswordPlugin(); sha256PasswordPlugin.init(this.connection, this.connection.getProperties()); if (addAuthenticationPlugin((AuthenticationPlugin)sha256PasswordPlugin)) defaultIsFound = true;  CachingSha2PasswordPlugin cachingSha2PasswordPlugin = new CachingSha2PasswordPlugin(); cachingSha2PasswordPlugin.init(this.connection, this.connection.getProperties()); if (addAuthenticationPlugin((AuthenticationPlugin)cachingSha2PasswordPlugin))
/*      */       defaultIsFound = true;  String authenticationPluginClasses = this.connection.getAuthenticationPlugins(); if (authenticationPluginClasses != null && !"".equals(authenticationPluginClasses)) { List<Extension> plugins = Util.loadExtensions(this.connection, this.connection.getProperties(), authenticationPluginClasses, "Connection.BadAuthenticationPlugin", getExceptionInterceptor()); for (Extension object : plugins) { AuthenticationPlugin authenticationPlugin = (AuthenticationPlugin)object; if (addAuthenticationPlugin(authenticationPlugin))
/*      */           defaultIsFound = true;  }  }  if (!defaultIsFound)
/*      */       throw SQLError.createSQLException(Messages.getString("Connection.DefaultAuthenticationPluginIsNotListed", new Object[] { this.clientDefaultAuthenticationPlugin }), getExceptionInterceptor());  } private boolean addAuthenticationPlugin(AuthenticationPlugin plugin) throws SQLException { boolean isDefault = false; String pluginClassName = plugin.getClass().getName(); String pluginProtocolName = plugin.getProtocolPluginName(); boolean disabledByClassName = (this.disabledAuthenticationPlugins != null && this.disabledAuthenticationPlugins.contains(pluginClassName)); boolean disabledByMechanism = (this.disabledAuthenticationPlugins != null && this.disabledAuthenticationPlugins.contains(pluginProtocolName)); if (disabledByClassName || disabledByMechanism) { if (this.clientDefaultAuthenticationPlugin.equals(pluginClassName))
/*      */         throw SQLError.createSQLException(Messages.getString("Connection.BadDisabledAuthenticationPlugin", new Object[] { disabledByClassName ? pluginClassName : pluginProtocolName }), getExceptionInterceptor());  } else { this.authenticationPlugins.put(pluginProtocolName, plugin); if (this.clientDefaultAuthenticationPlugin.equals(pluginClassName)) { this.clientDefaultAuthenticationPluginName = pluginProtocolName; isDefault = true; }  }  return isDefault; }
/*      */   private AuthenticationPlugin getAuthenticationPlugin(String pluginName) throws SQLException { AuthenticationPlugin plugin = this.authenticationPlugins.get(pluginName); if (plugin != null && !plugin.isReusable())
/*      */       try { plugin = (AuthenticationPlugin)plugin.getClass().newInstance(); plugin.init(this.connection, this.connection.getProperties()); } catch (Throwable t) { SQLException sqlEx = SQLError.createSQLException(Messages.getString("Connection.BadAuthenticationPlugin", new Object[] { plugin.getClass().getName() }), getExceptionInterceptor()); sqlEx.initCause(t); throw sqlEx; }   return plugin; }
/*      */   private void checkConfidentiality(AuthenticationPlugin plugin) throws SQLException { if (plugin.requiresConfidentiality() && !isSSLEstablished())
/*      */       throw SQLError.createSQLException(Messages.getString("Connection.AuthenticationPluginRequiresSSL", new Object[] { plugin.getProtocolPluginName() }), getExceptionInterceptor());  }
/* 1388 */   public MysqlIO(String host, int port, Properties props, String socketFactoryClassName, MySQLConnection conn, int socketTimeout, int useBufferRowSizeThreshold) throws IOException, SQLException { this.authenticationPlugins = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1393 */     this.disabledAuthenticationPlugins = null;
/*      */ 
/*      */ 
/*      */     
/* 1397 */     this.clientDefaultAuthenticationPlugin = null;
/*      */ 
/*      */ 
/*      */     
/* 1401 */     this.clientDefaultAuthenticationPluginName = null;
/*      */ 
/*      */ 
/*      */     
/* 1405 */     this.serverDefaultAuthenticationPluginName = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2555 */     this.statementExecutionDepth = 0; this.connection = conn; if (this.connection.getEnablePacketDebug()) this.packetDebugRingBuffer = new LinkedList<StringBuilder>();  this.traceProtocol = this.connection.getTraceProtocol(); this.useAutoSlowLog = this.connection.getAutoSlowLog(); this.useBufferRowSizeThreshold = useBufferRowSizeThreshold; this.useDirectRowUnpack = this.connection.getUseDirectRowUnpack(); this.logSlowQueries = this.connection.getLogSlowQueries(); this.reusablePacket = new Buffer(1024); this.sendPacket = new Buffer(1024); this.port = port; this.host = host; this.socketFactoryClassName = socketFactoryClassName; this.socketFactory = createSocketFactory(); this.exceptionInterceptor = this.connection.getExceptionInterceptor(); try { this.mysqlConnection = this.socketFactory.connect(this.host, this.port, props); if (socketTimeout != 0) try { this.mysqlConnection.setSoTimeout(socketTimeout); } catch (Exception ex) {}  this.mysqlConnection = this.socketFactory.beforeHandshake(); if (this.connection.getUseReadAheadInput()) { this.mysqlInput = (InputStream)new ReadAheadInputStream(this.mysqlConnection.getInputStream(), 16384, this.connection.getTraceProtocol(), this.connection.getLog()); } else if (this.connection.useUnbufferedInput()) { this.mysqlInput = this.mysqlConnection.getInputStream(); } else { this.mysqlInput = new BufferedInputStream(this.mysqlConnection.getInputStream(), 16384); }  this.mysqlOutput = new BufferedOutputStream(this.mysqlConnection.getOutputStream(), 16384); this.isInteractiveClient = this.connection.getInteractiveClient(); this.profileSql = this.connection.getProfileSql(); this.autoGenerateTestcaseScript = this.connection.getAutoGenerateTestcaseScript(); this.needToGrabQueryFromPacket = (this.profileSql || this.logSlowQueries || this.autoGenerateTestcaseScript); if (this.connection.getUseNanosForElapsedTime() && TimeUtil.nanoTimeAvailable()) { this.useNanosForElapsedTime = true; this.queryTimingUnits = Messages.getString("Nanoseconds"); } else { this.queryTimingUnits = Messages.getString("Milliseconds"); }  if (this.connection.getLogSlowQueries()) calculateSlowQueryThreshold();  } catch (IOException ioEx) { throw SQLError.createCommunicationsException(this.connection, 0L, 0L, ioEx, getExceptionInterceptor()); }  } private void proceedHandshakeWithPluggableAuthentication(String user, String password, String database, Buffer challenge) throws SQLException { if (this.authenticationPlugins == null) loadAuthenticationPlugins();  boolean skipPassword = false; int passwordLength = 16; int userLength = (user != null) ? user.length() : 0; int databaseLength = (database != null) ? database.length() : 0; int packLength = (userLength + passwordLength + databaseLength) * 3 + 7 + 4 + 33; AuthenticationPlugin plugin = null; Buffer fromServer = null; ArrayList<Buffer> toServer = new ArrayList<Buffer>(); boolean done = false; Buffer last_sent = null; boolean old_raw_challenge = false; int counter = 100; while (0 < counter--) { if (!done) { if (challenge != null) { if (challenge.isOKPacket()) throw SQLError.createSQLException(Messages.getString("Connection.UnexpectedAuthenticationApproval", new Object[] { plugin.getProtocolPluginName() }), getExceptionInterceptor());  this.clientParam |= 0xAA201L; if (this.connection.getAllowMultiQueries()) this.clientParam |= 0x10000L;  if ((this.serverCapabilities & 0x400000) != 0 && !this.connection.getDisconnectOnExpiredPasswords()) this.clientParam |= 0x400000L;  if ((this.serverCapabilities & 0x100000) != 0 && !"none".equals(this.connection.getConnectionAttributes())) this.clientParam |= 0x100000L;  if ((this.serverCapabilities & 0x200000) != 0) this.clientParam |= 0x200000L;  this.has41NewNewProt = true; this.use41Extensions = true; if (this.connection.getUseSSL()) negotiateSSLConnection(user, password, database, packLength);  String pluginName = null; if ((this.serverCapabilities & 0x80000) != 0) if (!versionMeetsMinimum(5, 5, 10) || (versionMeetsMinimum(5, 6, 0) && !versionMeetsMinimum(5, 6, 2))) { pluginName = challenge.readString("ASCII", getExceptionInterceptor(), this.authPluginDataLength); } else { pluginName = challenge.readString("ASCII", getExceptionInterceptor()); }   plugin = getAuthenticationPlugin(pluginName); if (plugin == null) { plugin = getAuthenticationPlugin(this.clientDefaultAuthenticationPluginName); } else if (pluginName.equals(Sha256PasswordPlugin.PLUGIN_NAME) && !isSSLEstablished() && this.connection.getServerRSAPublicKeyFile() == null && !this.connection.getAllowPublicKeyRetrieval()) { plugin = getAuthenticationPlugin(this.clientDefaultAuthenticationPluginName); skipPassword = !this.clientDefaultAuthenticationPluginName.equals(pluginName); }  this.serverDefaultAuthenticationPluginName = plugin.getProtocolPluginName(); checkConfidentiality(plugin); fromServer = new Buffer(StringUtils.getBytes(this.seed)); } else { plugin = getAuthenticationPlugin((this.serverDefaultAuthenticationPluginName == null) ? this.clientDefaultAuthenticationPluginName : this.serverDefaultAuthenticationPluginName); checkConfidentiality(plugin); fromServer = new Buffer(StringUtils.getBytes(this.seed)); }  } else { challenge = checkErrorPacket(); old_raw_challenge = false; this.packetSequence = (byte)(this.packetSequence + 1); this.compressedPacketSequence = (byte)(this.compressedPacketSequence + 1); if (plugin == null) plugin = getAuthenticationPlugin((this.serverDefaultAuthenticationPluginName != null) ? this.serverDefaultAuthenticationPluginName : this.clientDefaultAuthenticationPluginName);  if (challenge.isOKPacket()) { challenge.newReadLength(); challenge.newReadLength(); this.oldServerStatus = this.serverStatus; this.serverStatus = challenge.readInt(); plugin.destroy(); break; }  if (challenge.isAuthMethodSwitchRequestPacket()) { skipPassword = false; String pluginName = challenge.readString("ASCII", getExceptionInterceptor()); if (!plugin.getProtocolPluginName().equals(pluginName)) { plugin.destroy(); plugin = getAuthenticationPlugin(pluginName); if (plugin == null) throw SQLError.createSQLException(Messages.getString("Connection.BadAuthenticationPlugin", new Object[] { pluginName }), getExceptionInterceptor());  } else { plugin.reset(); }  checkConfidentiality(plugin); fromServer = new Buffer(StringUtils.getBytes(challenge.readString("ASCII", getExceptionInterceptor()))); } else if (versionMeetsMinimum(5, 5, 16)) { fromServer = new Buffer(challenge.getBytes(challenge.getPosition(), challenge.getBufLength() - challenge.getPosition())); } else { old_raw_challenge = true; fromServer = new Buffer(challenge.getBytes(challenge.getPosition() - 1, challenge.getBufLength() - challenge.getPosition() + 1)); }  }  try { plugin.setAuthenticationParameters(user, skipPassword ? null : password); done = plugin.nextAuthenticationStep(fromServer, toServer); } catch (SQLException e) { throw SQLError.createSQLException(e.getMessage(), e.getSQLState(), e, getExceptionInterceptor()); }  if (toServer.size() > 0) { if (challenge == null) { String str = getEncodingForHandshake(); last_sent = new Buffer(packLength + 1); last_sent.writeByte((byte)17); last_sent.writeString(user, str, this.connection); if (((Buffer)toServer.get(0)).getBufLength() < 256) { last_sent.writeByte((byte)((Buffer)toServer.get(0)).getBufLength()); last_sent.writeBytesNoNull(((Buffer)toServer.get(0)).getByteBuffer(), 0, ((Buffer)toServer.get(0)).getBufLength()); } else { last_sent.writeByte((byte)0); }  if (this.useConnectWithDb) { last_sent.writeString(database, str, this.connection); } else { last_sent.writeByte((byte)0); }  appendCharsetByteForHandshake(last_sent, str); last_sent.writeByte((byte)0); if ((this.serverCapabilities & 0x80000) != 0) last_sent.writeString(plugin.getProtocolPluginName(), str, this.connection);  if ((this.clientParam & 0x100000L) != 0L) { sendConnectionAttributes(last_sent, str, this.connection); last_sent.writeByte((byte)0); }  send(last_sent, last_sent.getPosition()); continue; }  if (challenge.isAuthMethodSwitchRequestPacket()) { last_sent = new Buffer(((Buffer)toServer.get(0)).getBufLength() + 4); last_sent.writeBytesNoNull(((Buffer)toServer.get(0)).getByteBuffer(), 0, ((Buffer)toServer.get(0)).getBufLength()); send(last_sent, last_sent.getPosition()); continue; }  if (challenge.isRawPacket() || old_raw_challenge) { for (Buffer buffer : toServer) { last_sent = new Buffer(buffer.getBufLength() + 4); last_sent.writeBytesNoNull(buffer.getByteBuffer(), 0, ((Buffer)toServer.get(0)).getBufLength()); send(last_sent, last_sent.getPosition()); }  continue; }  String enc = getEncodingForHandshake(); last_sent = new Buffer(packLength); last_sent.writeLong(this.clientParam); last_sent.writeLong(this.maxThreeBytes); appendCharsetByteForHandshake(last_sent, enc); last_sent.writeBytesNoNull(new byte[23]); last_sent.writeString(user, enc, this.connection); if ((this.serverCapabilities & 0x200000) != 0) { last_sent.writeLenBytes(((Buffer)toServer.get(0)).getBytes(((Buffer)toServer.get(0)).getBufLength())); } else { last_sent.writeByte((byte)((Buffer)toServer.get(0)).getBufLength()); last_sent.writeBytesNoNull(((Buffer)toServer.get(0)).getByteBuffer(), 0, ((Buffer)toServer.get(0)).getBufLength()); }  if (this.useConnectWithDb) last_sent.writeString(database, enc, this.connection);  if ((this.serverCapabilities & 0x80000) != 0) last_sent.writeString(plugin.getProtocolPluginName(), enc, this.connection);  if ((this.clientParam & 0x100000L) != 0L) sendConnectionAttributes(last_sent, enc, this.connection);  send(last_sent, last_sent.getPosition()); }  }  if (counter == 0) throw SQLError.createSQLException(Messages.getString("CommunicationsException.TooManyAuthenticationPluginNegotiations"), getExceptionInterceptor());  if ((this.serverCapabilities & 0x20) != 0 && this.connection.getUseCompression() && !(this.mysqlInput instanceof CompressedInputStream)) { this.deflater = new Deflater(); this.useCompression = true; this.mysqlInput = new CompressedInputStream(this.connection, this.mysqlInput); }  if (!this.useConnectWithDb) changeDatabaseTo(database);  try { this.mysqlConnection = this.socketFactory.afterHandshake(); } catch (IOException ioEx) { throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor()); }  }
/*      */   private Properties getConnectionAttributesAsProperties(String atts) throws SQLException { Properties props = new Properties(); if (atts != null) { String[] pairs = atts.split(","); for (String pair : pairs) { int keyEnd = pair.indexOf(":"); if (keyEnd > 0 && keyEnd + 1 < pair.length()) props.setProperty(pair.substring(0, keyEnd), pair.substring(keyEnd + 1));  }  }  props.setProperty("_client_name", "MySQL Connector Java"); props.setProperty("_client_version", "5.1.47"); props.setProperty("_runtime_vendor", NonRegisteringDriver.RUNTIME_VENDOR); props.setProperty("_runtime_version", NonRegisteringDriver.RUNTIME_VERSION); props.setProperty("_client_license", "GPL"); return props; }
/*      */   private void sendConnectionAttributes(Buffer buf, String enc, MySQLConnection conn) throws SQLException { String atts = conn.getConnectionAttributes(); Buffer lb = new Buffer(100); try { Properties props = getConnectionAttributesAsProperties(atts); for (Object key : props.keySet()) { lb.writeLenString((String)key, enc, conn.getServerCharset(), null, conn.parserKnowsUnicode(), conn); lb.writeLenString(props.getProperty((String)key), enc, conn.getServerCharset(), null, conn.parserKnowsUnicode(), conn); }  } catch (UnsupportedEncodingException e) {} buf.writeByte((byte)(lb.getPosition() - 4)); buf.writeBytesNoNull(lb.getByteBuffer(), 4, lb.getBufLength() - 4); }
/*      */   private void changeDatabaseTo(String database) throws SQLException { if (database == null || database.length() == 0) return;  try { sendCommand(2, database, null, false, null, 0); } catch (Exception ex) { if (this.connection.getCreateDatabaseIfNotExist()) { sendCommand(3, "CREATE DATABASE IF NOT EXISTS " + database, null, false, null, 0); sendCommand(2, database, null, false, null, 0); } else { throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ex, getExceptionInterceptor()); }  }  }
/* 2559 */   protected boolean shouldIntercept() { return (this.statementInterceptors != null); }
/*      */   final ResultSetRow nextRow(Field[] fields, int columnCount, boolean isBinaryEncoded, int resultSetConcurrency, boolean useBufferRowIfPossible, boolean useBufferRowExplicit, boolean canReuseRowPacketForBufferRow, Buffer existingRowPacket) throws SQLException { if (this.useDirectRowUnpack && existingRowPacket == null && !isBinaryEncoded && !useBufferRowIfPossible && !useBufferRowExplicit)
/*      */       return nextRowFast(fields, columnCount, isBinaryEncoded, resultSetConcurrency, useBufferRowIfPossible, useBufferRowExplicit, canReuseRowPacketForBufferRow);  Buffer rowPacket = null; if (existingRowPacket == null) { rowPacket = checkErrorPacket(); if (!useBufferRowExplicit && useBufferRowIfPossible && rowPacket.getBufLength() > this.useBufferRowSizeThreshold)
/*      */         useBufferRowExplicit = true;  } else { rowPacket = existingRowPacket; checkErrorPacket(existingRowPacket); }  if (!isBinaryEncoded) { rowPacket.setPosition(rowPacket.getPosition() - 1); if ((isEOFDeprecated() || !rowPacket.isEOFPacket()) && (!isEOFDeprecated() || !rowPacket.isResultSetOKPacket())) { if (resultSetConcurrency == 1008 || (!useBufferRowIfPossible && !useBufferRowExplicit)) { byte[][] rowData = new byte[columnCount][]; for (int i = 0; i < columnCount; i++)
/*      */             rowData[i] = rowPacket.readLenByteArray(0);  return new ByteArrayRow(rowData, getExceptionInterceptor()); }  if (!canReuseRowPacketForBufferRow)
/*      */           this.reusablePacket = new Buffer(rowPacket.getBufLength());  return new BufferRow(rowPacket, fields, false, getExceptionInterceptor()); }  readServerStatusForResultSets(rowPacket); return null; }  if ((isEOFDeprecated() || !rowPacket.isEOFPacket()) && (!isEOFDeprecated() || !rowPacket.isResultSetOKPacket())) { if (resultSetConcurrency == 1008 || (!useBufferRowIfPossible && !useBufferRowExplicit))
/*      */         return unpackBinaryResultSetRow(fields, rowPacket, resultSetConcurrency);  if (!canReuseRowPacketForBufferRow)
/*      */         this.reusablePacket = new Buffer(rowPacket.getBufLength());  return new BufferRow(rowPacket, fields, true, getExceptionInterceptor()); }  rowPacket.setPosition(rowPacket.getPosition() - 1); readServerStatusForResultSets(rowPacket); return null; }
/*      */   final ResultSetRow nextRowFast(Field[] fields, int columnCount, boolean isBinaryEncoded, int resultSetConcurrency, boolean useBufferRowIfPossible, boolean useBufferRowExplicit, boolean canReuseRowPacket) throws SQLException { try { int lengthRead = readFully(this.mysqlInput, this.packetHeaderBuf, 0, 4); if (lengthRead < 4) { forceClose(); throw new RuntimeException(Messages.getString("MysqlIO.43")); }  int packetLength = (this.packetHeaderBuf[0] & 0xFF) + ((this.packetHeaderBuf[1] & 0xFF) << 8) + ((this.packetHeaderBuf[2] & 0xFF) << 16); if (packetLength == this.maxThreeBytes) { reuseAndReadPacket(this.reusablePacket, packetLength); return nextRow(fields, columnCount, isBinaryEncoded, resultSetConcurrency, useBufferRowIfPossible, useBufferRowExplicit, canReuseRowPacket, this.reusablePacket); }  if (packetLength > this.useBufferRowSizeThreshold) { reuseAndReadPacket(this.reusablePacket, packetLength); return nextRow(fields, columnCount, isBinaryEncoded, resultSetConcurrency, true, true, false, this.reusablePacket); }  int remaining = packetLength; boolean firstTime = true; byte[][] rowData = (byte[][])null; for (int i = 0; i < columnCount; i++) { int sw = this.mysqlInput.read() & 0xFF; remaining--; if (firstTime) { if (sw == 255) { Buffer errorPacket = new Buffer(packetLength + 4); errorPacket.setPosition(0); errorPacket.writeByte(this.packetHeaderBuf[0]); errorPacket.writeByte(this.packetHeaderBuf[1]); errorPacket.writeByte(this.packetHeaderBuf[2]); errorPacket.writeByte((byte)1); errorPacket.writeByte((byte)sw); readFully(this.mysqlInput, errorPacket.getByteBuffer(), 5, packetLength - 1); errorPacket.setPosition(4); checkErrorPacket(errorPacket); }  if (sw == 254 && packetLength < 16777215) { if (this.use41Extensions) { if (isEOFDeprecated()) { remaining -= skipLengthEncodedInteger(this.mysqlInput); remaining -= skipLengthEncodedInteger(this.mysqlInput); this.oldServerStatus = this.serverStatus; this.serverStatus = this.mysqlInput.read() & 0xFF | (this.mysqlInput.read() & 0xFF) << 8; checkTransactionState(this.oldServerStatus); remaining -= 2; this.warningCount = this.mysqlInput.read() & 0xFF | (this.mysqlInput.read() & 0xFF) << 8; remaining -= 2; if (this.warningCount > 0)
/*      */                   this.hadWarnings = true;  } else { this.warningCount = this.mysqlInput.read() & 0xFF | (this.mysqlInput.read() & 0xFF) << 8; remaining -= 2; if (this.warningCount > 0)
/*      */                   this.hadWarnings = true;  this.oldServerStatus = this.serverStatus; this.serverStatus = this.mysqlInput.read() & 0xFF | (this.mysqlInput.read() & 0xFF) << 8; checkTransactionState(this.oldServerStatus); remaining -= 2; }  setServerSlowQueryFlags(); if (remaining > 0)
/*      */                 skipFully(this.mysqlInput, remaining);  }  return null; }  rowData = new byte[columnCount][]; firstTime = false; }  int len = 0; switch (sw) { case 251: len = -1; break;
/*      */           case 252: len = this.mysqlInput.read() & 0xFF | (this.mysqlInput.read() & 0xFF) << 8; remaining -= 2; break;
/*      */           case 253: len = this.mysqlInput.read() & 0xFF | (this.mysqlInput.read() & 0xFF) << 8 | (this.mysqlInput.read() & 0xFF) << 16; remaining -= 3; break;
/*      */           case 254:
/*      */             len = (int)((this.mysqlInput.read() & 0xFF) | (this.mysqlInput.read() & 0xFF) << 8L | (this.mysqlInput.read() & 0xFF) << 16L | (this.mysqlInput.read() & 0xFF) << 24L | (this.mysqlInput.read() & 0xFF) << 32L | (this.mysqlInput.read() & 0xFF) << 40L | (this.mysqlInput.read() & 0xFF) << 48L | (this.mysqlInput.read() & 0xFF) << 56L); remaining -= 8; break;
/*      */           default:
/*      */             len = sw; break; }  if (len == -1) { rowData[i] = null; } else if (len == 0) { rowData[i] = Constants.EMPTY_BYTE_ARRAY; } else { rowData[i] = new byte[len]; int bytesRead = readFully(this.mysqlInput, rowData[i], 0, len); if (bytesRead != len)
/*      */             throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, new IOException(Messages.getString("MysqlIO.43")), getExceptionInterceptor());  remaining -= bytesRead; }  }  if (remaining > 0)
/*      */         skipFully(this.mysqlInput, remaining);  return new ByteArrayRow(rowData, getExceptionInterceptor()); } catch (IOException ioEx) { throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor()); }  }
/*      */   final void quit() throws SQLException { try { if (!this.mysqlConnection.isClosed())
/*      */         try { this.mysqlConnection.shutdownInput(); } catch (UnsupportedOperationException ex) {}  } catch (IOException ioEx) { this.connection.getLog().logWarn("Caught while disconnecting...", ioEx); } finally { forceClose(); }  }
/*      */   Buffer getSharedSendPacket() { if (this.sharedSendPacket == null)
/* 2582 */       this.sharedSendPacket = new Buffer(1024);  return this.sharedSendPacket; } final ResultSetInternalMethods sqlQueryDirect(StatementImpl callingStatement, String query, String characterEncoding, Buffer queryPacket, int maxRows, int resultSetType, int resultSetConcurrency, boolean streamResults, String catalog, Field[] cachedMetadata) throws Exception { this.statementExecutionDepth++;
/*      */ 
/*      */     
/* 2585 */     try { if (this.statementInterceptors != null) {
/* 2586 */         ResultSetInternalMethods interceptedResults = invokeStatementInterceptorsPre(query, callingStatement, false);
/*      */         
/* 2588 */         if (interceptedResults != null) {
/* 2589 */           return interceptedResults;
/*      */         }
/*      */       } 
/*      */       
/* 2593 */       long queryStartTime = 0L;
/* 2594 */       long queryEndTime = 0L;
/*      */       
/* 2596 */       String statementComment = this.connection.getStatementComment();
/*      */       
/* 2598 */       if (this.connection.getIncludeThreadNamesAsStatementComment()) {
/* 2599 */         statementComment = ((statementComment != null) ? (statementComment + ", ") : "") + "java thread: " + Thread.currentThread().getName();
/*      */       }
/*      */       
/* 2602 */       if (query != null) {
/*      */ 
/*      */         
/* 2605 */         int packLength = 5 + query.length() * 3 + 2;
/*      */         
/* 2607 */         byte[] commentAsBytes = null;
/*      */         
/* 2609 */         if (statementComment != null) {
/* 2610 */           commentAsBytes = StringUtils.getBytes(statementComment, (SingleByteCharsetConverter)null, characterEncoding, this.connection.getServerCharset(), this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */ 
/*      */           
/* 2613 */           packLength += commentAsBytes.length;
/* 2614 */           packLength += 6;
/*      */         } 
/*      */         
/* 2617 */         if (this.sendPacket == null) {
/* 2618 */           this.sendPacket = new Buffer(packLength);
/*      */         } else {
/* 2620 */           this.sendPacket.clear();
/*      */         } 
/*      */         
/* 2623 */         this.sendPacket.writeByte((byte)3);
/*      */         
/* 2625 */         if (commentAsBytes != null) {
/* 2626 */           this.sendPacket.writeBytesNoNull(Constants.SLASH_STAR_SPACE_AS_BYTES);
/* 2627 */           this.sendPacket.writeBytesNoNull(commentAsBytes);
/* 2628 */           this.sendPacket.writeBytesNoNull(Constants.SPACE_STAR_SLASH_SPACE_AS_BYTES);
/*      */         } 
/*      */         
/* 2631 */         if (characterEncoding != null) {
/* 2632 */           if (this.platformDbCharsetMatches) {
/* 2633 */             this.sendPacket.writeStringNoNull(query, characterEncoding, this.connection.getServerCharset(), this.connection.parserKnowsUnicode(), this.connection);
/*      */           
/*      */           }
/* 2636 */           else if (StringUtils.startsWithIgnoreCaseAndWs(query, "LOAD DATA")) {
/* 2637 */             this.sendPacket.writeBytesNoNull(StringUtils.getBytes(query));
/*      */           } else {
/* 2639 */             this.sendPacket.writeStringNoNull(query, characterEncoding, this.connection.getServerCharset(), this.connection.parserKnowsUnicode(), this.connection);
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/* 2644 */           this.sendPacket.writeStringNoNull(query);
/*      */         } 
/*      */         
/* 2647 */         queryPacket = this.sendPacket;
/*      */       } 
/*      */       
/* 2650 */       byte[] queryBuf = null;
/* 2651 */       int oldPacketPosition = 0;
/*      */       
/* 2653 */       if (this.needToGrabQueryFromPacket) {
/* 2654 */         queryBuf = queryPacket.getByteBuffer();
/*      */ 
/*      */         
/* 2657 */         oldPacketPosition = queryPacket.getPosition();
/*      */         
/* 2659 */         queryStartTime = getCurrentTimeNanosOrMillis();
/*      */       } 
/*      */       
/* 2662 */       if (this.autoGenerateTestcaseScript) {
/* 2663 */         String testcaseQuery = null;
/*      */         
/* 2665 */         if (query != null) {
/* 2666 */           if (statementComment != null) {
/* 2667 */             testcaseQuery = "/* " + statementComment + " */ " + query;
/*      */           } else {
/* 2669 */             testcaseQuery = query;
/*      */           } 
/*      */         } else {
/* 2672 */           testcaseQuery = StringUtils.toString(queryBuf, 5, oldPacketPosition - 5);
/*      */         } 
/*      */         
/* 2675 */         StringBuilder debugBuf = new StringBuilder(testcaseQuery.length() + 32);
/* 2676 */         this.connection.generateConnectionCommentBlock(debugBuf);
/* 2677 */         debugBuf.append(testcaseQuery);
/* 2678 */         debugBuf.append(';');
/* 2679 */         this.connection.dumpTestcaseQuery(debugBuf.toString());
/*      */       } 
/*      */ 
/*      */       
/* 2683 */       Buffer resultPacket = sendCommand(3, null, queryPacket, false, null, 0);
/*      */       
/* 2685 */       long fetchBeginTime = 0L;
/* 2686 */       long fetchEndTime = 0L;
/*      */       
/* 2688 */       String profileQueryToLog = null;
/*      */       
/* 2690 */       boolean queryWasSlow = false;
/*      */       
/* 2692 */       if (this.profileSql || this.logSlowQueries) {
/* 2693 */         queryEndTime = getCurrentTimeNanosOrMillis();
/*      */         
/* 2695 */         boolean shouldExtractQuery = false;
/*      */         
/* 2697 */         if (this.profileSql) {
/* 2698 */           shouldExtractQuery = true;
/* 2699 */         } else if (this.logSlowQueries) {
/* 2700 */           long queryTime = queryEndTime - queryStartTime;
/*      */           
/* 2702 */           boolean logSlow = false;
/*      */           
/* 2704 */           if (!this.useAutoSlowLog) {
/* 2705 */             logSlow = (queryTime > this.connection.getSlowQueryThresholdMillis());
/*      */           } else {
/* 2707 */             logSlow = this.connection.isAbonormallyLongQuery(queryTime);
/*      */             
/* 2709 */             this.connection.reportQueryTime(queryTime);
/*      */           } 
/*      */           
/* 2712 */           if (logSlow) {
/* 2713 */             shouldExtractQuery = true;
/* 2714 */             queryWasSlow = true;
/*      */           } 
/*      */         } 
/*      */         
/* 2718 */         if (shouldExtractQuery) {
/*      */           
/* 2720 */           boolean truncated = false;
/*      */           
/* 2722 */           int extractPosition = oldPacketPosition;
/*      */           
/* 2724 */           if (oldPacketPosition > this.connection.getMaxQuerySizeToLog()) {
/* 2725 */             extractPosition = this.connection.getMaxQuerySizeToLog() + 5;
/* 2726 */             truncated = true;
/*      */           } 
/*      */           
/* 2729 */           profileQueryToLog = StringUtils.toString(queryBuf, 5, extractPosition - 5);
/*      */           
/* 2731 */           if (truncated) {
/* 2732 */             profileQueryToLog = profileQueryToLog + Messages.getString("MysqlIO.25");
/*      */           }
/*      */         } 
/*      */         
/* 2736 */         fetchBeginTime = queryEndTime;
/*      */       } 
/*      */       
/* 2739 */       ResultSetInternalMethods rs = readAllResults(callingStatement, maxRows, resultSetType, resultSetConcurrency, streamResults, catalog, resultPacket, false, -1L, cachedMetadata);
/*      */ 
/*      */       
/* 2742 */       if (queryWasSlow && !this.serverQueryWasSlow) {
/* 2743 */         StringBuilder mesgBuf = new StringBuilder(48 + profileQueryToLog.length());
/*      */         
/* 2745 */         mesgBuf.append(Messages.getString("MysqlIO.SlowQuery", new Object[] { String.valueOf(this.useAutoSlowLog ? " 95% of all queries " : Long.valueOf(this.slowQueryThreshold)), this.queryTimingUnits, Long.valueOf(queryEndTime - queryStartTime) }));
/*      */ 
/*      */         
/* 2748 */         mesgBuf.append(profileQueryToLog);
/*      */         
/* 2750 */         ProfilerEventHandler eventSink = ProfilerEventHandlerFactory.getInstance(this.connection);
/*      */         
/* 2752 */         eventSink.consumeEvent(new ProfilerEvent((byte)6, "", catalog, this.connection.getId(), (callingStatement != null) ? callingStatement.getId() : 999, ((ResultSetImpl)rs).resultId, System.currentTimeMillis(), (int)(queryEndTime - queryStartTime), this.queryTimingUnits, null, LogUtils.findCallingClassAndMethod(new Throwable()), mesgBuf.toString()));
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2757 */         if (this.connection.getExplainSlowQueries()) {
/* 2758 */           if (oldPacketPosition < 1048576) {
/* 2759 */             explainSlowQuery(queryPacket.getBytes(5, oldPacketPosition - 5), profileQueryToLog);
/*      */           } else {
/* 2761 */             this.connection.getLog().logWarn(Messages.getString("MysqlIO.28") + 1048576 + Messages.getString("MysqlIO.29"));
/*      */           } 
/*      */         }
/*      */       } 
/*      */       
/* 2766 */       if (this.logSlowQueries) {
/*      */         
/* 2768 */         ProfilerEventHandler eventSink = ProfilerEventHandlerFactory.getInstance(this.connection);
/*      */         
/* 2770 */         if (this.queryBadIndexUsed && this.profileSql) {
/* 2771 */           eventSink.consumeEvent(new ProfilerEvent((byte)6, "", catalog, this.connection.getId(), (callingStatement != null) ? callingStatement.getId() : 999, ((ResultSetImpl)rs).resultId, System.currentTimeMillis(), queryEndTime - queryStartTime, this.queryTimingUnits, null, LogUtils.findCallingClassAndMethod(new Throwable()), Messages.getString("MysqlIO.33") + profileQueryToLog));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2777 */         if (this.queryNoIndexUsed && this.profileSql) {
/* 2778 */           eventSink.consumeEvent(new ProfilerEvent((byte)6, "", catalog, this.connection.getId(), (callingStatement != null) ? callingStatement.getId() : 999, ((ResultSetImpl)rs).resultId, System.currentTimeMillis(), queryEndTime - queryStartTime, this.queryTimingUnits, null, LogUtils.findCallingClassAndMethod(new Throwable()), Messages.getString("MysqlIO.35") + profileQueryToLog));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2784 */         if (this.serverQueryWasSlow && this.profileSql) {
/* 2785 */           eventSink.consumeEvent(new ProfilerEvent((byte)6, "", catalog, this.connection.getId(), (callingStatement != null) ? callingStatement.getId() : 999, ((ResultSetImpl)rs).resultId, System.currentTimeMillis(), queryEndTime - queryStartTime, this.queryTimingUnits, null, LogUtils.findCallingClassAndMethod(new Throwable()), Messages.getString("MysqlIO.ServerSlowQuery") + profileQueryToLog));
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2792 */       if (this.profileSql) {
/* 2793 */         fetchEndTime = getCurrentTimeNanosOrMillis();
/*      */         
/* 2795 */         ProfilerEventHandler eventSink = ProfilerEventHandlerFactory.getInstance(this.connection);
/*      */         
/* 2797 */         eventSink.consumeEvent(new ProfilerEvent((byte)3, "", catalog, this.connection.getId(), (callingStatement != null) ? callingStatement.getId() : 999, ((ResultSetImpl)rs).resultId, System.currentTimeMillis(), queryEndTime - queryStartTime, this.queryTimingUnits, null, LogUtils.findCallingClassAndMethod(new Throwable()), profileQueryToLog));
/*      */ 
/*      */ 
/*      */         
/* 2801 */         eventSink.consumeEvent(new ProfilerEvent((byte)5, "", catalog, this.connection.getId(), (callingStatement != null) ? callingStatement.getId() : 999, ((ResultSetImpl)rs).resultId, System.currentTimeMillis(), fetchEndTime - fetchBeginTime, this.queryTimingUnits, null, LogUtils.findCallingClassAndMethod(new Throwable()), null));
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2806 */       if (this.hadWarnings) {
/* 2807 */         scanForAndThrowDataTruncation();
/*      */       }
/*      */       
/* 2810 */       if (this.statementInterceptors != null) {
/* 2811 */         ResultSetInternalMethods interceptedResults = invokeStatementInterceptorsPost(query, callingStatement, rs, false, null);
/*      */         
/* 2813 */         if (interceptedResults != null) {
/* 2814 */           rs = interceptedResults;
/*      */         }
/*      */       } 
/*      */       
/* 2818 */       return rs; }
/* 2819 */     catch (SQLException sqlEx)
/* 2820 */     { if (this.statementInterceptors != null) {
/* 2821 */         invokeStatementInterceptorsPost(query, callingStatement, null, false, sqlEx);
/*      */       }
/*      */       
/* 2824 */       if (callingStatement != null) {
/* 2825 */         synchronized (callingStatement.cancelTimeoutMutex) {
/* 2826 */           if (callingStatement.wasCancelled) {
/* 2827 */             MySQLStatementCancelledException mySQLStatementCancelledException; SQLException cause = null;
/*      */             
/* 2829 */             if (callingStatement.wasCancelledByTimeout) {
/* 2830 */               MySQLTimeoutException mySQLTimeoutException = new MySQLTimeoutException();
/*      */             } else {
/* 2832 */               mySQLStatementCancelledException = new MySQLStatementCancelledException();
/*      */             } 
/*      */             
/* 2835 */             callingStatement.resetCancelledState();
/*      */             
/* 2837 */             throw mySQLStatementCancelledException;
/*      */           } 
/*      */         } 
/*      */       }
/*      */       
/* 2842 */       throw sqlEx; }
/*      */     finally
/* 2844 */     { this.statementExecutionDepth--; }  }
/*      */   void closeStreamer(RowData streamer) throws SQLException { if (this.streamingData == null) throw SQLError.createSQLException(Messages.getString("MysqlIO.17") + streamer + Messages.getString("MysqlIO.18"), getExceptionInterceptor());  if (streamer != this.streamingData) throw SQLError.createSQLException(Messages.getString("MysqlIO.19") + streamer + Messages.getString("MysqlIO.20") + Messages.getString("MysqlIO.21") + Messages.getString("MysqlIO.22"), getExceptionInterceptor());  this.streamingData = null; }
/*      */   boolean tackOnMoreStreamingResults(ResultSetImpl addingTo) throws SQLException { if ((this.serverStatus & 0x8) != 0) { boolean moreRowSetsExist = true; ResultSetImpl currentResultSet = addingTo; boolean firstTime = true; while (moreRowSetsExist && (firstTime || !currentResultSet.reallyResult())) { firstTime = false; Buffer fieldPacket = checkErrorPacket(); fieldPacket.setPosition(0); Statement owningStatement = addingTo.getStatement(); int maxRows = owningStatement.getMaxRows(); ResultSetImpl newResultSet = readResultsForQueryOrUpdate((StatementImpl)owningStatement, maxRows, owningStatement.getResultSetType(), owningStatement.getResultSetConcurrency(), true, owningStatement.getConnection().getCatalog(), fieldPacket, addingTo.isBinaryEncoded, -1L, null); currentResultSet.setNextResultSet(newResultSet); currentResultSet = newResultSet; moreRowSetsExist = ((this.serverStatus & 0x8) != 0); if (!currentResultSet.reallyResult() && !moreRowSetsExist) return false;  }  return true; }  return false; }
/*      */   ResultSetImpl readAllResults(StatementImpl callingStatement, int maxRows, int resultSetType, int resultSetConcurrency, boolean streamResults, String catalog, Buffer resultPacket, boolean isBinaryEncoded, long preSentColumnCount, Field[] metadataFromCache) throws SQLException { resultPacket.setPosition(resultPacket.getPosition() - 1); ResultSetImpl topLevelResultSet = readResultsForQueryOrUpdate(callingStatement, maxRows, resultSetType, resultSetConcurrency, streamResults, catalog, resultPacket, isBinaryEncoded, preSentColumnCount, metadataFromCache); ResultSetImpl currentResultSet = topLevelResultSet; boolean checkForMoreResults = ((this.clientParam & 0x20000L) != 0L); boolean serverHasMoreResults = ((this.serverStatus & 0x8) != 0); if (serverHasMoreResults && streamResults) { if (topLevelResultSet.getUpdateCount() != -1L) tackOnMoreStreamingResults(topLevelResultSet);  reclaimLargeReusablePacket(); return topLevelResultSet; }  boolean moreRowSetsExist = checkForMoreResults & serverHasMoreResults; while (moreRowSetsExist) { Buffer fieldPacket = checkErrorPacket(); fieldPacket.setPosition(0); ResultSetImpl newResultSet = readResultsForQueryOrUpdate(callingStatement, maxRows, resultSetType, resultSetConcurrency, streamResults, catalog, fieldPacket, isBinaryEncoded, preSentColumnCount, metadataFromCache); currentResultSet.setNextResultSet(newResultSet); currentResultSet = newResultSet; moreRowSetsExist = ((this.serverStatus & 0x8) != 0); }  if (!streamResults) clearInputStream();  reclaimLargeReusablePacket(); return topLevelResultSet; }
/*      */   void resetMaxBuf() { this.maxAllowedPacket = this.connection.getMaxAllowedPacket(); }
/* 2849 */   final Buffer sendCommand(int command, String extraData, Buffer queryPacket, boolean skipCheck, String extraDataCharEncoding, int timeoutMillis) throws SQLException { this.commandCount++; this.enablePacketDebug = this.connection.getEnablePacketDebug(); this.readPacketSequence = 0; int oldTimeout = 0; if (timeoutMillis != 0) try { oldTimeout = this.mysqlConnection.getSoTimeout(); this.mysqlConnection.setSoTimeout(timeoutMillis); } catch (SocketException e) { throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, e, getExceptionInterceptor()); }   try { checkForOutstandingStreamingData(); this.oldServerStatus = this.serverStatus; this.serverStatus = 0; this.hadWarnings = false; this.warningCount = 0; this.queryNoIndexUsed = false; this.queryBadIndexUsed = false; this.serverQueryWasSlow = false; if (this.useCompression) { int bytesLeft = this.mysqlInput.available(); if (bytesLeft > 0) this.mysqlInput.skip(bytesLeft);  }  try { clearInputStream(); if (queryPacket == null) { int packLength = 8 + ((extraData != null) ? extraData.length() : 0) + 2; if (this.sendPacket == null) this.sendPacket = new Buffer(packLength);  this.packetSequence = -1; this.compressedPacketSequence = -1; this.readPacketSequence = 0; this.checkPacketSequence = true; this.sendPacket.clear(); this.sendPacket.writeByte((byte)command); if (command == 2 || command == 3 || command == 22) if (extraDataCharEncoding == null) { this.sendPacket.writeStringNoNull(extraData); } else { this.sendPacket.writeStringNoNull(extraData, extraDataCharEncoding, this.connection.getServerCharset(), this.connection.parserKnowsUnicode(), this.connection); }   send(this.sendPacket, this.sendPacket.getPosition()); } else { this.packetSequence = -1; this.compressedPacketSequence = -1; send(queryPacket, queryPacket.getPosition()); }  } catch (SQLException sqlEx) { throw sqlEx; } catch (Exception ex) { throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ex, getExceptionInterceptor()); }  Buffer returnPacket = null; if (!skipCheck) { if (command == 23 || command == 26) { this.readPacketSequence = 0; this.packetSequenceReset = true; }  returnPacket = checkErrorPacket(command); }  return returnPacket; } catch (IOException ioEx) { preserveOldTransactionState(); throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor()); } catch (SQLException e) { preserveOldTransactionState(); throw e; } finally { if (timeoutMillis != 0) try { this.mysqlConnection.setSoTimeout(oldTimeout); } catch (SocketException e) { throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, e, getExceptionInterceptor()); }   }  } ResultSetInternalMethods invokeStatementInterceptorsPre(String sql, Statement interceptedStatement, boolean forceExecute) throws SQLException { ResultSetInternalMethods previousResultSet = null;
/*      */     
/* 2851 */     for (int i = 0, s = this.statementInterceptors.size(); i < s; i++) {
/* 2852 */       StatementInterceptorV2 interceptor = this.statementInterceptors.get(i);
/*      */       
/* 2854 */       boolean executeTopLevelOnly = interceptor.executeTopLevelOnly();
/* 2855 */       boolean shouldExecute = ((executeTopLevelOnly && (this.statementExecutionDepth == 1 || forceExecute)) || !executeTopLevelOnly);
/*      */       
/* 2857 */       if (shouldExecute) {
/* 2858 */         String sqlToInterceptor = sql;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2865 */         ResultSetInternalMethods interceptedResultSet = interceptor.preProcess(sqlToInterceptor, interceptedStatement, this.connection);
/*      */         
/* 2867 */         if (interceptedResultSet != null) {
/* 2868 */           previousResultSet = interceptedResultSet;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 2873 */     return previousResultSet; }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ResultSetInternalMethods invokeStatementInterceptorsPost(String sql, Statement interceptedStatement, ResultSetInternalMethods originalResultSet, boolean forceExecute, SQLException statementException) throws SQLException {
/* 2879 */     for (int i = 0, s = this.statementInterceptors.size(); i < s; i++) {
/* 2880 */       StatementInterceptorV2 interceptor = this.statementInterceptors.get(i);
/*      */       
/* 2882 */       boolean executeTopLevelOnly = interceptor.executeTopLevelOnly();
/* 2883 */       boolean shouldExecute = ((executeTopLevelOnly && (this.statementExecutionDepth == 1 || forceExecute)) || !executeTopLevelOnly);
/*      */       
/* 2885 */       if (shouldExecute) {
/* 2886 */         String sqlToInterceptor = sql;
/*      */         
/* 2888 */         ResultSetInternalMethods interceptedResultSet = interceptor.postProcess(sqlToInterceptor, interceptedStatement, originalResultSet, this.connection, this.warningCount, this.queryNoIndexUsed, this.queryBadIndexUsed, statementException);
/*      */ 
/*      */         
/* 2891 */         if (interceptedResultSet != null) {
/* 2892 */           originalResultSet = interceptedResultSet;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 2897 */     return originalResultSet;
/*      */   }
/*      */   
/*      */   private void calculateSlowQueryThreshold() {
/* 2901 */     this.slowQueryThreshold = this.connection.getSlowQueryThresholdMillis();
/*      */     
/* 2903 */     if (this.connection.getUseNanosForElapsedTime()) {
/* 2904 */       long nanosThreshold = this.connection.getSlowQueryThresholdNanos();
/*      */       
/* 2906 */       if (nanosThreshold != 0L) {
/* 2907 */         this.slowQueryThreshold = nanosThreshold;
/*      */       } else {
/* 2909 */         this.slowQueryThreshold *= 1000000L;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   protected long getCurrentTimeNanosOrMillis() {
/* 2915 */     if (this.useNanosForElapsedTime) {
/* 2916 */       return TimeUtil.getCurrentTimeNanosOrMillis();
/*      */     }
/*      */     
/* 2919 */     return System.currentTimeMillis();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getHost() {
/* 2926 */     return this.host;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isVersion(int major, int minor, int subminor) {
/* 2944 */     return (major == getServerMajorVersion() && minor == getServerMinorVersion() && subminor == getServerSubMinorVersion());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean versionMeetsMinimum(int major, int minor, int subminor) {
/* 2956 */     if (getServerMajorVersion() >= major) {
/* 2957 */       if (getServerMajorVersion() == major) {
/* 2958 */         if (getServerMinorVersion() >= minor) {
/* 2959 */           if (getServerMinorVersion() == minor) {
/* 2960 */             return (getServerSubMinorVersion() >= subminor);
/*      */           }
/*      */ 
/*      */           
/* 2964 */           return true;
/*      */         } 
/*      */ 
/*      */         
/* 2968 */         return false;
/*      */       } 
/*      */ 
/*      */       
/* 2972 */       return true;
/*      */     } 
/*      */     
/* 2975 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String getPacketDumpToLog(Buffer packetToDump, int packetLength) {
/* 2990 */     if (packetLength < 1024) {
/* 2991 */       return packetToDump.dump(packetLength);
/*      */     }
/*      */     
/* 2994 */     StringBuilder packetDumpBuf = new StringBuilder(4096);
/* 2995 */     packetDumpBuf.append(packetToDump.dump(1024));
/* 2996 */     packetDumpBuf.append(Messages.getString("MysqlIO.36"));
/* 2997 */     packetDumpBuf.append(1024);
/* 2998 */     packetDumpBuf.append(Messages.getString("MysqlIO.37"));
/*      */     
/* 3000 */     return packetDumpBuf.toString();
/*      */   }
/*      */   
/*      */   private final int readFully(InputStream in, byte[] b, int off, int len) throws IOException {
/* 3004 */     if (len < 0) {
/* 3005 */       throw new IndexOutOfBoundsException();
/*      */     }
/*      */     
/* 3008 */     int n = 0;
/*      */     
/* 3010 */     while (n < len) {
/* 3011 */       int count = in.read(b, off + n, len - n);
/*      */       
/* 3013 */       if (count < 0) {
/* 3014 */         throw new EOFException(Messages.getString("MysqlIO.EOF", new Object[] { Integer.valueOf(len), Integer.valueOf(n) }));
/*      */       }
/*      */       
/* 3017 */       n += count;
/*      */     } 
/*      */     
/* 3020 */     return n;
/*      */   }
/*      */   
/*      */   private final long skipFully(InputStream in, long len) throws IOException {
/* 3024 */     if (len < 0L) {
/* 3025 */       throw new IOException("Negative skip length not allowed");
/*      */     }
/*      */     
/* 3028 */     long n = 0L;
/*      */     
/* 3030 */     while (n < len) {
/* 3031 */       long count = in.skip(len - n);
/*      */       
/* 3033 */       if (count < 0L) {
/* 3034 */         throw new EOFException(Messages.getString("MysqlIO.EOF", new Object[] { Long.valueOf(len), Long.valueOf(n) }));
/*      */       }
/*      */       
/* 3037 */       n += count;
/*      */     } 
/*      */     
/* 3040 */     return n;
/*      */   }
/*      */   
/*      */   private final int skipLengthEncodedInteger(InputStream in) throws IOException {
/* 3044 */     int sw = in.read() & 0xFF;
/*      */     
/* 3046 */     switch (sw) {
/*      */       case 252:
/* 3048 */         return (int)skipFully(in, 2L) + 1;
/*      */       
/*      */       case 253:
/* 3051 */         return (int)skipFully(in, 3L) + 1;
/*      */       
/*      */       case 254:
/* 3054 */         return (int)skipFully(in, 8L) + 1;
/*      */     } 
/*      */     
/* 3057 */     return 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final ResultSetImpl readResultsForQueryOrUpdate(StatementImpl callingStatement, int maxRows, int resultSetType, int resultSetConcurrency, boolean streamResults, String catalog, Buffer resultPacket, boolean isBinaryEncoded, long preSentColumnCount, Field[] metadataFromCache) throws SQLException {
/* 3094 */     long columnCount = resultPacket.readFieldLength();
/*      */     
/* 3096 */     if (columnCount == 0L)
/* 3097 */       return buildResultSetWithUpdates(callingStatement, resultPacket); 
/* 3098 */     if (columnCount == -1L) {
/* 3099 */       String charEncoding = null;
/*      */       
/* 3101 */       if (this.connection.getUseUnicode()) {
/* 3102 */         charEncoding = this.connection.getEncoding();
/*      */       }
/*      */       
/* 3105 */       String fileName = null;
/*      */       
/* 3107 */       if (this.platformDbCharsetMatches) {
/* 3108 */         fileName = (charEncoding != null) ? resultPacket.readString(charEncoding, getExceptionInterceptor()) : resultPacket.readString();
/*      */       } else {
/* 3110 */         fileName = resultPacket.readString();
/*      */       } 
/*      */       
/* 3113 */       return sendFileToServer(callingStatement, fileName);
/*      */     } 
/* 3115 */     ResultSetImpl results = getResultSet(callingStatement, columnCount, maxRows, resultSetType, resultSetConcurrency, streamResults, catalog, isBinaryEncoded, metadataFromCache);
/*      */ 
/*      */     
/* 3118 */     return results;
/*      */   }
/*      */ 
/*      */   
/*      */   private int alignPacketSize(int a, int l) {
/* 3123 */     return a + l - 1 & (l - 1 ^ 0xFFFFFFFF);
/*      */   }
/*      */ 
/*      */   
/*      */   private ResultSetImpl buildResultSetWithRows(StatementImpl callingStatement, String catalog, Field[] fields, RowData rows, int resultSetType, int resultSetConcurrency, boolean isBinaryEncoded) throws SQLException {
/* 3128 */     ResultSetImpl rs = null;
/*      */     
/* 3130 */     switch (resultSetConcurrency) {
/*      */       case 1007:
/* 3132 */         rs = ResultSetImpl.getInstance(catalog, fields, rows, this.connection, callingStatement, false);
/*      */         
/* 3134 */         if (isBinaryEncoded) {
/* 3135 */           rs.setBinaryEncoded();
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3149 */         rs.setResultSetType(resultSetType);
/* 3150 */         rs.setResultSetConcurrency(resultSetConcurrency);
/*      */         
/* 3152 */         return rs;case 1008: rs = ResultSetImpl.getInstance(catalog, fields, rows, this.connection, callingStatement, true); rs.setResultSetType(resultSetType); rs.setResultSetConcurrency(resultSetConcurrency); return rs;
/*      */     } 
/*      */     return ResultSetImpl.getInstance(catalog, fields, rows, this.connection, callingStatement, false);
/*      */   } private ResultSetImpl buildResultSetWithUpdates(StatementImpl callingStatement, Buffer resultPacket) throws SQLException {
/* 3156 */     long updateCount = -1L;
/* 3157 */     long updateID = -1L;
/* 3158 */     String info = null;
/*      */     
/*      */     try {
/* 3161 */       if (this.useNewUpdateCounts) {
/* 3162 */         updateCount = resultPacket.newReadLength();
/* 3163 */         updateID = resultPacket.newReadLength();
/*      */       } else {
/* 3165 */         updateCount = resultPacket.readLength();
/* 3166 */         updateID = resultPacket.readLength();
/*      */       } 
/*      */       
/* 3169 */       if (this.use41Extensions) {
/*      */         
/* 3171 */         this.serverStatus = resultPacket.readInt();
/*      */         
/* 3173 */         checkTransactionState(this.oldServerStatus);
/*      */         
/* 3175 */         this.warningCount = resultPacket.readInt();
/*      */         
/* 3177 */         if (this.warningCount > 0) {
/* 3178 */           this.hadWarnings = true;
/*      */         }
/*      */         
/* 3181 */         resultPacket.readByte();
/*      */         
/* 3183 */         setServerSlowQueryFlags();
/*      */       } 
/*      */       
/* 3186 */       if (this.connection.isReadInfoMsgEnabled()) {
/* 3187 */         info = resultPacket.readString(this.connection.getErrorMessageEncoding(), getExceptionInterceptor());
/*      */       }
/* 3189 */     } catch (Exception ex) {
/* 3190 */       SQLException sqlEx = SQLError.createSQLException(SQLError.get("S1000"), "S1000", -1, getExceptionInterceptor());
/*      */       
/* 3192 */       sqlEx.initCause(ex);
/*      */       
/* 3194 */       throw sqlEx;
/*      */     } 
/*      */     
/* 3197 */     ResultSetInternalMethods updateRs = ResultSetImpl.getInstance(updateCount, updateID, this.connection, callingStatement);
/*      */     
/* 3199 */     if (info != null) {
/* 3200 */       ((ResultSetImpl)updateRs).setServerInfo(info);
/*      */     }
/*      */     
/* 3203 */     return (ResultSetImpl)updateRs;
/*      */   }
/*      */   
/*      */   private void setServerSlowQueryFlags() {
/* 3207 */     this.queryBadIndexUsed = ((this.serverStatus & 0x10) != 0);
/* 3208 */     this.queryNoIndexUsed = ((this.serverStatus & 0x20) != 0);
/* 3209 */     this.serverQueryWasSlow = ((this.serverStatus & 0x800) != 0);
/*      */   }
/*      */   
/*      */   private void checkForOutstandingStreamingData() throws SQLException {
/* 3213 */     if (this.streamingData != null) {
/* 3214 */       boolean shouldClobber = this.connection.getClobberStreamingResults();
/*      */       
/* 3216 */       if (!shouldClobber) {
/* 3217 */         throw SQLError.createSQLException(Messages.getString("MysqlIO.39") + this.streamingData + Messages.getString("MysqlIO.40") + Messages.getString("MysqlIO.41") + Messages.getString("MysqlIO.42"), getExceptionInterceptor());
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 3222 */       this.streamingData.getOwner().realClose(false);
/*      */ 
/*      */       
/* 3225 */       clearInputStream();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Buffer compressPacket(Buffer packet, int offset, int packetLen) throws SQLException {
/* 3242 */     int compressedLength = packetLen;
/* 3243 */     int uncompressedLength = 0;
/* 3244 */     byte[] compressedBytes = null;
/* 3245 */     int offsetWrite = offset;
/*      */     
/* 3247 */     if (packetLen < 50) {
/* 3248 */       compressedBytes = packet.getByteBuffer();
/*      */     } else {
/*      */       
/* 3251 */       byte[] bytesToCompress = packet.getByteBuffer();
/* 3252 */       compressedBytes = new byte[bytesToCompress.length * 2];
/*      */       
/* 3254 */       if (this.deflater == null) {
/* 3255 */         this.deflater = new Deflater();
/*      */       }
/* 3257 */       this.deflater.reset();
/* 3258 */       this.deflater.setInput(bytesToCompress, offset, packetLen);
/* 3259 */       this.deflater.finish();
/*      */       
/* 3261 */       compressedLength = this.deflater.deflate(compressedBytes);
/*      */       
/* 3263 */       if (compressedLength > packetLen) {
/*      */         
/* 3265 */         compressedBytes = packet.getByteBuffer();
/* 3266 */         compressedLength = packetLen;
/*      */       } else {
/* 3268 */         uncompressedLength = packetLen;
/* 3269 */         offsetWrite = 0;
/*      */       } 
/*      */     } 
/*      */     
/* 3273 */     Buffer compressedPacket = new Buffer(7 + compressedLength);
/*      */     
/* 3275 */     compressedPacket.setPosition(0);
/* 3276 */     compressedPacket.writeLongInt(compressedLength);
/* 3277 */     compressedPacket.writeByte(this.compressedPacketSequence);
/* 3278 */     compressedPacket.writeLongInt(uncompressedLength);
/* 3279 */     compressedPacket.writeBytesNoNull(compressedBytes, offsetWrite, compressedLength);
/*      */     
/* 3281 */     return compressedPacket;
/*      */   }
/*      */   
/*      */   private final void readServerStatusForResultSets(Buffer rowPacket) throws SQLException {
/* 3285 */     if (this.use41Extensions) {
/* 3286 */       rowPacket.readByte();
/*      */       
/* 3288 */       if (isEOFDeprecated()) {
/*      */         
/* 3290 */         rowPacket.newReadLength();
/* 3291 */         rowPacket.newReadLength();
/*      */         
/* 3293 */         this.oldServerStatus = this.serverStatus;
/* 3294 */         this.serverStatus = rowPacket.readInt();
/* 3295 */         checkTransactionState(this.oldServerStatus);
/*      */         
/* 3297 */         this.warningCount = rowPacket.readInt();
/* 3298 */         if (this.warningCount > 0) {
/* 3299 */           this.hadWarnings = true;
/*      */         }
/*      */         
/* 3302 */         rowPacket.readByte();
/*      */         
/* 3304 */         if (this.connection.isReadInfoMsgEnabled()) {
/* 3305 */           rowPacket.readString(this.connection.getErrorMessageEncoding(), getExceptionInterceptor());
/*      */         }
/*      */       }
/*      */       else {
/*      */         
/* 3310 */         this.warningCount = rowPacket.readInt();
/* 3311 */         if (this.warningCount > 0) {
/* 3312 */           this.hadWarnings = true;
/*      */         }
/*      */         
/* 3315 */         this.oldServerStatus = this.serverStatus;
/* 3316 */         this.serverStatus = rowPacket.readInt();
/* 3317 */         checkTransactionState(this.oldServerStatus);
/*      */       } 
/*      */       
/* 3320 */       setServerSlowQueryFlags();
/*      */     } 
/*      */   }
/*      */   
/*      */   private SocketFactory createSocketFactory() throws SQLException {
/*      */     try {
/* 3326 */       if (this.socketFactoryClassName == null) {
/* 3327 */         throw SQLError.createSQLException(Messages.getString("MysqlIO.75"), "08001", getExceptionInterceptor());
/*      */       }
/*      */ 
/*      */       
/* 3331 */       return (SocketFactory)Class.forName(this.socketFactoryClassName).newInstance();
/* 3332 */     } catch (Exception ex) {
/* 3333 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString("MysqlIO.76") + this.socketFactoryClassName + Messages.getString("MysqlIO.77"), "08001", getExceptionInterceptor());
/*      */ 
/*      */       
/* 3336 */       sqlEx.initCause(ex);
/*      */       
/* 3338 */       throw sqlEx;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void enqueuePacketForDebugging(boolean isPacketBeingSent, boolean isPacketReused, int sendLength, byte[] header, Buffer packet) throws SQLException {
/* 3344 */     if (this.packetDebugRingBuffer.size() + 1 > this.connection.getPacketDebugBufferSize()) {
/* 3345 */       this.packetDebugRingBuffer.removeFirst();
/*      */     }
/*      */     
/* 3348 */     StringBuilder packetDump = null;
/*      */     
/* 3350 */     if (!isPacketBeingSent) {
/* 3351 */       int bytesToDump = Math.min(1024, packet.getBufLength());
/*      */       
/* 3353 */       Buffer packetToDump = new Buffer(4 + bytesToDump);
/*      */       
/* 3355 */       packetToDump.setPosition(0);
/* 3356 */       packetToDump.writeBytesNoNull(header);
/* 3357 */       packetToDump.writeBytesNoNull(packet.getBytes(0, bytesToDump));
/*      */       
/* 3359 */       String packetPayload = packetToDump.dump(bytesToDump);
/*      */       
/* 3361 */       packetDump = new StringBuilder(96 + packetPayload.length());
/*      */       
/* 3363 */       packetDump.append("Server ");
/*      */       
/* 3365 */       packetDump.append(isPacketReused ? "(re-used) " : "(new) ");
/*      */       
/* 3367 */       packetDump.append(packet.toSuperString());
/* 3368 */       packetDump.append(" --------------------> Client\n");
/* 3369 */       packetDump.append("\nPacket payload:\n\n");
/* 3370 */       packetDump.append(packetPayload);
/*      */       
/* 3372 */       if (bytesToDump == 1024) {
/* 3373 */         packetDump.append("\nNote: Packet of " + packet.getBufLength() + " bytes truncated to " + 'Ѐ' + " bytes.\n");
/*      */       }
/*      */     } else {
/* 3376 */       int bytesToDump = Math.min(1024, sendLength);
/*      */       
/* 3378 */       String packetPayload = packet.dump(bytesToDump);
/*      */       
/* 3380 */       packetDump = new StringBuilder(68 + packetPayload.length());
/*      */       
/* 3382 */       packetDump.append("Client ");
/* 3383 */       packetDump.append(packet.toSuperString());
/* 3384 */       packetDump.append("--------------------> Server\n");
/* 3385 */       packetDump.append("\nPacket payload:\n\n");
/* 3386 */       packetDump.append(packetPayload);
/*      */       
/* 3388 */       if (bytesToDump == 1024) {
/* 3389 */         packetDump.append("\nNote: Packet of " + sendLength + " bytes truncated to " + 'Ѐ' + " bytes.\n");
/*      */       }
/*      */     } 
/*      */     
/* 3393 */     this.packetDebugRingBuffer.addLast(packetDump);
/*      */   }
/*      */ 
/*      */   
/*      */   private RowData readSingleRowSet(long columnCount, int maxRows, int resultSetConcurrency, boolean isBinaryEncoded, Field[] fields) throws SQLException {
/* 3398 */     ArrayList<ResultSetRow> rows = new ArrayList<ResultSetRow>();
/*      */     
/* 3400 */     boolean useBufferRowExplicit = useBufferRowExplicit(fields);
/*      */ 
/*      */     
/* 3403 */     ResultSetRow row = nextRow(fields, (int)columnCount, isBinaryEncoded, resultSetConcurrency, false, useBufferRowExplicit, false, null);
/*      */     
/* 3405 */     int rowCount = 0;
/*      */     
/* 3407 */     if (row != null) {
/* 3408 */       rows.add(row);
/* 3409 */       rowCount = 1;
/*      */     } 
/*      */     
/* 3412 */     while (row != null) {
/* 3413 */       row = nextRow(fields, (int)columnCount, isBinaryEncoded, resultSetConcurrency, false, useBufferRowExplicit, false, null);
/*      */       
/* 3415 */       if (row != null && (
/* 3416 */         maxRows == -1 || rowCount < maxRows)) {
/* 3417 */         rows.add(row);
/* 3418 */         rowCount++;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 3423 */     RowData rowData = new RowDataStatic(rows);
/*      */     
/* 3425 */     return rowData;
/*      */   }
/*      */   
/*      */   public static boolean useBufferRowExplicit(Field[] fields) {
/* 3429 */     if (fields == null) {
/* 3430 */       return false;
/*      */     }
/*      */     
/* 3433 */     for (int i = 0; i < fields.length; i++) {
/* 3434 */       switch (fields[i].getSQLType()) {
/*      */         case -4:
/*      */         case -1:
/*      */         case 2004:
/*      */         case 2005:
/* 3439 */           return true;
/*      */       } 
/*      */     
/*      */     } 
/* 3443 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void reclaimLargeReusablePacket() {
/* 3450 */     if (this.reusablePacket != null && this.reusablePacket.getCapacity() > 1048576) {
/* 3451 */       this.reusablePacket = new Buffer(1024);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Buffer reuseAndReadPacket(Buffer reuse) throws SQLException {
/* 3462 */     return reuseAndReadPacket(reuse, -1);
/*      */   }
/*      */ 
/*      */   
/*      */   private final Buffer reuseAndReadPacket(Buffer reuse, int existingPacketLength) throws SQLException {
/*      */     try {
/* 3468 */       reuse.setWasMultiPacket(false);
/* 3469 */       int packetLength = 0;
/*      */       
/* 3471 */       if (existingPacketLength == -1) {
/* 3472 */         int lengthRead = readFully(this.mysqlInput, this.packetHeaderBuf, 0, 4);
/*      */         
/* 3474 */         if (lengthRead < 4) {
/* 3475 */           forceClose();
/* 3476 */           throw new IOException(Messages.getString("MysqlIO.43"));
/*      */         } 
/*      */         
/* 3479 */         packetLength = (this.packetHeaderBuf[0] & 0xFF) + ((this.packetHeaderBuf[1] & 0xFF) << 8) + ((this.packetHeaderBuf[2] & 0xFF) << 16);
/*      */       } else {
/* 3481 */         packetLength = existingPacketLength;
/*      */       } 
/*      */       
/* 3484 */       if (this.traceProtocol) {
/* 3485 */         StringBuilder traceMessageBuf = new StringBuilder();
/*      */         
/* 3487 */         traceMessageBuf.append(Messages.getString("MysqlIO.44"));
/* 3488 */         traceMessageBuf.append(packetLength);
/* 3489 */         traceMessageBuf.append(Messages.getString("MysqlIO.45"));
/* 3490 */         traceMessageBuf.append(StringUtils.dumpAsHex(this.packetHeaderBuf, 4));
/*      */         
/* 3492 */         this.connection.getLog().logTrace(traceMessageBuf.toString());
/*      */       } 
/*      */       
/* 3495 */       byte multiPacketSeq = this.packetHeaderBuf[3];
/*      */       
/* 3497 */       if (!this.packetSequenceReset) {
/* 3498 */         if (this.enablePacketDebug && this.checkPacketSequence) {
/* 3499 */           checkPacketSequencing(multiPacketSeq);
/*      */         }
/*      */       } else {
/* 3502 */         this.packetSequenceReset = false;
/*      */       } 
/*      */       
/* 3505 */       this.readPacketSequence = multiPacketSeq;
/*      */ 
/*      */       
/* 3508 */       reuse.setPosition(0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3514 */       if ((reuse.getByteBuffer()).length <= packetLength) {
/* 3515 */         reuse.setByteBuffer(new byte[packetLength + 1]);
/*      */       }
/*      */ 
/*      */       
/* 3519 */       reuse.setBufLength(packetLength);
/*      */ 
/*      */       
/* 3522 */       int numBytesRead = readFully(this.mysqlInput, reuse.getByteBuffer(), 0, packetLength);
/*      */       
/* 3524 */       if (numBytesRead != packetLength) {
/* 3525 */         throw new IOException("Short read, expected " + packetLength + " bytes, only read " + numBytesRead);
/*      */       }
/*      */       
/* 3528 */       if (this.traceProtocol) {
/* 3529 */         StringBuilder traceMessageBuf = new StringBuilder();
/*      */         
/* 3531 */         traceMessageBuf.append(Messages.getString("MysqlIO.46"));
/* 3532 */         traceMessageBuf.append(getPacketDumpToLog(reuse, packetLength));
/*      */         
/* 3534 */         this.connection.getLog().logTrace(traceMessageBuf.toString());
/*      */       } 
/*      */       
/* 3537 */       if (this.enablePacketDebug) {
/* 3538 */         enqueuePacketForDebugging(false, true, 0, this.packetHeaderBuf, reuse);
/*      */       }
/*      */       
/* 3541 */       boolean isMultiPacket = false;
/*      */       
/* 3543 */       if (packetLength == this.maxThreeBytes) {
/* 3544 */         reuse.setPosition(this.maxThreeBytes);
/*      */ 
/*      */         
/* 3547 */         isMultiPacket = true;
/*      */         
/* 3549 */         packetLength = readRemainingMultiPackets(reuse, multiPacketSeq);
/*      */       } 
/*      */       
/* 3552 */       if (!isMultiPacket) {
/* 3553 */         reuse.getByteBuffer()[packetLength] = 0;
/*      */       }
/*      */       
/* 3556 */       if (this.connection.getMaintainTimeStats()) {
/* 3557 */         this.lastPacketReceivedTimeMs = System.currentTimeMillis();
/*      */       }
/*      */       
/* 3560 */       return reuse;
/* 3561 */     } catch (IOException ioEx) {
/* 3562 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor());
/*      */     }
/* 3564 */     catch (OutOfMemoryError oom) {
/*      */       
/*      */       try {
/* 3567 */         clearInputStream();
/* 3568 */       } catch (Exception ex) {}
/*      */       
/*      */       try {
/* 3571 */         this.connection.realClose(false, false, true, oom);
/* 3572 */       } catch (Exception ex) {}
/*      */       
/* 3574 */       throw oom;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private int readRemainingMultiPackets(Buffer reuse, byte multiPacketSeq) throws IOException, SQLException {
/* 3580 */     int packetLength = -1;
/* 3581 */     Buffer multiPacket = null;
/*      */     
/*      */     do {
/* 3584 */       int lengthRead = readFully(this.mysqlInput, this.packetHeaderBuf, 0, 4);
/* 3585 */       if (lengthRead < 4) {
/* 3586 */         forceClose();
/* 3587 */         throw new IOException(Messages.getString("MysqlIO.47"));
/*      */       } 
/*      */       
/* 3590 */       packetLength = (this.packetHeaderBuf[0] & 0xFF) + ((this.packetHeaderBuf[1] & 0xFF) << 8) + ((this.packetHeaderBuf[2] & 0xFF) << 16);
/* 3591 */       if (multiPacket == null) {
/* 3592 */         multiPacket = new Buffer(packetLength);
/*      */       }
/*      */       
/* 3595 */       if (!this.useNewLargePackets && packetLength == 1) {
/* 3596 */         clearInputStream();
/*      */         
/*      */         break;
/*      */       } 
/* 3600 */       multiPacketSeq = (byte)(multiPacketSeq + 1);
/* 3601 */       if (multiPacketSeq != this.packetHeaderBuf[3]) {
/* 3602 */         throw new IOException(Messages.getString("MysqlIO.49"));
/*      */       }
/*      */ 
/*      */       
/* 3606 */       multiPacket.setPosition(0);
/*      */ 
/*      */       
/* 3609 */       multiPacket.setBufLength(packetLength);
/*      */ 
/*      */       
/* 3612 */       byte[] byteBuf = multiPacket.getByteBuffer();
/* 3613 */       int lengthToWrite = packetLength;
/*      */       
/* 3615 */       int bytesRead = readFully(this.mysqlInput, byteBuf, 0, packetLength);
/*      */       
/* 3617 */       if (bytesRead != lengthToWrite) {
/* 3618 */         throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, SQLError.createSQLException(Messages.getString("MysqlIO.50") + lengthToWrite + Messages.getString("MysqlIO.51") + bytesRead + ".", getExceptionInterceptor()), getExceptionInterceptor());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3624 */       reuse.writeBytesNoNull(byteBuf, 0, lengthToWrite);
/* 3625 */     } while (packetLength == this.maxThreeBytes);
/*      */     
/* 3627 */     reuse.setPosition(0);
/* 3628 */     reuse.setWasMultiPacket(true);
/* 3629 */     return packetLength;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkPacketSequencing(byte multiPacketSeq) throws SQLException {
/* 3637 */     if (multiPacketSeq == Byte.MIN_VALUE && this.readPacketSequence != Byte.MAX_VALUE) {
/* 3638 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, new IOException("Packets out of order, expected packet # -128, but received packet # " + multiPacketSeq), getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */     
/* 3642 */     if (this.readPacketSequence == -1 && multiPacketSeq != 0) {
/* 3643 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, new IOException("Packets out of order, expected packet # -1, but received packet # " + multiPacketSeq), getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */     
/* 3647 */     if (multiPacketSeq != Byte.MIN_VALUE && this.readPacketSequence != -1 && multiPacketSeq != this.readPacketSequence + 1) {
/* 3648 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, new IOException("Packets out of order, expected packet # " + (this.readPacketSequence + 1) + ", but received packet # " + multiPacketSeq), getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void enableMultiQueries() throws SQLException {
/* 3655 */     Buffer buf = getSharedSendPacket();
/*      */     
/* 3657 */     buf.clear();
/* 3658 */     buf.writeByte((byte)27);
/* 3659 */     buf.writeInt(0);
/* 3660 */     sendCommand(27, null, buf, false, null, 0);
/* 3661 */     preserveOldTransactionState();
/*      */   }
/*      */   
/*      */   void disableMultiQueries() throws SQLException {
/* 3665 */     Buffer buf = getSharedSendPacket();
/*      */     
/* 3667 */     buf.clear();
/* 3668 */     buf.writeByte((byte)27);
/* 3669 */     buf.writeInt(1);
/* 3670 */     sendCommand(27, null, buf, false, null, 0);
/* 3671 */     preserveOldTransactionState();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void send(Buffer packet, int packetLen) throws SQLException {
/*      */     try {
/* 3682 */       if (this.maxAllowedPacket > 0 && packetLen > this.maxAllowedPacket) {
/* 3683 */         throw new PacketTooBigException(packetLen, this.maxAllowedPacket);
/*      */       }
/*      */       
/* 3686 */       if (this.serverMajorVersion >= 4 && (packetLen - 4 >= this.maxThreeBytes || (this.useCompression && packetLen - 4 >= this.maxThreeBytes - 3))) {
/*      */         
/* 3688 */         sendSplitPackets(packet, packetLen);
/*      */       } else {
/*      */         
/* 3691 */         this.packetSequence = (byte)(this.packetSequence + 1);
/*      */         
/* 3693 */         Buffer packetToSend = packet;
/* 3694 */         packetToSend.setPosition(0);
/* 3695 */         packetToSend.writeLongInt(packetLen - 4);
/* 3696 */         packetToSend.writeByte(this.packetSequence);
/*      */         
/* 3698 */         if (this.useCompression) {
/* 3699 */           this.compressedPacketSequence = (byte)(this.compressedPacketSequence + 1);
/* 3700 */           int originalPacketLen = packetLen;
/*      */           
/* 3702 */           packetToSend = compressPacket(packetToSend, 0, packetLen);
/* 3703 */           packetLen = packetToSend.getPosition();
/*      */           
/* 3705 */           if (this.traceProtocol) {
/* 3706 */             StringBuilder traceMessageBuf = new StringBuilder();
/*      */             
/* 3708 */             traceMessageBuf.append(Messages.getString("MysqlIO.57"));
/* 3709 */             traceMessageBuf.append(getPacketDumpToLog(packetToSend, packetLen));
/* 3710 */             traceMessageBuf.append(Messages.getString("MysqlIO.58"));
/* 3711 */             traceMessageBuf.append(getPacketDumpToLog(packet, originalPacketLen));
/*      */             
/* 3713 */             this.connection.getLog().logTrace(traceMessageBuf.toString());
/*      */           }
/*      */         
/*      */         }
/* 3717 */         else if (this.traceProtocol) {
/* 3718 */           StringBuilder traceMessageBuf = new StringBuilder();
/*      */           
/* 3720 */           traceMessageBuf.append(Messages.getString("MysqlIO.59"));
/* 3721 */           traceMessageBuf.append("host: '");
/* 3722 */           traceMessageBuf.append(this.host);
/* 3723 */           traceMessageBuf.append("' threadId: '");
/* 3724 */           traceMessageBuf.append(this.threadId);
/* 3725 */           traceMessageBuf.append("'\n");
/* 3726 */           traceMessageBuf.append(packetToSend.dump(packetLen));
/*      */           
/* 3728 */           this.connection.getLog().logTrace(traceMessageBuf.toString());
/*      */         } 
/*      */ 
/*      */         
/* 3732 */         this.mysqlOutput.write(packetToSend.getByteBuffer(), 0, packetLen);
/* 3733 */         this.mysqlOutput.flush();
/*      */       } 
/*      */       
/* 3736 */       if (this.enablePacketDebug) {
/* 3737 */         enqueuePacketForDebugging(true, false, packetLen + 5, this.packetHeaderBuf, packet);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3743 */       if (packet == this.sharedSendPacket) {
/* 3744 */         reclaimLargeSharedSendPacket();
/*      */       }
/*      */       
/* 3747 */       if (this.connection.getMaintainTimeStats()) {
/* 3748 */         this.lastPacketSentTimeMs = System.currentTimeMillis();
/*      */       }
/* 3750 */     } catch (IOException ioEx) {
/* 3751 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final ResultSetImpl sendFileToServer(StatementImpl callingStatement, String fileName) throws SQLException {
/* 3767 */     if (this.useCompression) {
/* 3768 */       this.compressedPacketSequence = (byte)(this.compressedPacketSequence + 1);
/*      */     }
/*      */     
/* 3771 */     Buffer filePacket = (this.loadFileBufRef == null) ? null : this.loadFileBufRef.get();
/*      */     
/* 3773 */     int bigPacketLength = Math.min(this.connection.getMaxAllowedPacket() - 12, alignPacketSize(this.connection.getMaxAllowedPacket() - 16, 4096) - 12);
/*      */ 
/*      */     
/* 3776 */     int oneMeg = 1048576;
/*      */     
/* 3778 */     int smallerPacketSizeAligned = Math.min(oneMeg - 12, alignPacketSize(oneMeg - 16, 4096) - 12);
/*      */     
/* 3780 */     int packetLength = Math.min(smallerPacketSizeAligned, bigPacketLength);
/*      */     
/* 3782 */     if (filePacket == null) {
/*      */       try {
/* 3784 */         filePacket = new Buffer(packetLength + 4);
/* 3785 */         this.loadFileBufRef = new SoftReference<Buffer>(filePacket);
/* 3786 */       } catch (OutOfMemoryError oom) {
/* 3787 */         throw SQLError.createSQLException("Could not allocate packet of " + packetLength + " bytes required for LOAD DATA LOCAL INFILE operation." + " Try increasing max heap allocation for JVM or decreasing server variable 'max_allowed_packet'", "S1001", getExceptionInterceptor());
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3795 */     filePacket.clear();
/* 3796 */     send(filePacket, 0);
/*      */     
/* 3798 */     byte[] fileBuf = new byte[packetLength];
/*      */     
/* 3800 */     BufferedInputStream fileIn = null;
/*      */     
/*      */     try {
/* 3803 */       if (!this.connection.getAllowLoadLocalInfile()) {
/* 3804 */         throw SQLError.createSQLException(Messages.getString("MysqlIO.LoadDataLocalNotAllowed"), "S1000", getExceptionInterceptor());
/*      */       }
/*      */ 
/*      */       
/* 3808 */       InputStream hookedStream = null;
/*      */       
/* 3810 */       if (callingStatement != null) {
/* 3811 */         hookedStream = callingStatement.getLocalInfileInputStream();
/*      */       }
/*      */       
/* 3814 */       if (hookedStream != null) {
/* 3815 */         fileIn = new BufferedInputStream(hookedStream);
/* 3816 */       } else if (!this.connection.getAllowUrlInLocalInfile()) {
/* 3817 */         fileIn = new BufferedInputStream(new FileInputStream(fileName));
/*      */       
/*      */       }
/* 3820 */       else if (fileName.indexOf(':') != -1) {
/*      */         try {
/* 3822 */           URL urlFromFileName = new URL(fileName);
/* 3823 */           fileIn = new BufferedInputStream(urlFromFileName.openStream());
/* 3824 */         } catch (MalformedURLException badUrlEx) {
/*      */           
/* 3826 */           fileIn = new BufferedInputStream(new FileInputStream(fileName));
/*      */         } 
/*      */       } else {
/* 3829 */         fileIn = new BufferedInputStream(new FileInputStream(fileName));
/*      */       } 
/*      */ 
/*      */       
/* 3833 */       int bytesRead = 0;
/*      */       
/* 3835 */       while ((bytesRead = fileIn.read(fileBuf)) != -1) {
/* 3836 */         filePacket.clear();
/* 3837 */         filePacket.writeBytesNoNull(fileBuf, 0, bytesRead);
/* 3838 */         send(filePacket, filePacket.getPosition());
/*      */       } 
/* 3840 */     } catch (IOException ioEx) {
/* 3841 */       StringBuilder messageBuf = new StringBuilder(Messages.getString("MysqlIO.60"));
/*      */       
/* 3843 */       if (fileName != null && !this.connection.getParanoid()) {
/* 3844 */         messageBuf.append("'");
/* 3845 */         messageBuf.append(fileName);
/* 3846 */         messageBuf.append("'");
/*      */       } 
/*      */       
/* 3849 */       messageBuf.append(Messages.getString("MysqlIO.63"));
/*      */       
/* 3851 */       if (!this.connection.getParanoid()) {
/* 3852 */         messageBuf.append(Messages.getString("MysqlIO.64"));
/* 3853 */         messageBuf.append(Util.stackTraceToString(ioEx));
/*      */       } 
/*      */       
/* 3856 */       throw SQLError.createSQLException(messageBuf.toString(), "S1009", getExceptionInterceptor());
/*      */     } finally {
/* 3858 */       if (fileIn != null) {
/*      */         try {
/* 3860 */           fileIn.close();
/* 3861 */         } catch (Exception ex) {
/* 3862 */           SQLException sqlEx = SQLError.createSQLException(Messages.getString("MysqlIO.65"), "S1000", ex, getExceptionInterceptor());
/*      */ 
/*      */           
/* 3865 */           throw sqlEx;
/*      */         } 
/*      */         
/* 3868 */         fileIn = null;
/*      */       } else {
/*      */         
/* 3871 */         filePacket.clear();
/* 3872 */         send(filePacket, filePacket.getPosition());
/* 3873 */         checkErrorPacket();
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 3878 */     filePacket.clear();
/* 3879 */     send(filePacket, filePacket.getPosition());
/*      */     
/* 3881 */     Buffer resultPacket = checkErrorPacket();
/*      */     
/* 3883 */     return buildResultSetWithUpdates(callingStatement, resultPacket);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Buffer checkErrorPacket(int command) throws SQLException {
/* 3899 */     Buffer resultPacket = null;
/* 3900 */     this.serverStatus = 0;
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 3905 */       resultPacket = reuseAndReadPacket(this.reusablePacket);
/* 3906 */     } catch (SQLException sqlEx) {
/*      */       
/* 3908 */       throw sqlEx;
/* 3909 */     } catch (Exception fallThru) {
/* 3910 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, fallThru, getExceptionInterceptor());
/*      */     } 
/*      */ 
/*      */     
/* 3914 */     checkErrorPacket(resultPacket);
/*      */     
/* 3916 */     return resultPacket;
/*      */   }
/*      */ 
/*      */   
/*      */   private void checkErrorPacket(Buffer resultPacket) throws SQLException {
/* 3921 */     int statusCode = resultPacket.readByte();
/*      */ 
/*      */     
/* 3924 */     if (statusCode == -1) {
/*      */       
/* 3926 */       int errno = 2000;
/*      */       
/* 3928 */       if (this.protocolVersion > 9) {
/* 3929 */         errno = resultPacket.readInt();
/*      */         
/* 3931 */         String xOpen = null;
/*      */         
/* 3933 */         String str1 = resultPacket.readString(this.connection.getErrorMessageEncoding(), getExceptionInterceptor());
/*      */         
/* 3935 */         if (str1.charAt(0) == '#') {
/*      */ 
/*      */           
/* 3938 */           if (str1.length() > 6) {
/* 3939 */             xOpen = str1.substring(1, 6);
/* 3940 */             str1 = str1.substring(6);
/*      */             
/* 3942 */             if (xOpen.equals("HY000")) {
/* 3943 */               xOpen = SQLError.mysqlToSqlState(errno, this.connection.getUseSqlStateCodes());
/*      */             }
/*      */           } else {
/* 3946 */             xOpen = SQLError.mysqlToSqlState(errno, this.connection.getUseSqlStateCodes());
/*      */           } 
/*      */         } else {
/* 3949 */           xOpen = SQLError.mysqlToSqlState(errno, this.connection.getUseSqlStateCodes());
/*      */         } 
/*      */         
/* 3952 */         clearInputStream();
/*      */         
/* 3954 */         StringBuilder stringBuilder = new StringBuilder();
/*      */         
/* 3956 */         String xOpenErrorMessage = SQLError.get(xOpen);
/*      */         
/* 3958 */         if (!this.connection.getUseOnlyServerErrorMessages() && 
/* 3959 */           xOpenErrorMessage != null) {
/* 3960 */           stringBuilder.append(xOpenErrorMessage);
/* 3961 */           stringBuilder.append(Messages.getString("MysqlIO.68"));
/*      */         } 
/*      */ 
/*      */         
/* 3965 */         stringBuilder.append(str1);
/*      */         
/* 3967 */         if (!this.connection.getUseOnlyServerErrorMessages() && 
/* 3968 */           xOpenErrorMessage != null) {
/* 3969 */           stringBuilder.append("\"");
/*      */         }
/*      */ 
/*      */         
/* 3973 */         appendDeadlockStatusInformation(xOpen, stringBuilder);
/*      */         
/* 3975 */         if (xOpen != null && xOpen.startsWith("22")) {
/* 3976 */           throw new MysqlDataTruncation(stringBuilder.toString(), 0, true, false, 0, 0, errno);
/*      */         }
/* 3978 */         throw SQLError.createSQLException(stringBuilder.toString(), xOpen, errno, false, getExceptionInterceptor(), this.connection);
/*      */       } 
/*      */       
/* 3981 */       String serverErrorMessage = resultPacket.readString(this.connection.getErrorMessageEncoding(), getExceptionInterceptor());
/* 3982 */       clearInputStream();
/*      */       
/* 3984 */       if (serverErrorMessage.indexOf(Messages.getString("MysqlIO.70")) != -1) {
/* 3985 */         throw SQLError.createSQLException(SQLError.get("S0022") + ", " + serverErrorMessage, "S0022", -1, false, getExceptionInterceptor(), this.connection);
/*      */       }
/*      */ 
/*      */       
/* 3989 */       StringBuilder errorBuf = new StringBuilder(Messages.getString("MysqlIO.72"));
/* 3990 */       errorBuf.append(serverErrorMessage);
/* 3991 */       errorBuf.append("\"");
/*      */       
/* 3993 */       throw SQLError.createSQLException(SQLError.get("S1000") + ", " + errorBuf.toString(), "S1000", -1, false, getExceptionInterceptor(), this.connection);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void appendDeadlockStatusInformation(String xOpen, StringBuilder errorBuf) throws SQLException {
/* 3999 */     if (this.connection.getIncludeInnodbStatusInDeadlockExceptions() && xOpen != null && (xOpen.startsWith("40") || xOpen.startsWith("41")) && this.streamingData == null) {
/*      */       
/* 4001 */       ResultSet rs = null;
/*      */       
/*      */       try {
/* 4004 */         rs = sqlQueryDirect(null, "SHOW ENGINE INNODB STATUS", this.connection.getEncoding(), null, -1, 1003, 1007, false, this.connection.getCatalog(), null);
/*      */ 
/*      */         
/* 4007 */         if (rs.next()) {
/* 4008 */           errorBuf.append("\n\n");
/* 4009 */           errorBuf.append(rs.getString("Status"));
/*      */         } else {
/* 4011 */           errorBuf.append("\n\n");
/* 4012 */           errorBuf.append(Messages.getString("MysqlIO.NoInnoDBStatusFound"));
/*      */         } 
/* 4014 */       } catch (Exception ex) {
/* 4015 */         errorBuf.append("\n\n");
/* 4016 */         errorBuf.append(Messages.getString("MysqlIO.InnoDBStatusFailed"));
/* 4017 */         errorBuf.append("\n\n");
/* 4018 */         errorBuf.append(Util.stackTraceToString(ex));
/*      */       } finally {
/* 4020 */         if (rs != null) {
/* 4021 */           rs.close();
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 4026 */     if (this.connection.getIncludeThreadDumpInDeadlockExceptions()) {
/* 4027 */       errorBuf.append("\n\n*** Java threads running at time of deadlock ***\n\n");
/*      */       
/* 4029 */       ThreadMXBean threadMBean = ManagementFactory.getThreadMXBean();
/* 4030 */       long[] threadIds = threadMBean.getAllThreadIds();
/*      */       
/* 4032 */       ThreadInfo[] threads = threadMBean.getThreadInfo(threadIds, 2147483647);
/* 4033 */       List<ThreadInfo> activeThreads = new ArrayList<ThreadInfo>();
/*      */       
/* 4035 */       for (ThreadInfo info : threads) {
/* 4036 */         if (info != null) {
/* 4037 */           activeThreads.add(info);
/*      */         }
/*      */       } 
/*      */       
/* 4041 */       for (ThreadInfo threadInfo : activeThreads) {
/*      */ 
/*      */         
/* 4044 */         errorBuf.append('"');
/* 4045 */         errorBuf.append(threadInfo.getThreadName());
/* 4046 */         errorBuf.append("\" tid=");
/* 4047 */         errorBuf.append(threadInfo.getThreadId());
/* 4048 */         errorBuf.append(" ");
/* 4049 */         errorBuf.append(threadInfo.getThreadState());
/*      */         
/* 4051 */         if (threadInfo.getLockName() != null) {
/* 4052 */           errorBuf.append(" on lock=" + threadInfo.getLockName());
/*      */         }
/* 4054 */         if (threadInfo.isSuspended()) {
/* 4055 */           errorBuf.append(" (suspended)");
/*      */         }
/* 4057 */         if (threadInfo.isInNative()) {
/* 4058 */           errorBuf.append(" (running in native)");
/*      */         }
/*      */         
/* 4061 */         StackTraceElement[] stackTrace = threadInfo.getStackTrace();
/*      */         
/* 4063 */         if (stackTrace.length > 0) {
/* 4064 */           errorBuf.append(" in ");
/* 4065 */           errorBuf.append(stackTrace[0].getClassName());
/* 4066 */           errorBuf.append(".");
/* 4067 */           errorBuf.append(stackTrace[0].getMethodName());
/* 4068 */           errorBuf.append("()");
/*      */         } 
/*      */         
/* 4071 */         errorBuf.append("\n");
/*      */         
/* 4073 */         if (threadInfo.getLockOwnerName() != null) {
/* 4074 */           errorBuf.append("\t owned by " + threadInfo.getLockOwnerName() + " Id=" + threadInfo.getLockOwnerId());
/* 4075 */           errorBuf.append("\n");
/*      */         } 
/*      */         
/* 4078 */         for (int j = 0; j < stackTrace.length; j++) {
/* 4079 */           StackTraceElement ste = stackTrace[j];
/* 4080 */           errorBuf.append("\tat " + ste.toString());
/* 4081 */           errorBuf.append("\n");
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void sendSplitPackets(Buffer packet, int packetLen) throws SQLException {
/*      */     try {
/* 4097 */       Buffer packetToSend = (this.splitBufRef == null) ? null : this.splitBufRef.get();
/* 4098 */       Buffer toCompress = (!this.useCompression || this.compressBufRef == null) ? null : this.compressBufRef.get();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4104 */       if (packetToSend == null) {
/* 4105 */         packetToSend = new Buffer(this.maxThreeBytes + 4);
/* 4106 */         this.splitBufRef = new SoftReference<Buffer>(packetToSend);
/*      */       } 
/* 4108 */       if (this.useCompression) {
/* 4109 */         int cbuflen = packetLen + (packetLen / this.maxThreeBytes + 1) * 4;
/* 4110 */         if (toCompress == null) {
/* 4111 */           toCompress = new Buffer(cbuflen);
/* 4112 */           this.compressBufRef = new SoftReference<Buffer>(toCompress);
/* 4113 */         } else if (toCompress.getBufLength() < cbuflen) {
/* 4114 */           toCompress.setPosition(toCompress.getBufLength());
/* 4115 */           toCompress.ensureCapacity(cbuflen - toCompress.getBufLength());
/*      */         } 
/*      */       } 
/*      */       
/* 4119 */       int len = packetLen - 4;
/* 4120 */       int splitSize = this.maxThreeBytes;
/* 4121 */       int originalPacketPos = 4;
/* 4122 */       byte[] origPacketBytes = packet.getByteBuffer();
/*      */       
/* 4124 */       int toCompressPosition = 0;
/*      */ 
/*      */       
/* 4127 */       while (len >= 0) {
/* 4128 */         this.packetSequence = (byte)(this.packetSequence + 1);
/*      */         
/* 4130 */         if (len < splitSize) {
/* 4131 */           splitSize = len;
/*      */         }
/*      */         
/* 4134 */         packetToSend.setPosition(0);
/* 4135 */         packetToSend.writeLongInt(splitSize);
/* 4136 */         packetToSend.writeByte(this.packetSequence);
/* 4137 */         if (len > 0) {
/* 4138 */           System.arraycopy(origPacketBytes, originalPacketPos, packetToSend.getByteBuffer(), 4, splitSize);
/*      */         }
/*      */         
/* 4141 */         if (this.useCompression) {
/* 4142 */           System.arraycopy(packetToSend.getByteBuffer(), 0, toCompress.getByteBuffer(), toCompressPosition, 4 + splitSize);
/* 4143 */           toCompressPosition += 4 + splitSize;
/*      */         } else {
/* 4145 */           this.mysqlOutput.write(packetToSend.getByteBuffer(), 0, 4 + splitSize);
/* 4146 */           this.mysqlOutput.flush();
/*      */         } 
/*      */         
/* 4149 */         originalPacketPos += splitSize;
/* 4150 */         len -= this.maxThreeBytes;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 4155 */       if (this.useCompression) {
/* 4156 */         len = toCompressPosition;
/* 4157 */         toCompressPosition = 0;
/* 4158 */         splitSize = this.maxThreeBytes - 3;
/* 4159 */         while (len >= 0) {
/* 4160 */           this.compressedPacketSequence = (byte)(this.compressedPacketSequence + 1);
/*      */           
/* 4162 */           if (len < splitSize) {
/* 4163 */             splitSize = len;
/*      */           }
/*      */           
/* 4166 */           Buffer compressedPacketToSend = compressPacket(toCompress, toCompressPosition, splitSize);
/* 4167 */           packetLen = compressedPacketToSend.getPosition();
/* 4168 */           this.mysqlOutput.write(compressedPacketToSend.getByteBuffer(), 0, packetLen);
/* 4169 */           this.mysqlOutput.flush();
/*      */           
/* 4171 */           toCompressPosition += splitSize;
/* 4172 */           len -= this.maxThreeBytes - 3;
/*      */         } 
/*      */       } 
/* 4175 */     } catch (IOException ioEx) {
/* 4176 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void reclaimLargeSharedSendPacket() {
/* 4182 */     if (this.sharedSendPacket != null && this.sharedSendPacket.getCapacity() > 1048576) {
/* 4183 */       this.sharedSendPacket = new Buffer(1024);
/*      */     }
/*      */   }
/*      */   
/*      */   boolean hadWarnings() {
/* 4188 */     return this.hadWarnings;
/*      */   }
/*      */   
/*      */   void scanForAndThrowDataTruncation() throws SQLException {
/* 4192 */     if (this.streamingData == null && versionMeetsMinimum(4, 1, 0) && this.connection.getJdbcCompliantTruncation() && this.warningCount > 0) {
/* 4193 */       int warningCountOld = this.warningCount;
/* 4194 */       SQLError.convertShowWarningsToSQLWarnings(this.connection, this.warningCount, true);
/* 4195 */       this.warningCount = warningCountOld;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void secureAuth(Buffer packet, int packLength, String user, String password, String database, boolean writeClientParams) throws SQLException {
/* 4213 */     if (packet == null) {
/* 4214 */       packet = new Buffer(packLength);
/*      */     }
/*      */     
/* 4217 */     if (writeClientParams) {
/* 4218 */       if (this.use41Extensions) {
/* 4219 */         if (versionMeetsMinimum(4, 1, 1)) {
/* 4220 */           packet.writeLong(this.clientParam);
/* 4221 */           packet.writeLong(this.maxThreeBytes);
/*      */ 
/*      */           
/* 4224 */           packet.writeByte((byte)8);
/*      */ 
/*      */           
/* 4227 */           packet.writeBytesNoNull(new byte[23]);
/*      */         } else {
/* 4229 */           packet.writeLong(this.clientParam);
/* 4230 */           packet.writeLong(this.maxThreeBytes);
/*      */         } 
/*      */       } else {
/* 4233 */         packet.writeInt((int)this.clientParam);
/* 4234 */         packet.writeLongInt(this.maxThreeBytes);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 4239 */     packet.writeString(user, "Cp1252", this.connection);
/*      */     
/* 4241 */     if (password.length() != 0) {
/*      */       
/* 4243 */       packet.writeString("xxxxxxxx", "Cp1252", this.connection);
/*      */     } else {
/*      */       
/* 4246 */       packet.writeString("", "Cp1252", this.connection);
/*      */     } 
/*      */     
/* 4249 */     if (this.useConnectWithDb) {
/* 4250 */       packet.writeString(database, "Cp1252", this.connection);
/*      */     }
/*      */     
/* 4253 */     send(packet, packet.getPosition());
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4258 */     if (password.length() > 0) {
/* 4259 */       Buffer b = readPacket();
/*      */       
/* 4261 */       b.setPosition(0);
/*      */       
/* 4263 */       byte[] replyAsBytes = b.getByteBuffer();
/*      */       
/* 4265 */       if (replyAsBytes.length == 24 && replyAsBytes[0] != 0)
/*      */       {
/* 4267 */         if (replyAsBytes[0] != 42) {
/*      */           
/*      */           try {
/* 4270 */             byte[] buff = Security.passwordHashStage1(password);
/*      */ 
/*      */             
/* 4273 */             byte[] passwordHash = new byte[buff.length];
/* 4274 */             System.arraycopy(buff, 0, passwordHash, 0, buff.length);
/*      */ 
/*      */             
/* 4277 */             passwordHash = Security.passwordHashStage2(passwordHash, replyAsBytes);
/*      */             
/* 4279 */             byte[] packetDataAfterSalt = new byte[replyAsBytes.length - 4];
/*      */             
/* 4281 */             System.arraycopy(replyAsBytes, 4, packetDataAfterSalt, 0, replyAsBytes.length - 4);
/*      */             
/* 4283 */             byte[] mysqlScrambleBuff = new byte[20];
/*      */ 
/*      */             
/* 4286 */             Security.xorString(packetDataAfterSalt, mysqlScrambleBuff, passwordHash, 20);
/*      */ 
/*      */             
/* 4289 */             Security.xorString(mysqlScrambleBuff, buff, buff, 20);
/*      */             
/* 4291 */             Buffer packet2 = new Buffer(25);
/* 4292 */             packet2.writeBytesNoNull(buff);
/*      */             
/* 4294 */             this.packetSequence = (byte)(this.packetSequence + 1);
/*      */             
/* 4296 */             send(packet2, 24);
/* 4297 */           } catch (NoSuchAlgorithmException nse) {
/* 4298 */             throw SQLError.createSQLException(Messages.getString("MysqlIO.91") + Messages.getString("MysqlIO.92"), "S1000", getExceptionInterceptor());
/*      */           } 
/*      */         } else {
/*      */ 
/*      */           
/*      */           try {
/* 4304 */             byte[] passwordHash = Security.createKeyFromOldPassword(password);
/*      */ 
/*      */             
/* 4307 */             byte[] netReadPos4 = new byte[replyAsBytes.length - 4];
/*      */             
/* 4309 */             System.arraycopy(replyAsBytes, 4, netReadPos4, 0, replyAsBytes.length - 4);
/*      */             
/* 4311 */             byte[] mysqlScrambleBuff = new byte[20];
/*      */ 
/*      */             
/* 4314 */             Security.xorString(netReadPos4, mysqlScrambleBuff, passwordHash, 20);
/*      */ 
/*      */             
/* 4317 */             String scrambledPassword = Util.scramble(StringUtils.toString(mysqlScrambleBuff), password);
/*      */             
/* 4319 */             Buffer packet2 = new Buffer(packLength);
/* 4320 */             packet2.writeString(scrambledPassword, "Cp1252", this.connection);
/* 4321 */             this.packetSequence = (byte)(this.packetSequence + 1);
/*      */             
/* 4323 */             send(packet2, 24);
/* 4324 */           } catch (NoSuchAlgorithmException nse) {
/* 4325 */             throw SQLError.createSQLException(Messages.getString("MysqlIO.91") + Messages.getString("MysqlIO.92"), "S1000", getExceptionInterceptor());
/*      */           } 
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void secureAuth411(Buffer packet, int packLength, String user, String password, String database, boolean writeClientParams, boolean forChangeUser) throws SQLException {
/* 4348 */     String enc = getEncodingForHandshake();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4367 */     if (packet == null) {
/* 4368 */       packet = new Buffer(packLength);
/*      */     }
/*      */     
/* 4371 */     if (writeClientParams) {
/* 4372 */       if (this.use41Extensions) {
/* 4373 */         if (versionMeetsMinimum(4, 1, 1)) {
/* 4374 */           packet.writeLong(this.clientParam);
/* 4375 */           packet.writeLong(this.maxThreeBytes);
/*      */           
/* 4377 */           appendCharsetByteForHandshake(packet, enc);
/*      */ 
/*      */           
/* 4380 */           packet.writeBytesNoNull(new byte[23]);
/*      */         } else {
/* 4382 */           packet.writeLong(this.clientParam);
/* 4383 */           packet.writeLong(this.maxThreeBytes);
/*      */         } 
/*      */       } else {
/* 4386 */         packet.writeInt((int)this.clientParam);
/* 4387 */         packet.writeLongInt(this.maxThreeBytes);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 4392 */     if (user != null) {
/* 4393 */       packet.writeString(user, enc, this.connection);
/*      */     }
/*      */     
/* 4396 */     if (password.length() != 0) {
/* 4397 */       packet.writeByte((byte)20);
/*      */       
/*      */       try {
/* 4400 */         packet.writeBytesNoNull(Security.scramble411(password, this.seed, this.connection.getPasswordCharacterEncoding()));
/* 4401 */       } catch (NoSuchAlgorithmException nse) {
/* 4402 */         throw SQLError.createSQLException(Messages.getString("MysqlIO.91") + Messages.getString("MysqlIO.92"), "S1000", getExceptionInterceptor());
/*      */       }
/* 4404 */       catch (UnsupportedEncodingException e) {
/* 4405 */         throw SQLError.createSQLException(Messages.getString("MysqlIO.91") + Messages.getString("MysqlIO.92"), "S1000", getExceptionInterceptor());
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 4410 */       packet.writeByte((byte)0);
/*      */     } 
/*      */     
/* 4413 */     if (this.useConnectWithDb) {
/* 4414 */       packet.writeString(database, enc, this.connection);
/* 4415 */     } else if (forChangeUser) {
/*      */       
/* 4417 */       packet.writeByte((byte)0);
/*      */     } 
/*      */ 
/*      */     
/* 4421 */     if ((this.serverCapabilities & 0x100000) != 0) {
/* 4422 */       sendConnectionAttributes(packet, enc, this.connection);
/*      */     }
/*      */     
/* 4425 */     send(packet, packet.getPosition());
/*      */     
/* 4427 */     byte savePacketSequence = this.packetSequence = (byte)(this.packetSequence + 1);
/*      */     
/* 4429 */     Buffer reply = checkErrorPacket();
/*      */     
/* 4431 */     if (reply.isAuthMethodSwitchRequestPacket()) {
/*      */ 
/*      */ 
/*      */       
/* 4435 */       this.packetSequence = savePacketSequence = (byte)(savePacketSequence + 1);
/* 4436 */       packet.clear();
/*      */       
/* 4438 */       String seed323 = this.seed.substring(0, 8);
/* 4439 */       packet.writeString(Util.newCrypt(password, seed323, this.connection.getPasswordCharacterEncoding()));
/* 4440 */       send(packet, packet.getPosition());
/*      */ 
/*      */       
/* 4443 */       checkErrorPacket();
/*      */     } 
/*      */     
/* 4446 */     if (!this.useConnectWithDb) {
/* 4447 */       changeDatabaseTo(database);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final ResultSetRow unpackBinaryResultSetRow(Field[] fields, Buffer binaryData, int resultSetConcurrency) throws SQLException {
/* 4463 */     int numFields = fields.length;
/*      */     
/* 4465 */     byte[][] unpackedRowData = new byte[numFields][];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4471 */     int nullCount = (numFields + 9) / 8;
/* 4472 */     int nullMaskPos = binaryData.getPosition();
/* 4473 */     binaryData.setPosition(nullMaskPos + nullCount);
/* 4474 */     int bit = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4480 */     for (int i = 0; i < numFields; i++) {
/* 4481 */       if ((binaryData.readByte(nullMaskPos) & bit) != 0) {
/* 4482 */         unpackedRowData[i] = null;
/*      */       }
/* 4484 */       else if (resultSetConcurrency != 1008) {
/* 4485 */         extractNativeEncodedColumn(binaryData, fields, i, unpackedRowData);
/*      */       } else {
/* 4487 */         unpackNativeEncodedColumn(binaryData, fields, i, unpackedRowData);
/*      */       } 
/*      */ 
/*      */       
/* 4491 */       if (((bit <<= 1) & 0xFF) == 0) {
/* 4492 */         bit = 1;
/*      */         
/* 4494 */         nullMaskPos++;
/*      */       } 
/*      */     } 
/*      */     
/* 4498 */     return new ByteArrayRow(unpackedRowData, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */   private final void extractNativeEncodedColumn(Buffer binaryData, Field[] fields, int columnIndex, byte[][] unpackedRowData) throws SQLException { int length;
/* 4502 */     Field curField = fields[columnIndex];
/*      */     
/* 4504 */     switch (curField.getMysqlType()) {
/*      */       case 6:
/*      */         return;
/*      */ 
/*      */       
/*      */       case 1:
/* 4510 */         (new byte[1])[0] = binaryData.readByte(); unpackedRowData[columnIndex] = new byte[1];
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/*      */       case 13:
/* 4516 */         unpackedRowData[columnIndex] = binaryData.getBytes(2);
/*      */ 
/*      */       
/*      */       case 3:
/*      */       case 9:
/* 4521 */         unpackedRowData[columnIndex] = binaryData.getBytes(4);
/*      */ 
/*      */       
/*      */       case 8:
/* 4525 */         unpackedRowData[columnIndex] = binaryData.getBytes(8);
/*      */ 
/*      */       
/*      */       case 4:
/* 4529 */         unpackedRowData[columnIndex] = binaryData.getBytes(4);
/*      */ 
/*      */       
/*      */       case 5:
/* 4533 */         unpackedRowData[columnIndex] = binaryData.getBytes(8);
/*      */ 
/*      */       
/*      */       case 11:
/* 4537 */         length = (int)binaryData.readFieldLength();
/*      */         
/* 4539 */         unpackedRowData[columnIndex] = binaryData.getBytes(length);
/*      */ 
/*      */ 
/*      */       
/*      */       case 10:
/* 4544 */         length = (int)binaryData.readFieldLength();
/*      */         
/* 4546 */         unpackedRowData[columnIndex] = binaryData.getBytes(length);
/*      */ 
/*      */       
/*      */       case 7:
/*      */       case 12:
/* 4551 */         length = (int)binaryData.readFieldLength();
/*      */         
/* 4553 */         unpackedRowData[columnIndex] = binaryData.getBytes(length);
/*      */       
/*      */       case 0:
/*      */       case 15:
/*      */       case 16:
/*      */       case 245:
/*      */       case 246:
/*      */       case 249:
/*      */       case 250:
/*      */       case 251:
/*      */       case 252:
/*      */       case 253:
/*      */       case 254:
/*      */       case 255:
/* 4567 */         unpackedRowData[columnIndex] = binaryData.readLenByteArray(0);
/*      */     } 
/*      */ 
/*      */     
/* 4571 */     throw SQLError.createSQLException(Messages.getString("MysqlIO.97") + curField.getMysqlType() + Messages.getString("MysqlIO.98") + columnIndex + Messages.getString("MysqlIO.99") + fields.length + Messages.getString("MysqlIO.100"), "S1000", getExceptionInterceptor()); } private final void unpackNativeEncodedColumn(Buffer binaryData, Field[] fields, int columnIndex, byte[][] unpackedRowData) throws SQLException { byte tinyVal; short shortVal; int intVal; long longVal; float floatVal; double doubleVal;
/*      */     int length, hour, minute, seconds;
/*      */     byte[] timeAsBytes;
/*      */     int year, month, day;
/*      */     byte[] arrayOfByte1;
/*      */     int i, j, nanos, k;
/*      */     byte[] arrayOfByte2, arrayOfByte3;
/*      */     byte b;
/* 4579 */     Field curField = fields[columnIndex];
/*      */     
/* 4581 */     switch (curField.getMysqlType()) {
/*      */       case 6:
/*      */         return;
/*      */ 
/*      */       
/*      */       case 1:
/* 4587 */         tinyVal = binaryData.readByte();
/*      */         
/* 4589 */         if (!curField.isUnsigned()) {
/* 4590 */           unpackedRowData[columnIndex] = StringUtils.getBytes(String.valueOf(tinyVal));
/*      */         } else {
/* 4592 */           short unsignedTinyVal = (short)(tinyVal & 0xFF);
/*      */           
/* 4594 */           unpackedRowData[columnIndex] = StringUtils.getBytes(String.valueOf(unsignedTinyVal));
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/*      */       case 13:
/* 4602 */         shortVal = (short)binaryData.readInt();
/*      */         
/* 4604 */         if (!curField.isUnsigned()) {
/* 4605 */           unpackedRowData[columnIndex] = StringUtils.getBytes(String.valueOf(shortVal));
/*      */         } else {
/* 4607 */           int unsignedShortVal = shortVal & 0xFFFF;
/*      */           
/* 4609 */           unpackedRowData[columnIndex] = StringUtils.getBytes(String.valueOf(unsignedShortVal));
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 3:
/*      */       case 9:
/* 4617 */         intVal = (int)binaryData.readLong();
/*      */         
/* 4619 */         if (!curField.isUnsigned()) {
/* 4620 */           unpackedRowData[columnIndex] = StringUtils.getBytes(String.valueOf(intVal));
/*      */         } else {
/* 4622 */           long l = intVal & 0xFFFFFFFFL;
/*      */           
/* 4624 */           unpackedRowData[columnIndex] = StringUtils.getBytes(String.valueOf(l));
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 8:
/* 4631 */         longVal = binaryData.readLongLong();
/*      */         
/* 4633 */         if (!curField.isUnsigned()) {
/* 4634 */           unpackedRowData[columnIndex] = StringUtils.getBytes(String.valueOf(longVal));
/*      */         } else {
/* 4636 */           BigInteger asBigInteger = ResultSetImpl.convertLongToUlong(longVal);
/*      */           
/* 4638 */           unpackedRowData[columnIndex] = StringUtils.getBytes(asBigInteger.toString());
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 4:
/* 4645 */         floatVal = Float.intBitsToFloat(binaryData.readIntAsLong());
/*      */         
/* 4647 */         unpackedRowData[columnIndex] = StringUtils.getBytes(String.valueOf(floatVal));
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 5:
/* 4653 */         doubleVal = Double.longBitsToDouble(binaryData.readLongLong());
/*      */         
/* 4655 */         unpackedRowData[columnIndex] = StringUtils.getBytes(String.valueOf(doubleVal));
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 11:
/* 4661 */         length = (int)binaryData.readFieldLength();
/*      */         
/* 4663 */         hour = 0;
/* 4664 */         minute = 0;
/* 4665 */         seconds = 0;
/*      */         
/* 4667 */         if (length != 0) {
/* 4668 */           binaryData.readByte();
/* 4669 */           binaryData.readLong();
/* 4670 */           hour = binaryData.readByte();
/* 4671 */           minute = binaryData.readByte();
/* 4672 */           seconds = binaryData.readByte();
/*      */           
/* 4674 */           if (length > 8) {
/* 4675 */             binaryData.readLong();
/*      */           }
/*      */         } 
/*      */         
/* 4679 */         timeAsBytes = new byte[8];
/*      */         
/* 4681 */         timeAsBytes[0] = (byte)Character.forDigit(hour / 10, 10);
/* 4682 */         timeAsBytes[1] = (byte)Character.forDigit(hour % 10, 10);
/*      */         
/* 4684 */         timeAsBytes[2] = 58;
/*      */         
/* 4686 */         timeAsBytes[3] = (byte)Character.forDigit(minute / 10, 10);
/* 4687 */         timeAsBytes[4] = (byte)Character.forDigit(minute % 10, 10);
/*      */         
/* 4689 */         timeAsBytes[5] = 58;
/*      */         
/* 4691 */         timeAsBytes[6] = (byte)Character.forDigit(seconds / 10, 10);
/* 4692 */         timeAsBytes[7] = (byte)Character.forDigit(seconds % 10, 10);
/*      */         
/* 4694 */         unpackedRowData[columnIndex] = timeAsBytes;
/*      */ 
/*      */ 
/*      */       
/*      */       case 10:
/* 4699 */         length = (int)binaryData.readFieldLength();
/*      */         
/* 4701 */         year = 0;
/* 4702 */         month = 0;
/* 4703 */         day = 0;
/*      */         
/* 4705 */         hour = 0;
/* 4706 */         minute = 0;
/* 4707 */         seconds = 0;
/*      */         
/* 4709 */         if (length != 0) {
/* 4710 */           year = binaryData.readInt();
/* 4711 */           month = binaryData.readByte();
/* 4712 */           day = binaryData.readByte();
/*      */         } 
/*      */         
/* 4715 */         if (year == 0 && month == 0 && day == 0)
/* 4716 */           if ("convertToNull".equals(this.connection.getZeroDateTimeBehavior()))
/* 4717 */           { unpackedRowData[columnIndex] = null; }
/*      */           else
/*      */           
/* 4720 */           { if ("exception".equals(this.connection.getZeroDateTimeBehavior())) {
/* 4721 */               throw SQLError.createSQLException("Value '0000-00-00' can not be represented as java.sql.Date", "S1009", getExceptionInterceptor());
/*      */             }
/*      */ 
/*      */             
/* 4725 */             year = 1;
/* 4726 */             month = 1;
/* 4727 */             day = 1;
/*      */ 
/*      */             
/* 4730 */             byte[] dateAsBytes = new byte[10];
/*      */             
/* 4732 */             dateAsBytes[0] = (byte)Character.forDigit(year / 1000, 10);
/*      */             
/* 4734 */             int after1000 = year % 1000;
/*      */             
/* 4736 */             dateAsBytes[1] = (byte)Character.forDigit(after1000 / 100, 10);
/*      */             
/* 4738 */             int after100 = after1000 % 100;
/*      */             
/* 4740 */             dateAsBytes[2] = (byte)Character.forDigit(after100 / 10, 10);
/* 4741 */             dateAsBytes[3] = (byte)Character.forDigit(after100 % 10, 10);
/*      */             
/* 4743 */             dateAsBytes[4] = 45;
/*      */             
/* 4745 */             dateAsBytes[5] = (byte)Character.forDigit(month / 10, 10);
/* 4746 */             dateAsBytes[6] = (byte)Character.forDigit(month % 10, 10);
/*      */             
/* 4748 */             dateAsBytes[7] = 45;
/*      */             
/* 4750 */             dateAsBytes[8] = (byte)Character.forDigit(day / 10, 10);
/* 4751 */             dateAsBytes[9] = (byte)Character.forDigit(day % 10, 10);
/*      */             
/* 4753 */             unpackedRowData[columnIndex] = dateAsBytes; }   arrayOfByte1 = new byte[10]; arrayOfByte1[0] = (byte)Character.forDigit(year / 1000, 10); i = year % 1000; arrayOfByte1[1] = (byte)Character.forDigit(i / 100, 10); j = i % 100; arrayOfByte1[2] = (byte)Character.forDigit(j / 10, 10); arrayOfByte1[3] = (byte)Character.forDigit(j % 10, 10); arrayOfByte1[4] = 45; arrayOfByte1[5] = (byte)Character.forDigit(month / 10, 10); arrayOfByte1[6] = (byte)Character.forDigit(month % 10, 10); arrayOfByte1[7] = 45; arrayOfByte1[8] = (byte)Character.forDigit(day / 10, 10); arrayOfByte1[9] = (byte)Character.forDigit(day % 10, 10); unpackedRowData[columnIndex] = arrayOfByte1;
/*      */ 
/*      */ 
/*      */       
/*      */       case 7:
/*      */       case 12:
/* 4759 */         length = (int)binaryData.readFieldLength();
/*      */         
/* 4761 */         year = 0;
/* 4762 */         month = 0;
/* 4763 */         day = 0;
/*      */         
/* 4765 */         hour = 0;
/* 4766 */         minute = 0;
/* 4767 */         seconds = 0;
/*      */         
/* 4769 */         nanos = 0;
/*      */         
/* 4771 */         if (length != 0) {
/* 4772 */           year = binaryData.readInt();
/* 4773 */           month = binaryData.readByte();
/* 4774 */           day = binaryData.readByte();
/*      */           
/* 4776 */           if (length > 4) {
/* 4777 */             hour = binaryData.readByte();
/* 4778 */             minute = binaryData.readByte();
/* 4779 */             seconds = binaryData.readByte();
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4787 */         if (year == 0 && month == 0 && day == 0)
/* 4788 */           if ("convertToNull".equals(this.connection.getZeroDateTimeBehavior()))
/* 4789 */           { unpackedRowData[columnIndex] = null; }
/*      */           else
/*      */           
/* 4792 */           { if ("exception".equals(this.connection.getZeroDateTimeBehavior())) {
/* 4793 */               throw SQLError.createSQLException("Value '0000-00-00' can not be represented as java.sql.Timestamp", "S1009", getExceptionInterceptor());
/*      */             }
/*      */ 
/*      */             
/* 4797 */             year = 1;
/* 4798 */             month = 1;
/* 4799 */             day = 1;
/*      */ 
/*      */             
/* 4802 */             int stringLength = 19;
/*      */             
/* 4804 */             byte[] nanosAsBytes = StringUtils.getBytes(Integer.toString(nanos));
/*      */             
/* 4806 */             stringLength += 1 + nanosAsBytes.length;
/*      */             
/* 4808 */             byte[] datetimeAsBytes = new byte[stringLength];
/*      */             
/* 4810 */             datetimeAsBytes[0] = (byte)Character.forDigit(year / 1000, 10);
/*      */             
/* 4812 */             i = year % 1000;
/*      */             
/* 4814 */             datetimeAsBytes[1] = (byte)Character.forDigit(i / 100, 10);
/*      */             
/* 4816 */             j = i % 100;
/*      */             
/* 4818 */             datetimeAsBytes[2] = (byte)Character.forDigit(j / 10, 10);
/* 4819 */             datetimeAsBytes[3] = (byte)Character.forDigit(j % 10, 10);
/*      */             
/* 4821 */             datetimeAsBytes[4] = 45;
/*      */             
/* 4823 */             datetimeAsBytes[5] = (byte)Character.forDigit(month / 10, 10);
/* 4824 */             datetimeAsBytes[6] = (byte)Character.forDigit(month % 10, 10);
/*      */             
/* 4826 */             datetimeAsBytes[7] = 45;
/*      */             
/* 4828 */             datetimeAsBytes[8] = (byte)Character.forDigit(day / 10, 10);
/* 4829 */             datetimeAsBytes[9] = (byte)Character.forDigit(day % 10, 10);
/*      */             
/* 4831 */             datetimeAsBytes[10] = 32;
/*      */             
/* 4833 */             datetimeAsBytes[11] = (byte)Character.forDigit(hour / 10, 10);
/* 4834 */             datetimeAsBytes[12] = (byte)Character.forDigit(hour % 10, 10);
/*      */             
/* 4836 */             datetimeAsBytes[13] = 58;
/*      */             
/* 4838 */             datetimeAsBytes[14] = (byte)Character.forDigit(minute / 10, 10);
/* 4839 */             datetimeAsBytes[15] = (byte)Character.forDigit(minute % 10, 10);
/*      */             
/* 4841 */             datetimeAsBytes[16] = 58;
/*      */             
/* 4843 */             datetimeAsBytes[17] = (byte)Character.forDigit(seconds / 10, 10);
/* 4844 */             datetimeAsBytes[18] = (byte)Character.forDigit(seconds % 10, 10);
/*      */             
/* 4846 */             datetimeAsBytes[19] = 46;
/*      */             
/* 4848 */             int nanosOffset = 20;
/*      */             
/* 4850 */             System.arraycopy(nanosAsBytes, 0, datetimeAsBytes, 20, nanosAsBytes.length);
/*      */             
/* 4852 */             unpackedRowData[columnIndex] = datetimeAsBytes; }   k = 19; arrayOfByte2 = StringUtils.getBytes(Integer.toString(nanos)); k += 1 + arrayOfByte2.length; arrayOfByte3 = new byte[k]; arrayOfByte3[0] = (byte)Character.forDigit(year / 1000, 10); i = year % 1000; arrayOfByte3[1] = (byte)Character.forDigit(i / 100, 10); j = i % 100; arrayOfByte3[2] = (byte)Character.forDigit(j / 10, 10); arrayOfByte3[3] = (byte)Character.forDigit(j % 10, 10); arrayOfByte3[4] = 45; arrayOfByte3[5] = (byte)Character.forDigit(month / 10, 10); arrayOfByte3[6] = (byte)Character.forDigit(month % 10, 10); arrayOfByte3[7] = 45; arrayOfByte3[8] = (byte)Character.forDigit(day / 10, 10); arrayOfByte3[9] = (byte)Character.forDigit(day % 10, 10); arrayOfByte3[10] = 32; arrayOfByte3[11] = (byte)Character.forDigit(hour / 10, 10); arrayOfByte3[12] = (byte)Character.forDigit(hour % 10, 10); arrayOfByte3[13] = 58; arrayOfByte3[14] = (byte)Character.forDigit(minute / 10, 10); arrayOfByte3[15] = (byte)Character.forDigit(minute % 10, 10); arrayOfByte3[16] = 58; arrayOfByte3[17] = (byte)Character.forDigit(seconds / 10, 10); arrayOfByte3[18] = (byte)Character.forDigit(seconds % 10, 10); arrayOfByte3[19] = 46; b = 20; System.arraycopy(arrayOfByte2, 0, arrayOfByte3, 20, arrayOfByte2.length); unpackedRowData[columnIndex] = arrayOfByte3;
/*      */ 
/*      */ 
/*      */       
/*      */       case 0:
/*      */       case 15:
/*      */       case 16:
/*      */       case 245:
/*      */       case 246:
/*      */       case 249:
/*      */       case 250:
/*      */       case 251:
/*      */       case 252:
/*      */       case 253:
/*      */       case 254:
/* 4867 */         unpackedRowData[columnIndex] = binaryData.readLenByteArray(0);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 4872 */     throw SQLError.createSQLException(Messages.getString("MysqlIO.97") + curField.getMysqlType() + Messages.getString("MysqlIO.98") + columnIndex + Messages.getString("MysqlIO.99") + fields.length + Messages.getString("MysqlIO.100"), "S1000", getExceptionInterceptor()); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void negotiateSSLConnection(String user, String password, String database, int packLength) throws SQLException {
/* 4891 */     if (!ExportControlled.enabled()) {
/* 4892 */       throw new ConnectionFeatureNotAvailableException(this.connection, this.lastPacketSentTimeMs, null);
/*      */     }
/*      */     
/* 4895 */     if ((this.serverCapabilities & 0x8000) != 0) {
/* 4896 */       this.clientParam |= 0x8000L;
/*      */     }
/*      */     
/* 4899 */     this.clientParam |= 0x800L;
/*      */     
/* 4901 */     Buffer packet = new Buffer(packLength);
/*      */     
/* 4903 */     if (this.use41Extensions) {
/* 4904 */       packet.writeLong(this.clientParam);
/* 4905 */       packet.writeLong(this.maxThreeBytes);
/* 4906 */       appendCharsetByteForHandshake(packet, getEncodingForHandshake());
/* 4907 */       packet.writeBytesNoNull(new byte[23]);
/*      */     } else {
/* 4909 */       packet.writeInt((int)this.clientParam);
/*      */     } 
/*      */     
/* 4912 */     send(packet, packet.getPosition());
/*      */     
/* 4914 */     ExportControlled.transformSocketToSSLSocket(this);
/*      */   }
/*      */   
/*      */   public boolean isSSLEstablished() {
/* 4918 */     return (ExportControlled.enabled() && ExportControlled.isSSLEstablished(this));
/*      */   }
/*      */   
/*      */   protected int getServerStatus() {
/* 4922 */     return this.serverStatus;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected List<ResultSetRow> fetchRowsViaCursor(List<ResultSetRow> fetchedRows, long statementId, Field[] columnTypes, int fetchSize, boolean useBufferRowExplicit) throws SQLException {
/* 4928 */     if (fetchedRows == null) {
/* 4929 */       fetchedRows = new ArrayList<ResultSetRow>(fetchSize);
/*      */     } else {
/* 4931 */       fetchedRows.clear();
/*      */     } 
/*      */     
/* 4934 */     this.sharedSendPacket.clear();
/*      */     
/* 4936 */     this.sharedSendPacket.writeByte((byte)28);
/* 4937 */     this.sharedSendPacket.writeLong(statementId);
/* 4938 */     this.sharedSendPacket.writeLong(fetchSize);
/*      */     
/* 4940 */     sendCommand(28, null, this.sharedSendPacket, true, null, 0);
/*      */     
/* 4942 */     ResultSetRow row = null;
/*      */     
/* 4944 */     while ((row = nextRow(columnTypes, columnTypes.length, true, 1007, false, useBufferRowExplicit, false, null)) != null) {
/* 4945 */       fetchedRows.add(row);
/*      */     }
/*      */     
/* 4948 */     return fetchedRows;
/*      */   }
/*      */   
/*      */   protected long getThreadId() {
/* 4952 */     return this.threadId;
/*      */   }
/*      */   
/*      */   protected boolean useNanosForElapsedTime() {
/* 4956 */     return this.useNanosForElapsedTime;
/*      */   }
/*      */   
/*      */   protected long getSlowQueryThreshold() {
/* 4960 */     return this.slowQueryThreshold;
/*      */   }
/*      */   
/*      */   protected String getQueryTimingUnits() {
/* 4964 */     return this.queryTimingUnits;
/*      */   }
/*      */   
/*      */   protected int getCommandCount() {
/* 4968 */     return this.commandCount;
/*      */   }
/*      */   
/*      */   private void checkTransactionState(int oldStatus) throws SQLException {
/* 4972 */     boolean previouslyInTrans = ((oldStatus & 0x1) != 0);
/* 4973 */     boolean currentlyInTrans = inTransactionOnServer();
/*      */     
/* 4975 */     if (previouslyInTrans && !currentlyInTrans) {
/* 4976 */       this.connection.transactionCompleted();
/* 4977 */     } else if (!previouslyInTrans && currentlyInTrans) {
/* 4978 */       this.connection.transactionBegun();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void preserveOldTransactionState() {
/* 4983 */     this.serverStatus |= this.oldServerStatus & 0x1;
/*      */   }
/*      */   
/*      */   protected void setStatementInterceptors(List<StatementInterceptorV2> statementInterceptors) {
/* 4987 */     this.statementInterceptors = statementInterceptors.isEmpty() ? null : statementInterceptors;
/*      */   }
/*      */   
/*      */   protected ExceptionInterceptor getExceptionInterceptor() {
/* 4991 */     return this.exceptionInterceptor;
/*      */   }
/*      */   
/*      */   protected void setSocketTimeout(int milliseconds) throws SQLException {
/*      */     try {
/* 4996 */       if (this.mysqlConnection != null) {
/* 4997 */         this.mysqlConnection.setSoTimeout(milliseconds);
/*      */       }
/* 4999 */     } catch (SocketException e) {
/* 5000 */       SQLException sqlEx = SQLError.createSQLException("Invalid socket timeout value or state", "S1009", getExceptionInterceptor());
/*      */       
/* 5002 */       sqlEx.initCause(e);
/*      */       
/* 5004 */       throw sqlEx;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void releaseResources() {
/* 5009 */     if (this.deflater != null) {
/* 5010 */       this.deflater.end();
/* 5011 */       this.deflater = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getEncodingForHandshake() {
/* 5020 */     String enc = this.connection.getEncoding();
/* 5021 */     if (enc == null) {
/* 5022 */       enc = "UTF-8";
/*      */     }
/* 5024 */     return enc;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void appendCharsetByteForHandshake(Buffer packet, String enc) throws SQLException {
/* 5044 */     int charsetIndex = 0;
/* 5045 */     if (enc != null) {
/* 5046 */       charsetIndex = CharsetMapping.getCollationIndexForJavaEncoding(enc, this.connection);
/*      */     }
/* 5048 */     if (charsetIndex == 0) {
/* 5049 */       charsetIndex = 33;
/*      */     }
/* 5051 */     if (charsetIndex > 255) {
/* 5052 */       throw SQLError.createSQLException("Invalid character set index for encoding: " + enc, "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/* 5055 */     packet.writeByte((byte)charsetIndex);
/*      */   }
/*      */   
/*      */   public boolean isEOFDeprecated() {
/* 5059 */     return ((this.clientParam & 0x1000000L) != 0L);
/*      */   }
/*      */ }


/* Location:              C:\Users\neons\Desktop\JacobAloSchedulingApp\build\classes\!\lib\mysql-connector-java-5.1.47.jar!\com\mysql\jdbc\MysqlIO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.lang.ref.PhantomReference;
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.net.URLDecoder;
/*     */ import java.sql.Connection;
/*     */ import java.sql.Driver;
/*     */ import java.sql.DriverPropertyInfo;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Properties;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NonRegisteringDriver
/*     */   implements Driver
/*     */ {
/*     */   private static final String ALLOWED_QUOTES = "\"'";
/*     */   private static final String REPLICATION_URL_PREFIX = "jdbc:mysql:replication://";
/*     */   private static final String URL_PREFIX = "jdbc:mysql://";
/*     */   private static final String MXJ_URL_PREFIX = "jdbc:mysql:mxj://";
/*     */   public static final String LOADBALANCE_URL_PREFIX = "jdbc:mysql:loadbalance://";
/*  71 */   protected static final ConcurrentHashMap<ConnectionPhantomReference, ConnectionPhantomReference> connectionPhantomRefs = new ConcurrentHashMap<ConnectionPhantomReference, ConnectionPhantomReference>();
/*     */   
/*  73 */   protected static final ReferenceQueue<ConnectionImpl> refQueue = new ReferenceQueue<ConnectionImpl>();
/*     */   
/*  75 */   public static final String OS = getOSName();
/*  76 */   public static final String PLATFORM = getPlatform();
/*     */   public static final String LICENSE = "GPL";
/*  78 */   public static final String RUNTIME_VENDOR = System.getProperty("java.vendor");
/*  79 */   public static final String RUNTIME_VERSION = System.getProperty("java.version");
/*     */   public static final String VERSION = "5.1.47";
/*     */   public static final String NAME = "MySQL Connector Java";
/*     */   public static final String DBNAME_PROPERTY_KEY = "DBNAME";
/*     */   public static final boolean DEBUG = false;
/*     */   public static final int HOST_NAME_INDEX = 0;
/*     */   public static final String HOST_PROPERTY_KEY = "HOST";
/*     */   public static final String NUM_HOSTS_PROPERTY_KEY = "NUM_HOSTS";
/*     */   public static final String PASSWORD_PROPERTY_KEY = "password";
/*     */   
/*     */   public static String getOSName() {
/*  90 */     return System.getProperty("os.name");
/*     */   }
/*     */ 
/*     */   
/*     */   public static final int PORT_NUMBER_INDEX = 1;
/*     */   public static final String PORT_PROPERTY_KEY = "PORT";
/*     */   public static final String PROPERTIES_TRANSFORM_KEY = "propertiesTransform";
/*     */   public static final boolean TRACE = false;
/*     */   
/*     */   public static String getPlatform() {
/* 100 */     return System.getProperty("os.arch");
/*     */   }
/*     */   public static final String USE_CONFIG_PROPERTY_KEY = "useConfigs"; public static final String USER_PROPERTY_KEY = "user"; public static final String PROTOCOL_PROPERTY_KEY = "PROTOCOL"; public static final String PATH_PROPERTY_KEY = "PATH";
/*     */   static {
/*     */     try {
/* 105 */       Class.forName(AbandonedConnectionCleanupThread.class.getName());
/* 106 */     } catch (ClassNotFoundException e) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int getMajorVersionInternal() {
/* 169 */     return safeIntParse("5");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int getMinorVersionInternal() {
/* 178 */     return safeIntParse("1");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String[] parseHostPortPair(String hostPortPair) throws SQLException {
/* 197 */     String[] splitValues = new String[2];
/*     */     
/* 199 */     if (StringUtils.startsWithIgnoreCaseAndWs(hostPortPair, "address=")) {
/* 200 */       splitValues[0] = hostPortPair.trim();
/* 201 */       splitValues[1] = null;
/*     */       
/* 203 */       return splitValues;
/*     */     } 
/*     */     
/* 206 */     int portIndex = hostPortPair.indexOf(":");
/*     */     
/* 208 */     String hostname = null;
/*     */     
/* 210 */     if (portIndex != -1) {
/* 211 */       if (portIndex + 1 < hostPortPair.length()) {
/* 212 */         String portAsString = hostPortPair.substring(portIndex + 1);
/* 213 */         hostname = hostPortPair.substring(0, portIndex);
/*     */         
/* 215 */         splitValues[0] = hostname;
/*     */         
/* 217 */         splitValues[1] = portAsString;
/*     */       } else {
/* 219 */         throw SQLError.createSQLException(Messages.getString("NonRegisteringDriver.37"), "01S00", null);
/*     */       } 
/*     */     } else {
/* 222 */       splitValues[0] = hostPortPair;
/* 223 */       splitValues[1] = null;
/*     */     } 
/*     */     
/* 226 */     return splitValues;
/*     */   }
/*     */   
/*     */   private static int safeIntParse(String intAsString) {
/*     */     try {
/* 231 */       return Integer.parseInt(intAsString);
/* 232 */     } catch (NumberFormatException nfe) {
/* 233 */       return 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean acceptsURL(String url) throws SQLException {
/* 263 */     if (url == null) {
/* 264 */       throw SQLError.createSQLException(Messages.getString("NonRegisteringDriver.1"), "08001", null);
/*     */     }
/* 266 */     return (parseURL(url, null) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection connect(String url, Properties info) throws SQLException {
/* 309 */     if (url == null) {
/* 310 */       throw SQLError.createSQLException(Messages.getString("NonRegisteringDriver.1"), "08001", null);
/*     */     }
/*     */     
/* 313 */     if (StringUtils.startsWithIgnoreCase(url, "jdbc:mysql:loadbalance://"))
/* 314 */       return connectLoadBalanced(url, info); 
/* 315 */     if (StringUtils.startsWithIgnoreCase(url, "jdbc:mysql:replication://")) {
/* 316 */       return connectReplicationConnection(url, info);
/*     */     }
/*     */     
/* 319 */     Properties props = null;
/*     */     
/* 321 */     if ((props = parseURL(url, info)) == null) {
/* 322 */       return null;
/*     */     }
/*     */     
/* 325 */     if (!"1".equals(props.getProperty("NUM_HOSTS"))) {
/* 326 */       return connectFailover(url, info);
/*     */     }
/*     */     
/*     */     try {
/* 330 */       Connection newConn = ConnectionImpl.getInstance(host(props), port(props), props, database(props), url);
/*     */       
/* 332 */       return newConn;
/* 333 */     } catch (SQLException sqlEx) {
/*     */ 
/*     */       
/* 336 */       throw sqlEx;
/* 337 */     } catch (Exception ex) {
/* 338 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString("NonRegisteringDriver.17") + ex.toString() + Messages.getString("NonRegisteringDriver.18"), "08001", (ExceptionInterceptor)null);
/*     */ 
/*     */ 
/*     */       
/* 342 */       sqlEx.initCause(ex);
/*     */       
/* 344 */       throw sqlEx;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected static void trackConnection(Connection newConn) {
/* 350 */     ConnectionPhantomReference phantomRef = new ConnectionPhantomReference((ConnectionImpl)newConn, refQueue);
/* 351 */     connectionPhantomRefs.put(phantomRef, phantomRef);
/*     */   }
/*     */   
/*     */   private Connection connectLoadBalanced(String url, Properties info) throws SQLException {
/* 355 */     Properties parsedProps = parseURL(url, info);
/*     */     
/* 357 */     if (parsedProps == null) {
/* 358 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 362 */     parsedProps.remove("roundRobinLoadBalance");
/*     */     
/* 364 */     int numHosts = Integer.parseInt(parsedProps.getProperty("NUM_HOSTS"));
/*     */     
/* 366 */     List<String> hostList = new ArrayList<String>();
/*     */     
/* 368 */     for (int i = 0; i < numHosts; i++) {
/* 369 */       int index = i + 1;
/*     */       
/* 371 */       hostList.add(parsedProps.getProperty("HOST." + index) + ":" + parsedProps.getProperty("PORT." + index));
/*     */     } 
/*     */     
/* 374 */     return LoadBalancedConnectionProxy.createProxyInstance(hostList, parsedProps);
/*     */   }
/*     */   
/*     */   private Connection connectFailover(String url, Properties info) throws SQLException {
/* 378 */     Properties parsedProps = parseURL(url, info);
/*     */     
/* 380 */     if (parsedProps == null) {
/* 381 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 385 */     parsedProps.remove("roundRobinLoadBalance");
/*     */     
/* 387 */     int numHosts = Integer.parseInt(parsedProps.getProperty("NUM_HOSTS"));
/*     */     
/* 389 */     List<String> hostList = new ArrayList<String>();
/*     */     
/* 391 */     for (int i = 0; i < numHosts; i++) {
/* 392 */       int index = i + 1;
/*     */       
/* 394 */       hostList.add(parsedProps.getProperty("HOST." + index) + ":" + parsedProps.getProperty("PORT." + index));
/*     */     } 
/*     */     
/* 397 */     return FailoverConnectionProxy.createProxyInstance(hostList, parsedProps);
/*     */   }
/*     */   
/*     */   protected Connection connectReplicationConnection(String url, Properties info) throws SQLException {
/* 401 */     Properties parsedProps = parseURL(url, info);
/*     */     
/* 403 */     if (parsedProps == null) {
/* 404 */       return null;
/*     */     }
/*     */     
/* 407 */     Properties masterProps = (Properties)parsedProps.clone();
/* 408 */     Properties slavesProps = (Properties)parsedProps.clone();
/*     */ 
/*     */ 
/*     */     
/* 412 */     slavesProps.setProperty("com.mysql.jdbc.ReplicationConnection.isSlave", "true");
/*     */     
/* 414 */     int numHosts = Integer.parseInt(parsedProps.getProperty("NUM_HOSTS"));
/*     */     
/* 416 */     if (numHosts < 2) {
/* 417 */       throw SQLError.createSQLException("Must specify at least one slave host to connect to for master/slave replication load-balancing functionality", "01S00", null);
/*     */     }
/*     */     
/* 420 */     List<String> slaveHostList = new ArrayList<String>();
/* 421 */     List<String> masterHostList = new ArrayList<String>();
/*     */     
/* 423 */     String firstHost = masterProps.getProperty("HOST.1") + ":" + masterProps.getProperty("PORT.1");
/*     */     
/* 425 */     boolean usesExplicitServerType = isHostPropertiesList(firstHost);
/*     */     
/* 427 */     for (int i = 0; i < numHosts; i++) {
/* 428 */       int index = i + 1;
/*     */       
/* 430 */       masterProps.remove("HOST." + index);
/* 431 */       masterProps.remove("PORT." + index);
/* 432 */       slavesProps.remove("HOST." + index);
/* 433 */       slavesProps.remove("PORT." + index);
/*     */       
/* 435 */       String host = parsedProps.getProperty("HOST." + index);
/* 436 */       String port = parsedProps.getProperty("PORT." + index);
/* 437 */       if (usesExplicitServerType) {
/* 438 */         if (isHostMaster(host)) {
/* 439 */           masterHostList.add(host);
/*     */         } else {
/* 441 */           slaveHostList.add(host);
/*     */         }
/*     */       
/* 444 */       } else if (i == 0) {
/* 445 */         masterHostList.add(host + ":" + port);
/*     */       } else {
/* 447 */         slaveHostList.add(host + ":" + port);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 452 */     slavesProps.remove("NUM_HOSTS");
/* 453 */     masterProps.remove("NUM_HOSTS");
/* 454 */     masterProps.remove("HOST");
/* 455 */     masterProps.remove("PORT");
/* 456 */     slavesProps.remove("HOST");
/* 457 */     slavesProps.remove("PORT");
/*     */     
/* 459 */     return ReplicationConnectionProxy.createProxyInstance(masterHostList, masterProps, slaveHostList, slavesProps);
/*     */   }
/*     */   
/*     */   private boolean isHostMaster(String host) {
/* 463 */     if (isHostPropertiesList(host)) {
/* 464 */       Properties hostSpecificProps = expandHostKeyValues(host);
/* 465 */       if (hostSpecificProps.containsKey("type") && "master".equalsIgnoreCase(hostSpecificProps.get("type").toString())) {
/* 466 */         return true;
/*     */       }
/*     */     } 
/* 469 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String database(Properties props) {
/* 481 */     return props.getProperty("DBNAME");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMajorVersion() {
/* 490 */     return getMajorVersionInternal();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMinorVersion() {
/* 499 */     return getMinorVersionInternal();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DriverPropertyInfo[] getPropertyInfo(String url, Properties info) throws SQLException {
/* 528 */     if (info == null) {
/* 529 */       info = new Properties();
/*     */     }
/*     */     
/* 532 */     if (url != null && url.startsWith("jdbc:mysql://")) {
/* 533 */       info = parseURL(url, info);
/*     */     }
/*     */     
/* 536 */     DriverPropertyInfo hostProp = new DriverPropertyInfo("HOST", info.getProperty("HOST"));
/* 537 */     hostProp.required = true;
/* 538 */     hostProp.description = Messages.getString("NonRegisteringDriver.3");
/*     */     
/* 540 */     DriverPropertyInfo portProp = new DriverPropertyInfo("PORT", info.getProperty("PORT", "3306"));
/* 541 */     portProp.required = false;
/* 542 */     portProp.description = Messages.getString("NonRegisteringDriver.7");
/*     */     
/* 544 */     DriverPropertyInfo dbProp = new DriverPropertyInfo("DBNAME", info.getProperty("DBNAME"));
/* 545 */     dbProp.required = false;
/* 546 */     dbProp.description = "Database name";
/*     */     
/* 548 */     DriverPropertyInfo userProp = new DriverPropertyInfo("user", info.getProperty("user"));
/* 549 */     userProp.required = true;
/* 550 */     userProp.description = Messages.getString("NonRegisteringDriver.13");
/*     */     
/* 552 */     DriverPropertyInfo passwordProp = new DriverPropertyInfo("password", info.getProperty("password"));
/* 553 */     passwordProp.required = true;
/* 554 */     passwordProp.description = Messages.getString("NonRegisteringDriver.16");
/*     */     
/* 556 */     DriverPropertyInfo[] dpi = ConnectionPropertiesImpl.exposeAsDriverPropertyInfo(info, 5);
/*     */     
/* 558 */     dpi[0] = hostProp;
/* 559 */     dpi[1] = portProp;
/* 560 */     dpi[2] = dbProp;
/* 561 */     dpi[3] = userProp;
/* 562 */     dpi[4] = passwordProp;
/*     */     
/* 564 */     return dpi;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String host(Properties props) {
/* 581 */     return props.getProperty("HOST", "localhost");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean jdbcCompliant() {
/* 597 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Properties parseURL(String url, Properties defaults) throws SQLException {
/* 602 */     Properties urlProps = (defaults != null) ? new Properties(defaults) : new Properties();
/*     */     
/* 604 */     if (url == null) {
/* 605 */       return null;
/*     */     }
/*     */     
/* 608 */     if (!StringUtils.startsWithIgnoreCase(url, "jdbc:mysql://") && !StringUtils.startsWithIgnoreCase(url, "jdbc:mysql:mxj://") && !StringUtils.startsWithIgnoreCase(url, "jdbc:mysql:loadbalance://") && !StringUtils.startsWithIgnoreCase(url, "jdbc:mysql:replication://"))
/*     */     {
/*     */       
/* 611 */       return null;
/*     */     }
/*     */     
/* 614 */     int beginningOfSlashes = url.indexOf("//");
/*     */     
/* 616 */     if (StringUtils.startsWithIgnoreCase(url, "jdbc:mysql:mxj://"))
/*     */     {
/* 618 */       urlProps.setProperty("socketFactory", "com.mysql.management.driverlaunched.ServerLauncherSocketFactory");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 625 */     int index = url.indexOf("?");
/*     */     
/* 627 */     if (index != -1) {
/* 628 */       String paramString = url.substring(index + 1, url.length());
/* 629 */       url = url.substring(0, index);
/*     */       
/* 631 */       StringTokenizer queryParams = new StringTokenizer(paramString, "&");
/*     */       
/* 633 */       while (queryParams.hasMoreTokens()) {
/* 634 */         String parameterValuePair = queryParams.nextToken();
/*     */         
/* 636 */         int indexOfEquals = StringUtils.indexOfIgnoreCase(0, parameterValuePair, "=");
/*     */         
/* 638 */         String parameter = null;
/* 639 */         String value = null;
/*     */         
/* 641 */         if (indexOfEquals != -1) {
/* 642 */           parameter = parameterValuePair.substring(0, indexOfEquals);
/*     */           
/* 644 */           if (indexOfEquals + 1 < parameterValuePair.length()) {
/* 645 */             value = parameterValuePair.substring(indexOfEquals + 1);
/*     */           }
/*     */         } 
/*     */         
/* 649 */         if (value != null && value.length() > 0 && parameter != null && parameter.length() > 0) {
/*     */           try {
/* 651 */             urlProps.setProperty(parameter, URLDecoder.decode(value, "UTF-8"));
/* 652 */           } catch (UnsupportedEncodingException badEncoding) {
/*     */             
/* 654 */             urlProps.setProperty(parameter, URLDecoder.decode(value));
/* 655 */           } catch (NoSuchMethodError nsme) {
/*     */             
/* 657 */             urlProps.setProperty(parameter, URLDecoder.decode(value));
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 663 */     url = url.substring(beginningOfSlashes + 2);
/*     */     
/* 665 */     String hostStuff = null;
/*     */     
/* 667 */     int slashIndex = StringUtils.indexOfIgnoreCase(0, url, "/", "\"'", "\"'", StringUtils.SEARCH_MODE__ALL);
/*     */     
/* 669 */     if (slashIndex != -1) {
/* 670 */       hostStuff = url.substring(0, slashIndex);
/*     */       
/* 672 */       if (slashIndex + 1 < url.length()) {
/* 673 */         urlProps.put("DBNAME", url.substring(slashIndex + 1, url.length()));
/*     */       }
/*     */     } else {
/* 676 */       hostStuff = url;
/*     */     } 
/*     */     
/* 679 */     int numHosts = 0;
/*     */     
/* 681 */     if (hostStuff != null && hostStuff.trim().length() > 0) {
/* 682 */       List<String> hosts = StringUtils.split(hostStuff, ",", "\"'", "\"'", false);
/*     */       
/* 684 */       for (String hostAndPort : hosts) {
/* 685 */         numHosts++;
/*     */         
/* 687 */         String[] hostPortPair = parseHostPortPair(hostAndPort);
/*     */         
/* 689 */         if (hostPortPair[0] != null && hostPortPair[0].trim().length() > 0) {
/* 690 */           urlProps.setProperty("HOST." + numHosts, hostPortPair[0]);
/*     */         } else {
/* 692 */           urlProps.setProperty("HOST." + numHosts, "localhost");
/*     */         } 
/*     */         
/* 695 */         if (hostPortPair[1] != null) {
/* 696 */           urlProps.setProperty("PORT." + numHosts, hostPortPair[1]); continue;
/*     */         } 
/* 698 */         urlProps.setProperty("PORT." + numHosts, "3306");
/*     */       } 
/*     */     } else {
/*     */       
/* 702 */       numHosts = 1;
/* 703 */       urlProps.setProperty("HOST.1", "localhost");
/* 704 */       urlProps.setProperty("PORT.1", "3306");
/*     */     } 
/*     */     
/* 707 */     urlProps.setProperty("NUM_HOSTS", String.valueOf(numHosts));
/* 708 */     urlProps.setProperty("HOST", urlProps.getProperty("HOST.1"));
/* 709 */     urlProps.setProperty("PORT", urlProps.getProperty("PORT.1"));
/*     */     
/* 711 */     String propertiesTransformClassName = urlProps.getProperty("propertiesTransform");
/*     */     
/* 713 */     if (propertiesTransformClassName != null) {
/*     */       try {
/* 715 */         ConnectionPropertiesTransform propTransformer = (ConnectionPropertiesTransform)Class.forName(propertiesTransformClassName).newInstance();
/*     */         
/* 717 */         urlProps = propTransformer.transformProperties(urlProps);
/* 718 */       } catch (InstantiationException e) {
/* 719 */         throw SQLError.createSQLException("Unable to create properties transform instance '" + propertiesTransformClassName + "' due to underlying exception: " + e.toString(), "01S00", null);
/*     */       
/*     */       }
/* 722 */       catch (IllegalAccessException e) {
/* 723 */         throw SQLError.createSQLException("Unable to create properties transform instance '" + propertiesTransformClassName + "' due to underlying exception: " + e.toString(), "01S00", null);
/*     */       
/*     */       }
/* 726 */       catch (ClassNotFoundException e) {
/* 727 */         throw SQLError.createSQLException("Unable to create properties transform instance '" + propertiesTransformClassName + "' due to underlying exception: " + e.toString(), "01S00", null);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 733 */     if (Util.isColdFusion() && urlProps.getProperty("autoConfigureForColdFusion", "true").equalsIgnoreCase("true")) {
/* 734 */       String configs = urlProps.getProperty("useConfigs");
/*     */       
/* 736 */       StringBuilder newConfigs = new StringBuilder();
/*     */       
/* 738 */       if (configs != null) {
/* 739 */         newConfigs.append(configs);
/* 740 */         newConfigs.append(",");
/*     */       } 
/*     */       
/* 743 */       newConfigs.append("coldFusion");
/*     */       
/* 745 */       urlProps.setProperty("useConfigs", newConfigs.toString());
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 750 */     String configNames = null;
/*     */     
/* 752 */     if (defaults != null) {
/* 753 */       configNames = defaults.getProperty("useConfigs");
/*     */     }
/*     */     
/* 756 */     if (configNames == null) {
/* 757 */       configNames = urlProps.getProperty("useConfigs");
/*     */     }
/*     */     
/* 760 */     if (configNames != null) {
/* 761 */       List<String> splitNames = StringUtils.split(configNames, ",", true);
/*     */       
/* 763 */       Properties configProps = new Properties();
/*     */       
/* 765 */       Iterator<String> namesIter = splitNames.iterator();
/*     */       
/* 767 */       while (namesIter.hasNext()) {
/* 768 */         String configName = namesIter.next();
/*     */         
/*     */         try {
/* 771 */           InputStream configAsStream = getClass().getResourceAsStream("configs/" + configName + ".properties");
/*     */           
/* 773 */           if (configAsStream == null) {
/* 774 */             throw SQLError.createSQLException("Can't find configuration template named '" + configName + "'", "01S00", null);
/*     */           }
/*     */           
/* 777 */           configProps.load(configAsStream);
/* 778 */         } catch (IOException ioEx) {
/* 779 */           SQLException sqlEx = SQLError.createSQLException("Unable to load configuration template '" + configName + "' due to underlying IOException: " + ioEx, "01S00", (ExceptionInterceptor)null);
/*     */ 
/*     */           
/* 782 */           sqlEx.initCause(ioEx);
/*     */           
/* 784 */           throw sqlEx;
/*     */         } 
/*     */       } 
/*     */       
/* 788 */       Iterator<Object> propsIter = urlProps.keySet().iterator();
/*     */       
/* 790 */       while (propsIter.hasNext()) {
/* 791 */         String key = propsIter.next().toString();
/* 792 */         String property = urlProps.getProperty(key);
/* 793 */         configProps.setProperty(key, property);
/*     */       } 
/*     */       
/* 796 */       urlProps = configProps;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 801 */     if (defaults != null) {
/* 802 */       Iterator<Object> propsIter = defaults.keySet().iterator();
/*     */       
/* 804 */       while (propsIter.hasNext()) {
/* 805 */         String key = propsIter.next().toString();
/* 806 */         if (!key.equals("NUM_HOSTS")) {
/* 807 */           String property = defaults.getProperty(key);
/* 808 */           urlProps.setProperty(key, property);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 813 */     return urlProps;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int port(Properties props) {
/* 825 */     return Integer.parseInt(props.getProperty("PORT", "3306"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String property(String name, Properties props) {
/* 839 */     return props.getProperty(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Properties expandHostKeyValues(String host) {
/* 848 */     Properties hostProps = new Properties();
/*     */     
/* 850 */     if (isHostPropertiesList(host)) {
/* 851 */       host = host.substring("address=".length() + 1);
/* 852 */       List<String> hostPropsList = StringUtils.split(host, ")", "'\"", "'\"", true);
/*     */       
/* 854 */       for (String propDef : hostPropsList) {
/* 855 */         if (propDef.startsWith("(")) {
/* 856 */           propDef = propDef.substring(1);
/*     */         }
/*     */         
/* 859 */         List<String> kvp = StringUtils.split(propDef, "=", "'\"", "'\"", true);
/*     */         
/* 861 */         String key = kvp.get(0);
/* 862 */         String value = (kvp.size() > 1) ? kvp.get(1) : null;
/*     */         
/* 864 */         if (value != null && ((value.startsWith("\"") && value.endsWith("\"")) || (value.startsWith("'") && value.endsWith("'")))) {
/* 865 */           value = value.substring(1, value.length() - 1);
/*     */         }
/*     */         
/* 868 */         if (value != null) {
/* 869 */           if ("HOST".equalsIgnoreCase(key) || "DBNAME".equalsIgnoreCase(key) || "PORT".equalsIgnoreCase(key) || "PROTOCOL".equalsIgnoreCase(key) || "PATH".equalsIgnoreCase(key)) {
/*     */             
/* 871 */             key = key.toUpperCase(Locale.ENGLISH);
/* 872 */           } else if ("user".equalsIgnoreCase(key) || "password".equalsIgnoreCase(key)) {
/* 873 */             key = key.toLowerCase(Locale.ENGLISH);
/*     */           } 
/*     */           
/* 876 */           hostProps.setProperty(key, value);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 881 */     return hostProps;
/*     */   }
/*     */   
/*     */   public static boolean isHostPropertiesList(String host) {
/* 885 */     return (host != null && StringUtils.startsWithIgnoreCase(host, "address="));
/*     */   }
/*     */   
/*     */   static class ConnectionPhantomReference extends PhantomReference<ConnectionImpl> {
/*     */     private NetworkResources io;
/*     */     
/*     */     ConnectionPhantomReference(ConnectionImpl connectionImpl, ReferenceQueue<ConnectionImpl> q) {
/* 892 */       super(connectionImpl, q);
/*     */       
/*     */       try {
/* 895 */         this.io = connectionImpl.getIO().getNetworkResources();
/* 896 */       } catch (SQLException e) {}
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     void cleanup() {
/* 902 */       if (this.io != null)
/*     */         try {
/* 904 */           this.io.forceClose();
/*     */         } finally {
/* 906 */           this.io = null;
/*     */         }  
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\neons\Desktop\JacobAloSchedulingApp\build\classes\!\lib\mysql-connector-java-5.1.47.jar!\com\mysql\jdbc\NonRegisteringDriver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */
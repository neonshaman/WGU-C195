/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.exceptions.MySQLStatementCancelledException;
/*      */ import com.mysql.jdbc.exceptions.MySQLTimeoutException;
/*      */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.StringReader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.net.URL;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.CharBuffer;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.charset.CharsetEncoder;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.Date;
/*      */ import java.sql.ParameterMetaData;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.DateFormat;
/*      */ import java.text.ParsePosition;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Date;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.TimeZone;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PreparedStatement
/*      */   extends StatementImpl
/*      */   implements PreparedStatement
/*      */ {
/*      */   private static final Constructor<?> JDBC_4_PSTMT_2_ARG_CTOR;
/*      */   private static final Constructor<?> JDBC_4_PSTMT_3_ARG_CTOR;
/*      */   private static final Constructor<?> JDBC_4_PSTMT_4_ARG_CTOR;
/*      */   
/*      */   static {
/*   82 */     if (Util.isJdbc4()) {
/*      */       try {
/*   84 */         String jdbc4ClassName = Util.isJdbc42() ? "com.mysql.jdbc.JDBC42PreparedStatement" : "com.mysql.jdbc.JDBC4PreparedStatement";
/*   85 */         JDBC_4_PSTMT_2_ARG_CTOR = Class.forName(jdbc4ClassName).getConstructor(new Class[] { MySQLConnection.class, String.class });
/*   86 */         JDBC_4_PSTMT_3_ARG_CTOR = Class.forName(jdbc4ClassName).getConstructor(new Class[] { MySQLConnection.class, String.class, String.class });
/*   87 */         JDBC_4_PSTMT_4_ARG_CTOR = Class.forName(jdbc4ClassName).getConstructor(new Class[] { MySQLConnection.class, String.class, String.class, ParseInfo.class });
/*      */       }
/*   89 */       catch (SecurityException e) {
/*   90 */         throw new RuntimeException(e);
/*   91 */       } catch (NoSuchMethodException e) {
/*   92 */         throw new RuntimeException(e);
/*   93 */       } catch (ClassNotFoundException e) {
/*   94 */         throw new RuntimeException(e);
/*      */       } 
/*      */     } else {
/*   97 */       JDBC_4_PSTMT_2_ARG_CTOR = null;
/*   98 */       JDBC_4_PSTMT_3_ARG_CTOR = null;
/*   99 */       JDBC_4_PSTMT_4_ARG_CTOR = null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public class BatchParams {
/*  104 */     public boolean[] isNull = null;
/*      */     
/*  106 */     public boolean[] isStream = null;
/*      */     
/*  108 */     public InputStream[] parameterStreams = null;
/*      */     
/*  110 */     public byte[][] parameterStrings = (byte[][])null;
/*      */     
/*  112 */     public int[] streamLengths = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     BatchParams(byte[][] strings, InputStream[] streams, boolean[] isStreamFlags, int[] lengths, boolean[] isNullFlags) {
/*  118 */       this.parameterStrings = new byte[strings.length][];
/*  119 */       this.parameterStreams = new InputStream[streams.length];
/*  120 */       this.isStream = new boolean[isStreamFlags.length];
/*  121 */       this.streamLengths = new int[lengths.length];
/*  122 */       this.isNull = new boolean[isNullFlags.length];
/*  123 */       System.arraycopy(strings, 0, this.parameterStrings, 0, strings.length);
/*  124 */       System.arraycopy(streams, 0, this.parameterStreams, 0, streams.length);
/*  125 */       System.arraycopy(isStreamFlags, 0, this.isStream, 0, isStreamFlags.length);
/*  126 */       System.arraycopy(lengths, 0, this.streamLengths, 0, lengths.length);
/*  127 */       System.arraycopy(isNullFlags, 0, this.isNull, 0, isNullFlags.length);
/*      */     }
/*      */   }
/*      */   
/*      */   class EndPoint
/*      */   {
/*      */     int begin;
/*      */     int end;
/*      */     
/*      */     EndPoint(int b, int e) {
/*  137 */       this.begin = b;
/*  138 */       this.end = e;
/*      */     }
/*      */   }
/*      */   
/*      */   public static final class ParseInfo {
/*  143 */     char firstStmtChar = Character.MIN_VALUE;
/*      */     
/*      */     boolean foundLoadData = false;
/*      */     
/*  147 */     long lastUsed = 0L;
/*      */     
/*  149 */     int statementLength = 0;
/*      */     
/*  151 */     int statementStartPos = 0;
/*      */     
/*      */     boolean canRewriteAsMultiValueInsert = false;
/*      */     
/*  155 */     byte[][] staticSql = (byte[][])null;
/*      */     
/*      */     boolean hasPlaceholders = false;
/*      */     
/*  159 */     int numberOfQueries = 1;
/*      */     
/*      */     boolean isOnDuplicateKeyUpdate = false;
/*      */     
/*  163 */     int locationOfOnDuplicateKeyUpdate = -1;
/*      */     
/*      */     String valuesClause;
/*      */     
/*      */     boolean parametersInDuplicateKeyClause = false;
/*      */     
/*      */     String charEncoding;
/*      */     
/*      */     private ParseInfo batchHead;
/*      */     private ParseInfo batchValues;
/*      */     private ParseInfo batchODKUClause;
/*      */     
/*      */     ParseInfo(String sql, MySQLConnection conn, DatabaseMetaData dbmd, String encoding, SingleByteCharsetConverter converter) throws SQLException {
/*  176 */       this(sql, conn, dbmd, encoding, converter, true);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ParseInfo(String sql, MySQLConnection conn, DatabaseMetaData dbmd, String encoding, SingleByteCharsetConverter converter, boolean buildRewriteInfo) throws SQLException {
/*      */       // Byte code:
/*      */       //   0: aload_0
/*      */       //   1: invokespecial <init> : ()V
/*      */       //   4: aload_0
/*      */       //   5: iconst_0
/*      */       //   6: putfield firstStmtChar : C
/*      */       //   9: aload_0
/*      */       //   10: iconst_0
/*      */       //   11: putfield foundLoadData : Z
/*      */       //   14: aload_0
/*      */       //   15: lconst_0
/*      */       //   16: putfield lastUsed : J
/*      */       //   19: aload_0
/*      */       //   20: iconst_0
/*      */       //   21: putfield statementLength : I
/*      */       //   24: aload_0
/*      */       //   25: iconst_0
/*      */       //   26: putfield statementStartPos : I
/*      */       //   29: aload_0
/*      */       //   30: iconst_0
/*      */       //   31: putfield canRewriteAsMultiValueInsert : Z
/*      */       //   34: aload_0
/*      */       //   35: aconst_null
/*      */       //   36: checkcast [[B
/*      */       //   39: putfield staticSql : [[B
/*      */       //   42: aload_0
/*      */       //   43: iconst_0
/*      */       //   44: putfield hasPlaceholders : Z
/*      */       //   47: aload_0
/*      */       //   48: iconst_1
/*      */       //   49: putfield numberOfQueries : I
/*      */       //   52: aload_0
/*      */       //   53: iconst_0
/*      */       //   54: putfield isOnDuplicateKeyUpdate : Z
/*      */       //   57: aload_0
/*      */       //   58: iconst_m1
/*      */       //   59: putfield locationOfOnDuplicateKeyUpdate : I
/*      */       //   62: aload_0
/*      */       //   63: iconst_0
/*      */       //   64: putfield parametersInDuplicateKeyClause : Z
/*      */       //   67: aload_1
/*      */       //   68: ifnonnull -> 88
/*      */       //   71: ldc 'PreparedStatement.61'
/*      */       //   73: invokestatic getString : (Ljava/lang/String;)Ljava/lang/String;
/*      */       //   76: ldc 'S1009'
/*      */       //   78: aload_2
/*      */       //   79: invokeinterface getExceptionInterceptor : ()Lcom/mysql/jdbc/ExceptionInterceptor;
/*      */       //   84: invokestatic createSQLException : (Ljava/lang/String;Ljava/lang/String;Lcom/mysql/jdbc/ExceptionInterceptor;)Ljava/sql/SQLException;
/*      */       //   87: athrow
/*      */       //   88: aload_0
/*      */       //   89: aload #4
/*      */       //   91: putfield charEncoding : Ljava/lang/String;
/*      */       //   94: aload_0
/*      */       //   95: invokestatic currentTimeMillis : ()J
/*      */       //   98: putfield lastUsed : J
/*      */       //   101: aload_3
/*      */       //   102: invokeinterface getIdentifierQuoteString : ()Ljava/lang/String;
/*      */       //   107: astore #7
/*      */       //   109: iconst_0
/*      */       //   110: istore #8
/*      */       //   112: aload #7
/*      */       //   114: ifnull -> 143
/*      */       //   117: aload #7
/*      */       //   119: ldc ' '
/*      */       //   121: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   124: ifne -> 143
/*      */       //   127: aload #7
/*      */       //   129: invokevirtual length : ()I
/*      */       //   132: ifle -> 143
/*      */       //   135: aload #7
/*      */       //   137: iconst_0
/*      */       //   138: invokevirtual charAt : (I)C
/*      */       //   141: istore #8
/*      */       //   143: aload_0
/*      */       //   144: aload_1
/*      */       //   145: invokevirtual length : ()I
/*      */       //   148: putfield statementLength : I
/*      */       //   151: new java/util/ArrayList
/*      */       //   154: dup
/*      */       //   155: invokespecial <init> : ()V
/*      */       //   158: astore #9
/*      */       //   160: iconst_0
/*      */       //   161: istore #10
/*      */       //   163: iconst_0
/*      */       //   164: istore #11
/*      */       //   166: iconst_0
/*      */       //   167: istore #12
/*      */       //   169: iconst_0
/*      */       //   170: istore #13
/*      */       //   172: aload_2
/*      */       //   173: invokeinterface isNoBackslashEscapesSet : ()Z
/*      */       //   178: istore #15
/*      */       //   180: aload_0
/*      */       //   181: aload_1
/*      */       //   182: invokestatic findStartOfStatement : (Ljava/lang/String;)I
/*      */       //   185: putfield statementStartPos : I
/*      */       //   188: aload_0
/*      */       //   189: getfield statementStartPos : I
/*      */       //   192: istore #14
/*      */       //   194: iload #14
/*      */       //   196: aload_0
/*      */       //   197: getfield statementLength : I
/*      */       //   200: if_icmpge -> 845
/*      */       //   203: aload_1
/*      */       //   204: iload #14
/*      */       //   206: invokevirtual charAt : (I)C
/*      */       //   209: istore #16
/*      */       //   211: aload_0
/*      */       //   212: getfield firstStmtChar : C
/*      */       //   215: ifne -> 287
/*      */       //   218: iload #16
/*      */       //   220: invokestatic isLetter : (C)Z
/*      */       //   223: ifeq -> 287
/*      */       //   226: aload_0
/*      */       //   227: iload #16
/*      */       //   229: invokestatic toUpperCase : (C)C
/*      */       //   232: putfield firstStmtChar : C
/*      */       //   235: aload_0
/*      */       //   236: getfield firstStmtChar : C
/*      */       //   239: bipush #73
/*      */       //   241: if_icmpne -> 287
/*      */       //   244: aload_0
/*      */       //   245: aload_1
/*      */       //   246: aload_2
/*      */       //   247: invokeinterface getDontCheckOnDuplicateKeyUpdateInSQL : ()Z
/*      */       //   252: aload_2
/*      */       //   253: invokeinterface getRewriteBatchedStatements : ()Z
/*      */       //   258: aload_2
/*      */       //   259: invokeinterface isNoBackslashEscapesSet : ()Z
/*      */       //   264: invokestatic getOnDuplicateKeyLocation : (Ljava/lang/String;ZZZ)I
/*      */       //   267: putfield locationOfOnDuplicateKeyUpdate : I
/*      */       //   270: aload_0
/*      */       //   271: aload_0
/*      */       //   272: getfield locationOfOnDuplicateKeyUpdate : I
/*      */       //   275: iconst_m1
/*      */       //   276: if_icmpeq -> 283
/*      */       //   279: iconst_1
/*      */       //   280: goto -> 284
/*      */       //   283: iconst_0
/*      */       //   284: putfield isOnDuplicateKeyUpdate : Z
/*      */       //   287: iload #15
/*      */       //   289: ifne -> 316
/*      */       //   292: iload #16
/*      */       //   294: bipush #92
/*      */       //   296: if_icmpne -> 316
/*      */       //   299: iload #14
/*      */       //   301: aload_0
/*      */       //   302: getfield statementLength : I
/*      */       //   305: iconst_1
/*      */       //   306: isub
/*      */       //   307: if_icmpge -> 316
/*      */       //   310: iinc #14, 1
/*      */       //   313: goto -> 839
/*      */       //   316: iload #10
/*      */       //   318: ifne -> 348
/*      */       //   321: iload #8
/*      */       //   323: ifeq -> 348
/*      */       //   326: iload #16
/*      */       //   328: iload #8
/*      */       //   330: if_icmpne -> 348
/*      */       //   333: iload #12
/*      */       //   335: ifne -> 342
/*      */       //   338: iconst_1
/*      */       //   339: goto -> 343
/*      */       //   342: iconst_0
/*      */       //   343: istore #12
/*      */       //   345: goto -> 696
/*      */       //   348: iload #12
/*      */       //   350: ifne -> 696
/*      */       //   353: iload #10
/*      */       //   355: ifeq -> 466
/*      */       //   358: iload #16
/*      */       //   360: bipush #39
/*      */       //   362: if_icmpeq -> 372
/*      */       //   365: iload #16
/*      */       //   367: bipush #34
/*      */       //   369: if_icmpne -> 427
/*      */       //   372: iload #16
/*      */       //   374: iload #11
/*      */       //   376: if_icmpne -> 427
/*      */       //   379: iload #14
/*      */       //   381: aload_0
/*      */       //   382: getfield statementLength : I
/*      */       //   385: iconst_1
/*      */       //   386: isub
/*      */       //   387: if_icmpge -> 409
/*      */       //   390: aload_1
/*      */       //   391: iload #14
/*      */       //   393: iconst_1
/*      */       //   394: iadd
/*      */       //   395: invokevirtual charAt : (I)C
/*      */       //   398: iload #11
/*      */       //   400: if_icmpne -> 409
/*      */       //   403: iinc #14, 1
/*      */       //   406: goto -> 839
/*      */       //   409: iload #10
/*      */       //   411: ifne -> 418
/*      */       //   414: iconst_1
/*      */       //   415: goto -> 419
/*      */       //   418: iconst_0
/*      */       //   419: istore #10
/*      */       //   421: iconst_0
/*      */       //   422: istore #11
/*      */       //   424: goto -> 696
/*      */       //   427: iload #16
/*      */       //   429: bipush #39
/*      */       //   431: if_icmpeq -> 441
/*      */       //   434: iload #16
/*      */       //   436: bipush #34
/*      */       //   438: if_icmpne -> 696
/*      */       //   441: iload #16
/*      */       //   443: iload #11
/*      */       //   445: if_icmpne -> 696
/*      */       //   448: iload #10
/*      */       //   450: ifne -> 457
/*      */       //   453: iconst_1
/*      */       //   454: goto -> 458
/*      */       //   457: iconst_0
/*      */       //   458: istore #10
/*      */       //   460: iconst_0
/*      */       //   461: istore #11
/*      */       //   463: goto -> 696
/*      */       //   466: iload #16
/*      */       //   468: bipush #35
/*      */       //   470: if_icmpeq -> 504
/*      */       //   473: iload #16
/*      */       //   475: bipush #45
/*      */       //   477: if_icmpne -> 550
/*      */       //   480: iload #14
/*      */       //   482: iconst_1
/*      */       //   483: iadd
/*      */       //   484: aload_0
/*      */       //   485: getfield statementLength : I
/*      */       //   488: if_icmpge -> 550
/*      */       //   491: aload_1
/*      */       //   492: iload #14
/*      */       //   494: iconst_1
/*      */       //   495: iadd
/*      */       //   496: invokevirtual charAt : (I)C
/*      */       //   499: bipush #45
/*      */       //   501: if_icmpne -> 550
/*      */       //   504: aload_0
/*      */       //   505: getfield statementLength : I
/*      */       //   508: iconst_1
/*      */       //   509: isub
/*      */       //   510: istore #17
/*      */       //   512: iload #14
/*      */       //   514: iload #17
/*      */       //   516: if_icmpge -> 839
/*      */       //   519: aload_1
/*      */       //   520: iload #14
/*      */       //   522: invokevirtual charAt : (I)C
/*      */       //   525: istore #16
/*      */       //   527: iload #16
/*      */       //   529: bipush #13
/*      */       //   531: if_icmpeq -> 839
/*      */       //   534: iload #16
/*      */       //   536: bipush #10
/*      */       //   538: if_icmpne -> 544
/*      */       //   541: goto -> 839
/*      */       //   544: iinc #14, 1
/*      */       //   547: goto -> 512
/*      */       //   550: iload #16
/*      */       //   552: bipush #47
/*      */       //   554: if_icmpne -> 675
/*      */       //   557: iload #14
/*      */       //   559: iconst_1
/*      */       //   560: iadd
/*      */       //   561: aload_0
/*      */       //   562: getfield statementLength : I
/*      */       //   565: if_icmpge -> 675
/*      */       //   568: aload_1
/*      */       //   569: iload #14
/*      */       //   571: iconst_1
/*      */       //   572: iadd
/*      */       //   573: invokevirtual charAt : (I)C
/*      */       //   576: istore #17
/*      */       //   578: iload #17
/*      */       //   580: bipush #42
/*      */       //   582: if_icmpne -> 672
/*      */       //   585: iinc #14, 2
/*      */       //   588: iload #14
/*      */       //   590: istore #18
/*      */       //   592: iload #18
/*      */       //   594: aload_0
/*      */       //   595: getfield statementLength : I
/*      */       //   598: if_icmpge -> 672
/*      */       //   601: iinc #14, 1
/*      */       //   604: aload_1
/*      */       //   605: iload #18
/*      */       //   607: invokevirtual charAt : (I)C
/*      */       //   610: istore #17
/*      */       //   612: iload #17
/*      */       //   614: bipush #42
/*      */       //   616: if_icmpne -> 666
/*      */       //   619: iload #18
/*      */       //   621: iconst_1
/*      */       //   622: iadd
/*      */       //   623: aload_0
/*      */       //   624: getfield statementLength : I
/*      */       //   627: if_icmpge -> 666
/*      */       //   630: aload_1
/*      */       //   631: iload #18
/*      */       //   633: iconst_1
/*      */       //   634: iadd
/*      */       //   635: invokevirtual charAt : (I)C
/*      */       //   638: bipush #47
/*      */       //   640: if_icmpne -> 666
/*      */       //   643: iinc #14, 1
/*      */       //   646: iload #14
/*      */       //   648: aload_0
/*      */       //   649: getfield statementLength : I
/*      */       //   652: if_icmpge -> 672
/*      */       //   655: aload_1
/*      */       //   656: iload #14
/*      */       //   658: invokevirtual charAt : (I)C
/*      */       //   661: istore #16
/*      */       //   663: goto -> 672
/*      */       //   666: iinc #18, 1
/*      */       //   669: goto -> 592
/*      */       //   672: goto -> 696
/*      */       //   675: iload #16
/*      */       //   677: bipush #39
/*      */       //   679: if_icmpeq -> 689
/*      */       //   682: iload #16
/*      */       //   684: bipush #34
/*      */       //   686: if_icmpne -> 696
/*      */       //   689: iconst_1
/*      */       //   690: istore #10
/*      */       //   692: iload #16
/*      */       //   694: istore #11
/*      */       //   696: iload #10
/*      */       //   698: ifne -> 839
/*      */       //   701: iload #12
/*      */       //   703: ifne -> 839
/*      */       //   706: iload #16
/*      */       //   708: bipush #63
/*      */       //   710: if_icmpne -> 762
/*      */       //   713: aload #9
/*      */       //   715: iconst_2
/*      */       //   716: newarray int
/*      */       //   718: dup
/*      */       //   719: iconst_0
/*      */       //   720: iload #13
/*      */       //   722: iastore
/*      */       //   723: dup
/*      */       //   724: iconst_1
/*      */       //   725: iload #14
/*      */       //   727: iastore
/*      */       //   728: invokevirtual add : (Ljava/lang/Object;)Z
/*      */       //   731: pop
/*      */       //   732: iload #14
/*      */       //   734: iconst_1
/*      */       //   735: iadd
/*      */       //   736: istore #13
/*      */       //   738: aload_0
/*      */       //   739: getfield isOnDuplicateKeyUpdate : Z
/*      */       //   742: ifeq -> 839
/*      */       //   745: iload #14
/*      */       //   747: aload_0
/*      */       //   748: getfield locationOfOnDuplicateKeyUpdate : I
/*      */       //   751: if_icmple -> 839
/*      */       //   754: aload_0
/*      */       //   755: iconst_1
/*      */       //   756: putfield parametersInDuplicateKeyClause : Z
/*      */       //   759: goto -> 839
/*      */       //   762: iload #16
/*      */       //   764: bipush #59
/*      */       //   766: if_icmpne -> 839
/*      */       //   769: iload #14
/*      */       //   771: iconst_1
/*      */       //   772: iadd
/*      */       //   773: istore #17
/*      */       //   775: iload #17
/*      */       //   777: aload_0
/*      */       //   778: getfield statementLength : I
/*      */       //   781: if_icmpge -> 839
/*      */       //   784: iload #17
/*      */       //   786: aload_0
/*      */       //   787: getfield statementLength : I
/*      */       //   790: if_icmpge -> 814
/*      */       //   793: aload_1
/*      */       //   794: iload #17
/*      */       //   796: invokevirtual charAt : (I)C
/*      */       //   799: invokestatic isWhitespace : (C)Z
/*      */       //   802: ifne -> 808
/*      */       //   805: goto -> 814
/*      */       //   808: iinc #17, 1
/*      */       //   811: goto -> 784
/*      */       //   814: iload #17
/*      */       //   816: aload_0
/*      */       //   817: getfield statementLength : I
/*      */       //   820: if_icmpge -> 833
/*      */       //   823: aload_0
/*      */       //   824: dup
/*      */       //   825: getfield numberOfQueries : I
/*      */       //   828: iconst_1
/*      */       //   829: iadd
/*      */       //   830: putfield numberOfQueries : I
/*      */       //   833: iload #17
/*      */       //   835: iconst_1
/*      */       //   836: isub
/*      */       //   837: istore #14
/*      */       //   839: iinc #14, 1
/*      */       //   842: goto -> 194
/*      */       //   845: aload_0
/*      */       //   846: getfield firstStmtChar : C
/*      */       //   849: bipush #76
/*      */       //   851: if_icmpne -> 879
/*      */       //   854: aload_1
/*      */       //   855: ldc 'LOAD DATA'
/*      */       //   857: invokestatic startsWithIgnoreCaseAndWs : (Ljava/lang/String;Ljava/lang/String;)Z
/*      */       //   860: ifeq -> 871
/*      */       //   863: aload_0
/*      */       //   864: iconst_1
/*      */       //   865: putfield foundLoadData : Z
/*      */       //   868: goto -> 884
/*      */       //   871: aload_0
/*      */       //   872: iconst_0
/*      */       //   873: putfield foundLoadData : Z
/*      */       //   876: goto -> 884
/*      */       //   879: aload_0
/*      */       //   880: iconst_0
/*      */       //   881: putfield foundLoadData : Z
/*      */       //   884: aload #9
/*      */       //   886: iconst_2
/*      */       //   887: newarray int
/*      */       //   889: dup
/*      */       //   890: iconst_0
/*      */       //   891: iload #13
/*      */       //   893: iastore
/*      */       //   894: dup
/*      */       //   895: iconst_1
/*      */       //   896: aload_0
/*      */       //   897: getfield statementLength : I
/*      */       //   900: iastore
/*      */       //   901: invokevirtual add : (Ljava/lang/Object;)Z
/*      */       //   904: pop
/*      */       //   905: aload_0
/*      */       //   906: aload #9
/*      */       //   908: invokevirtual size : ()I
/*      */       //   911: anewarray [B
/*      */       //   914: putfield staticSql : [[B
/*      */       //   917: aload_0
/*      */       //   918: aload_0
/*      */       //   919: getfield staticSql : [[B
/*      */       //   922: arraylength
/*      */       //   923: iconst_1
/*      */       //   924: if_icmple -> 931
/*      */       //   927: iconst_1
/*      */       //   928: goto -> 932
/*      */       //   931: iconst_0
/*      */       //   932: putfield hasPlaceholders : Z
/*      */       //   935: iconst_0
/*      */       //   936: istore #14
/*      */       //   938: iload #14
/*      */       //   940: aload_0
/*      */       //   941: getfield staticSql : [[B
/*      */       //   944: arraylength
/*      */       //   945: if_icmpge -> 1145
/*      */       //   948: aload #9
/*      */       //   950: iload #14
/*      */       //   952: invokevirtual get : (I)Ljava/lang/Object;
/*      */       //   955: checkcast [I
/*      */       //   958: astore #16
/*      */       //   960: aload #16
/*      */       //   962: iconst_1
/*      */       //   963: iaload
/*      */       //   964: istore #17
/*      */       //   966: aload #16
/*      */       //   968: iconst_0
/*      */       //   969: iaload
/*      */       //   970: istore #18
/*      */       //   972: iload #17
/*      */       //   974: iload #18
/*      */       //   976: isub
/*      */       //   977: istore #19
/*      */       //   979: aload_0
/*      */       //   980: getfield foundLoadData : Z
/*      */       //   983: ifeq -> 1004
/*      */       //   986: aload_0
/*      */       //   987: getfield staticSql : [[B
/*      */       //   990: iload #14
/*      */       //   992: aload_1
/*      */       //   993: iload #18
/*      */       //   995: iload #19
/*      */       //   997: invokestatic getBytes : (Ljava/lang/String;II)[B
/*      */       //   1000: aastore
/*      */       //   1001: goto -> 1139
/*      */       //   1004: aload #4
/*      */       //   1006: ifnonnull -> 1058
/*      */       //   1009: iload #19
/*      */       //   1011: newarray byte
/*      */       //   1013: astore #20
/*      */       //   1015: iconst_0
/*      */       //   1016: istore #21
/*      */       //   1018: iload #21
/*      */       //   1020: iload #19
/*      */       //   1022: if_icmpge -> 1046
/*      */       //   1025: aload #20
/*      */       //   1027: iload #21
/*      */       //   1029: aload_1
/*      */       //   1030: iload #18
/*      */       //   1032: iload #21
/*      */       //   1034: iadd
/*      */       //   1035: invokevirtual charAt : (I)C
/*      */       //   1038: i2b
/*      */       //   1039: bastore
/*      */       //   1040: iinc #21, 1
/*      */       //   1043: goto -> 1018
/*      */       //   1046: aload_0
/*      */       //   1047: getfield staticSql : [[B
/*      */       //   1050: iload #14
/*      */       //   1052: aload #20
/*      */       //   1054: aastore
/*      */       //   1055: goto -> 1139
/*      */       //   1058: aload #5
/*      */       //   1060: ifnull -> 1103
/*      */       //   1063: aload_0
/*      */       //   1064: getfield staticSql : [[B
/*      */       //   1067: iload #14
/*      */       //   1069: aload_1
/*      */       //   1070: aload #5
/*      */       //   1072: aload #4
/*      */       //   1074: aload_2
/*      */       //   1075: invokeinterface getServerCharset : ()Ljava/lang/String;
/*      */       //   1080: iload #18
/*      */       //   1082: iload #19
/*      */       //   1084: aload_2
/*      */       //   1085: invokeinterface parserKnowsUnicode : ()Z
/*      */       //   1090: aload_2
/*      */       //   1091: invokeinterface getExceptionInterceptor : ()Lcom/mysql/jdbc/ExceptionInterceptor;
/*      */       //   1096: invokestatic getBytes : (Ljava/lang/String;Lcom/mysql/jdbc/SingleByteCharsetConverter;Ljava/lang/String;Ljava/lang/String;IIZLcom/mysql/jdbc/ExceptionInterceptor;)[B
/*      */       //   1099: aastore
/*      */       //   1100: goto -> 1139
/*      */       //   1103: aload_0
/*      */       //   1104: getfield staticSql : [[B
/*      */       //   1107: iload #14
/*      */       //   1109: aload_1
/*      */       //   1110: aload #4
/*      */       //   1112: aload_2
/*      */       //   1113: invokeinterface getServerCharset : ()Ljava/lang/String;
/*      */       //   1118: iload #18
/*      */       //   1120: iload #19
/*      */       //   1122: aload_2
/*      */       //   1123: invokeinterface parserKnowsUnicode : ()Z
/*      */       //   1128: aload_2
/*      */       //   1129: aload_2
/*      */       //   1130: invokeinterface getExceptionInterceptor : ()Lcom/mysql/jdbc/ExceptionInterceptor;
/*      */       //   1135: invokestatic getBytes : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIZLcom/mysql/jdbc/MySQLConnection;Lcom/mysql/jdbc/ExceptionInterceptor;)[B
/*      */       //   1138: aastore
/*      */       //   1139: iinc #14, 1
/*      */       //   1142: goto -> 938
/*      */       //   1145: goto -> 1189
/*      */       //   1148: astore #7
/*      */       //   1150: new java/sql/SQLException
/*      */       //   1153: dup
/*      */       //   1154: new java/lang/StringBuilder
/*      */       //   1157: dup
/*      */       //   1158: invokespecial <init> : ()V
/*      */       //   1161: ldc 'Parse error for '
/*      */       //   1163: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */       //   1166: aload_1
/*      */       //   1167: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */       //   1170: invokevirtual toString : ()Ljava/lang/String;
/*      */       //   1173: invokespecial <init> : (Ljava/lang/String;)V
/*      */       //   1176: astore #8
/*      */       //   1178: aload #8
/*      */       //   1180: aload #7
/*      */       //   1182: invokevirtual initCause : (Ljava/lang/Throwable;)Ljava/lang/Throwable;
/*      */       //   1185: pop
/*      */       //   1186: aload #8
/*      */       //   1188: athrow
/*      */       //   1189: iload #6
/*      */       //   1191: ifeq -> 1264
/*      */       //   1194: aload_0
/*      */       //   1195: aload_0
/*      */       //   1196: getfield numberOfQueries : I
/*      */       //   1199: iconst_1
/*      */       //   1200: if_icmpne -> 1233
/*      */       //   1203: aload_0
/*      */       //   1204: getfield parametersInDuplicateKeyClause : Z
/*      */       //   1207: ifne -> 1233
/*      */       //   1210: aload_1
/*      */       //   1211: aload_0
/*      */       //   1212: getfield isOnDuplicateKeyUpdate : Z
/*      */       //   1215: aload_0
/*      */       //   1216: getfield locationOfOnDuplicateKeyUpdate : I
/*      */       //   1219: aload_0
/*      */       //   1220: getfield statementStartPos : I
/*      */       //   1223: invokestatic canRewrite : (Ljava/lang/String;ZII)Z
/*      */       //   1226: ifeq -> 1233
/*      */       //   1229: iconst_1
/*      */       //   1230: goto -> 1234
/*      */       //   1233: iconst_0
/*      */       //   1234: putfield canRewriteAsMultiValueInsert : Z
/*      */       //   1237: aload_0
/*      */       //   1238: getfield canRewriteAsMultiValueInsert : Z
/*      */       //   1241: ifeq -> 1264
/*      */       //   1244: aload_2
/*      */       //   1245: invokeinterface getRewriteBatchedStatements : ()Z
/*      */       //   1250: ifeq -> 1264
/*      */       //   1253: aload_0
/*      */       //   1254: aload_1
/*      */       //   1255: aload_2
/*      */       //   1256: aload_3
/*      */       //   1257: aload #4
/*      */       //   1259: aload #5
/*      */       //   1261: invokespecial buildRewriteBatchedParams : (Ljava/lang/String;Lcom/mysql/jdbc/MySQLConnection;Ljava/sql/DatabaseMetaData;Ljava/lang/String;Lcom/mysql/jdbc/SingleByteCharsetConverter;)V
/*      */       //   1264: return
/*      */       // Line number table:
/*      */       //   Java source line number -> byte code offset
/*      */       //   #180	-> 0
/*      */       //   #143	-> 4
/*      */       //   #145	-> 9
/*      */       //   #147	-> 14
/*      */       //   #149	-> 19
/*      */       //   #151	-> 24
/*      */       //   #153	-> 29
/*      */       //   #155	-> 34
/*      */       //   #157	-> 42
/*      */       //   #159	-> 47
/*      */       //   #161	-> 52
/*      */       //   #163	-> 57
/*      */       //   #167	-> 62
/*      */       //   #182	-> 67
/*      */       //   #183	-> 71
/*      */       //   #187	-> 88
/*      */       //   #188	-> 94
/*      */       //   #190	-> 101
/*      */       //   #192	-> 109
/*      */       //   #194	-> 112
/*      */       //   #195	-> 135
/*      */       //   #198	-> 143
/*      */       //   #200	-> 151
/*      */       //   #201	-> 160
/*      */       //   #202	-> 163
/*      */       //   #203	-> 166
/*      */       //   #204	-> 169
/*      */       //   #207	-> 172
/*      */       //   #212	-> 180
/*      */       //   #214	-> 188
/*      */       //   #215	-> 203
/*      */       //   #217	-> 211
/*      */       //   #219	-> 226
/*      */       //   #222	-> 235
/*      */       //   #223	-> 244
/*      */       //   #225	-> 270
/*      */       //   #229	-> 287
/*      */       //   #230	-> 310
/*      */       //   #231	-> 313
/*      */       //   #235	-> 316
/*      */       //   #236	-> 333
/*      */       //   #237	-> 348
/*      */       //   #240	-> 353
/*      */       //   #241	-> 358
/*      */       //   #242	-> 379
/*      */       //   #243	-> 403
/*      */       //   #244	-> 406
/*      */       //   #247	-> 409
/*      */       //   #248	-> 421
/*      */       //   #249	-> 427
/*      */       //   #250	-> 448
/*      */       //   #251	-> 460
/*      */       //   #254	-> 466
/*      */       //   #256	-> 504
/*      */       //   #258	-> 512
/*      */       //   #259	-> 519
/*      */       //   #261	-> 527
/*      */       //   #262	-> 541
/*      */       //   #258	-> 544
/*      */       //   #267	-> 550
/*      */       //   #269	-> 568
/*      */       //   #271	-> 578
/*      */       //   #272	-> 585
/*      */       //   #274	-> 588
/*      */       //   #275	-> 601
/*      */       //   #276	-> 604
/*      */       //   #278	-> 612
/*      */       //   #279	-> 630
/*      */       //   #280	-> 643
/*      */       //   #282	-> 646
/*      */       //   #283	-> 655
/*      */       //   #274	-> 666
/*      */       //   #291	-> 672
/*      */       //   #292	-> 689
/*      */       //   #293	-> 692
/*      */       //   #298	-> 696
/*      */       //   #299	-> 706
/*      */       //   #300	-> 713
/*      */       //   #301	-> 732
/*      */       //   #303	-> 738
/*      */       //   #304	-> 754
/*      */       //   #306	-> 762
/*      */       //   #307	-> 769
/*      */       //   #308	-> 775
/*      */       //   #309	-> 784
/*      */       //   #310	-> 793
/*      */       //   #311	-> 805
/*      */       //   #309	-> 808
/*      */       //   #314	-> 814
/*      */       //   #315	-> 823
/*      */       //   #317	-> 833
/*      */       //   #214	-> 839
/*      */       //   #323	-> 845
/*      */       //   #324	-> 854
/*      */       //   #325	-> 863
/*      */       //   #327	-> 871
/*      */       //   #330	-> 879
/*      */       //   #333	-> 884
/*      */       //   #334	-> 905
/*      */       //   #335	-> 917
/*      */       //   #337	-> 935
/*      */       //   #338	-> 948
/*      */       //   #339	-> 960
/*      */       //   #340	-> 966
/*      */       //   #341	-> 972
/*      */       //   #343	-> 979
/*      */       //   #344	-> 986
/*      */       //   #345	-> 1004
/*      */       //   #346	-> 1009
/*      */       //   #348	-> 1015
/*      */       //   #349	-> 1025
/*      */       //   #348	-> 1040
/*      */       //   #352	-> 1046
/*      */       //   #353	-> 1055
/*      */       //   #354	-> 1058
/*      */       //   #355	-> 1063
/*      */       //   #358	-> 1103
/*      */       //   #337	-> 1139
/*      */       //   #368	-> 1145
/*      */       //   #363	-> 1148
/*      */       //   #364	-> 1150
/*      */       //   #365	-> 1178
/*      */       //   #367	-> 1186
/*      */       //   #370	-> 1189
/*      */       //   #371	-> 1194
/*      */       //   #374	-> 1237
/*      */       //   #375	-> 1253
/*      */       //   #378	-> 1264
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	descriptor
/*      */       //   512	38	17	endOfStmt	I
/*      */       //   592	80	18	j	I
/*      */       //   578	94	17	cNext	C
/*      */       //   775	64	17	j	I
/*      */       //   211	628	16	c	C
/*      */       //   1018	28	21	j	I
/*      */       //   1015	40	20	buf	[B
/*      */       //   960	179	16	ep	[I
/*      */       //   966	173	17	end	I
/*      */       //   972	167	18	begin	I
/*      */       //   979	160	19	len	I
/*      */       //   109	1036	7	quotedIdentifierString	Ljava/lang/String;
/*      */       //   112	1033	8	quotedIdentifierChar	C
/*      */       //   160	985	9	endpointList	Ljava/util/ArrayList;
/*      */       //   163	982	10	inQuotes	Z
/*      */       //   166	979	11	quoteChar	C
/*      */       //   169	976	12	inQuotedId	Z
/*      */       //   172	973	13	lastParmEnd	I
/*      */       //   194	951	14	i	I
/*      */       //   180	965	15	noBackslashEscapes	Z
/*      */       //   1178	11	8	sqlEx	Ljava/sql/SQLException;
/*      */       //   1150	39	7	oobEx	Ljava/lang/StringIndexOutOfBoundsException;
/*      */       //   0	1265	0	this	Lcom/mysql/jdbc/PreparedStatement$ParseInfo;
/*      */       //   0	1265	1	sql	Ljava/lang/String;
/*      */       //   0	1265	2	conn	Lcom/mysql/jdbc/MySQLConnection;
/*      */       //   0	1265	3	dbmd	Ljava/sql/DatabaseMetaData;
/*      */       //   0	1265	4	encoding	Ljava/lang/String;
/*      */       //   0	1265	5	converter	Lcom/mysql/jdbc/SingleByteCharsetConverter;
/*      */       //   0	1265	6	buildRewriteInfo	Z
/*      */       // Local variable type table:
/*      */       //   start	length	slot	name	signature
/*      */       //   160	985	9	endpointList	Ljava/util/ArrayList<[I>;
/*      */       // Exception table:
/*      */       //   from	to	target	type
/*      */       //   67	1145	1148	java/lang/StringIndexOutOfBoundsException
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void buildRewriteBatchedParams(String sql, MySQLConnection conn, DatabaseMetaData metadata, String encoding, SingleByteCharsetConverter converter) throws SQLException {
/*  388 */       this.valuesClause = extractValuesClause(sql, conn.getMetaData().getIdentifierQuoteString());
/*  389 */       String odkuClause = this.isOnDuplicateKeyUpdate ? sql.substring(this.locationOfOnDuplicateKeyUpdate) : null;
/*      */       
/*  391 */       String headSql = null;
/*      */       
/*  393 */       if (this.isOnDuplicateKeyUpdate) {
/*  394 */         headSql = sql.substring(0, this.locationOfOnDuplicateKeyUpdate);
/*      */       } else {
/*  396 */         headSql = sql;
/*      */       } 
/*      */       
/*  399 */       this.batchHead = new ParseInfo(headSql, conn, metadata, encoding, converter, false);
/*  400 */       this.batchValues = new ParseInfo("," + this.valuesClause, conn, metadata, encoding, converter, false);
/*  401 */       this.batchODKUClause = null;
/*      */       
/*  403 */       if (odkuClause != null && odkuClause.length() > 0) {
/*  404 */         this.batchODKUClause = new ParseInfo("," + this.valuesClause + " " + odkuClause, conn, metadata, encoding, converter, false);
/*      */       }
/*      */     }
/*      */     
/*      */     private String extractValuesClause(String sql, String quoteCharStr) throws SQLException {
/*  409 */       int indexOfValues = -1;
/*  410 */       int valuesSearchStart = this.statementStartPos;
/*      */       
/*  412 */       while (indexOfValues == -1) {
/*  413 */         if (quoteCharStr.length() > 0) {
/*  414 */           indexOfValues = StringUtils.indexOfIgnoreCase(valuesSearchStart, sql, "VALUES", quoteCharStr, quoteCharStr, StringUtils.SEARCH_MODE__MRK_COM_WS);
/*      */         } else {
/*      */           
/*  417 */           indexOfValues = StringUtils.indexOfIgnoreCase(valuesSearchStart, sql, "VALUES");
/*      */         } 
/*      */         
/*  420 */         if (indexOfValues > 0) {
/*      */           
/*  422 */           char c = sql.charAt(indexOfValues - 1);
/*  423 */           if (!Character.isWhitespace(c) && c != ')' && c != '`') {
/*  424 */             valuesSearchStart = indexOfValues + 6;
/*  425 */             indexOfValues = -1;
/*      */             continue;
/*      */           } 
/*  428 */           c = sql.charAt(indexOfValues + 6);
/*  429 */           if (!Character.isWhitespace(c) && c != '(') {
/*  430 */             valuesSearchStart = indexOfValues + 6;
/*  431 */             indexOfValues = -1;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  439 */       if (indexOfValues == -1) {
/*  440 */         return null;
/*      */       }
/*      */       
/*  443 */       int indexOfFirstParen = sql.indexOf('(', indexOfValues + 6);
/*      */       
/*  445 */       if (indexOfFirstParen == -1) {
/*  446 */         return null;
/*      */       }
/*      */       
/*  449 */       int endOfValuesClause = this.isOnDuplicateKeyUpdate ? this.locationOfOnDuplicateKeyUpdate : sql.length();
/*      */       
/*  451 */       return sql.substring(indexOfFirstParen, endOfValuesClause);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     synchronized ParseInfo getParseInfoForBatch(int numBatch) {
/*  458 */       PreparedStatement.AppendingBatchVisitor apv = new PreparedStatement.AppendingBatchVisitor();
/*  459 */       buildInfoForBatch(numBatch, apv);
/*      */       
/*  461 */       ParseInfo batchParseInfo = new ParseInfo(apv.getStaticSqlStrings(), this.firstStmtChar, this.foundLoadData, this.isOnDuplicateKeyUpdate, this.locationOfOnDuplicateKeyUpdate, this.statementLength, this.statementStartPos);
/*      */ 
/*      */       
/*  464 */       return batchParseInfo;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     String getSqlForBatch(int numBatch) throws UnsupportedEncodingException {
/*  473 */       ParseInfo batchInfo = getParseInfoForBatch(numBatch);
/*      */       
/*  475 */       return getSqlForBatch(batchInfo);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     String getSqlForBatch(ParseInfo batchInfo) throws UnsupportedEncodingException {
/*  482 */       int size = 0;
/*  483 */       byte[][] sqlStrings = batchInfo.staticSql;
/*  484 */       int sqlStringsLength = sqlStrings.length;
/*      */       
/*  486 */       for (int i = 0; i < sqlStringsLength; i++) {
/*  487 */         size += (sqlStrings[i]).length;
/*  488 */         size++;
/*      */       } 
/*      */       
/*  491 */       StringBuilder buf = new StringBuilder(size);
/*      */       
/*  493 */       for (int j = 0; j < sqlStringsLength - 1; j++) {
/*  494 */         buf.append(StringUtils.toString(sqlStrings[j], this.charEncoding));
/*  495 */         buf.append("?");
/*      */       } 
/*      */       
/*  498 */       buf.append(StringUtils.toString(sqlStrings[sqlStringsLength - 1]));
/*      */       
/*  500 */       return buf.toString();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void buildInfoForBatch(int numBatch, PreparedStatement.BatchVisitor visitor) {
/*  512 */       if (!this.hasPlaceholders) {
/*  513 */         if (numBatch == 1) {
/*      */ 
/*      */           
/*  516 */           visitor.append(this.staticSql[0]);
/*      */ 
/*      */           
/*      */           return;
/*      */         } 
/*      */ 
/*      */         
/*  523 */         byte[] arrayOfByte1 = this.batchHead.staticSql[0];
/*  524 */         visitor.append(arrayOfByte1).increment();
/*      */         
/*  526 */         int k = numBatch - 1;
/*  527 */         if (this.batchODKUClause != null) {
/*  528 */           k--;
/*      */         }
/*      */         
/*  531 */         byte[] arrayOfByte2 = this.batchValues.staticSql[0];
/*  532 */         for (int m = 0; m < k; m++) {
/*  533 */           visitor.mergeWithLast(arrayOfByte2).increment();
/*      */         }
/*      */         
/*  536 */         if (this.batchODKUClause != null) {
/*  537 */           byte[] batchOdkuStaticSql = this.batchODKUClause.staticSql[0];
/*  538 */           visitor.mergeWithLast(batchOdkuStaticSql).increment();
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */ 
/*      */       
/*  547 */       byte[][] headStaticSql = this.batchHead.staticSql;
/*  548 */       int headStaticSqlLength = headStaticSql.length;
/*  549 */       byte[] endOfHead = headStaticSql[headStaticSqlLength - 1];
/*      */       
/*  551 */       for (int i = 0; i < headStaticSqlLength - 1; i++) {
/*  552 */         visitor.append(headStaticSql[i]).increment();
/*      */       }
/*      */ 
/*      */       
/*  556 */       int numValueRepeats = numBatch - 1;
/*  557 */       if (this.batchODKUClause != null) {
/*  558 */         numValueRepeats--;
/*      */       }
/*      */       
/*  561 */       byte[][] valuesStaticSql = this.batchValues.staticSql;
/*  562 */       int valuesStaticSqlLength = valuesStaticSql.length;
/*  563 */       byte[] beginOfValues = valuesStaticSql[0];
/*  564 */       byte[] endOfValues = valuesStaticSql[valuesStaticSqlLength - 1];
/*      */       
/*  566 */       for (int j = 0; j < numValueRepeats; j++) {
/*  567 */         visitor.merge(endOfValues, beginOfValues).increment();
/*  568 */         for (int k = 1; k < valuesStaticSqlLength - 1; k++) {
/*  569 */           visitor.append(valuesStaticSql[k]).increment();
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  574 */       if (this.batchODKUClause != null) {
/*  575 */         byte[][] batchOdkuStaticSql = this.batchODKUClause.staticSql;
/*  576 */         int batchOdkuStaticSqlLength = batchOdkuStaticSql.length;
/*  577 */         byte[] beginOfOdku = batchOdkuStaticSql[0];
/*  578 */         byte[] endOfOdku = batchOdkuStaticSql[batchOdkuStaticSqlLength - 1];
/*      */         
/*  580 */         if (numBatch > 1) {
/*  581 */           visitor.merge((numValueRepeats > 0) ? endOfValues : endOfHead, beginOfOdku).increment();
/*  582 */           for (int k = 1; k < batchOdkuStaticSqlLength; k++) {
/*  583 */             visitor.append(batchOdkuStaticSql[k]).increment();
/*      */           }
/*      */         } else {
/*  586 */           visitor.append(endOfOdku).increment();
/*      */         } 
/*      */       } else {
/*  589 */         visitor.append(endOfHead);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private ParseInfo(byte[][] staticSql, char firstStmtChar, boolean foundLoadData, boolean isOnDuplicateKeyUpdate, int locationOfOnDuplicateKeyUpdate, int statementLength, int statementStartPos) {
/*  595 */       this.firstStmtChar = firstStmtChar;
/*  596 */       this.foundLoadData = foundLoadData;
/*  597 */       this.isOnDuplicateKeyUpdate = isOnDuplicateKeyUpdate;
/*  598 */       this.locationOfOnDuplicateKeyUpdate = locationOfOnDuplicateKeyUpdate;
/*  599 */       this.statementLength = statementLength;
/*  600 */       this.statementStartPos = statementStartPos;
/*  601 */       this.staticSql = staticSql;
/*      */     }
/*      */   }
/*      */   
/*      */   static interface BatchVisitor {
/*      */     BatchVisitor increment();
/*      */     
/*      */     BatchVisitor decrement();
/*      */     
/*      */     BatchVisitor append(byte[] param1ArrayOfbyte);
/*      */     
/*      */     BatchVisitor merge(byte[] param1ArrayOfbyte1, byte[] param1ArrayOfbyte2);
/*      */     
/*      */     BatchVisitor mergeWithLast(byte[] param1ArrayOfbyte);
/*      */   }
/*      */   
/*      */   static class AppendingBatchVisitor implements BatchVisitor {
/*  618 */     LinkedList<byte[]> statementComponents = (LinkedList)new LinkedList<byte>();
/*      */     
/*      */     public PreparedStatement.BatchVisitor append(byte[] values) {
/*  621 */       this.statementComponents.addLast(values);
/*      */       
/*  623 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public PreparedStatement.BatchVisitor increment() {
/*  628 */       return this;
/*      */     }
/*      */     
/*      */     public PreparedStatement.BatchVisitor decrement() {
/*  632 */       this.statementComponents.removeLast();
/*      */       
/*  634 */       return this;
/*      */     }
/*      */     
/*      */     public PreparedStatement.BatchVisitor merge(byte[] front, byte[] back) {
/*  638 */       int mergedLength = front.length + back.length;
/*  639 */       byte[] merged = new byte[mergedLength];
/*  640 */       System.arraycopy(front, 0, merged, 0, front.length);
/*  641 */       System.arraycopy(back, 0, merged, front.length, back.length);
/*  642 */       this.statementComponents.addLast(merged);
/*  643 */       return this;
/*      */     }
/*      */     
/*      */     public PreparedStatement.BatchVisitor mergeWithLast(byte[] values) {
/*  647 */       if (this.statementComponents.isEmpty()) {
/*  648 */         return append(values);
/*      */       }
/*  650 */       return merge(this.statementComponents.removeLast(), values);
/*      */     }
/*      */     
/*      */     public byte[][] getStaticSqlStrings() {
/*  654 */       byte[][] asBytes = new byte[this.statementComponents.size()][];
/*  655 */       this.statementComponents.toArray(asBytes);
/*      */       
/*  657 */       return asBytes;
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  662 */       StringBuilder sb = new StringBuilder();
/*  663 */       for (byte[] comp : this.statementComponents) {
/*  664 */         sb.append(StringUtils.toString(comp));
/*      */       }
/*  666 */       return sb.toString();
/*      */     }
/*      */   }
/*      */   
/*  670 */   private static final byte[] HEX_DIGITS = new byte[] { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static int readFully(Reader reader, char[] buf, int length) throws IOException {
/*  684 */     int numCharsRead = 0;
/*      */     
/*  686 */     while (numCharsRead < length) {
/*  687 */       int count = reader.read(buf, numCharsRead, length - numCharsRead);
/*      */       
/*  689 */       if (count < 0) {
/*      */         break;
/*      */       }
/*      */       
/*  693 */       numCharsRead += count;
/*      */     } 
/*      */     
/*  696 */     return numCharsRead;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean batchHasPlainStatements = false;
/*      */ 
/*      */ 
/*      */   
/*  707 */   private DatabaseMetaData dbmd = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  713 */   protected char firstCharOfStmt = Character.MIN_VALUE;
/*      */ 
/*      */   
/*      */   protected boolean isLoadDataQuery = false;
/*      */   
/*  718 */   protected boolean[] isNull = null;
/*      */   
/*  720 */   private boolean[] isStream = null;
/*      */   
/*  722 */   protected int numberOfExecutions = 0;
/*      */ 
/*      */   
/*  725 */   protected String originalSql = null;
/*      */ 
/*      */   
/*      */   protected int parameterCount;
/*      */   
/*      */   protected MysqlParameterMetadata parameterMetaData;
/*      */   
/*  732 */   private InputStream[] parameterStreams = null;
/*      */   
/*  734 */   private byte[][] parameterValues = (byte[][])null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  740 */   protected int[] parameterTypes = null;
/*      */   
/*      */   protected ParseInfo parseInfo;
/*      */   
/*      */   private ResultSetMetaData pstmtResultMetaData;
/*      */   
/*  746 */   private byte[][] staticSqlStrings = (byte[][])null;
/*      */   
/*  748 */   private byte[] streamConvertBuf = null;
/*      */   
/*  750 */   private int[] streamLengths = null;
/*      */   
/*  752 */   private SimpleDateFormat tsdf = null;
/*      */ 
/*      */   
/*      */   private SimpleDateFormat ddf;
/*      */ 
/*      */   
/*      */   private SimpleDateFormat tdf;
/*      */ 
/*      */   
/*      */   protected boolean useTrueBoolean = false;
/*      */ 
/*      */   
/*      */   protected boolean usingAnsiMode;
/*      */ 
/*      */   
/*      */   protected String batchedValuesClause;
/*      */   
/*      */   private boolean doPingInstead;
/*      */   
/*      */   private boolean compensateForOnDuplicateKeyUpdate = false;
/*      */   
/*      */   private CharsetEncoder charsetEncoder;
/*      */   
/*  775 */   protected int batchCommandIndex = -1;
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean serverSupportsFracSecs;
/*      */ 
/*      */   
/*      */   protected int rewrittenBatchSize;
/*      */ 
/*      */ 
/*      */   
/*      */   protected static PreparedStatement getInstance(MySQLConnection conn, String catalog) throws SQLException {
/*  787 */     if (!Util.isJdbc4()) {
/*  788 */       return new PreparedStatement(conn, catalog);
/*      */     }
/*      */     
/*  791 */     return (PreparedStatement)Util.handleNewInstance(JDBC_4_PSTMT_2_ARG_CTOR, new Object[] { conn, catalog }, conn.getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static PreparedStatement getInstance(MySQLConnection conn, String sql, String catalog) throws SQLException {
/*  802 */     if (!Util.isJdbc4()) {
/*  803 */       return new PreparedStatement(conn, sql, catalog);
/*      */     }
/*      */     
/*  806 */     return (PreparedStatement)Util.handleNewInstance(JDBC_4_PSTMT_3_ARG_CTOR, new Object[] { conn, sql, catalog }, conn.getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static PreparedStatement getInstance(MySQLConnection conn, String sql, String catalog, ParseInfo cachedParseInfo) throws SQLException {
/*  817 */     if (!Util.isJdbc4()) {
/*  818 */       return new PreparedStatement(conn, sql, catalog, cachedParseInfo);
/*      */     }
/*      */     
/*  821 */     return (PreparedStatement)Util.handleNewInstance(JDBC_4_PSTMT_4_ARG_CTOR, new Object[] { conn, sql, catalog, cachedParseInfo }, conn.getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PreparedStatement(MySQLConnection conn, String catalog) throws SQLException
/*      */   {
/*  837 */     super(conn, catalog);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2281 */     this.rewrittenBatchSize = 0; detectFractionalSecondsSupport(); this.compensateForOnDuplicateKeyUpdate = this.connection.getCompensateOnDuplicateKeyUpdateCounts(); } protected void detectFractionalSecondsSupport() throws SQLException { this.serverSupportsFracSecs = (this.connection != null && this.connection.versionMeetsMinimum(5, 6, 4)); } public PreparedStatement(MySQLConnection conn, String sql, String catalog) throws SQLException { super(conn, catalog); this.rewrittenBatchSize = 0; if (sql == null) throw SQLError.createSQLException(Messages.getString("PreparedStatement.0"), "S1009", getExceptionInterceptor());  detectFractionalSecondsSupport(); this.originalSql = sql; this.doPingInstead = this.originalSql.startsWith("/* ping */"); this.dbmd = this.connection.getMetaData(); this.useTrueBoolean = this.connection.versionMeetsMinimum(3, 21, 23); this.parseInfo = new ParseInfo(sql, this.connection, this.dbmd, this.charEncoding, this.charConverter); initializeFromParseInfo(); this.compensateForOnDuplicateKeyUpdate = this.connection.getCompensateOnDuplicateKeyUpdateCounts(); if (conn.getRequiresEscapingEncoder()) this.charsetEncoder = Charset.forName(conn.getEncoding()).newEncoder();  } public PreparedStatement(MySQLConnection conn, String sql, String catalog, ParseInfo cachedParseInfo) throws SQLException { super(conn, catalog); this.rewrittenBatchSize = 0; if (sql == null) throw SQLError.createSQLException(Messages.getString("PreparedStatement.1"), "S1009", getExceptionInterceptor());  detectFractionalSecondsSupport(); this.originalSql = sql; this.dbmd = this.connection.getMetaData(); this.useTrueBoolean = this.connection.versionMeetsMinimum(3, 21, 23); this.parseInfo = cachedParseInfo; this.usingAnsiMode = !this.connection.useAnsiQuotedIdentifiers(); initializeFromParseInfo(); this.compensateForOnDuplicateKeyUpdate = this.connection.getCompensateOnDuplicateKeyUpdateCounts(); if (conn.getRequiresEscapingEncoder()) this.charsetEncoder = Charset.forName(conn.getEncoding()).newEncoder();  }
/*      */   public void addBatch() throws SQLException { synchronized (checkClosed().getConnectionMutex()) { if (this.batchedArgs == null) this.batchedArgs = new ArrayList();  for (int i = 0; i < this.parameterValues.length; i++) checkAllParametersSet(this.parameterValues[i], this.parameterStreams[i], i);  this.batchedArgs.add(new BatchParams(this.parameterValues, this.parameterStreams, this.isStream, this.streamLengths, this.isNull)); }  }
/*      */   public void addBatch(String sql) throws SQLException { synchronized (checkClosed().getConnectionMutex()) { this.batchHasPlainStatements = true; super.addBatch(sql); }  }
/* 2284 */   public String asSql() throws SQLException { return asSql(false); } public String asSql(boolean quoteStreamsAndUnknowns) throws SQLException { synchronized (checkClosed().getConnectionMutex()) { StringBuilder buf = new StringBuilder(); try { int realParameterCount = this.parameterCount + getParameterIndexOffset(); Object batchArg = null; if (this.batchCommandIndex != -1) batchArg = this.batchedArgs.get(this.batchCommandIndex);  for (int i = 0; i < realParameterCount; i++) { if (this.charEncoding != null) { buf.append(StringUtils.toString(this.staticSqlStrings[i], this.charEncoding)); } else { buf.append(StringUtils.toString(this.staticSqlStrings[i])); }  byte[] val = null; if (batchArg != null && batchArg instanceof String) { buf.append((String)batchArg); } else { if (this.batchCommandIndex == -1) { val = this.parameterValues[i]; } else { val = ((BatchParams)batchArg).parameterStrings[i]; }  boolean isStreamParam = false; if (this.batchCommandIndex == -1) { isStreamParam = this.isStream[i]; } else { isStreamParam = ((BatchParams)batchArg).isStream[i]; }  if (val == null && !isStreamParam) { if (quoteStreamsAndUnknowns) buf.append("'");  buf.append("** NOT SPECIFIED **"); if (quoteStreamsAndUnknowns) buf.append("'");  } else if (isStreamParam) { if (quoteStreamsAndUnknowns) buf.append("'");  buf.append("** STREAM DATA **"); if (quoteStreamsAndUnknowns) buf.append("'");  } else if (this.charConverter != null) { buf.append(this.charConverter.toString(val)); } else if (this.charEncoding != null) { buf.append(new String(val, this.charEncoding)); } else { buf.append(StringUtils.toAsciiString(val)); }  }  }  if (this.charEncoding != null) { buf.append(StringUtils.toString(this.staticSqlStrings[this.parameterCount + getParameterIndexOffset()], this.charEncoding)); } else { buf.append(StringUtils.toAsciiString(this.staticSqlStrings[this.parameterCount + getParameterIndexOffset()])); }  } catch (UnsupportedEncodingException uue) { throw new RuntimeException(Messages.getString("PreparedStatement.32") + this.charEncoding + Messages.getString("PreparedStatement.33")); }  return buf.toString(); }  } public void clearBatch() throws SQLException { synchronized (checkClosed().getConnectionMutex()) { this.batchHasPlainStatements = false; super.clearBatch(); }  } public void clearParameters() throws SQLException { synchronized (checkClosed().getConnectionMutex()) { for (int i = 0; i < this.parameterValues.length; i++) { this.parameterValues[i] = null; this.parameterStreams[i] = null; this.isStream[i] = false; this.isNull[i] = false; this.parameterTypes[i] = 0; }  }  } private final void escapeblockFast(byte[] buf, Buffer packet, int size) throws SQLException { int lastwritten = 0; for (int i = 0; i < size; i++) { byte b = buf[i]; if (b == 0) { if (i > lastwritten) packet.writeBytesNoNull(buf, lastwritten, i - lastwritten);  packet.writeByte((byte)92); packet.writeByte((byte)48); lastwritten = i + 1; } else if (b == 92 || b == 39 || (!this.usingAnsiMode && b == 34)) { if (i > lastwritten) packet.writeBytesNoNull(buf, lastwritten, i - lastwritten);  packet.writeByte((byte)92); lastwritten = i; }  }  if (lastwritten < size) packet.writeBytesNoNull(buf, lastwritten, size - lastwritten);  } private final void escapeblockFast(byte[] buf, ByteArrayOutputStream bytesOut, int size) { int lastwritten = 0; for (int i = 0; i < size; i++) { byte b = buf[i]; if (b == 0) { if (i > lastwritten) bytesOut.write(buf, lastwritten, i - lastwritten);  bytesOut.write(92); bytesOut.write(48); lastwritten = i + 1; } else if (b == 92 || b == 39 || (!this.usingAnsiMode && b == 34)) { if (i > lastwritten) bytesOut.write(buf, lastwritten, i - lastwritten);  bytesOut.write(92); lastwritten = i; }  }  if (lastwritten < size) bytesOut.write(buf, lastwritten, size - lastwritten);  } protected boolean checkReadOnlySafeStatement() throws SQLException { synchronized (checkClosed().getConnectionMutex()) { return (this.firstCharOfStmt == 'S' || !this.connection.isReadOnly()); }  } public boolean execute() throws SQLException { synchronized (checkClosed().getConnectionMutex()) { MySQLConnection locallyScopedConn = this.connection; if (!this.doPingInstead && !checkReadOnlySafeStatement()) throw SQLError.createSQLException(Messages.getString("PreparedStatement.20") + Messages.getString("PreparedStatement.21"), "S1009", getExceptionInterceptor());  ResultSetInternalMethods rs = null; this.lastQueryIsOnDupKeyUpdate = false; if (this.retrieveGeneratedKeys) this.lastQueryIsOnDupKeyUpdate = containsOnDuplicateKeyUpdateInSQL();  this.batchedGeneratedKeys = null; resetCancelledState(); implicitlyCloseAllOpenResults(); clearWarnings(); if (this.doPingInstead) { doPingInstead(); return true; }  setupStreamingTimeout(locallyScopedConn); Buffer sendPacket = fillSendPacket(); String oldCatalog = null; if (!locallyScopedConn.getCatalog().equals(this.currentCatalog)) { oldCatalog = locallyScopedConn.getCatalog(); locallyScopedConn.setCatalog(this.currentCatalog); }  CachedResultSetMetaData cachedMetadata = null; if (locallyScopedConn.getCacheResultSetMetadata()) cachedMetadata = locallyScopedConn.getCachedMetaData(this.originalSql);  Field[] metadataFromCache = null; if (cachedMetadata != null) metadataFromCache = cachedMetadata.fields;  boolean oldInfoMsgState = false; if (this.retrieveGeneratedKeys) { oldInfoMsgState = locallyScopedConn.isReadInfoMsgEnabled(); locallyScopedConn.setReadInfoMsgEnabled(true); }  locallyScopedConn.setSessionMaxRows((this.firstCharOfStmt == 'S') ? this.maxRows : -1); rs = executeInternal(this.maxRows, sendPacket, createStreamingResultSet(), (this.firstCharOfStmt == 'S'), metadataFromCache, false); if (cachedMetadata != null) { locallyScopedConn.initializeResultsMetadataFromCache(this.originalSql, cachedMetadata, rs); } else if (rs.reallyResult() && locallyScopedConn.getCacheResultSetMetadata()) { locallyScopedConn.initializeResultsMetadataFromCache(this.originalSql, (CachedResultSetMetaData)null, rs); }  if (this.retrieveGeneratedKeys) { locallyScopedConn.setReadInfoMsgEnabled(oldInfoMsgState); rs.setFirstCharOfQuery(this.firstCharOfStmt); }  if (oldCatalog != null) locallyScopedConn.setCatalog(oldCatalog);  if (rs != null) { this.lastInsertId = rs.getUpdateID(); this.results = rs; }  return (rs != null && rs.reallyResult()); }  } protected long[] executeBatchInternal() throws SQLException { synchronized (checkClosed().getConnectionMutex()) { if (this.connection.isReadOnly()) throw new SQLException(Messages.getString("PreparedStatement.25") + Messages.getString("PreparedStatement.26"), "S1009");  if (this.batchedArgs == null || this.batchedArgs.size() == 0) return new long[0];  int batchTimeout = this.timeoutInMillis; this.timeoutInMillis = 0; resetCancelledState(); try { statementBegins(); clearWarnings(); if (!this.batchHasPlainStatements && this.connection.getRewriteBatchedStatements()) { if (canRewriteAsMultiValueInsertAtSqlLevel()) return executeBatchedInserts(batchTimeout);  if (this.connection.versionMeetsMinimum(4, 1, 0) && !this.batchHasPlainStatements && this.batchedArgs != null && this.batchedArgs.size() > 3) return executePreparedBatchAsMultiStatement(batchTimeout);  }  return executeBatchSerially(batchTimeout); } finally { this.statementExecuting.set(false); clearBatch(); }  }  } public boolean canRewriteAsMultiValueInsertAtSqlLevel() throws SQLException { return this.parseInfo.canRewriteAsMultiValueInsert; } protected int getLocationOfOnDuplicateKeyUpdate() throws SQLException { return this.parseInfo.locationOfOnDuplicateKeyUpdate; } protected long[] executePreparedBatchAsMultiStatement(int batchTimeout) throws SQLException { synchronized (checkClosed().getConnectionMutex()) { if (this.batchedValuesClause == null) this.batchedValuesClause = this.originalSql + ";";  MySQLConnection locallyScopedConn = this.connection; boolean multiQueriesEnabled = locallyScopedConn.getAllowMultiQueries(); StatementImpl.CancelTask timeoutTask = null; try { clearWarnings(); int numBatchedArgs = this.batchedArgs.size(); if (this.retrieveGeneratedKeys) this.batchedGeneratedKeys = new ArrayList<ResultSetRow>(numBatchedArgs);  int numValuesPerBatch = computeBatchSize(numBatchedArgs); if (numBatchedArgs < numValuesPerBatch) numValuesPerBatch = numBatchedArgs;  PreparedStatement batchedStatement = null; int batchedParamIndex = 1; int numberToExecuteAsMultiValue = 0; int batchCounter = 0; int updateCountCounter = 0; long[] updateCounts = new long[numBatchedArgs * this.parseInfo.numberOfQueries]; SQLException sqlEx = null; try { if (!multiQueriesEnabled) locallyScopedConn.getIO().enableMultiQueries();  if (this.retrieveGeneratedKeys) { batchedStatement = ((Wrapper)locallyScopedConn.prepareStatement(generateMultiStatementForBatch(numValuesPerBatch), 1)).<PreparedStatement>unwrap(PreparedStatement.class); } else { batchedStatement = ((Wrapper)locallyScopedConn.prepareStatement(generateMultiStatementForBatch(numValuesPerBatch))).<PreparedStatement>unwrap(PreparedStatement.class); }  if (locallyScopedConn.getEnableQueryTimeouts() && batchTimeout != 0 && locallyScopedConn.versionMeetsMinimum(5, 0, 0)) { timeoutTask = new StatementImpl.CancelTask(this, (StatementImpl)batchedStatement); locallyScopedConn.getCancelTimer().schedule(timeoutTask, batchTimeout); }  if (numBatchedArgs < numValuesPerBatch) { numberToExecuteAsMultiValue = numBatchedArgs; } else { numberToExecuteAsMultiValue = numBatchedArgs / numValuesPerBatch; }  int numberArgsToExecute = numberToExecuteAsMultiValue * numValuesPerBatch; for (int i = 0; i < numberArgsToExecute; i++) { if (i != 0 && i % numValuesPerBatch == 0) { try { batchedStatement.execute(); } catch (SQLException ex) { sqlEx = handleExceptionForBatch(batchCounter, numValuesPerBatch, updateCounts, ex); }  updateCountCounter = processMultiCountsAndKeys((StatementImpl)batchedStatement, updateCountCounter, updateCounts); batchedStatement.clearParameters(); batchedParamIndex = 1; }  batchedParamIndex = setOneBatchedParameterSet(batchedStatement, batchedParamIndex, this.batchedArgs.get(batchCounter++)); }  try { batchedStatement.execute(); } catch (SQLException ex) { sqlEx = handleExceptionForBatch(batchCounter - 1, numValuesPerBatch, updateCounts, ex); }  updateCountCounter = processMultiCountsAndKeys((StatementImpl)batchedStatement, updateCountCounter, updateCounts); batchedStatement.clearParameters(); numValuesPerBatch = numBatchedArgs - batchCounter; } finally { if (batchedStatement != null) { batchedStatement.close(); batchedStatement = null; }  }  try { if (numValuesPerBatch > 0) { if (this.retrieveGeneratedKeys) { batchedStatement = locallyScopedConn.prepareStatement(generateMultiStatementForBatch(numValuesPerBatch), 1); } else { batchedStatement = locallyScopedConn.prepareStatement(generateMultiStatementForBatch(numValuesPerBatch)); }  if (timeoutTask != null) timeoutTask.toCancel = (StatementImpl)batchedStatement;  batchedParamIndex = 1; while (batchCounter < numBatchedArgs) batchedParamIndex = setOneBatchedParameterSet(batchedStatement, batchedParamIndex, this.batchedArgs.get(batchCounter++));  try { batchedStatement.execute(); } catch (SQLException ex) { sqlEx = handleExceptionForBatch(batchCounter - 1, numValuesPerBatch, updateCounts, ex); }  updateCountCounter = processMultiCountsAndKeys((StatementImpl)batchedStatement, updateCountCounter, updateCounts); batchedStatement.clearParameters(); }  if (timeoutTask != null) { if (timeoutTask.caughtWhileCancelling != null) throw timeoutTask.caughtWhileCancelling;  timeoutTask.cancel(); locallyScopedConn.getCancelTimer().purge(); timeoutTask = null; }  if (sqlEx != null) throw SQLError.createBatchUpdateException(sqlEx, updateCounts, getExceptionInterceptor());  return updateCounts; } finally { if (batchedStatement != null) batchedStatement.close();  }  } finally { if (timeoutTask != null) { timeoutTask.cancel(); locallyScopedConn.getCancelTimer().purge(); }  resetCancelledState(); if (!multiQueriesEnabled) locallyScopedConn.getIO().disableMultiQueries();  clearBatch(); }  }  } private String generateMultiStatementForBatch(int numBatches) throws SQLException { synchronized (checkClosed().getConnectionMutex()) { StringBuilder newStatementSql = new StringBuilder((this.originalSql.length() + 1) * numBatches); newStatementSql.append(this.originalSql); for (int i = 0; i < numBatches - 1; i++) { newStatementSql.append(';'); newStatementSql.append(this.originalSql); }  return newStatementSql.toString(); }  } protected long[] executeBatchedInserts(int batchTimeout) throws SQLException { synchronized (checkClosed().getConnectionMutex()) { String valuesClause = getValuesClause(); MySQLConnection locallyScopedConn = this.connection; if (valuesClause == null) return executeBatchSerially(batchTimeout);  int numBatchedArgs = this.batchedArgs.size(); if (this.retrieveGeneratedKeys) this.batchedGeneratedKeys = new ArrayList<ResultSetRow>(numBatchedArgs);  int numValuesPerBatch = computeBatchSize(numBatchedArgs); if (numBatchedArgs < numValuesPerBatch) numValuesPerBatch = numBatchedArgs;  PreparedStatement batchedStatement = null; int batchedParamIndex = 1; long updateCountRunningTotal = 0L; int numberToExecuteAsMultiValue = 0; int batchCounter = 0; StatementImpl.CancelTask timeoutTask = null; SQLException sqlEx = null; long[] updateCounts = new long[numBatchedArgs]; try { try { batchedStatement = prepareBatchedInsertSQL(locallyScopedConn, numValuesPerBatch); if (locallyScopedConn.getEnableQueryTimeouts() && batchTimeout != 0 && locallyScopedConn.versionMeetsMinimum(5, 0, 0)) { timeoutTask = new StatementImpl.CancelTask(this, batchedStatement); locallyScopedConn.getCancelTimer().schedule(timeoutTask, batchTimeout); }  if (numBatchedArgs < numValuesPerBatch) { numberToExecuteAsMultiValue = numBatchedArgs; } else { numberToExecuteAsMultiValue = numBatchedArgs / numValuesPerBatch; }  int numberArgsToExecute = numberToExecuteAsMultiValue * numValuesPerBatch; for (int i = 0; i < numberArgsToExecute; i++) { if (i != 0 && i % numValuesPerBatch == 0) { try { updateCountRunningTotal += batchedStatement.executeLargeUpdate(); } catch (SQLException ex) { sqlEx = handleExceptionForBatch(batchCounter - 1, numValuesPerBatch, updateCounts, ex); }  getBatchedGeneratedKeys(batchedStatement); batchedStatement.clearParameters(); batchedParamIndex = 1; }  batchedParamIndex = setOneBatchedParameterSet(batchedStatement, batchedParamIndex, this.batchedArgs.get(batchCounter++)); }  try { updateCountRunningTotal += batchedStatement.executeLargeUpdate(); } catch (SQLException ex) { sqlEx = handleExceptionForBatch(batchCounter - 1, numValuesPerBatch, updateCounts, ex); }  getBatchedGeneratedKeys(batchedStatement); numValuesPerBatch = numBatchedArgs - batchCounter; } finally { if (batchedStatement != null) { batchedStatement.close(); batchedStatement = null; }  }  try { if (numValuesPerBatch > 0) { batchedStatement = prepareBatchedInsertSQL(locallyScopedConn, numValuesPerBatch); if (timeoutTask != null) timeoutTask.toCancel = batchedStatement;  batchedParamIndex = 1; while (batchCounter < numBatchedArgs) batchedParamIndex = setOneBatchedParameterSet(batchedStatement, batchedParamIndex, this.batchedArgs.get(batchCounter++));  try { updateCountRunningTotal += batchedStatement.executeLargeUpdate(); } catch (SQLException ex) { sqlEx = handleExceptionForBatch(batchCounter - 1, numValuesPerBatch, updateCounts, ex); }  getBatchedGeneratedKeys(batchedStatement); }  if (sqlEx != null) throw SQLError.createBatchUpdateException(sqlEx, updateCounts, getExceptionInterceptor());  if (numBatchedArgs > 1) { long updCount = (updateCountRunningTotal > 0L) ? -2L : 0L; for (int j = 0; j < numBatchedArgs; j++) updateCounts[j] = updCount;  } else { updateCounts[0] = updateCountRunningTotal; }  return updateCounts; } finally { if (batchedStatement != null) batchedStatement.close();  }  } finally { if (timeoutTask != null) { timeoutTask.cancel(); locallyScopedConn.getCancelTimer().purge(); }  resetCancelledState(); }  }  } public int getRewrittenBatchSize() { return this.rewrittenBatchSize; }
/*      */   protected String getValuesClause() throws SQLException { return this.parseInfo.valuesClause; }
/*      */   protected int computeBatchSize(int numBatchedArgs) throws SQLException { synchronized (checkClosed().getConnectionMutex()) { long[] combinedValues = computeMaxParameterSetSizeAndBatchSize(numBatchedArgs); long maxSizeOfParameterSet = combinedValues[0]; long sizeOfEntireBatch = combinedValues[1]; int maxAllowedPacket = this.connection.getMaxAllowedPacket(); if (sizeOfEntireBatch < (maxAllowedPacket - this.originalSql.length())) return numBatchedArgs;  return (int)Math.max(1L, (maxAllowedPacket - this.originalSql.length()) / maxSizeOfParameterSet); }  }
/*      */   protected long[] computeMaxParameterSetSizeAndBatchSize(int numBatchedArgs) throws SQLException { synchronized (checkClosed().getConnectionMutex()) { long sizeOfEntireBatch = 0L; long maxSizeOfParameterSet = 0L; for (int i = 0; i < numBatchedArgs; i++) { BatchParams paramArg = (BatchParams)this.batchedArgs.get(i); boolean[] isNullBatch = paramArg.isNull; boolean[] isStreamBatch = paramArg.isStream; long sizeOfParameterSet = 0L; for (int j = 0; j < isNullBatch.length; j++) { if (!isNullBatch[j]) { if (isStreamBatch[j]) { int streamLength = paramArg.streamLengths[j]; if (streamLength != -1) { sizeOfParameterSet += (streamLength * 2); } else { int paramLength = (paramArg.parameterStrings[j]).length; sizeOfParameterSet += paramLength; }  } else { sizeOfParameterSet += (paramArg.parameterStrings[j]).length; }  } else { sizeOfParameterSet += 4L; }  }  if (getValuesClause() != null) { sizeOfParameterSet += (getValuesClause().length() + 1); } else { sizeOfParameterSet += (this.originalSql.length() + 1); }  sizeOfEntireBatch += sizeOfParameterSet; if (sizeOfParameterSet > maxSizeOfParameterSet) maxSizeOfParameterSet = sizeOfParameterSet;  }  (new long[2])[0] = maxSizeOfParameterSet; (new long[2])[1] = sizeOfEntireBatch; return new long[2]; }  }
/* 2288 */   protected long[] executeBatchSerially(int batchTimeout) throws SQLException { synchronized (checkClosed().getConnectionMutex()) { MySQLConnection locallyScopedConn = this.connection; if (locallyScopedConn == null) checkClosed();  long[] updateCounts = null; if (this.batchedArgs != null) { int nbrCommands = this.batchedArgs.size(); updateCounts = new long[nbrCommands]; for (int i = 0; i < nbrCommands; i++) updateCounts[i] = -3L;  SQLException sqlEx = null; StatementImpl.CancelTask timeoutTask = null; try { if (locallyScopedConn.getEnableQueryTimeouts() && batchTimeout != 0 && locallyScopedConn.versionMeetsMinimum(5, 0, 0)) { timeoutTask = new StatementImpl.CancelTask(this, this); locallyScopedConn.getCancelTimer().schedule(timeoutTask, batchTimeout); }  if (this.retrieveGeneratedKeys) this.batchedGeneratedKeys = new ArrayList<ResultSetRow>(nbrCommands);  for (this.batchCommandIndex = 0; this.batchCommandIndex < nbrCommands; this.batchCommandIndex++) { Object arg = this.batchedArgs.get(this.batchCommandIndex); try { if (arg instanceof String) { updateCounts[this.batchCommandIndex] = executeUpdateInternal((String)arg, true, this.retrieveGeneratedKeys); getBatchedGeneratedKeys((this.results.getFirstCharOfQuery() == 'I' && containsOnDuplicateKeyInString((String)arg)) ? 1 : 0); } else { BatchParams paramArg = (BatchParams)arg; updateCounts[this.batchCommandIndex] = executeUpdateInternal(paramArg.parameterStrings, paramArg.parameterStreams, paramArg.isStream, paramArg.streamLengths, paramArg.isNull, true); getBatchedGeneratedKeys(containsOnDuplicateKeyUpdateInSQL() ? 1 : 0); }  } catch (SQLException ex) { updateCounts[this.batchCommandIndex] = -3L; if (this.continueBatchOnError && !(ex instanceof MySQLTimeoutException) && !(ex instanceof MySQLStatementCancelledException) && !hasDeadlockOrTimeoutRolledBackTx(ex)) { sqlEx = ex; } else { long[] newUpdateCounts = new long[this.batchCommandIndex]; System.arraycopy(updateCounts, 0, newUpdateCounts, 0, this.batchCommandIndex); throw SQLError.createBatchUpdateException(ex, newUpdateCounts, getExceptionInterceptor()); }  }  }  if (sqlEx != null) throw SQLError.createBatchUpdateException(sqlEx, updateCounts, getExceptionInterceptor());  } catch (NullPointerException npe) { try { checkClosed(); } catch (SQLException connectionClosedEx) { updateCounts[this.batchCommandIndex] = -3L; long[] newUpdateCounts = new long[this.batchCommandIndex]; System.arraycopy(updateCounts, 0, newUpdateCounts, 0, this.batchCommandIndex); throw SQLError.createBatchUpdateException(connectionClosedEx, newUpdateCounts, getExceptionInterceptor()); }  throw npe; } finally { this.batchCommandIndex = -1; if (timeoutTask != null) { timeoutTask.cancel(); locallyScopedConn.getCancelTimer().purge(); }  resetCancelledState(); }  }  return (updateCounts != null) ? updateCounts : new long[0]; }  } public String getDateTime(String pattern) { SimpleDateFormat sdf = TimeUtil.getSimpleDateFormat(null, pattern, null, null); return sdf.format(new Date()); } protected ResultSetInternalMethods executeInternal(int maxRowsToRetrieve, Buffer sendPacket, boolean createStreamingResultSet, boolean queryIsSelectOnly, Field[] metadataFromCache, boolean isBatch) throws SQLException { synchronized (checkClosed().getConnectionMutex()) { ResultSetInternalMethods rs; MySQLConnection locallyScopedConnection = this.connection; this.numberOfExecutions++; StatementImpl.CancelTask timeoutTask = null; try { if (locallyScopedConnection.getEnableQueryTimeouts() && this.timeoutInMillis != 0 && locallyScopedConnection.versionMeetsMinimum(5, 0, 0)) { timeoutTask = new StatementImpl.CancelTask(this, this); locallyScopedConnection.getCancelTimer().schedule(timeoutTask, this.timeoutInMillis); }  if (!isBatch) statementBegins();  rs = locallyScopedConnection.execSQL(this, (String)null, maxRowsToRetrieve, sendPacket, this.resultSetType, this.resultSetConcurrency, createStreamingResultSet, this.currentCatalog, metadataFromCache, isBatch); if (timeoutTask != null) { timeoutTask.cancel(); locallyScopedConnection.getCancelTimer().purge(); if (timeoutTask.caughtWhileCancelling != null) throw timeoutTask.caughtWhileCancelling;  timeoutTask = null; }  synchronized (this.cancelTimeoutMutex) { if (this.wasCancelled) { MySQLStatementCancelledException mySQLStatementCancelledException; SQLException cause = null; if (this.wasCancelledByTimeout) { MySQLTimeoutException mySQLTimeoutException = new MySQLTimeoutException(); } else { mySQLStatementCancelledException = new MySQLStatementCancelledException(); }  resetCancelledState(); throw mySQLStatementCancelledException; }  }  } finally { if (!isBatch) this.statementExecuting.set(false);  if (timeoutTask != null) { timeoutTask.cancel(); locallyScopedConnection.getCancelTimer().purge(); }  }  return rs; }  } public ResultSet executeQuery() throws SQLException { synchronized (checkClosed().getConnectionMutex()) { MySQLConnection locallyScopedConn = this.connection; checkForDml(this.originalSql, this.firstCharOfStmt); this.batchedGeneratedKeys = null; resetCancelledState(); implicitlyCloseAllOpenResults(); clearWarnings(); if (this.doPingInstead) { doPingInstead(); return this.results; }  setupStreamingTimeout(locallyScopedConn); Buffer sendPacket = fillSendPacket(); String oldCatalog = null; if (!locallyScopedConn.getCatalog().equals(this.currentCatalog)) { oldCatalog = locallyScopedConn.getCatalog(); locallyScopedConn.setCatalog(this.currentCatalog); }  CachedResultSetMetaData cachedMetadata = null; if (locallyScopedConn.getCacheResultSetMetadata()) cachedMetadata = locallyScopedConn.getCachedMetaData(this.originalSql);  Field[] metadataFromCache = null; if (cachedMetadata != null) metadataFromCache = cachedMetadata.fields;  locallyScopedConn.setSessionMaxRows(this.maxRows); this.results = executeInternal(this.maxRows, sendPacket, createStreamingResultSet(), true, metadataFromCache, false); if (oldCatalog != null) locallyScopedConn.setCatalog(oldCatalog);  if (cachedMetadata != null) { locallyScopedConn.initializeResultsMetadataFromCache(this.originalSql, cachedMetadata, this.results); } else if (locallyScopedConn.getCacheResultSetMetadata()) { locallyScopedConn.initializeResultsMetadataFromCache(this.originalSql, (CachedResultSetMetaData)null, this.results); }  this.lastInsertId = this.results.getUpdateID(); return this.results; }  } public int executeUpdate() throws SQLException { return Util.truncateAndConvertToInt(executeLargeUpdate()); } protected long executeUpdateInternal(boolean clearBatchedGeneratedKeysAndWarnings, boolean isBatch) throws SQLException { synchronized (checkClosed().getConnectionMutex()) { if (clearBatchedGeneratedKeysAndWarnings) { clearWarnings(); this.batchedGeneratedKeys = null; }  return executeUpdateInternal(this.parameterValues, this.parameterStreams, this.isStream, this.streamLengths, this.isNull, isBatch); }  } protected long executeUpdateInternal(byte[][] batchedParameterStrings, InputStream[] batchedParameterStreams, boolean[] batchedIsStream, int[] batchedStreamLengths, boolean[] batchedIsNull, boolean isReallyBatch) throws SQLException { synchronized (checkClosed().getConnectionMutex()) { MySQLConnection locallyScopedConn = this.connection; if (locallyScopedConn.isReadOnly(false)) throw SQLError.createSQLException(Messages.getString("PreparedStatement.34") + Messages.getString("PreparedStatement.35"), "S1009", getExceptionInterceptor());  if (this.firstCharOfStmt == 'S' && isSelectQuery()) throw SQLError.createSQLException(Messages.getString("PreparedStatement.37"), "01S03", getExceptionInterceptor());  resetCancelledState(); implicitlyCloseAllOpenResults(); ResultSetInternalMethods rs = null; Buffer sendPacket = fillSendPacket(batchedParameterStrings, batchedParameterStreams, batchedIsStream, batchedStreamLengths); String oldCatalog = null; if (!locallyScopedConn.getCatalog().equals(this.currentCatalog)) { oldCatalog = locallyScopedConn.getCatalog(); locallyScopedConn.setCatalog(this.currentCatalog); }  locallyScopedConn.setSessionMaxRows(-1); boolean oldInfoMsgState = false; if (this.retrieveGeneratedKeys) { oldInfoMsgState = locallyScopedConn.isReadInfoMsgEnabled(); locallyScopedConn.setReadInfoMsgEnabled(true); }  rs = executeInternal(-1, sendPacket, false, false, (Field[])null, isReallyBatch); if (this.retrieveGeneratedKeys) { locallyScopedConn.setReadInfoMsgEnabled(oldInfoMsgState); rs.setFirstCharOfQuery(this.firstCharOfStmt); }  if (oldCatalog != null) locallyScopedConn.setCatalog(oldCatalog);  this.results = rs; this.updateCount = rs.getUpdateCount(); if (containsOnDuplicateKeyUpdateInSQL() && this.compensateForOnDuplicateKeyUpdate && (this.updateCount == 2L || this.updateCount == 0L)) this.updateCount = 1L;  this.lastInsertId = rs.getUpdateID(); return this.updateCount; }  } protected boolean containsOnDuplicateKeyUpdateInSQL() { return this.parseInfo.isOnDuplicateKeyUpdate; } protected Buffer fillSendPacket() throws SQLException { synchronized (checkClosed().getConnectionMutex()) { return fillSendPacket(this.parameterValues, this.parameterStreams, this.isStream, this.streamLengths); }  } protected Buffer fillSendPacket(byte[][] batchedParameterStrings, InputStream[] batchedParameterStreams, boolean[] batchedIsStream, int[] batchedStreamLengths) throws SQLException { synchronized (checkClosed().getConnectionMutex()) { Buffer sendPacket = this.connection.getIO().getSharedSendPacket(); sendPacket.clear(); sendPacket.writeByte((byte)3); boolean useStreamLengths = this.connection.getUseStreamLengthsInPrepStmts(); int ensurePacketSize = 0; String statementComment = this.connection.getStatementComment(); byte[] commentAsBytes = null; if (statementComment != null) { if (this.charConverter != null) { commentAsBytes = this.charConverter.toBytes(statementComment); } else { commentAsBytes = StringUtils.getBytes(statementComment, this.charConverter, this.charEncoding, this.connection.getServerCharset(), this.connection.parserKnowsUnicode(), getExceptionInterceptor()); }  ensurePacketSize += commentAsBytes.length; ensurePacketSize += 6; }  int i; for (i = 0; i < batchedParameterStrings.length; i++) { if (batchedIsStream[i] && useStreamLengths) ensurePacketSize += batchedStreamLengths[i];  }  if (ensurePacketSize != 0) sendPacket.ensureCapacity(ensurePacketSize);  if (commentAsBytes != null) { sendPacket.writeBytesNoNull(Constants.SLASH_STAR_SPACE_AS_BYTES); sendPacket.writeBytesNoNull(commentAsBytes); sendPacket.writeBytesNoNull(Constants.SPACE_STAR_SLASH_SPACE_AS_BYTES); }  for (i = 0; i < batchedParameterStrings.length; i++) { checkAllParametersSet(batchedParameterStrings[i], batchedParameterStreams[i], i); sendPacket.writeBytesNoNull(this.staticSqlStrings[i]); if (batchedIsStream[i]) { streamToBytes(sendPacket, batchedParameterStreams[i], true, batchedStreamLengths[i], useStreamLengths); } else { sendPacket.writeBytesNoNull(batchedParameterStrings[i]); }  }  sendPacket.writeBytesNoNull(this.staticSqlStrings[batchedParameterStrings.length]); return sendPacket; }  } private void checkAllParametersSet(byte[] parameterString, InputStream parameterStream, int columnIndex) throws SQLException { if (parameterString == null && parameterStream == null) throw SQLError.createSQLException(Messages.getString("PreparedStatement.40") + (columnIndex + 1), "07001", getExceptionInterceptor());  } protected PreparedStatement prepareBatchedInsertSQL(MySQLConnection localConn, int numBatches) throws SQLException { synchronized (checkClosed().getConnectionMutex()) { PreparedStatement pstmt = new PreparedStatement(localConn, "Rewritten batch of: " + this.originalSql, this.currentCatalog, this.parseInfo.getParseInfoForBatch(numBatches)); pstmt.setRetrieveGeneratedKeys(this.retrieveGeneratedKeys); pstmt.rewrittenBatchSize = numBatches; return pstmt; }  } protected void setRetrieveGeneratedKeys(boolean flag) throws SQLException { synchronized (checkClosed().getConnectionMutex()) { this.retrieveGeneratedKeys = flag; }  } public String getNonRewrittenSql() throws SQLException { synchronized (checkClosed().getConnectionMutex()) {
/* 2289 */       int indexOfBatch = this.originalSql.indexOf(" of: ");
/*      */       
/* 2291 */       if (indexOfBatch != -1) {
/* 2292 */         return this.originalSql.substring(indexOfBatch + 5);
/*      */       }
/*      */       
/* 2295 */       return this.originalSql;
/*      */     }  }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytesRepresentation(int parameterIndex) throws SQLException {
/* 2305 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2306 */       if (this.isStream[parameterIndex]) {
/* 2307 */         return streamToBytes(this.parameterStreams[parameterIndex], false, this.streamLengths[parameterIndex], this.connection.getUseStreamLengthsInPrepStmts());
/*      */       }
/*      */ 
/*      */       
/* 2311 */       byte[] parameterVal = this.parameterValues[parameterIndex];
/*      */       
/* 2313 */       if (parameterVal == null) {
/* 2314 */         return null;
/*      */       }
/*      */       
/* 2317 */       if (parameterVal[0] == 39 && parameterVal[parameterVal.length - 1] == 39) {
/* 2318 */         byte[] valNoQuotes = new byte[parameterVal.length - 2];
/* 2319 */         System.arraycopy(parameterVal, 1, valNoQuotes, 0, parameterVal.length - 2);
/*      */         
/* 2321 */         return valNoQuotes;
/*      */       } 
/*      */       
/* 2324 */       return parameterVal;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected byte[] getBytesRepresentationForBatch(int parameterIndex, int commandIndex) throws SQLException {
/* 2336 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2337 */       Object batchedArg = this.batchedArgs.get(commandIndex);
/* 2338 */       if (batchedArg instanceof String) {
/*      */         try {
/* 2340 */           return StringUtils.getBytes((String)batchedArg, this.charEncoding);
/*      */         }
/* 2342 */         catch (UnsupportedEncodingException uue) {
/* 2343 */           throw new RuntimeException(Messages.getString("PreparedStatement.32") + this.charEncoding + Messages.getString("PreparedStatement.33"));
/*      */         } 
/*      */       }
/*      */       
/* 2347 */       BatchParams params = (BatchParams)batchedArg;
/* 2348 */       if (params.isStream[parameterIndex]) {
/* 2349 */         return streamToBytes(params.parameterStreams[parameterIndex], false, params.streamLengths[parameterIndex], this.connection.getUseStreamLengthsInPrepStmts());
/*      */       }
/*      */       
/* 2352 */       byte[] parameterVal = params.parameterStrings[parameterIndex];
/* 2353 */       if (parameterVal == null) {
/* 2354 */         return null;
/*      */       }
/*      */       
/* 2357 */       if (parameterVal[0] == 39 && parameterVal[parameterVal.length - 1] == 39) {
/* 2358 */         byte[] valNoQuotes = new byte[parameterVal.length - 2];
/* 2359 */         System.arraycopy(parameterVal, 1, valNoQuotes, 0, parameterVal.length - 2);
/*      */         
/* 2361 */         return valNoQuotes;
/*      */       } 
/*      */       
/* 2364 */       return parameterVal;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String getDateTimePattern(String dt, boolean toTime) throws Exception {
/* 2374 */     int dtLength = (dt != null) ? dt.length() : 0;
/*      */     
/* 2376 */     if (dtLength >= 8 && dtLength <= 10) {
/* 2377 */       int dashCount = 0;
/* 2378 */       boolean isDateOnly = true;
/*      */       
/* 2380 */       for (int k = 0; k < dtLength; k++) {
/* 2381 */         char c = dt.charAt(k);
/*      */         
/* 2383 */         if (!Character.isDigit(c) && c != '-') {
/* 2384 */           isDateOnly = false;
/*      */           
/*      */           break;
/*      */         } 
/*      */         
/* 2389 */         if (c == '-') {
/* 2390 */           dashCount++;
/*      */         }
/*      */       } 
/*      */       
/* 2394 */       if (isDateOnly && dashCount == 2) {
/* 2395 */         return "yyyy-MM-dd";
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2402 */     boolean colonsOnly = true;
/*      */     
/* 2404 */     for (int i = 0; i < dtLength; i++) {
/* 2405 */       char c = dt.charAt(i);
/*      */       
/* 2407 */       if (!Character.isDigit(c) && c != ':') {
/* 2408 */         colonsOnly = false;
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/*      */     
/* 2414 */     if (colonsOnly) {
/* 2415 */       return "HH:mm:ss";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2424 */     StringReader reader = new StringReader(dt + " ");
/* 2425 */     ArrayList<Object[]> vec = new ArrayList();
/* 2426 */     ArrayList<Object[]> vecRemovelist = new ArrayList();
/* 2427 */     Object[] nv = new Object[3];
/*      */     
/* 2429 */     nv[0] = Character.valueOf('y');
/* 2430 */     nv[1] = new StringBuilder();
/* 2431 */     nv[2] = Integer.valueOf(0);
/* 2432 */     vec.add(nv);
/*      */     
/* 2434 */     if (toTime) {
/* 2435 */       nv = new Object[3];
/* 2436 */       nv[0] = Character.valueOf('h');
/* 2437 */       nv[1] = new StringBuilder();
/* 2438 */       nv[2] = Integer.valueOf(0);
/* 2439 */       vec.add(nv);
/*      */     } 
/*      */     int z;
/* 2442 */     while ((z = reader.read()) != -1) {
/* 2443 */       char separator = (char)z;
/* 2444 */       int maxvecs = vec.size();
/*      */       
/* 2446 */       for (int count = 0; count < maxvecs; count++) {
/* 2447 */         Object[] arrayOfObject = vec.get(count);
/* 2448 */         int n = ((Integer)arrayOfObject[2]).intValue();
/* 2449 */         char c = getSuccessor(((Character)arrayOfObject[0]).charValue(), n);
/*      */         
/* 2451 */         if (!Character.isLetterOrDigit(separator)) {
/* 2452 */           if (c == ((Character)arrayOfObject[0]).charValue() && c != 'S') {
/* 2453 */             vecRemovelist.add(arrayOfObject);
/*      */           } else {
/* 2455 */             ((StringBuilder)arrayOfObject[1]).append(separator);
/*      */             
/* 2457 */             if (c == 'X' || c == 'Y') {
/* 2458 */               arrayOfObject[2] = Integer.valueOf(4);
/*      */             }
/*      */           } 
/*      */         } else {
/* 2462 */           if (c == 'X') {
/* 2463 */             c = 'y';
/* 2464 */             nv = new Object[3];
/* 2465 */             nv[1] = (new StringBuilder(((StringBuilder)arrayOfObject[1]).toString())).append('M');
/* 2466 */             nv[0] = Character.valueOf('M');
/* 2467 */             nv[2] = Integer.valueOf(1);
/* 2468 */             vec.add(nv);
/* 2469 */           } else if (c == 'Y') {
/* 2470 */             c = 'M';
/* 2471 */             nv = new Object[3];
/* 2472 */             nv[1] = (new StringBuilder(((StringBuilder)arrayOfObject[1]).toString())).append('d');
/* 2473 */             nv[0] = Character.valueOf('d');
/* 2474 */             nv[2] = Integer.valueOf(1);
/* 2475 */             vec.add(nv);
/*      */           } 
/*      */           
/* 2478 */           ((StringBuilder)arrayOfObject[1]).append(c);
/*      */           
/* 2480 */           if (c == ((Character)arrayOfObject[0]).charValue()) {
/* 2481 */             arrayOfObject[2] = Integer.valueOf(n + 1);
/*      */           } else {
/* 2483 */             arrayOfObject[0] = Character.valueOf(c);
/* 2484 */             arrayOfObject[2] = Integer.valueOf(1);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 2489 */       int k = vecRemovelist.size();
/*      */       
/* 2491 */       for (int m = 0; m < k; m++) {
/* 2492 */         Object[] arrayOfObject = vecRemovelist.get(m);
/* 2493 */         vec.remove(arrayOfObject);
/*      */       } 
/*      */       
/* 2496 */       vecRemovelist.clear();
/*      */     } 
/*      */     
/* 2499 */     int size = vec.size();
/*      */     int j;
/* 2501 */     for (j = 0; j < size; j++) {
/* 2502 */       Object[] arrayOfObject = vec.get(j);
/* 2503 */       char c = ((Character)arrayOfObject[0]).charValue();
/* 2504 */       int n = ((Integer)arrayOfObject[2]).intValue();
/*      */       
/* 2506 */       boolean bk = (getSuccessor(c, n) != c);
/* 2507 */       boolean atEnd = ((c == 's' || c == 'm' || (c == 'h' && toTime)) && bk);
/* 2508 */       boolean finishesAtDate = (bk && c == 'd' && !toTime);
/* 2509 */       boolean containsEnd = (((StringBuilder)arrayOfObject[1]).toString().indexOf('W') != -1);
/*      */       
/* 2511 */       if ((!atEnd && !finishesAtDate) || containsEnd) {
/* 2512 */         vecRemovelist.add(arrayOfObject);
/*      */       }
/*      */     } 
/*      */     
/* 2516 */     size = vecRemovelist.size();
/*      */     
/* 2518 */     for (j = 0; j < size; j++) {
/* 2519 */       vec.remove(vecRemovelist.get(j));
/*      */     }
/*      */     
/* 2522 */     vecRemovelist.clear();
/* 2523 */     Object[] v = vec.get(0);
/*      */     
/* 2525 */     StringBuilder format = (StringBuilder)v[1];
/* 2526 */     format.setLength(format.length() - 1);
/*      */     
/* 2528 */     return format.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSetMetaData getMetaData() throws SQLException {
/* 2542 */     synchronized (checkClosed().getConnectionMutex()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2550 */       if (!isSelectQuery()) {
/* 2551 */         return null;
/*      */       }
/*      */       
/* 2554 */       PreparedStatement mdStmt = null;
/* 2555 */       ResultSet mdRs = null;
/*      */       
/* 2557 */       if (this.pstmtResultMetaData == null) {
/*      */         try {
/* 2559 */           mdStmt = new PreparedStatement(this.connection, this.originalSql, this.currentCatalog, this.parseInfo);
/*      */           
/* 2561 */           mdStmt.setMaxRows(1);
/*      */           
/* 2563 */           int paramCount = this.parameterValues.length;
/*      */           
/* 2565 */           for (int i = 1; i <= paramCount; i++) {
/* 2566 */             mdStmt.setString(i, "");
/*      */           }
/*      */           
/* 2569 */           boolean hadResults = mdStmt.execute();
/*      */           
/* 2571 */           if (hadResults) {
/* 2572 */             mdRs = mdStmt.getResultSet();
/*      */             
/* 2574 */             this.pstmtResultMetaData = mdRs.getMetaData();
/*      */           } else {
/* 2576 */             this.pstmtResultMetaData = new ResultSetMetaData(new Field[0], this.connection.getUseOldAliasMetadataBehavior(), this.connection.getYearIsDateType(), getExceptionInterceptor());
/*      */           } 
/*      */         } finally {
/*      */           
/* 2580 */           SQLException sqlExRethrow = null;
/*      */           
/* 2582 */           if (mdRs != null) {
/*      */             try {
/* 2584 */               mdRs.close();
/* 2585 */             } catch (SQLException sqlEx) {
/* 2586 */               sqlExRethrow = sqlEx;
/*      */             } 
/*      */             
/* 2589 */             mdRs = null;
/*      */           } 
/*      */           
/* 2592 */           if (mdStmt != null) {
/*      */             try {
/* 2594 */               mdStmt.close();
/* 2595 */             } catch (SQLException sqlEx) {
/* 2596 */               sqlExRethrow = sqlEx;
/*      */             } 
/*      */             
/* 2599 */             mdStmt = null;
/*      */           } 
/*      */           
/* 2602 */           if (sqlExRethrow != null) {
/* 2603 */             throw sqlExRethrow;
/*      */           }
/*      */         } 
/*      */       }
/*      */       
/* 2608 */       return this.pstmtResultMetaData;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected boolean isSelectQuery() throws SQLException {
/* 2613 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2614 */       return StringUtils.startsWithIgnoreCaseAndWs(StringUtils.stripComments(this.originalSql, "'\"", "'\"", true, false, true, true), "SELECT");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ParameterMetaData getParameterMetaData() throws SQLException {
/* 2622 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2623 */       if (this.parameterMetaData == null) {
/* 2624 */         if (this.connection.getGenerateSimpleParameterMetadata()) {
/* 2625 */           this.parameterMetaData = new MysqlParameterMetadata(this.parameterCount);
/*      */         } else {
/* 2627 */           this.parameterMetaData = new MysqlParameterMetadata(null, this.parameterCount, getExceptionInterceptor());
/*      */         } 
/*      */       }
/*      */       
/* 2631 */       return this.parameterMetaData;
/*      */     } 
/*      */   }
/*      */   
/*      */   ParseInfo getParseInfo() {
/* 2636 */     return this.parseInfo;
/*      */   }
/*      */   
/*      */   private final char getSuccessor(char c, int n) {
/* 2640 */     return (c == 'y' && n == 2) ? 'X' : ((c == 'y' && n < 4) ? 'y' : ((c == 'y') ? 'M' : ((c == 'M' && n == 2) ? 'Y' : ((c == 'M' && n < 3) ? 'M' : ((c == 'M') ? 'd' : ((c == 'd' && n < 2) ? 'd' : ((c == 'd') ? 'H' : ((c == 'H' && n < 2) ? 'H' : ((c == 'H') ? 'm' : ((c == 'm' && n < 2) ? 'm' : ((c == 'm') ? 's' : ((c == 's' && n < 2) ? 's' : 'W'))))))))))));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void hexEscapeBlock(byte[] buf, Buffer packet, int size) throws SQLException {
/* 2656 */     for (int i = 0; i < size; i++) {
/* 2657 */       byte b = buf[i];
/* 2658 */       int lowBits = (b & 0xFF) / 16;
/* 2659 */       int highBits = (b & 0xFF) % 16;
/*      */       
/* 2661 */       packet.writeByte(HEX_DIGITS[lowBits]);
/* 2662 */       packet.writeByte(HEX_DIGITS[highBits]);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void initializeFromParseInfo() throws SQLException {
/* 2667 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2668 */       this.staticSqlStrings = this.parseInfo.staticSql;
/* 2669 */       this.isLoadDataQuery = this.parseInfo.foundLoadData;
/* 2670 */       this.firstCharOfStmt = this.parseInfo.firstStmtChar;
/*      */       
/* 2672 */       this.parameterCount = this.staticSqlStrings.length - 1;
/*      */       
/* 2674 */       this.parameterValues = new byte[this.parameterCount][];
/* 2675 */       this.parameterStreams = new InputStream[this.parameterCount];
/* 2676 */       this.isStream = new boolean[this.parameterCount];
/* 2677 */       this.streamLengths = new int[this.parameterCount];
/* 2678 */       this.isNull = new boolean[this.parameterCount];
/* 2679 */       this.parameterTypes = new int[this.parameterCount];
/*      */       
/* 2681 */       clearParameters();
/*      */       
/* 2683 */       for (int j = 0; j < this.parameterCount; j++) {
/* 2684 */         this.isStream[j] = false;
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   boolean isNull(int paramIndex) throws SQLException {
/* 2690 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2691 */       return this.isNull[paramIndex];
/*      */     } 
/*      */   }
/*      */   
/*      */   private final int readblock(InputStream i, byte[] b) throws SQLException {
/*      */     try {
/* 2697 */       return i.read(b);
/* 2698 */     } catch (Throwable ex) {
/* 2699 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString("PreparedStatement.56") + ex.getClass().getName(), "S1000", getExceptionInterceptor());
/*      */       
/* 2701 */       sqlEx.initCause(ex);
/*      */       
/* 2703 */       throw sqlEx;
/*      */     } 
/*      */   }
/*      */   
/*      */   private final int readblock(InputStream i, byte[] b, int length) throws SQLException {
/*      */     try {
/* 2709 */       int lengthToRead = length;
/*      */       
/* 2711 */       if (lengthToRead > b.length) {
/* 2712 */         lengthToRead = b.length;
/*      */       }
/*      */       
/* 2715 */       return i.read(b, 0, lengthToRead);
/* 2716 */     } catch (Throwable ex) {
/* 2717 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString("PreparedStatement.56") + ex.getClass().getName(), "S1000", getExceptionInterceptor());
/*      */       
/* 2719 */       sqlEx.initCause(ex);
/*      */       
/* 2721 */       throw sqlEx;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void realClose(boolean calledExplicitly, boolean closeOpenResults) throws SQLException {
/* 2736 */     MySQLConnection locallyScopedConn = this.connection;
/*      */     
/* 2738 */     if (locallyScopedConn == null) {
/*      */       return;
/*      */     }
/*      */     
/* 2742 */     synchronized (locallyScopedConn.getConnectionMutex()) {
/*      */ 
/*      */ 
/*      */       
/* 2746 */       if (this.isClosed) {
/*      */         return;
/*      */       }
/*      */       
/* 2750 */       if (this.useUsageAdvisor && 
/* 2751 */         this.numberOfExecutions <= 1) {
/* 2752 */         String message = Messages.getString("PreparedStatement.43");
/*      */         
/* 2754 */         this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", this.currentCatalog, this.connectionId, getId(), -1, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, message));
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2759 */       super.realClose(calledExplicitly, closeOpenResults);
/*      */       
/* 2761 */       this.dbmd = null;
/* 2762 */       this.originalSql = null;
/* 2763 */       this.staticSqlStrings = (byte[][])null;
/* 2764 */       this.parameterValues = (byte[][])null;
/* 2765 */       this.parameterStreams = null;
/* 2766 */       this.isStream = null;
/* 2767 */       this.streamLengths = null;
/* 2768 */       this.isNull = null;
/* 2769 */       this.streamConvertBuf = null;
/* 2770 */       this.parameterTypes = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setArray(int i, Array x) throws SQLException {
/* 2787 */     throw SQLError.createSQLFeatureNotSupportedException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStream(int parameterIndex, InputStream x, int length) throws SQLException {
/* 2812 */     if (x == null) {
/* 2813 */       setNull(parameterIndex, 12);
/*      */     } else {
/* 2815 */       setBinaryStream(parameterIndex, x, length);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBigDecimal(int parameterIndex, BigDecimal x) throws SQLException {
/* 2832 */     if (x == null) {
/* 2833 */       setNull(parameterIndex, 3);
/*      */     } else {
/* 2835 */       setInternal(parameterIndex, StringUtils.fixDecimalExponent(StringUtils.consistentToString(x)));
/*      */       
/* 2837 */       this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 3;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStream(int parameterIndex, InputStream x, int length) throws SQLException {
/* 2861 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2862 */       if (x == null) {
/* 2863 */         setNull(parameterIndex, -2);
/*      */       } else {
/* 2865 */         int parameterIndexOffset = getParameterIndexOffset();
/*      */         
/* 2867 */         if (parameterIndex < 1 || parameterIndex > this.staticSqlStrings.length) {
/* 2868 */           throw SQLError.createSQLException(Messages.getString("PreparedStatement.2") + parameterIndex + Messages.getString("PreparedStatement.3") + this.staticSqlStrings.length + Messages.getString("PreparedStatement.4"), "S1009", getExceptionInterceptor());
/*      */         }
/*      */ 
/*      */         
/* 2872 */         if (parameterIndexOffset == -1 && parameterIndex == 1) {
/* 2873 */           throw SQLError.createSQLException("Can't set IN parameter for return value of stored function call.", "S1009", getExceptionInterceptor());
/*      */         }
/*      */ 
/*      */         
/* 2877 */         this.parameterStreams[parameterIndex - 1 + parameterIndexOffset] = x;
/* 2878 */         this.isStream[parameterIndex - 1 + parameterIndexOffset] = true;
/* 2879 */         this.streamLengths[parameterIndex - 1 + parameterIndexOffset] = length;
/* 2880 */         this.isNull[parameterIndex - 1 + parameterIndexOffset] = false;
/* 2881 */         this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 2004;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setBlob(int parameterIndex, InputStream inputStream, long length) throws SQLException {
/* 2887 */     setBinaryStream(parameterIndex, inputStream, (int)length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlob(int i, Blob x) throws SQLException {
/* 2902 */     if (x == null) {
/* 2903 */       setNull(i, 2004);
/*      */     } else {
/* 2905 */       ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
/*      */       
/* 2907 */       bytesOut.write(39);
/* 2908 */       escapeblockFast(x.getBytes(1L, (int)x.length()), bytesOut, (int)x.length());
/* 2909 */       bytesOut.write(39);
/*      */       
/* 2911 */       setInternal(i, bytesOut.toByteArray());
/*      */       
/* 2913 */       this.parameterTypes[i - 1 + getParameterIndexOffset()] = 2004;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBoolean(int parameterIndex, boolean x) throws SQLException {
/* 2930 */     if (this.useTrueBoolean) {
/* 2931 */       setInternal(parameterIndex, x ? "1" : "0");
/*      */     } else {
/* 2933 */       setInternal(parameterIndex, x ? "'t'" : "'f'");
/*      */       
/* 2935 */       this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 16;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setByte(int parameterIndex, byte x) throws SQLException {
/* 2952 */     setInternal(parameterIndex, String.valueOf(x));
/*      */     
/* 2954 */     this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = -6;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytes(int parameterIndex, byte[] x) throws SQLException {
/* 2971 */     setBytes(parameterIndex, x, true, true);
/*      */     
/* 2973 */     if (x != null) {
/* 2974 */       this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = -2;
/*      */     }
/*      */   }
/*      */   
/*      */   protected void setBytes(int parameterIndex, byte[] x, boolean checkForIntroducer, boolean escapeForMBChars) throws SQLException {
/* 2979 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2980 */       if (x == null) {
/* 2981 */         setNull(parameterIndex, -2);
/*      */       } else {
/* 2983 */         String connectionEncoding = this.connection.getEncoding();
/*      */         
/*      */         try {
/* 2986 */           if (this.connection.isNoBackslashEscapesSet() || (escapeForMBChars && this.connection.getUseUnicode() && connectionEncoding != null && CharsetMapping.isMultibyteCharset(connectionEncoding))) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2991 */             ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(x.length * 2 + 3);
/* 2992 */             byteArrayOutputStream.write(120);
/* 2993 */             byteArrayOutputStream.write(39);
/*      */             
/* 2995 */             for (int j = 0; j < x.length; j++) {
/* 2996 */               int lowBits = (x[j] & 0xFF) / 16;
/* 2997 */               int highBits = (x[j] & 0xFF) % 16;
/*      */               
/* 2999 */               byteArrayOutputStream.write(HEX_DIGITS[lowBits]);
/* 3000 */               byteArrayOutputStream.write(HEX_DIGITS[highBits]);
/*      */             } 
/*      */             
/* 3003 */             byteArrayOutputStream.write(39);
/*      */             
/* 3005 */             setInternal(parameterIndex, byteArrayOutputStream.toByteArray());
/*      */             
/*      */             return;
/*      */           } 
/* 3009 */         } catch (SQLException ex) {
/* 3010 */           throw ex;
/* 3011 */         } catch (RuntimeException ex) {
/* 3012 */           SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", (ExceptionInterceptor)null);
/* 3013 */           sqlEx.initCause(ex);
/* 3014 */           throw sqlEx;
/*      */         } 
/*      */ 
/*      */         
/* 3018 */         int numBytes = x.length;
/*      */         
/* 3020 */         int pad = 2;
/*      */         
/* 3022 */         boolean needsIntroducer = (checkForIntroducer && this.connection.versionMeetsMinimum(4, 1, 0));
/*      */         
/* 3024 */         if (needsIntroducer) {
/* 3025 */           pad += 7;
/*      */         }
/*      */         
/* 3028 */         ByteArrayOutputStream bOut = new ByteArrayOutputStream(numBytes + pad);
/*      */         
/* 3030 */         if (needsIntroducer) {
/* 3031 */           bOut.write(95);
/* 3032 */           bOut.write(98);
/* 3033 */           bOut.write(105);
/* 3034 */           bOut.write(110);
/* 3035 */           bOut.write(97);
/* 3036 */           bOut.write(114);
/* 3037 */           bOut.write(121);
/*      */         } 
/* 3039 */         bOut.write(39);
/*      */         
/* 3041 */         for (int i = 0; i < numBytes; i++) {
/* 3042 */           byte b = x[i];
/*      */           
/* 3044 */           switch (b) {
/*      */             case 0:
/* 3046 */               bOut.write(92);
/* 3047 */               bOut.write(48);
/*      */               break;
/*      */ 
/*      */             
/*      */             case 10:
/* 3052 */               bOut.write(92);
/* 3053 */               bOut.write(110);
/*      */               break;
/*      */ 
/*      */             
/*      */             case 13:
/* 3058 */               bOut.write(92);
/* 3059 */               bOut.write(114);
/*      */               break;
/*      */ 
/*      */             
/*      */             case 92:
/* 3064 */               bOut.write(92);
/* 3065 */               bOut.write(92);
/*      */               break;
/*      */ 
/*      */             
/*      */             case 39:
/* 3070 */               bOut.write(92);
/* 3071 */               bOut.write(39);
/*      */               break;
/*      */ 
/*      */             
/*      */             case 34:
/* 3076 */               bOut.write(92);
/* 3077 */               bOut.write(34);
/*      */               break;
/*      */ 
/*      */             
/*      */             case 26:
/* 3082 */               bOut.write(92);
/* 3083 */               bOut.write(90);
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 3088 */               bOut.write(b);
/*      */               break;
/*      */           } 
/*      */         } 
/* 3092 */         bOut.write(39);
/*      */         
/* 3094 */         setInternal(parameterIndex, bOut.toByteArray());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setBytesNoEscape(int parameterIndex, byte[] parameterAsBytes) throws SQLException {
/* 3112 */     byte[] parameterWithQuotes = new byte[parameterAsBytes.length + 2];
/* 3113 */     parameterWithQuotes[0] = 39;
/* 3114 */     System.arraycopy(parameterAsBytes, 0, parameterWithQuotes, 1, parameterAsBytes.length);
/* 3115 */     parameterWithQuotes[parameterAsBytes.length + 1] = 39;
/*      */     
/* 3117 */     setInternal(parameterIndex, parameterWithQuotes);
/*      */   }
/*      */   
/*      */   protected void setBytesNoEscapeNoQuotes(int parameterIndex, byte[] parameterAsBytes) throws SQLException {
/* 3121 */     setInternal(parameterIndex, parameterAsBytes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStream(int parameterIndex, Reader reader, int length) throws SQLException {
/* 3146 */     synchronized (checkClosed().getConnectionMutex()) {
/*      */       try {
/* 3148 */         if (reader == null) {
/* 3149 */           setNull(parameterIndex, -1);
/*      */         } else {
/* 3151 */           char[] c = null;
/* 3152 */           int len = 0;
/*      */           
/* 3154 */           boolean useLength = this.connection.getUseStreamLengthsInPrepStmts();
/*      */           
/* 3156 */           String forcedEncoding = this.connection.getClobCharacterEncoding();
/*      */           
/* 3158 */           if (useLength && length != -1) {
/* 3159 */             c = new char[length];
/*      */             
/* 3161 */             int numCharsRead = readFully(reader, c, length);
/*      */             
/* 3163 */             if (forcedEncoding == null) {
/* 3164 */               setString(parameterIndex, new String(c, 0, numCharsRead));
/*      */             } else {
/*      */               try {
/* 3167 */                 setBytes(parameterIndex, StringUtils.getBytes(new String(c, 0, numCharsRead), forcedEncoding));
/* 3168 */               } catch (UnsupportedEncodingException uee) {
/* 3169 */                 throw SQLError.createSQLException("Unsupported character encoding " + forcedEncoding, "S1009", getExceptionInterceptor());
/*      */               } 
/*      */             } 
/*      */           } else {
/*      */             
/* 3174 */             c = new char[4096];
/*      */             
/* 3176 */             StringBuilder buf = new StringBuilder();
/*      */             
/* 3178 */             while ((len = reader.read(c)) != -1) {
/* 3179 */               buf.append(c, 0, len);
/*      */             }
/*      */             
/* 3182 */             if (forcedEncoding == null) {
/* 3183 */               setString(parameterIndex, buf.toString());
/*      */             } else {
/*      */               try {
/* 3186 */                 setBytes(parameterIndex, StringUtils.getBytes(buf.toString(), forcedEncoding));
/* 3187 */               } catch (UnsupportedEncodingException uee) {
/* 3188 */                 throw SQLError.createSQLException("Unsupported character encoding " + forcedEncoding, "S1009", getExceptionInterceptor());
/*      */               } 
/*      */             } 
/*      */           } 
/*      */ 
/*      */           
/* 3194 */           this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 2005;
/*      */         } 
/* 3196 */       } catch (IOException ioEx) {
/* 3197 */         throw SQLError.createSQLException(ioEx.toString(), "S1000", getExceptionInterceptor());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClob(int i, Clob x) throws SQLException {
/* 3214 */     synchronized (checkClosed().getConnectionMutex()) {
/* 3215 */       if (x == null) {
/* 3216 */         setNull(i, 2005);
/*      */       } else {
/*      */         
/* 3219 */         String forcedEncoding = this.connection.getClobCharacterEncoding();
/*      */         
/* 3221 */         if (forcedEncoding == null) {
/* 3222 */           setString(i, x.getSubString(1L, (int)x.length()));
/*      */         } else {
/*      */           try {
/* 3225 */             setBytes(i, StringUtils.getBytes(x.getSubString(1L, (int)x.length()), forcedEncoding));
/* 3226 */           } catch (UnsupportedEncodingException uee) {
/* 3227 */             throw SQLError.createSQLException("Unsupported character encoding " + forcedEncoding, "S1009", getExceptionInterceptor());
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/* 3232 */         this.parameterTypes[i - 1 + getParameterIndexOffset()] = 2005;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(int parameterIndex, Date x) throws SQLException {
/* 3250 */     setDate(parameterIndex, x, (Calendar)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(int parameterIndex, Date x, Calendar cal) throws SQLException {
/* 3268 */     if (x == null) {
/* 3269 */       setNull(parameterIndex, 91);
/*      */     }
/* 3271 */     else if (!this.useLegacyDatetimeCode) {
/* 3272 */       newSetDateInternal(parameterIndex, x, cal);
/*      */     } else {
/* 3274 */       synchronized (checkClosed().getConnectionMutex()) {
/* 3275 */         this.ddf = TimeUtil.getSimpleDateFormat(this.ddf, "''yyyy-MM-dd''", cal, null);
/*      */         
/* 3277 */         setInternal(parameterIndex, this.ddf.format(x));
/*      */         
/* 3279 */         this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 91;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDouble(int parameterIndex, double x) throws SQLException {
/* 3298 */     synchronized (checkClosed().getConnectionMutex()) {
/* 3299 */       if (!this.connection.getAllowNanAndInf() && (x == Double.POSITIVE_INFINITY || x == Double.NEGATIVE_INFINITY || Double.isNaN(x))) {
/* 3300 */         throw SQLError.createSQLException("'" + x + "' is not a valid numeric or approximate numeric value", "S1009", getExceptionInterceptor());
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 3305 */       setInternal(parameterIndex, StringUtils.fixDecimalExponent(String.valueOf(x)));
/*      */       
/* 3307 */       this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 8;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFloat(int parameterIndex, float x) throws SQLException {
/* 3324 */     setInternal(parameterIndex, StringUtils.fixDecimalExponent(String.valueOf(x)));
/*      */     
/* 3326 */     this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 6;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInt(int parameterIndex, int x) throws SQLException {
/* 3342 */     setInternal(parameterIndex, String.valueOf(x));
/*      */     
/* 3344 */     this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 4;
/*      */   }
/*      */   
/*      */   protected final void setInternal(int paramIndex, byte[] val) throws SQLException {
/* 3348 */     synchronized (checkClosed().getConnectionMutex()) {
/*      */       
/* 3350 */       int parameterIndexOffset = getParameterIndexOffset();
/*      */       
/* 3352 */       checkBounds(paramIndex, parameterIndexOffset);
/*      */       
/* 3354 */       this.isStream[paramIndex - 1 + parameterIndexOffset] = false;
/* 3355 */       this.isNull[paramIndex - 1 + parameterIndexOffset] = false;
/* 3356 */       this.parameterStreams[paramIndex - 1 + parameterIndexOffset] = null;
/* 3357 */       this.parameterValues[paramIndex - 1 + parameterIndexOffset] = val;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void checkBounds(int paramIndex, int parameterIndexOffset) throws SQLException {
/* 3362 */     synchronized (checkClosed().getConnectionMutex()) {
/* 3363 */       if (paramIndex < 1) {
/* 3364 */         throw SQLError.createSQLException(Messages.getString("PreparedStatement.49") + paramIndex + Messages.getString("PreparedStatement.50"), "S1009", getExceptionInterceptor());
/*      */       }
/* 3366 */       if (paramIndex > this.parameterCount) {
/* 3367 */         throw SQLError.createSQLException(Messages.getString("PreparedStatement.51") + paramIndex + Messages.getString("PreparedStatement.52") + this.parameterValues.length + Messages.getString("PreparedStatement.53"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 3372 */       if (parameterIndexOffset == -1 && paramIndex == 1) {
/* 3373 */         throw SQLError.createSQLException("Can't set IN parameter for return value of stored function call.", "S1009", getExceptionInterceptor());
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void setInternal(int paramIndex, String val) throws SQLException {
/* 3380 */     synchronized (checkClosed().getConnectionMutex()) {
/*      */       
/* 3382 */       byte[] parameterAsBytes = null;
/*      */       
/* 3384 */       if (this.charConverter != null) {
/* 3385 */         parameterAsBytes = this.charConverter.toBytes(val);
/*      */       } else {
/* 3387 */         parameterAsBytes = StringUtils.getBytes(val, this.charConverter, this.charEncoding, this.connection.getServerCharset(), this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */       } 
/*      */ 
/*      */       
/* 3391 */       setInternal(paramIndex, parameterAsBytes);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLong(int parameterIndex, long x) throws SQLException {
/* 3408 */     setInternal(parameterIndex, String.valueOf(x));
/*      */     
/* 3410 */     this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = -5;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNull(int parameterIndex, int sqlType) throws SQLException {
/* 3429 */     synchronized (checkClosed().getConnectionMutex()) {
/* 3430 */       setInternal(parameterIndex, "null");
/* 3431 */       this.isNull[parameterIndex - 1 + getParameterIndexOffset()] = true;
/*      */       
/* 3433 */       this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNull(int parameterIndex, int sqlType, String arg) throws SQLException {
/* 3455 */     setNull(parameterIndex, sqlType);
/*      */     
/* 3457 */     this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 0;
/*      */   }
/*      */ 
/*      */   
/*      */   private void setNumericObject(int parameterIndex, Object parameterObj, int targetSqlType, int scale) throws SQLException {
/*      */     Number parameterAsNum;
/* 3463 */     if (parameterObj instanceof Boolean) {
/* 3464 */       parameterAsNum = ((Boolean)parameterObj).booleanValue() ? Integer.valueOf(1) : Integer.valueOf(0);
/* 3465 */     } else if (parameterObj instanceof String) {
/* 3466 */       boolean parameterAsBoolean; switch (targetSqlType) {
/*      */         case -7:
/* 3468 */           if ("1".equals(parameterObj) || "0".equals(parameterObj)) {
/* 3469 */             Number number = Integer.valueOf((String)parameterObj); break;
/*      */           } 
/* 3471 */           parameterAsBoolean = "true".equalsIgnoreCase((String)parameterObj);
/*      */           
/* 3473 */           parameterAsNum = parameterAsBoolean ? Integer.valueOf(1) : Integer.valueOf(0);
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case -6:
/*      */         case 4:
/*      */         case 5:
/* 3481 */           parameterAsNum = Integer.valueOf((String)parameterObj);
/*      */           break;
/*      */ 
/*      */         
/*      */         case -5:
/* 3486 */           parameterAsNum = Long.valueOf((String)parameterObj);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 7:
/* 3491 */           parameterAsNum = Float.valueOf((String)parameterObj);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 6:
/*      */         case 8:
/* 3497 */           parameterAsNum = Double.valueOf((String)parameterObj);
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         default:
/* 3504 */           parameterAsNum = new BigDecimal((String)parameterObj); break;
/*      */       } 
/*      */     } else {
/* 3507 */       parameterAsNum = (Number)parameterObj;
/*      */     } 
/*      */     
/* 3510 */     switch (targetSqlType) {
/*      */       case -7:
/*      */       case -6:
/*      */       case 4:
/*      */       case 5:
/* 3515 */         setInt(parameterIndex, parameterAsNum.intValue());
/*      */         break;
/*      */ 
/*      */       
/*      */       case -5:
/* 3520 */         setLong(parameterIndex, parameterAsNum.longValue());
/*      */         break;
/*      */ 
/*      */       
/*      */       case 7:
/* 3525 */         setFloat(parameterIndex, parameterAsNum.floatValue());
/*      */         break;
/*      */ 
/*      */       
/*      */       case 6:
/*      */       case 8:
/* 3531 */         setDouble(parameterIndex, parameterAsNum.doubleValue());
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/*      */       case 3:
/* 3538 */         if (parameterAsNum instanceof BigDecimal) {
/* 3539 */           BigDecimal scaledBigDecimal = null;
/*      */           
/*      */           try {
/* 3542 */             scaledBigDecimal = ((BigDecimal)parameterAsNum).setScale(scale);
/* 3543 */           } catch (ArithmeticException ex) {
/*      */             try {
/* 3545 */               scaledBigDecimal = ((BigDecimal)parameterAsNum).setScale(scale, 4);
/* 3546 */             } catch (ArithmeticException arEx) {
/* 3547 */               throw SQLError.createSQLException("Can't set scale of '" + scale + "' for DECIMAL argument '" + parameterAsNum + "'", "S1009", getExceptionInterceptor());
/*      */             } 
/*      */           } 
/*      */ 
/*      */           
/* 3552 */           setBigDecimal(parameterIndex, scaledBigDecimal); break;
/* 3553 */         }  if (parameterAsNum instanceof BigInteger) {
/* 3554 */           setBigDecimal(parameterIndex, new BigDecimal((BigInteger)parameterAsNum, scale)); break;
/*      */         } 
/* 3556 */         setBigDecimal(parameterIndex, new BigDecimal(parameterAsNum.doubleValue()));
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(int parameterIndex, Object parameterObj) throws SQLException {
/* 3564 */     synchronized (checkClosed().getConnectionMutex()) {
/* 3565 */       if (parameterObj == null) {
/* 3566 */         setNull(parameterIndex, 1111);
/*      */       }
/* 3568 */       else if (parameterObj instanceof Byte) {
/* 3569 */         setInt(parameterIndex, ((Byte)parameterObj).intValue());
/* 3570 */       } else if (parameterObj instanceof String) {
/* 3571 */         setString(parameterIndex, (String)parameterObj);
/* 3572 */       } else if (parameterObj instanceof BigDecimal) {
/* 3573 */         setBigDecimal(parameterIndex, (BigDecimal)parameterObj);
/* 3574 */       } else if (parameterObj instanceof Short) {
/* 3575 */         setShort(parameterIndex, ((Short)parameterObj).shortValue());
/* 3576 */       } else if (parameterObj instanceof Integer) {
/* 3577 */         setInt(parameterIndex, ((Integer)parameterObj).intValue());
/* 3578 */       } else if (parameterObj instanceof Long) {
/* 3579 */         setLong(parameterIndex, ((Long)parameterObj).longValue());
/* 3580 */       } else if (parameterObj instanceof Float) {
/* 3581 */         setFloat(parameterIndex, ((Float)parameterObj).floatValue());
/* 3582 */       } else if (parameterObj instanceof Double) {
/* 3583 */         setDouble(parameterIndex, ((Double)parameterObj).doubleValue());
/* 3584 */       } else if (parameterObj instanceof byte[]) {
/* 3585 */         setBytes(parameterIndex, (byte[])parameterObj);
/* 3586 */       } else if (parameterObj instanceof Date) {
/* 3587 */         setDate(parameterIndex, (Date)parameterObj);
/* 3588 */       } else if (parameterObj instanceof Time) {
/* 3589 */         setTime(parameterIndex, (Time)parameterObj);
/* 3590 */       } else if (parameterObj instanceof Timestamp) {
/* 3591 */         setTimestamp(parameterIndex, (Timestamp)parameterObj);
/* 3592 */       } else if (parameterObj instanceof Boolean) {
/* 3593 */         setBoolean(parameterIndex, ((Boolean)parameterObj).booleanValue());
/* 3594 */       } else if (parameterObj instanceof InputStream) {
/* 3595 */         setBinaryStream(parameterIndex, (InputStream)parameterObj, -1);
/* 3596 */       } else if (parameterObj instanceof Blob) {
/* 3597 */         setBlob(parameterIndex, (Blob)parameterObj);
/* 3598 */       } else if (parameterObj instanceof Clob) {
/* 3599 */         setClob(parameterIndex, (Clob)parameterObj);
/* 3600 */       } else if (this.connection.getTreatUtilDateAsTimestamp() && parameterObj instanceof Date) {
/* 3601 */         setTimestamp(parameterIndex, new Timestamp(((Date)parameterObj).getTime()));
/* 3602 */       } else if (parameterObj instanceof BigInteger) {
/* 3603 */         setString(parameterIndex, parameterObj.toString());
/*      */       } else {
/* 3605 */         setSerializableObject(parameterIndex, parameterObj);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(int parameterIndex, Object parameterObj, int targetSqlType) throws SQLException {
/* 3619 */     if (!(parameterObj instanceof BigDecimal)) {
/* 3620 */       setObject(parameterIndex, parameterObj, targetSqlType, 0);
/*      */     } else {
/* 3622 */       setObject(parameterIndex, parameterObj, targetSqlType, ((BigDecimal)parameterObj).scale());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(int parameterIndex, Object parameterObj, int targetSqlType, int scale) throws SQLException {
/* 3654 */     synchronized (checkClosed().getConnectionMutex()) {
/* 3655 */       if (parameterObj == null) {
/* 3656 */         setNull(parameterIndex, 1111);
/*      */       } else {
/*      */         try {
/*      */           Date parameterAsDate;
/*      */ 
/*      */           
/* 3662 */           switch (targetSqlType) {
/*      */             
/*      */             case 16:
/* 3665 */               if (parameterObj instanceof Boolean) {
/* 3666 */                 setBoolean(parameterIndex, ((Boolean)parameterObj).booleanValue());
/*      */                 break;
/*      */               } 
/* 3669 */               if (parameterObj instanceof String) {
/* 3670 */                 setBoolean(parameterIndex, ("true".equalsIgnoreCase((String)parameterObj) || !"0".equalsIgnoreCase((String)parameterObj)));
/*      */                 break;
/*      */               } 
/* 3673 */               if (parameterObj instanceof Number) {
/* 3674 */                 int intValue = ((Number)parameterObj).intValue();
/*      */                 
/* 3676 */                 setBoolean(parameterIndex, (intValue != 0));
/*      */                 
/*      */                 break;
/*      */               } 
/* 3680 */               throw SQLError.createSQLException("No conversion from " + parameterObj.getClass().getName() + " to Types.BOOLEAN possible.", "S1009", getExceptionInterceptor());
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             case -7:
/*      */             case -6:
/*      */             case -5:
/*      */             case 2:
/*      */             case 3:
/*      */             case 4:
/*      */             case 5:
/*      */             case 6:
/*      */             case 7:
/*      */             case 8:
/* 3695 */               setNumericObject(parameterIndex, parameterObj, targetSqlType, scale);
/*      */               break;
/*      */ 
/*      */             
/*      */             case -1:
/*      */             case 1:
/*      */             case 12:
/* 3702 */               if (parameterObj instanceof BigDecimal) {
/* 3703 */                 setString(parameterIndex, StringUtils.fixDecimalExponent(StringUtils.consistentToString((BigDecimal)parameterObj))); break;
/*      */               } 
/* 3705 */               setString(parameterIndex, parameterObj.toString());
/*      */               break;
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             case 2005:
/* 3712 */               if (parameterObj instanceof Clob) {
/* 3713 */                 setClob(parameterIndex, (Clob)parameterObj); break;
/*      */               } 
/* 3715 */               setString(parameterIndex, parameterObj.toString());
/*      */               break;
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             case -4:
/*      */             case -3:
/*      */             case -2:
/*      */             case 2004:
/* 3725 */               if (parameterObj instanceof byte[]) {
/* 3726 */                 setBytes(parameterIndex, (byte[])parameterObj); break;
/* 3727 */               }  if (parameterObj instanceof Blob) {
/* 3728 */                 setBlob(parameterIndex, (Blob)parameterObj); break;
/*      */               } 
/* 3730 */               setBytes(parameterIndex, StringUtils.getBytes(parameterObj.toString(), this.charConverter, this.charEncoding, this.connection.getServerCharset(), this.connection.parserKnowsUnicode(), getExceptionInterceptor()));
/*      */               break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             case 91:
/*      */             case 93:
/* 3741 */               if (parameterObj instanceof String) {
/* 3742 */                 ParsePosition pp = new ParsePosition(0);
/*      */                 
/* 3744 */                 DateFormat sdf = TimeUtil.getSimpleDateFormat(null, getDateTimePattern((String)parameterObj, false), null, null);
/* 3745 */                 parameterAsDate = sdf.parse((String)parameterObj, pp);
/*      */               } else {
/* 3747 */                 parameterAsDate = (Date)parameterObj;
/*      */               } 
/*      */               
/* 3750 */               switch (targetSqlType) {
/*      */                 
/*      */                 case 91:
/* 3753 */                   if (parameterAsDate instanceof Date) {
/* 3754 */                     setDate(parameterIndex, (Date)parameterAsDate); break;
/*      */                   } 
/* 3756 */                   setDate(parameterIndex, new Date(parameterAsDate.getTime()));
/*      */                   break;
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 case 93:
/* 3763 */                   if (parameterAsDate instanceof Timestamp) {
/* 3764 */                     setTimestamp(parameterIndex, (Timestamp)parameterAsDate); break;
/*      */                   } 
/* 3766 */                   setTimestamp(parameterIndex, new Timestamp(parameterAsDate.getTime()));
/*      */                   break;
/*      */               } 
/*      */ 
/*      */ 
/*      */               
/*      */               break;
/*      */ 
/*      */             
/*      */             case 92:
/* 3776 */               if (parameterObj instanceof String) {
/* 3777 */                 DateFormat sdf = TimeUtil.getSimpleDateFormat(null, getDateTimePattern((String)parameterObj, true), null, null);
/* 3778 */                 setTime(parameterIndex, new Time(sdf.parse((String)parameterObj).getTime())); break;
/* 3779 */               }  if (parameterObj instanceof Timestamp) {
/* 3780 */                 Timestamp xT = (Timestamp)parameterObj;
/* 3781 */                 setTime(parameterIndex, new Time(xT.getTime())); break;
/*      */               } 
/* 3783 */               setTime(parameterIndex, (Time)parameterObj);
/*      */               break;
/*      */ 
/*      */ 
/*      */             
/*      */             case 1111:
/* 3789 */               setSerializableObject(parameterIndex, parameterObj);
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 3794 */               throw SQLError.createSQLException(Messages.getString("PreparedStatement.16"), "S1000", getExceptionInterceptor());
/*      */           } 
/*      */         
/* 3797 */         } catch (Exception ex) {
/* 3798 */           if (ex instanceof SQLException) {
/* 3799 */             throw (SQLException)ex;
/*      */           }
/*      */           
/* 3802 */           SQLException sqlEx = SQLError.createSQLException(Messages.getString("PreparedStatement.17") + parameterObj.getClass().toString() + Messages.getString("PreparedStatement.18") + ex.getClass().getName() + Messages.getString("PreparedStatement.19") + ex.getMessage(), "S1000", getExceptionInterceptor());
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3807 */           sqlEx.initCause(ex);
/*      */           
/* 3809 */           throw sqlEx;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   protected int setOneBatchedParameterSet(PreparedStatement batchedStatement, int batchedParamIndex, Object paramSet) throws SQLException {
/* 3816 */     BatchParams paramArg = (BatchParams)paramSet;
/*      */     
/* 3818 */     boolean[] isNullBatch = paramArg.isNull;
/* 3819 */     boolean[] isStreamBatch = paramArg.isStream;
/*      */     
/* 3821 */     for (int j = 0; j < isNullBatch.length; j++) {
/* 3822 */       if (isNullBatch[j]) {
/* 3823 */         batchedStatement.setNull(batchedParamIndex++, 0);
/*      */       }
/* 3825 */       else if (isStreamBatch[j]) {
/* 3826 */         batchedStatement.setBinaryStream(batchedParamIndex++, paramArg.parameterStreams[j], paramArg.streamLengths[j]);
/*      */       } else {
/* 3828 */         ((PreparedStatement)batchedStatement).setBytesNoEscapeNoQuotes(batchedParamIndex++, paramArg.parameterStrings[j]);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 3833 */     return batchedParamIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRef(int i, Ref x) throws SQLException {
/* 3849 */     throw SQLError.createSQLFeatureNotSupportedException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void setSerializableObject(int parameterIndex, Object parameterObj) throws SQLException {
/*      */     try {
/* 3863 */       ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
/* 3864 */       ObjectOutputStream objectOut = new ObjectOutputStream(bytesOut);
/* 3865 */       objectOut.writeObject(parameterObj);
/* 3866 */       objectOut.flush();
/* 3867 */       objectOut.close();
/* 3868 */       bytesOut.flush();
/* 3869 */       bytesOut.close();
/*      */       
/* 3871 */       byte[] buf = bytesOut.toByteArray();
/* 3872 */       ByteArrayInputStream bytesIn = new ByteArrayInputStream(buf);
/* 3873 */       setBinaryStream(parameterIndex, bytesIn, buf.length);
/* 3874 */       this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = -2;
/* 3875 */     } catch (Exception ex) {
/* 3876 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString("PreparedStatement.54") + ex.getClass().getName(), "S1009", getExceptionInterceptor());
/*      */       
/* 3878 */       sqlEx.initCause(ex);
/*      */       
/* 3880 */       throw sqlEx;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setShort(int parameterIndex, short x) throws SQLException {
/* 3897 */     setInternal(parameterIndex, String.valueOf(x));
/*      */     
/* 3899 */     this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 5;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setString(int parameterIndex, String x) throws SQLException {
/* 3916 */     synchronized (checkClosed().getConnectionMutex()) {
/*      */       
/* 3918 */       if (x == null) {
/* 3919 */         setNull(parameterIndex, 1);
/*      */       } else {
/* 3921 */         checkClosed();
/*      */         
/* 3923 */         int stringLength = x.length();
/*      */         
/* 3925 */         if (this.connection.isNoBackslashEscapesSet()) {
/*      */ 
/*      */           
/* 3928 */           boolean needsHexEscape = isEscapeNeededForString(x, stringLength);
/*      */           
/* 3930 */           if (!needsHexEscape) {
/* 3931 */             byte[] arrayOfByte = null;
/*      */             
/* 3933 */             StringBuilder quotedString = new StringBuilder(x.length() + 2);
/* 3934 */             quotedString.append('\'');
/* 3935 */             quotedString.append(x);
/* 3936 */             quotedString.append('\'');
/*      */             
/* 3938 */             if (!this.isLoadDataQuery) {
/* 3939 */               arrayOfByte = StringUtils.getBytes(quotedString.toString(), this.charConverter, this.charEncoding, this.connection.getServerCharset(), this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */             }
/*      */             else {
/*      */               
/* 3943 */               arrayOfByte = StringUtils.getBytes(quotedString.toString());
/*      */             } 
/*      */             
/* 3946 */             setInternal(parameterIndex, arrayOfByte);
/*      */           } else {
/* 3948 */             byte[] arrayOfByte = null;
/*      */             
/* 3950 */             if (!this.isLoadDataQuery) {
/* 3951 */               arrayOfByte = StringUtils.getBytes(x, this.charConverter, this.charEncoding, this.connection.getServerCharset(), this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */             }
/*      */             else {
/*      */               
/* 3955 */               arrayOfByte = StringUtils.getBytes(x);
/*      */             } 
/*      */             
/* 3958 */             setBytes(parameterIndex, arrayOfByte);
/*      */           } 
/*      */           
/*      */           return;
/*      */         } 
/*      */         
/* 3964 */         String parameterAsString = x;
/* 3965 */         boolean needsQuoted = true;
/*      */         
/* 3967 */         if (this.isLoadDataQuery || isEscapeNeededForString(x, stringLength)) {
/* 3968 */           needsQuoted = false;
/*      */           
/* 3970 */           StringBuilder buf = new StringBuilder((int)(x.length() * 1.1D));
/*      */           
/* 3972 */           buf.append('\'');
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3978 */           for (int i = 0; i < stringLength; i++) {
/* 3979 */             char c = x.charAt(i);
/*      */             
/* 3981 */             switch (c) {
/*      */               case '\000':
/* 3983 */                 buf.append('\\');
/* 3984 */                 buf.append('0');
/*      */                 break;
/*      */ 
/*      */               
/*      */               case '\n':
/* 3989 */                 buf.append('\\');
/* 3990 */                 buf.append('n');
/*      */                 break;
/*      */ 
/*      */               
/*      */               case '\r':
/* 3995 */                 buf.append('\\');
/* 3996 */                 buf.append('r');
/*      */                 break;
/*      */ 
/*      */               
/*      */               case '\\':
/* 4001 */                 buf.append('\\');
/* 4002 */                 buf.append('\\');
/*      */                 break;
/*      */ 
/*      */               
/*      */               case '\'':
/* 4007 */                 buf.append('\\');
/* 4008 */                 buf.append('\'');
/*      */                 break;
/*      */ 
/*      */               
/*      */               case '"':
/* 4013 */                 if (this.usingAnsiMode) {
/* 4014 */                   buf.append('\\');
/*      */                 }
/*      */                 
/* 4017 */                 buf.append('"');
/*      */                 break;
/*      */ 
/*      */               
/*      */               case '\032':
/* 4022 */                 buf.append('\\');
/* 4023 */                 buf.append('Z');
/*      */                 break;
/*      */ 
/*      */ 
/*      */               
/*      */               case '¥':
/*      */               case '₩':
/* 4030 */                 if (this.charsetEncoder != null) {
/* 4031 */                   CharBuffer cbuf = CharBuffer.allocate(1);
/* 4032 */                   ByteBuffer bbuf = ByteBuffer.allocate(1);
/* 4033 */                   cbuf.put(c);
/* 4034 */                   cbuf.position(0);
/* 4035 */                   this.charsetEncoder.encode(cbuf, bbuf, true);
/* 4036 */                   if (bbuf.get(0) == 92) {
/* 4037 */                     buf.append('\\');
/*      */                   }
/*      */                 } 
/* 4040 */                 buf.append(c);
/*      */                 break;
/*      */               
/*      */               default:
/* 4044 */                 buf.append(c);
/*      */                 break;
/*      */             } 
/*      */           } 
/* 4048 */           buf.append('\'');
/*      */           
/* 4050 */           parameterAsString = buf.toString();
/*      */         } 
/*      */         
/* 4053 */         byte[] parameterAsBytes = null;
/*      */         
/* 4055 */         if (!this.isLoadDataQuery) {
/* 4056 */           if (needsQuoted) {
/* 4057 */             parameterAsBytes = StringUtils.getBytesWrapped(parameterAsString, '\'', '\'', this.charConverter, this.charEncoding, this.connection.getServerCharset(), this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */           } else {
/*      */             
/* 4060 */             parameterAsBytes = StringUtils.getBytes(parameterAsString, this.charConverter, this.charEncoding, this.connection.getServerCharset(), this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/* 4065 */           parameterAsBytes = StringUtils.getBytes(parameterAsString);
/*      */         } 
/*      */         
/* 4068 */         setInternal(parameterIndex, parameterAsBytes);
/*      */         
/* 4070 */         this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 12;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean isEscapeNeededForString(String x, int stringLength) {
/* 4076 */     boolean needsHexEscape = false;
/*      */     
/* 4078 */     for (int i = 0; i < stringLength; i++) {
/* 4079 */       char c = x.charAt(i);
/*      */       
/* 4081 */       switch (c) {
/*      */         
/*      */         case '\000':
/* 4084 */           needsHexEscape = true;
/*      */           break;
/*      */         
/*      */         case '\n':
/* 4088 */           needsHexEscape = true;
/*      */           break;
/*      */ 
/*      */         
/*      */         case '\r':
/* 4093 */           needsHexEscape = true;
/*      */           break;
/*      */         
/*      */         case '\\':
/* 4097 */           needsHexEscape = true;
/*      */           break;
/*      */ 
/*      */         
/*      */         case '\'':
/* 4102 */           needsHexEscape = true;
/*      */           break;
/*      */ 
/*      */         
/*      */         case '"':
/* 4107 */           needsHexEscape = true;
/*      */           break;
/*      */ 
/*      */         
/*      */         case '\032':
/* 4112 */           needsHexEscape = true;
/*      */           break;
/*      */       } 
/*      */       
/* 4116 */       if (needsHexEscape) {
/*      */         break;
/*      */       }
/*      */     } 
/* 4120 */     return needsHexEscape;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(int parameterIndex, Time x, Calendar cal) throws SQLException {
/* 4138 */     synchronized (checkClosed().getConnectionMutex()) {
/* 4139 */       setTimeInternal(parameterIndex, x, cal, cal.getTimeZone(), true);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(int parameterIndex, Time x) throws SQLException {
/* 4156 */     synchronized (checkClosed().getConnectionMutex()) {
/* 4157 */       setTimeInternal(parameterIndex, x, (Calendar)null, this.connection.getDefaultTimeZone(), false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setTimeInternal(int parameterIndex, Time x, Calendar targetCalendar, TimeZone tz, boolean rollForward) throws SQLException {
/* 4177 */     if (x == null) {
/* 4178 */       setNull(parameterIndex, 92);
/*      */     } else {
/* 4180 */       checkClosed();
/*      */       
/* 4182 */       if (!this.useLegacyDatetimeCode) {
/* 4183 */         newSetTimeInternal(parameterIndex, x, targetCalendar);
/*      */       } else {
/* 4185 */         Calendar sessionCalendar = getCalendarInstanceForSessionOrNew();
/*      */         
/* 4187 */         x = TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, x, tz, this.connection.getServerTimezoneTZ(), rollForward);
/*      */         
/* 4189 */         setInternal(parameterIndex, "'" + x.toString() + "'");
/*      */       } 
/*      */       
/* 4192 */       this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 92;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal) throws SQLException {
/* 4211 */     synchronized (checkClosed().getConnectionMutex()) {
/* 4212 */       int fractLen = -1;
/* 4213 */       if (!this.sendFractionalSeconds || !this.serverSupportsFracSecs) {
/* 4214 */         fractLen = 0;
/* 4215 */       } else if (this.parameterMetaData != null && parameterIndex <= this.parameterMetaData.metadata.fields.length && parameterIndex >= 0 && this.parameterMetaData.metadata.getField(parameterIndex).getDecimals() > 0) {
/*      */         
/* 4217 */         fractLen = this.parameterMetaData.metadata.getField(parameterIndex).getDecimals();
/*      */       } 
/*      */       
/* 4220 */       setTimestampInternal(parameterIndex, x, cal, cal.getTimeZone(), true, fractLen, this.connection.getUseSSPSCompatibleTimezoneShift());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(int parameterIndex, Timestamp x) throws SQLException {
/* 4237 */     synchronized (checkClosed().getConnectionMutex()) {
/* 4238 */       int fractLen = -1;
/* 4239 */       if (!this.sendFractionalSeconds || !this.serverSupportsFracSecs) {
/* 4240 */         fractLen = 0;
/* 4241 */       } else if (this.parameterMetaData != null && parameterIndex <= this.parameterMetaData.metadata.fields.length && parameterIndex >= 0) {
/* 4242 */         fractLen = this.parameterMetaData.metadata.getField(parameterIndex).getDecimals();
/*      */       } 
/*      */       
/* 4245 */       setTimestampInternal(parameterIndex, x, (Calendar)null, this.connection.getDefaultTimeZone(), false, fractLen, this.connection.getUseSSPSCompatibleTimezoneShift());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setTimestampInternal(int parameterIndex, Timestamp x, Calendar targetCalendar, TimeZone tz, boolean rollForward, int fractionalLength, boolean useSSPSCompatibleTimezoneShift) throws SQLException {
/* 4266 */     if (x == null) {
/* 4267 */       setNull(parameterIndex, 93);
/*      */     } else {
/* 4269 */       checkClosed();
/*      */       
/* 4271 */       x = (Timestamp)x.clone();
/*      */       
/* 4273 */       if (!this.serverSupportsFracSecs || (!this.sendFractionalSeconds && fractionalLength == 0)) {
/* 4274 */         x = TimeUtil.truncateFractionalSeconds(x);
/*      */       }
/*      */       
/* 4277 */       if (fractionalLength < 0)
/*      */       {
/* 4279 */         fractionalLength = 6;
/*      */       }
/*      */       
/* 4282 */       x = TimeUtil.adjustTimestampNanosPrecision(x, fractionalLength, !this.connection.isServerTruncatesFracSecs());
/*      */       
/* 4284 */       if (!this.useLegacyDatetimeCode) {
/* 4285 */         newSetTimestampInternal(parameterIndex, x, targetCalendar);
/*      */       } else {
/* 4287 */         Calendar sessionCalendar = this.connection.getUseJDBCCompliantTimezoneShift() ? this.connection.getUtcCalendar() : getCalendarInstanceForSessionOrNew();
/*      */ 
/*      */ 
/*      */         
/* 4291 */         sessionCalendar = TimeUtil.setProlepticIfNeeded(sessionCalendar, targetCalendar);
/*      */         
/* 4293 */         x = TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, x, tz, this.connection.getServerTimezoneTZ(), rollForward);
/*      */         
/* 4295 */         if (useSSPSCompatibleTimezoneShift) {
/* 4296 */           doSSPSCompatibleTimezoneShift(parameterIndex, x, fractionalLength, targetCalendar);
/*      */         } else {
/* 4298 */           synchronized (this) {
/*      */             
/* 4300 */             this.tsdf = TimeUtil.getSimpleDateFormat(this.tsdf, "''yyyy-MM-dd HH:mm:ss", null, null);
/*      */             
/* 4302 */             Calendar adjCal = TimeUtil.setProlepticIfNeeded(this.tsdf.getCalendar(), targetCalendar);
/* 4303 */             if (this.tsdf.getCalendar() != adjCal) {
/* 4304 */               this.tsdf.setCalendar(adjCal);
/*      */             }
/*      */             
/* 4307 */             StringBuffer buf = new StringBuffer();
/* 4308 */             buf.append(this.tsdf.format(x));
/*      */             
/* 4310 */             if (fractionalLength > 0) {
/* 4311 */               int nanos = x.getNanos();
/*      */               
/* 4313 */               if (nanos != 0) {
/* 4314 */                 buf.append('.');
/* 4315 */                 buf.append(TimeUtil.formatNanos(nanos, this.serverSupportsFracSecs, fractionalLength));
/*      */               } 
/*      */             } 
/*      */             
/* 4319 */             buf.append('\'');
/*      */             
/* 4321 */             setInternal(parameterIndex, buf.toString());
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 4327 */       this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 93;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void newSetTimestampInternal(int parameterIndex, Timestamp x, Calendar targetCalendar) throws SQLException {
/* 4332 */     synchronized (checkClosed().getConnectionMutex()) {
/* 4333 */       this.tsdf = TimeUtil.getSimpleDateFormat(this.tsdf, "''yyyy-MM-dd HH:mm:ss", targetCalendar, (targetCalendar != null) ? null : this.connection.getServerTimezoneTZ());
/*      */ 
/*      */       
/* 4336 */       StringBuffer buf = new StringBuffer();
/* 4337 */       buf.append(this.tsdf.format(x));
/* 4338 */       buf.append('.');
/* 4339 */       buf.append(TimeUtil.formatNanos(x.getNanos(), this.serverSupportsFracSecs, 6));
/* 4340 */       buf.append('\'');
/*      */       
/* 4342 */       setInternal(parameterIndex, buf.toString());
/*      */     } 
/*      */   }
/*      */   
/*      */   private void newSetTimeInternal(int parameterIndex, Time x, Calendar targetCalendar) throws SQLException {
/* 4347 */     synchronized (checkClosed().getConnectionMutex()) {
/* 4348 */       this.tdf = TimeUtil.getSimpleDateFormat(this.tdf, "''HH:mm:ss''", targetCalendar, (targetCalendar != null) ? null : this.connection.getServerTimezoneTZ());
/*      */ 
/*      */       
/* 4351 */       setInternal(parameterIndex, this.tdf.format(x));
/*      */     } 
/*      */   }
/*      */   
/*      */   private void newSetDateInternal(int parameterIndex, Date x, Calendar targetCalendar) throws SQLException {
/* 4356 */     synchronized (checkClosed().getConnectionMutex()) {
/* 4357 */       this.ddf = TimeUtil.getSimpleDateFormat(this.ddf, "''yyyy-MM-dd''", targetCalendar, (targetCalendar != null) ? null : (this.connection.getNoTimezoneConversionForDateType() ? this.connection.getDefaultTimeZone() : this.connection.getServerTimezoneTZ()));
/*      */ 
/*      */       
/* 4360 */       setInternal(parameterIndex, this.ddf.format(x));
/*      */     } 
/*      */   }
/*      */   
/*      */   private void doSSPSCompatibleTimezoneShift(int parameterIndex, Timestamp x, int fractionalLength, Calendar targetCalendar) throws SQLException {
/* 4365 */     synchronized (checkClosed().getConnectionMutex()) {
/* 4366 */       Calendar sessionCalendar2 = this.connection.getUseJDBCCompliantTimezoneShift() ? this.connection.getUtcCalendar() : getCalendarInstanceForSessionOrNew();
/*      */ 
/*      */ 
/*      */       
/* 4370 */       sessionCalendar2 = TimeUtil.setProlepticIfNeeded(sessionCalendar2, targetCalendar);
/*      */       
/* 4372 */       synchronized (sessionCalendar2) {
/* 4373 */         Date oldTime = sessionCalendar2.getTime();
/*      */         
/*      */         try {
/* 4376 */           sessionCalendar2.setTime(x);
/*      */           
/* 4378 */           int year = sessionCalendar2.get(1);
/* 4379 */           int month = sessionCalendar2.get(2) + 1;
/* 4380 */           int date = sessionCalendar2.get(5);
/*      */           
/* 4382 */           int hour = sessionCalendar2.get(11);
/* 4383 */           int minute = sessionCalendar2.get(12);
/* 4384 */           int seconds = sessionCalendar2.get(13);
/*      */           
/* 4386 */           StringBuilder tsBuf = new StringBuilder();
/*      */           
/* 4388 */           tsBuf.append('\'');
/* 4389 */           tsBuf.append(year);
/*      */           
/* 4391 */           tsBuf.append("-");
/*      */           
/* 4393 */           if (month < 10) {
/* 4394 */             tsBuf.append('0');
/*      */           }
/*      */           
/* 4397 */           tsBuf.append(month);
/*      */           
/* 4399 */           tsBuf.append('-');
/*      */           
/* 4401 */           if (date < 10) {
/* 4402 */             tsBuf.append('0');
/*      */           }
/*      */           
/* 4405 */           tsBuf.append(date);
/*      */           
/* 4407 */           tsBuf.append(' ');
/*      */           
/* 4409 */           if (hour < 10) {
/* 4410 */             tsBuf.append('0');
/*      */           }
/*      */           
/* 4413 */           tsBuf.append(hour);
/*      */           
/* 4415 */           tsBuf.append(':');
/*      */           
/* 4417 */           if (minute < 10) {
/* 4418 */             tsBuf.append('0');
/*      */           }
/*      */           
/* 4421 */           tsBuf.append(minute);
/*      */           
/* 4423 */           tsBuf.append(':');
/*      */           
/* 4425 */           if (seconds < 10) {
/* 4426 */             tsBuf.append('0');
/*      */           }
/*      */           
/* 4429 */           tsBuf.append(seconds);
/*      */           
/* 4431 */           tsBuf.append('.');
/* 4432 */           tsBuf.append(TimeUtil.formatNanos(x.getNanos(), this.serverSupportsFracSecs, fractionalLength));
/* 4433 */           tsBuf.append('\'');
/*      */           
/* 4435 */           setInternal(parameterIndex, tsBuf.toString());
/*      */         } finally {
/*      */           
/* 4438 */           sessionCalendar2.setTime(oldTime);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void setUnicodeStream(int parameterIndex, InputStream x, int length) throws SQLException {
/* 4469 */     if (x == null) {
/* 4470 */       setNull(parameterIndex, 12);
/*      */     } else {
/* 4472 */       setBinaryStream(parameterIndex, x, length);
/*      */       
/* 4474 */       this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 2005;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setURL(int parameterIndex, URL arg) throws SQLException {
/* 4482 */     if (arg != null) {
/* 4483 */       setString(parameterIndex, arg.toString());
/*      */       
/* 4485 */       this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 70;
/*      */     } else {
/* 4487 */       setNull(parameterIndex, 1);
/*      */     } 
/*      */   }
/*      */   
/*      */   private final void streamToBytes(Buffer packet, InputStream in, boolean escape, int streamLength, boolean useLength) throws SQLException {
/* 4492 */     synchronized (checkClosed().getConnectionMutex()) {
/*      */       try {
/* 4494 */         if (this.streamConvertBuf == null) {
/* 4495 */           this.streamConvertBuf = new byte[4096];
/*      */         }
/*      */         
/* 4498 */         String connectionEncoding = this.connection.getEncoding();
/*      */         
/* 4500 */         boolean hexEscape = false;
/*      */         
/*      */         try {
/* 4503 */           if (this.connection.isNoBackslashEscapesSet() || (this.connection.getUseUnicode() && connectionEncoding != null && CharsetMapping.isMultibyteCharset(connectionEncoding) && !this.connection.parserKnowsUnicode()))
/*      */           {
/* 4505 */             hexEscape = true;
/*      */           }
/* 4507 */         } catch (RuntimeException ex) {
/* 4508 */           SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", (ExceptionInterceptor)null);
/* 4509 */           sqlEx.initCause(ex);
/* 4510 */           throw sqlEx;
/*      */         } 
/*      */         
/* 4513 */         if (streamLength == -1) {
/* 4514 */           useLength = false;
/*      */         }
/*      */         
/* 4517 */         int bc = -1;
/*      */         
/* 4519 */         if (useLength) {
/* 4520 */           bc = readblock(in, this.streamConvertBuf, streamLength);
/*      */         } else {
/* 4522 */           bc = readblock(in, this.streamConvertBuf);
/*      */         } 
/*      */         
/* 4525 */         int lengthLeftToRead = streamLength - bc;
/*      */         
/* 4527 */         if (hexEscape) {
/* 4528 */           packet.writeStringNoNull("x");
/* 4529 */         } else if (this.connection.getIO().versionMeetsMinimum(4, 1, 0)) {
/* 4530 */           packet.writeStringNoNull("_binary");
/*      */         } 
/*      */         
/* 4533 */         if (escape) {
/* 4534 */           packet.writeByte((byte)39);
/*      */         }
/*      */         
/* 4537 */         while (bc > 0) {
/* 4538 */           if (hexEscape) {
/* 4539 */             hexEscapeBlock(this.streamConvertBuf, packet, bc);
/* 4540 */           } else if (escape) {
/* 4541 */             escapeblockFast(this.streamConvertBuf, packet, bc);
/*      */           } else {
/* 4543 */             packet.writeBytesNoNull(this.streamConvertBuf, 0, bc);
/*      */           } 
/*      */           
/* 4546 */           if (useLength) {
/* 4547 */             bc = readblock(in, this.streamConvertBuf, lengthLeftToRead);
/*      */             
/* 4549 */             if (bc > 0)
/* 4550 */               lengthLeftToRead -= bc; 
/*      */             continue;
/*      */           } 
/* 4553 */           bc = readblock(in, this.streamConvertBuf);
/*      */         } 
/*      */ 
/*      */         
/* 4557 */         if (escape) {
/* 4558 */           packet.writeByte((byte)39);
/*      */         }
/*      */       } finally {
/* 4561 */         if (this.connection.getAutoClosePStmtStreams()) {
/*      */           try {
/* 4563 */             in.close();
/* 4564 */           } catch (IOException ioEx) {}
/*      */ 
/*      */           
/* 4567 */           in = null;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private final byte[] streamToBytes(InputStream in, boolean escape, int streamLength, boolean useLength) throws SQLException {
/* 4574 */     synchronized (checkClosed().getConnectionMutex()) {
/* 4575 */       in.mark(2147483647);
/*      */       try {
/* 4577 */         if (this.streamConvertBuf == null) {
/* 4578 */           this.streamConvertBuf = new byte[4096];
/*      */         }
/* 4580 */         if (streamLength == -1) {
/* 4581 */           useLength = false;
/*      */         }
/*      */         
/* 4584 */         ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
/*      */         
/* 4586 */         int bc = -1;
/*      */         
/* 4588 */         if (useLength) {
/* 4589 */           bc = readblock(in, this.streamConvertBuf, streamLength);
/*      */         } else {
/* 4591 */           bc = readblock(in, this.streamConvertBuf);
/*      */         } 
/*      */         
/* 4594 */         int lengthLeftToRead = streamLength - bc;
/*      */         
/* 4596 */         if (escape) {
/* 4597 */           if (this.connection.versionMeetsMinimum(4, 1, 0)) {
/* 4598 */             bytesOut.write(95);
/* 4599 */             bytesOut.write(98);
/* 4600 */             bytesOut.write(105);
/* 4601 */             bytesOut.write(110);
/* 4602 */             bytesOut.write(97);
/* 4603 */             bytesOut.write(114);
/* 4604 */             bytesOut.write(121);
/*      */           } 
/*      */           
/* 4607 */           bytesOut.write(39);
/*      */         } 
/*      */         
/* 4610 */         while (bc > 0) {
/* 4611 */           if (escape) {
/* 4612 */             escapeblockFast(this.streamConvertBuf, bytesOut, bc);
/*      */           } else {
/* 4614 */             bytesOut.write(this.streamConvertBuf, 0, bc);
/*      */           } 
/*      */           
/* 4617 */           if (useLength) {
/* 4618 */             bc = readblock(in, this.streamConvertBuf, lengthLeftToRead);
/*      */             
/* 4620 */             if (bc > 0)
/* 4621 */               lengthLeftToRead -= bc; 
/*      */             continue;
/*      */           } 
/* 4624 */           bc = readblock(in, this.streamConvertBuf);
/*      */         } 
/*      */ 
/*      */         
/* 4628 */         if (escape) {
/* 4629 */           bytesOut.write(39);
/*      */         }
/*      */         
/* 4632 */         return bytesOut.toByteArray();
/*      */       } finally {
/*      */         try {
/* 4635 */           in.reset();
/* 4636 */         } catch (IOException e) {}
/*      */         
/* 4638 */         if (this.connection.getAutoClosePStmtStreams()) {
/*      */           try {
/* 4640 */             in.close();
/* 4641 */           } catch (IOException ioEx) {}
/*      */ 
/*      */           
/* 4644 */           in = null;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 4657 */     StringBuilder buf = new StringBuilder();
/* 4658 */     buf.append(super.toString());
/* 4659 */     buf.append(": ");
/*      */     
/*      */     try {
/* 4662 */       buf.append(asSql());
/* 4663 */     } catch (SQLException sqlEx) {
/* 4664 */       buf.append("EXCEPTION: " + sqlEx.toString());
/*      */     } 
/*      */     
/* 4667 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getParameterIndexOffset() {
/* 4677 */     return 0;
/*      */   }
/*      */   
/*      */   public void setAsciiStream(int parameterIndex, InputStream x) throws SQLException {
/* 4681 */     setAsciiStream(parameterIndex, x, -1);
/*      */   }
/*      */   
/*      */   public void setAsciiStream(int parameterIndex, InputStream x, long length) throws SQLException {
/* 4685 */     setAsciiStream(parameterIndex, x, (int)length);
/* 4686 */     this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 2005;
/*      */   }
/*      */   
/*      */   public void setBinaryStream(int parameterIndex, InputStream x) throws SQLException {
/* 4690 */     setBinaryStream(parameterIndex, x, -1);
/*      */   }
/*      */   
/*      */   public void setBinaryStream(int parameterIndex, InputStream x, long length) throws SQLException {
/* 4694 */     setBinaryStream(parameterIndex, x, (int)length);
/*      */   }
/*      */   
/*      */   public void setBlob(int parameterIndex, InputStream inputStream) throws SQLException {
/* 4698 */     setBinaryStream(parameterIndex, inputStream);
/*      */   }
/*      */   
/*      */   public void setCharacterStream(int parameterIndex, Reader reader) throws SQLException {
/* 4702 */     setCharacterStream(parameterIndex, reader, -1);
/*      */   }
/*      */   
/*      */   public void setCharacterStream(int parameterIndex, Reader reader, long length) throws SQLException {
/* 4706 */     setCharacterStream(parameterIndex, reader, (int)length);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setClob(int parameterIndex, Reader reader) throws SQLException {
/* 4711 */     setCharacterStream(parameterIndex, reader);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setClob(int parameterIndex, Reader reader, long length) throws SQLException {
/* 4716 */     setCharacterStream(parameterIndex, reader, length);
/*      */   }
/*      */   
/*      */   public void setNCharacterStream(int parameterIndex, Reader value) throws SQLException {
/* 4720 */     setNCharacterStream(parameterIndex, value, -1L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNString(int parameterIndex, String x) throws SQLException {
/* 4738 */     synchronized (checkClosed().getConnectionMutex()) {
/* 4739 */       if (this.charEncoding.equalsIgnoreCase("UTF-8") || this.charEncoding.equalsIgnoreCase("utf8")) {
/* 4740 */         setString(parameterIndex, x);
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/* 4745 */       if (x == null) {
/* 4746 */         setNull(parameterIndex, 1);
/*      */       } else {
/* 4748 */         int stringLength = x.length();
/*      */ 
/*      */ 
/*      */         
/* 4752 */         StringBuilder buf = new StringBuilder((int)(x.length() * 1.1D + 4.0D));
/* 4753 */         buf.append("_utf8");
/* 4754 */         buf.append('\'');
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4760 */         for (int i = 0; i < stringLength; i++) {
/* 4761 */           char c = x.charAt(i);
/*      */           
/* 4763 */           switch (c) {
/*      */             case '\000':
/* 4765 */               buf.append('\\');
/* 4766 */               buf.append('0');
/*      */               break;
/*      */ 
/*      */             
/*      */             case '\n':
/* 4771 */               buf.append('\\');
/* 4772 */               buf.append('n');
/*      */               break;
/*      */ 
/*      */             
/*      */             case '\r':
/* 4777 */               buf.append('\\');
/* 4778 */               buf.append('r');
/*      */               break;
/*      */ 
/*      */             
/*      */             case '\\':
/* 4783 */               buf.append('\\');
/* 4784 */               buf.append('\\');
/*      */               break;
/*      */ 
/*      */             
/*      */             case '\'':
/* 4789 */               buf.append('\\');
/* 4790 */               buf.append('\'');
/*      */               break;
/*      */ 
/*      */             
/*      */             case '"':
/* 4795 */               if (this.usingAnsiMode) {
/* 4796 */                 buf.append('\\');
/*      */               }
/*      */               
/* 4799 */               buf.append('"');
/*      */               break;
/*      */ 
/*      */             
/*      */             case '\032':
/* 4804 */               buf.append('\\');
/* 4805 */               buf.append('Z');
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 4810 */               buf.append(c);
/*      */               break;
/*      */           } 
/*      */         } 
/* 4814 */         buf.append('\'');
/*      */         
/* 4816 */         String parameterAsString = buf.toString();
/*      */         
/* 4818 */         byte[] parameterAsBytes = null;
/*      */         
/* 4820 */         if (!this.isLoadDataQuery) {
/* 4821 */           parameterAsBytes = StringUtils.getBytes(parameterAsString, this.connection.getCharsetConverter("UTF-8"), "UTF-8", this.connection.getServerCharset(), this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */         }
/*      */         else {
/*      */           
/* 4825 */           parameterAsBytes = StringUtils.getBytes(parameterAsString);
/*      */         } 
/*      */         
/* 4828 */         setInternal(parameterIndex, parameterAsBytes);
/*      */         
/* 4830 */         this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = -9;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNCharacterStream(int parameterIndex, Reader reader, long length) throws SQLException {
/* 4857 */     synchronized (checkClosed().getConnectionMutex()) {
/*      */       try {
/* 4859 */         if (reader == null) {
/* 4860 */           setNull(parameterIndex, -1);
/*      */         } else {
/*      */           
/* 4863 */           char[] c = null;
/* 4864 */           int len = 0;
/*      */           
/* 4866 */           boolean useLength = this.connection.getUseStreamLengthsInPrepStmts();
/*      */ 
/*      */ 
/*      */           
/* 4870 */           if (useLength && length != -1L) {
/* 4871 */             c = new char[(int)length];
/*      */             
/* 4873 */             int numCharsRead = readFully(reader, c, (int)length);
/* 4874 */             setNString(parameterIndex, new String(c, 0, numCharsRead));
/*      */           } else {
/*      */             
/* 4877 */             c = new char[4096];
/*      */             
/* 4879 */             StringBuilder buf = new StringBuilder();
/*      */             
/* 4881 */             while ((len = reader.read(c)) != -1) {
/* 4882 */               buf.append(c, 0, len);
/*      */             }
/*      */             
/* 4885 */             setNString(parameterIndex, buf.toString());
/*      */           } 
/*      */           
/* 4888 */           this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 2011;
/*      */         } 
/* 4890 */       } catch (IOException ioEx) {
/* 4891 */         throw SQLError.createSQLException(ioEx.toString(), "S1000", getExceptionInterceptor());
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setNClob(int parameterIndex, Reader reader) throws SQLException {
/* 4897 */     setNCharacterStream(parameterIndex, reader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNClob(int parameterIndex, Reader reader, long length) throws SQLException {
/* 4914 */     if (reader == null) {
/* 4915 */       setNull(parameterIndex, -1);
/*      */     } else {
/* 4917 */       setNCharacterStream(parameterIndex, reader, length);
/*      */     } 
/*      */   }
/*      */   
/*      */   public ParameterBindings getParameterBindings() throws SQLException {
/* 4922 */     synchronized (checkClosed().getConnectionMutex()) {
/* 4923 */       return new EmulatedPreparedStatementBindings();
/*      */     } 
/*      */   }
/*      */   
/*      */   class EmulatedPreparedStatementBindings
/*      */     implements ParameterBindings {
/*      */     private ResultSetImpl bindingsAsRs;
/*      */     private boolean[] parameterIsNull;
/*      */     
/*      */     EmulatedPreparedStatementBindings() throws SQLException {
/* 4933 */       List<ResultSetRow> rows = new ArrayList<ResultSetRow>();
/* 4934 */       this.parameterIsNull = new boolean[PreparedStatement.this.parameterCount];
/* 4935 */       System.arraycopy(PreparedStatement.this.isNull, 0, this.parameterIsNull, 0, PreparedStatement.this.parameterCount);
/* 4936 */       byte[][] rowData = new byte[PreparedStatement.this.parameterCount][];
/* 4937 */       Field[] typeMetadata = new Field[PreparedStatement.this.parameterCount];
/*      */       
/* 4939 */       for (int i = 0; i < PreparedStatement.this.parameterCount; i++) {
/* 4940 */         if (PreparedStatement.this.batchCommandIndex == -1) {
/* 4941 */           rowData[i] = PreparedStatement.this.getBytesRepresentation(i);
/*      */         } else {
/* 4943 */           rowData[i] = PreparedStatement.this.getBytesRepresentationForBatch(i, PreparedStatement.this.batchCommandIndex);
/*      */         } 
/*      */         
/* 4946 */         int charsetIndex = 0;
/*      */         
/* 4948 */         if (PreparedStatement.this.parameterTypes[i] == -2 || PreparedStatement.this.parameterTypes[i] == 2004) {
/* 4949 */           charsetIndex = 63;
/*      */         } else {
/*      */           try {
/* 4952 */             charsetIndex = CharsetMapping.getCollationIndexForJavaEncoding(PreparedStatement.this.connection.getEncoding(), PreparedStatement.this.connection);
/*      */           }
/* 4954 */           catch (SQLException ex) {
/* 4955 */             throw ex;
/* 4956 */           } catch (RuntimeException ex) {
/* 4957 */             SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", (ExceptionInterceptor)null);
/* 4958 */             sqlEx.initCause(ex);
/* 4959 */             throw sqlEx;
/*      */           } 
/*      */         } 
/*      */         
/* 4963 */         Field parameterMetadata = new Field(null, "parameter_" + (i + 1), charsetIndex, PreparedStatement.this.parameterTypes[i], (rowData[i]).length);
/* 4964 */         parameterMetadata.setConnection(PreparedStatement.this.connection);
/* 4965 */         typeMetadata[i] = parameterMetadata;
/*      */       } 
/*      */       
/* 4968 */       rows.add(new ByteArrayRow(rowData, PreparedStatement.this.getExceptionInterceptor()));
/*      */       
/* 4970 */       this.bindingsAsRs = new ResultSetImpl(PreparedStatement.this.connection.getCatalog(), typeMetadata, new RowDataStatic(rows), PreparedStatement.this.connection, null);
/*      */       
/* 4972 */       this.bindingsAsRs.next();
/*      */     }
/*      */     
/*      */     public Array getArray(int parameterIndex) throws SQLException {
/* 4976 */       return this.bindingsAsRs.getArray(parameterIndex);
/*      */     }
/*      */     
/*      */     public InputStream getAsciiStream(int parameterIndex) throws SQLException {
/* 4980 */       return this.bindingsAsRs.getAsciiStream(parameterIndex);
/*      */     }
/*      */     
/*      */     public BigDecimal getBigDecimal(int parameterIndex) throws SQLException {
/* 4984 */       return this.bindingsAsRs.getBigDecimal(parameterIndex);
/*      */     }
/*      */     
/*      */     public InputStream getBinaryStream(int parameterIndex) throws SQLException {
/* 4988 */       return this.bindingsAsRs.getBinaryStream(parameterIndex);
/*      */     }
/*      */     
/*      */     public Blob getBlob(int parameterIndex) throws SQLException {
/* 4992 */       return this.bindingsAsRs.getBlob(parameterIndex);
/*      */     }
/*      */     
/*      */     public boolean getBoolean(int parameterIndex) throws SQLException {
/* 4996 */       return this.bindingsAsRs.getBoolean(parameterIndex);
/*      */     }
/*      */     
/*      */     public byte getByte(int parameterIndex) throws SQLException {
/* 5000 */       return this.bindingsAsRs.getByte(parameterIndex);
/*      */     }
/*      */     
/*      */     public byte[] getBytes(int parameterIndex) throws SQLException {
/* 5004 */       return this.bindingsAsRs.getBytes(parameterIndex);
/*      */     }
/*      */     
/*      */     public Reader getCharacterStream(int parameterIndex) throws SQLException {
/* 5008 */       return this.bindingsAsRs.getCharacterStream(parameterIndex);
/*      */     }
/*      */     
/*      */     public Clob getClob(int parameterIndex) throws SQLException {
/* 5012 */       return this.bindingsAsRs.getClob(parameterIndex);
/*      */     }
/*      */     
/*      */     public Date getDate(int parameterIndex) throws SQLException {
/* 5016 */       return this.bindingsAsRs.getDate(parameterIndex);
/*      */     }
/*      */     
/*      */     public double getDouble(int parameterIndex) throws SQLException {
/* 5020 */       return this.bindingsAsRs.getDouble(parameterIndex);
/*      */     }
/*      */     
/*      */     public float getFloat(int parameterIndex) throws SQLException {
/* 5024 */       return this.bindingsAsRs.getFloat(parameterIndex);
/*      */     }
/*      */     
/*      */     public int getInt(int parameterIndex) throws SQLException {
/* 5028 */       return this.bindingsAsRs.getInt(parameterIndex);
/*      */     }
/*      */     
/*      */     public long getLong(int parameterIndex) throws SQLException {
/* 5032 */       return this.bindingsAsRs.getLong(parameterIndex);
/*      */     }
/*      */     
/*      */     public Reader getNCharacterStream(int parameterIndex) throws SQLException {
/* 5036 */       return this.bindingsAsRs.getCharacterStream(parameterIndex);
/*      */     }
/*      */     
/*      */     public Reader getNClob(int parameterIndex) throws SQLException {
/* 5040 */       return this.bindingsAsRs.getCharacterStream(parameterIndex);
/*      */     }
/*      */     
/*      */     public Object getObject(int parameterIndex) throws SQLException {
/* 5044 */       PreparedStatement.this.checkBounds(parameterIndex, 0);
/*      */       
/* 5046 */       if (this.parameterIsNull[parameterIndex - 1]) {
/* 5047 */         return null;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 5052 */       switch (PreparedStatement.this.parameterTypes[parameterIndex - 1]) {
/*      */         case -6:
/* 5054 */           return Byte.valueOf(getByte(parameterIndex));
/*      */         case 5:
/* 5056 */           return Short.valueOf(getShort(parameterIndex));
/*      */         case 4:
/* 5058 */           return Integer.valueOf(getInt(parameterIndex));
/*      */         case -5:
/* 5060 */           return Long.valueOf(getLong(parameterIndex));
/*      */         case 6:
/* 5062 */           return Float.valueOf(getFloat(parameterIndex));
/*      */         case 8:
/* 5064 */           return Double.valueOf(getDouble(parameterIndex));
/*      */       } 
/* 5066 */       return this.bindingsAsRs.getObject(parameterIndex);
/*      */     }
/*      */ 
/*      */     
/*      */     public Ref getRef(int parameterIndex) throws SQLException {
/* 5071 */       return this.bindingsAsRs.getRef(parameterIndex);
/*      */     }
/*      */     
/*      */     public short getShort(int parameterIndex) throws SQLException {
/* 5075 */       return this.bindingsAsRs.getShort(parameterIndex);
/*      */     }
/*      */     
/*      */     public String getString(int parameterIndex) throws SQLException {
/* 5079 */       return this.bindingsAsRs.getString(parameterIndex);
/*      */     }
/*      */     
/*      */     public Time getTime(int parameterIndex) throws SQLException {
/* 5083 */       return this.bindingsAsRs.getTime(parameterIndex);
/*      */     }
/*      */     
/*      */     public Timestamp getTimestamp(int parameterIndex) throws SQLException {
/* 5087 */       return this.bindingsAsRs.getTimestamp(parameterIndex);
/*      */     }
/*      */     
/*      */     public URL getURL(int parameterIndex) throws SQLException {
/* 5091 */       return this.bindingsAsRs.getURL(parameterIndex);
/*      */     }
/*      */     
/*      */     public boolean isNull(int parameterIndex) throws SQLException {
/* 5095 */       PreparedStatement.this.checkBounds(parameterIndex, 0);
/*      */       
/* 5097 */       return this.parameterIsNull[parameterIndex - 1];
/*      */     }
/*      */   }
/*      */   
/*      */   public String getPreparedSql() {
/*      */     try {
/* 5103 */       synchronized (checkClosed().getConnectionMutex()) {
/* 5104 */         if (this.rewrittenBatchSize == 0) {
/* 5105 */           return this.originalSql;
/*      */         }
/*      */         
/*      */         try {
/* 5109 */           return this.parseInfo.getSqlForBatch(this.parseInfo);
/* 5110 */         } catch (UnsupportedEncodingException e) {
/* 5111 */           throw new RuntimeException(e);
/*      */         } 
/*      */       } 
/* 5114 */     } catch (SQLException e) {
/* 5115 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public int getUpdateCount() throws SQLException {
/* 5121 */     int count = super.getUpdateCount();
/*      */     
/* 5123 */     if (containsOnDuplicateKeyUpdateInSQL() && this.compensateForOnDuplicateKeyUpdate && (
/* 5124 */       count == 2 || count == 0)) {
/* 5125 */       count = 1;
/*      */     }
/*      */ 
/*      */     
/* 5129 */     return count;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static boolean canRewrite(String sql, boolean isOnDuplicateKeyUpdate, int locationOfOnDuplicateKeyUpdate, int statementStartPos) {
/* 5136 */     if (StringUtils.startsWithIgnoreCaseAndWs(sql, "INSERT", statementStartPos)) {
/* 5137 */       if (StringUtils.indexOfIgnoreCase(statementStartPos, sql, "SELECT", "\"'`", "\"'`", StringUtils.SEARCH_MODE__MRK_COM_WS) != -1) {
/* 5138 */         return false;
/*      */       }
/* 5140 */       if (isOnDuplicateKeyUpdate) {
/* 5141 */         int updateClausePos = StringUtils.indexOfIgnoreCase(locationOfOnDuplicateKeyUpdate, sql, " UPDATE ");
/* 5142 */         if (updateClausePos != -1) {
/* 5143 */           return (StringUtils.indexOfIgnoreCase(updateClausePos, sql, "LAST_INSERT_ID", "\"'`", "\"'`", StringUtils.SEARCH_MODE__MRK_COM_WS) == -1);
/*      */         }
/*      */       } 
/* 5146 */       return true;
/*      */     } 
/*      */     
/* 5149 */     return (StringUtils.startsWithIgnoreCaseAndWs(sql, "REPLACE", statementStartPos) && StringUtils.indexOfIgnoreCase(statementStartPos, sql, "SELECT", "\"'`", "\"'`", StringUtils.SEARCH_MODE__MRK_COM_WS) == -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long executeLargeUpdate() throws SQLException {
/* 5158 */     return executeUpdateInternal(true, false);
/*      */   }
/*      */ }


/* Location:              C:\Users\neons\Desktop\JacobAloSchedulingApp\build\classes\!\lib\mysql-connector-java-5.1.47.jar!\com\mysql\jdbc\PreparedStatement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */
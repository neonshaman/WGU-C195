/*    */ package com.mysql.fabric;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ServerRole
/*    */ {
/* 30 */   FAULTY, SPARE, SECONDARY, PRIMARY, CONFIGURING;
/*    */   
/*    */   public static ServerRole getFromConstant(Integer constant) {
/* 33 */     return values()[constant.intValue()];
/*    */   }
/*    */ }


/* Location:              C:\Users\neons\Desktop\JacobAloSchedulingApp\build\classes\!\lib\mysql-connector-java-5.1.47.jar!\com\mysql\fabric\ServerRole.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */